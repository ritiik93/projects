<?php

session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}




$search_results = array();
$keyword = '';
if (isset($_GET['keyword']) || isset($_GET['search'])) {
    $keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
    if (!empty($keyword)) {
        $search_query = $obj->search_product($keyword);
        if ($search_query) {
            while ($search = mysqli_fetch_assoc($search_query)) {
                $search_results[] = $search;
            }
        }
    } else {
        header('location:all_product.php');
        exit;
    }
}




?>


<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->

    <?php
    include_once("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once("includes/header_top.php");
        ?>

        <?php
        include_once("includes/header_middle.php");
        ?>

        <?php
        include_once("includes/header_bottom.php");
        ?>

    </header>

    <!-- Page Contain -->
    <div class="page-contain">

        <!-- Main content -->
        <div id="main-content" class="main-content">

            <!-- Hero Banner -->
            <div class="postic-hero-banner">
                <div class="container">
                    <h1>Search Results</h1>
                    <p>
                        <?php 
                            $search_item = count($search_results);
                            echo "Found <strong>{$search_item}</strong> " . ($search_item === 1 ? 'flavor' : 'flavors') . (!empty($keyword) ? " for \"<strong>" . htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8') . "</strong>\"" : "");
                        ?>
                    </p>
                </div>
            </div>

            <!-- Product Grid -->
            <div class="container" style="padding-bottom: 40px;">
                <div class="product-category grid-style">
                    <div class="row">
                        <ul class="products-list">
                            <?php
                            if (empty($search_results)) {
                            ?>
                                <li class="col-xs-12" style="width: 100%; display: block;">
                                    <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 50px 20px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.04); max-width: 500px; margin: 30px auto;">
                                        <i class="fa fa-search" style="font-size: 48px; color: #cbd5e1; margin-bottom: 16px;"></i>
                                        <h3 style="font-size: 20px; font-weight: 700; color: #1e293b; margin-bottom: 8px;">No Makhana Found</h3>
                                        <p style="color: #64748b; font-size: 14px; margin-bottom: 22px;">We couldn't find any flavors matching "<strong><?php echo htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8'); ?></strong>". Try searching for Cheese, Lemon, Coriander or Onion.</p>
                                        <a href="all_product.php" class="btn btn-bold" style="background: #d32f2f; color: #fff; padding: 10px 24px; border-radius: 25px; text-decoration: none; font-weight: 700; display: inline-block;">
                                            Explore All Flavors &rarr;
                                        </a>
                                    </div>
                                </li>
                            <?php
                            } else {
                                foreach ($search_results as $search_pdt) {
                                    $is_out_of_stock = isset($search_pdt['product_stock']) && (int)$search_pdt['product_stock'] <= 0;
                            ?>
                                <li class="product-item col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb">
                                            <a href="single_product.php?status=singleproduct&id=<?php echo $search_pdt['pdt_id'] ?>" class="link-to-product">
                                                <img src="admin/uploads/<?php echo $search_pdt['pdt_img'] ?>" alt="<?php echo htmlspecialchars($search_pdt['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>" class="product-thumnail">
                                            </a>
                                            <?php if ($is_out_of_stock) { ?>
                                                <div class="labels" style="position: absolute; top: 10px; left: 10px;">
                                                    <span class="sale-label" style="background: #d32f2f; color: #fff; font-size: 11px; padding: 3px 8px; border-radius: 12px; font-weight: 700;">Sold Out</span>
                                                </div>
                                            <?php } ?>
                                        </div>
                                        <div class="info">
                                            <b class="categories"><?php echo htmlspecialchars($search_pdt['ctg_name'], ENT_QUOTES, 'UTF-8'); ?></b>
                                            <h4 class="product-title">
                                                <a href="single_product.php?status=singleproduct&id=<?php echo $search_pdt['pdt_id'] ?>" class="pr-name">
                                                    <?php echo htmlspecialchars($search_pdt['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>
                                                </a>
                                            </h4>
                                            <div class="price">
                                                <ins><span class="price-amount"><span class="currencySymbol">₹ </span><?php echo $search_pdt['pdt_price'] ?></span></ins>
                                            </div>
                                            <a href="single_product.php?status=singleproduct&id=<?php echo $search_pdt['pdt_id'] ?>" class="postic-btn-detail">
                                                View Details
                                            </a>
                                        </div>
                                    </div>
                                </li>
                            <?php 
                                }
                            } 
                            ?>
                        </ul>
                    </div>

                    <?php if (count($search_results) > 12) { ?>
                    <div class="biolife-panigations-block text-center" style="margin-top: 20px;">
                        <ul class="panigation-contain">
                            <li><span class="current-page">1</span></li>
                        </ul>
                    </div>
                    <?php } ?>
                </div>





            </div>
        </div>
    </div>

    <!-- FOOTER -->

    <?php
    include_once("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>
