<?php

session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}

$logo_info = $obj->display_logo();
$logo = $logo_info ? mysqli_fetch_assoc($logo_info) : null;
$logo_img = $logo ? $logo['img'] : 'logo.png';

if (isset($_SESSION['user_id'])) {
    header("location:userprofile.php");
    exit();
}

$update_id = 0;
if (isset($_GET['status']) && $_GET['status'] == 'update' && isset($_GET['id'])) {
    $update_id = (int) $_GET['id'];
}

if(isset($_POST['u_pass_recover'])){
    $update_msg = $obj->update_user_password($_POST);
}
?>

<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->
    <?php include_once("includes/preloader.php"); ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">
        <?php include_once("includes/header_top.php"); ?>
        <?php include_once("includes/header_middle.php"); ?>
        <?php include_once("includes/header_bottom.php"); ?>
    </header>

    <!-- Centered Clean D2C Auth Card Section -->
    <div class="postic-auth-page">
        <div class="postic-auth-box">
            <div class="postic-auth-card-clean">
                
                <!-- Logo & Brand Header -->
                <div class="postic-auth-top">
                    <a href="index.php">
                        <img src="admin/uploads/<?php echo htmlspecialchars($logo_img); ?>" alt="Postic Foods" class="postic-auth-logo">
                    </a>
                    <span class="postic-auth-brand-tag">100% Roasted Superfoods &bull; Udaipur</span>
                    
                    <h3 style="font-size: 20px; font-weight: 800; color: #1e293b; margin: 15px 0 6px 0;">Create New Password</h3>
                    <p style="font-size: 13px; color: #64748b; margin: 0 0 15px 0; line-height: 1.5;">
                        Please enter a strong new password for your Postic customer account.
                    </p>
                </div>

                <!-- Notification -->
                <?php if (!empty($update_msg)) { 
                    $is_success = (stripos($update_msg, 'success') !== false || stripos($update_msg, 'updated') !== false);
                    $alert_bg = $is_success ? '#ecfdf5' : '#fef2f2';
                    $alert_border = $is_success ? '#a7f3d0' : '#fecaca';
                    $alert_color = $is_success ? '#065f46' : '#991b1b';
                    $alert_icon = $is_success ? 'fa-check-circle' : 'fa-exclamation-circle';
                ?>
                    <div class="alert alert-dismissible" role="alert" style="border-radius: 10px; background: <?php echo $alert_bg; ?>; border: 1px solid <?php echo $alert_border; ?>; color: <?php echo $alert_color; ?>; font-size: 13px; padding: 12px 14px; margin-bottom: 20px;">
                        <i class="fa <?php echo $alert_icon; ?>" style="margin-right: 6px;"></i>
                        <?php echo htmlspecialchars($update_msg, ENT_QUOTES, 'UTF-8'); ?>
                        <button type="button" class="close" data-dismiss="alert" style="color: <?php echo $alert_color; ?>;">&times;</button>
                    </div>
                <?php } ?>

                <!-- Form -->
                <form action="" name="frm-update" method="POST" autocomplete="off">
                    <input type="hidden" name="update_user_id" value="<?php echo (int) $update_id; ?>">

                    <div class="postic-form-group">
                        <label class="postic-form-label" for="update_user_password">
                            New Password <span class="req">*</span>
                        </label>
                        <div class="postic-password-wrapper">
                            <input type="password" id="update_user_password" name="update_user_password" class="postic-form-input" placeholder="Enter new password (min. 6 chars)" minlength="6" required autofocus>
                            <button type="button" class="postic-pwd-toggle" id="toggleUpdatePwd" aria-label="Toggle password visibility">
                                <i class="fa fa-eye" id="toggleUpdateIcon"></i>
                            </button>
                        </div>
                    </div>

                    <button type="submit" name="u_pass_recover" class="postic-submit-btn">
                        Set New Password &rarr;
                    </button>
                </form>

                <div style="text-align: center; margin-top: 20px; padding-top: 15px; border-top: 1px solid #f1f5f9; font-size: 13px;">
                    <span style="color: #64748b;">Ready to sign in?</span>
                    <a href="user_login.php" style="color: #d32f2f; font-weight: 700; text-decoration: none; margin-left: 4px;">Go to Login &rarr;</a>
                </div>

                <!-- Footer Trust Strip -->
                <div class="postic-auth-footer-trust">
                    <span><i class="fa fa-shield"></i> 256-Bit SSL Secure</span>
                    <span><i class="fa fa-leaf"></i> 100% Roasted</span>
                    <span><i class="fa fa-truck"></i> Fast Delivery</span>
                </div>

            </div>
        </div>
    </div>

    <!-- Eye Toggle Script -->
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        var btn = document.getElementById("toggleUpdatePwd");
        var input = document.getElementById("update_user_password");
        var icon = document.getElementById("toggleUpdateIcon");
        if (btn && input && icon) {
            btn.addEventListener("click", function() {
                if (input.type === "password") {
                    input.type = "text";
                    icon.className = "fa fa-eye-slash";
                } else {
                    input.type = "password";
                    icon.className = "fa fa-eye";
                }
            });
        }
    });
    </script>

    <!-- FOOTER -->

    <?php
    include_once("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>