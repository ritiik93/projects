<?php 

session_start();
include_once ("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj-> p_display_catagory();
$cataDatas = array();
if ($cata_info) {
    while($data = mysqli_fetch_assoc($cata_info)){
        $cataDatas[]=$data;
    }
}
?>

<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->
    <?php
    include_once("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once("includes/header_top.php");
        ?>

        <?php
        include_once("includes/header_middle.php");
        ?>

        <?php
        include_once("includes/header_bottom.php");
        ?>

    </header>

    <!-- Page Contain -->
    <div class="page-contain">

        <!-- Main content -->
        <div id="main-content" class="main-content">

            <!-- Block 01: High-Res Creative Hero Banner Slider (No Clashing Text) -->
            <?php
            include_once("includes/slider_main.php");
            ?>

            <!-- Block 02: D2C Flavor Quick Navigation Pills (Warm Cream & Postic Red) -->
            <?php
            include_once("includes/home_flavor_strip.php");
            ?>

            <!-- Block 03: Master Product Collection (Filter Tabs, Direct Add-to-Cart, WhatsApp Order) -->
            <?php
            include_once("includes/home_related_product.php");
            ?>

            <!-- Block 04: The Postic Standard / 4 Quality & Craft Pillars -->
            <?php
            include_once("includes/home_highlights_strip.php");
            ?>

            <!-- Block 05: Roastery Heritage & Story (Udaipur Craft) -->
            <?php
            include_once("includes/home_story_section.php");
            ?>

            <!-- Block 06: Verified Customer Love & Social Proof -->
            <?php
            include_once("includes/home_testimonials.php");
            ?>

            <!-- Block 07: Wholesale & Distribution Partner Desk -->
            <?php
            include_once("includes/home_partner_contact.php");
            ?>

        </div>
    </div>

    <!-- FOOTER -->
    <?php
    include_once("includes/footer.php");
    ?>

    <!-- Footer For Mobile -->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>

    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>