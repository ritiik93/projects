<?php
header('Content-Type: application/json');

include_once("../admin/class/adminback.php");

$obj = new adminback();
$response = array(
    'discount_amount' => 0,
    'discount_percent' => 0,
    'coupon_code' => '',
    'is_valid' => false,
);

if (isset($_POST['action']) && $_POST['action'] == 'load_discount') {
    $coupon_code = '';
    if (isset($_POST['coupon'])) {
        $coupon_code = $_POST['coupon'];
    } elseif (isset($_POST['cupon'])) {
        $coupon_code = $_POST['cupon'];
    }

    $price = isset($_POST['price']) ? (int) $_POST['price'] : 0;
    if ($price < 0) {
        $price = 0;
    }

    $coupon = $obj->get_coupon_by_code($coupon_code);
    if ($coupon) {
        $discount_percent = (int) $coupon['discount'];
        $discount_amount = (int) round(($price * $discount_percent) / 100);

        $response['discount_amount'] = $discount_amount;
        $response['discount_percent'] = $discount_percent;
        $response['coupon_code'] = $coupon['cupon_code'];
        $response['is_valid'] = true;
    }
}

echo json_encode($response);
?>
