<?php
header('Content-Type: application/json; charset=utf-8');

include_once("../admin/class/adminback.php");
$obj = new adminback();

$query_text = '';
if (isset($_GET['query'])) {
    $query_text = trim($_GET['query']);
} elseif (isset($_GET['keyword'])) {
    $query_text = trim($_GET['keyword']);
} elseif (isset($_POST['query'])) {
    $query_text = trim($_POST['query']);
}

$results = array();

if ($query_text !== '' && strlen($query_text) >= 1) {
    $search_res = $obj->live_search_product($query_text, 6);
    if ($search_res) {
        while ($row = mysqli_fetch_assoc($search_res)) {
            $results[] = array(
                'id'       => (int) $row['pdt_id'],
                'name'     => trim($row['pdt_name']),
                'price'    => (int) $row['pdt_price'],
                'img'      => !empty($row['pdt_img']) ? $row['pdt_img'] : 'default.png',
                'category' => isset($row['ctg_name']) ? trim($row['ctg_name']) : 'Makhana',
                'url'      => 'single_product.php?status=singleproduct&&id=' . (int)$row['pdt_id']
            );
        }
    }
}

echo json_encode(array(
    'status' => 'success',
    'query'  => $query_text,
    'count'  => count($results),
    'data'   => $results
), JSON_UNESCAPED_SLASHES);
?>
