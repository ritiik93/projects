<?php
session_start();
header('Content-Type: application/json');

include_once("admin/class/adminback.php");

$obj = new adminback();
$config = include("config/razorpay.php");

function payment_json_response($data, $status_code = 200)
{
    http_response_code($status_code);
    echo json_encode($data);
    exit();
}

function calculate_checkout_amount($cart, $coupon_code, $obj)
{
    $subtotal = 0;
    foreach ($cart as $item) {
        $price = isset($item['pdt_price']) ? (int) $item['pdt_price'] : 0;
        $quantity = isset($item['quantity']) ? (int) $item['quantity'] : 1;
        if ($quantity < 1) {
            $quantity = 1;
        }
        if ($quantity > 10) {
            $quantity = 10;
        }
        $subtotal += $price * $quantity;
    }

    $discount = 0;
    $coupon = $obj->get_coupon_by_code($coupon_code);
    if ($coupon) {
        $discount = (int) round(($subtotal * (int) $coupon['discount']) / 100);
    }

    $amount = $subtotal - $discount;
    return $amount > 0 ? $amount : 0;
}

if (empty($_SESSION['user_id'])) {
    payment_json_response(array('success' => false, 'message' => 'Please login before payment.'), 401);
}

if (empty($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    payment_json_response(array('success' => false, 'message' => 'Your cart is empty.'), 400);
}

if (empty($config['enabled']) || empty($config['key_id']) || empty($config['key_secret'])) {
    payment_json_response(array('success' => false, 'message' => 'Razorpay keys are not configured yet.'), 400);
}

$coupon_code = isset($_POST['coupon']) ? trim($_POST['coupon']) : '';
$amount = calculate_checkout_amount($_SESSION['cart'], $coupon_code, $obj);
if ($amount <= 0) {
    payment_json_response(array('success' => false, 'message' => 'Invalid order amount.'), 400);
}

$receipt = 'postic_' . $_SESSION['user_id'] . '_' . time();
$payload = array(
    'amount' => $amount * 100,
    'currency' => $config['currency'],
    'receipt' => $receipt,
);

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($ch, CURLOPT_USERPWD, $config['key_id'] . ':' . $config['key_secret']);
$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

if ($response === false || $http_code < 200 || $http_code >= 300) {
    payment_json_response(array(
        'success' => false,
        'message' => $curl_error ? $curl_error : 'Could not create Razorpay order.',
    ), 500);
}

$order = json_decode($response, true);
if (empty($order['id'])) {
    payment_json_response(array('success' => false, 'message' => 'Invalid Razorpay response.'), 500);
}

$_SESSION['razorpay_order_id'] = $order['id'];
$_SESSION['razorpay_order_amount'] = $amount;

payment_json_response(array(
    'success' => true,
    'key' => $config['key_id'],
    'order_id' => $order['id'],
    'amount' => $order['amount'],
    'currency' => $order['currency'],
    'store_name' => $config['store_name'],
    'customer' => array(
        'name' => isset($_SESSION['username']) ? $_SESSION['username'] : '',
        'email' => isset($_SESSION['email']) ? $_SESSION['email'] : '',
        'contact' => isset($_SESSION['mobile']) ? $_SESSION['mobile'] : '',
    ),
));
