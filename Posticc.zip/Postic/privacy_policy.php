<?php
session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
if ($cata_info) {
    while ($data = mysqli_fetch_assoc($cata_info)) {
        $cataDatas[] = $data;
    }
}

include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->
    <?php include_once("includes/preloader.php"); ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">
        <?php
        include_once("includes/header_top.php");
        include_once("includes/header_middle.php");
        include_once("includes/header_bottom.php");
        ?>
    </header>

    <!-- Page Contain -->
    <div class="page-contain">
        <div id="main-content" class="main-content">

            <!-- Hero Banner -->
            <div class="postic-hero-banner" style="background: linear-gradient(135deg, #b71c1c 0%, #d32f2f 100%); padding: 50px 0 45px 0; color: #ffffff; text-align: center; margin-bottom: 40px; box-shadow: 0 4px 20px rgba(211,47,47,0.15);">
                <div class="container">
                    <span style="background: rgba(255,255,255,0.18); color: #fff; padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">
                        Trust &amp; Transparency
                    </span>
                    <h1 style="font-size: 34px; font-weight: 800; margin: 0 0 10px 0; color: #ffffff;">Privacy Policy</h1>
                    <p style="font-size: 16px; color: #ffebee; max-width: 700px; margin: 0 auto; line-height: 1.6;">
                        How Postic Foods protects, secures, and respects your personal data and privacy.
                    </p>
                </div>
            </div>

            <div class="container" style="margin-bottom: 60px;">
                <div style="background: #ffffff; border-radius: 16px; padding: 40px 35px; border: 1px solid #e2e8f0; box-shadow: 0 4px 20px rgba(0,0,0,0.04);">
                    <p style="color: #64748b; font-size: 13px; margin-bottom: 25px;">
                        <em>Last Updated: October 2026 &bull; Postic Foods (Udaipur, Rajasthan)</em>
                    </p>

                    <div style="color: #334155; font-size: 14px; line-height: 1.8;">
                        <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 25px 0 10px 0;">1. Introduction</h3>
                        <p>
                            Welcome to <strong>Postic Foods</strong> ("we", "our", or "us"). We are dedicated to providing premium quality roasted Makhana (Fox Nuts) snacks while holding the highest standards for user privacy and data security. This Privacy Policy details how we collect, use, store, and safeguard your personal information when you visit or make a purchase from <strong>postic.in</strong> or its affiliated platforms.
                        </p>

                        <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 25px 0 10px 0;">2. Information We Collect</h3>
                        <p>When you browse, register, or place an order on Postic, we may collect the following details:</p>
                        <ul style="padding-left: 20px; margin-bottom: 15px;">
                            <li><strong>Account &amp; Contact Details:</strong> Your full name, email address, phone number, and account credentials.</li>
                            <li><strong>Shipping &amp; Delivery Information:</strong> Full delivery address (including Home and Office address book entries), postal pin codes, and recipient contact numbers.</li>
                            <li><strong>Order Records:</strong> Items ordered, selected pack sizes (e.g. 55g pouch, 250g pack), order totals, coupon codes applied, and invoice timestamps.</li>
                            <li><strong>Device &amp; Usage Information:</strong> Anonymous device types (mobile, tablet, desktop), browser types, IP address, and site interaction metrics collected via our internal visitor logs to optimize site responsiveness.</li>
                        </ul>

                        <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 25px 0 10px 0;">3. Payment Processing &amp; Financial Security</h3>
                        <p>
                            We prioritize your payment security above all. All online electronic payments (Debit Cards, Credit Cards, UPI, Net Banking, and Wallets) are processed through certified, PCI-DSS compliant payment gateways such as <strong>Razorpay</strong>.
                        </p>
                        <p>
                            <strong>Postic does NOT store, view, or retain your credit/debit card numbers, CVV codes, or net banking passwords</strong> on our servers. All transaction data is encrypted in transit using industry-standard SSL/TLS technology.
                        </p>

                        <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 25px 0 10px 0;">4. How We Use Your Information</h3>
                        <p>Your data is used strictly for legitimate business and fulfillment purposes:</p>
                        <ul style="padding-left: 20px; margin-bottom: 15px;">
                            <li>To process, pack, and ship your roasted Makhana orders to your doorstep.</li>
                            <li>To send automated order confirmation receipts, tax invoices, and shipment tracking alerts.</li>
                            <li>To provide live customer support via phone, email, or our verified WhatsApp helpline.</li>
                            <li>To provide convenient 1-click address autofill for saved Home and Office locations in your personal customer dashboard.</li>
                            <li>To detect and prevent fraudulent transactions or bot attacks.</li>
                        </ul>

                        <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 25px 0 10px 0;">5. Zero Third-Party Selling Policy</h3>
                        <p>
                            <strong>We never sell, trade, rent, or lease your personal information to third-party marketing agencies.</strong> Your data is shared only with trusted logistics partners (courier companies delivering your packages) and authorized payment processors solely to complete your transactions.
                        </p>

                        <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 25px 0 10px 0;">6. Cookies &amp; Visitor Analytics</h3>
                        <p>
                            We use functional session cookies to maintain your shopping cart contents and login session. Our website also utilizes an anonymous internal traffic tracker to analyze aggregate metrics such as visitor counts and popular Makhana flavors. You can adjust your browser settings to refuse cookies at any time.
                        </p>

                        <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 25px 0 10px 0;">7. Your Rights &amp; Address Book Control</h3>
                        <p>
                            You hold full control over your data. By logging into your account dashboard (<a href="exist_order.php" style="color: #d32f2f; font-weight: 600;">My Orders</a>), you can review your order history, download tax invoices, and edit or delete your saved Home and Office delivery addresses at any time.
                        </p>

                        <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 25px 0 10px 0;">8. Contact Us Regarding Your Privacy</h3>
                        <p>If you have any questions, feedback, or data requests regarding this Privacy Policy, please contact our team:</p>
                        <div style="background: #f8fafc; border-radius: 10px; padding: 18px 22px; border: 1px solid #e2e8f0; margin-top: 15px;">
                            <strong style="color: #1e293b; display: block; font-size: 15px;">Postic Foods - Customer Care &amp; Compliance</strong>
                            <span style="color: #64748b; font-size: 13px; display: block; margin-top: 4px;">Udaipur, Rajasthan - 313001, India</span>
                            <span style="color: #64748b; font-size: 13px; display: block;">Email: <a href="mailto:care@postic.in" style="color: #d32f2f; font-weight: 600;">care@postic.in</a></span>
                            <span style="color: #64748b; font-size: 13px; display: block;">Phone / WhatsApp: <a href="tel:+919216398316" style="color: #d32f2f; font-weight: 600;">+91 9216398316</a></span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- FOOTER -->
    <?php
    include_once("includes/footer.php");
    include_once("includes/mobile_footer.php");
    include_once("includes/mobile_global.php");
    ?>

    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>
    <?php include_once("includes/script.php"); ?>
</body>
</html>
