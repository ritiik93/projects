<?php
session_start();
include_once ("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}

$pro_datas = array();
$comment_datas = array();
$cmt_row = 0;

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location:all_product.php");
    exit();
}

$pdtId = (int) $_GET['id'];
$pdt_info = $obj->display_product_byId($pdtId);
$pdt_fetch = $pdt_info ? mysqli_fetch_assoc($pdt_info) : false;

if (!$pdt_fetch) {
    header("location:all_product.php");
    exit();
}

$pro_datas[] = $pdt_fetch;
$ctg_id = $pdt_fetch['ctg_id'];
$rel_pro = $obj->related_product($ctg_id);


if (isset($_POST['post_comment'])) {
    $cmt_msg = $obj->post_comment($_POST);
}

$cmt_fetch = $obj->view_comment_id($pdtId);
if ($cmt_fetch) {
    $cmt_row = mysqli_num_rows($cmt_fetch);
    while ($comment = mysqli_fetch_assoc($cmt_fetch)) {
        $comment_datas[] = $comment;
    }
}
$rating_summary = $obj->get_product_rating_summary($pdtId);
?>




<?php
include_once ("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->

    <?php
    include_once ("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once ("includes/header_top.php");
        ?>

        <?php
        include_once ("includes/header_middle.php");
        ?>

        <?php
        include_once ("includes/header_bottom.php");
        ?>

    </header>

    <!-- Page Contain -->
    <div class="page-contain">

        <!-- Main content -->
        <div id="main-content" class="main-content">

            <!--Hero Section-->
            <div class="hero-section hero-background">
                <h1 class="page-title">
                    <?php
                    foreach ($pro_datas as $pro_data) {
                        echo $pro_data['pdt_name'];
                    }
                    ?>
                </h1>


            </div>




            <!--Navigation section-->
            <div class="container">
                <nav class="biolife-nav">
                    <ul>
                        <li class="nav-item"><a href="index.php" class="permal-link">Home</a></li>

                        <li class="nav-item"><span class="current-page">

                                <?php
                                foreach ($pro_datas as $pro_data) {
                                    echo $pro_data['ctg_name'];
                                }
                                ?>
                            </span></li>

                        <li class="nav-item"><span class="current-page">

                                <?php
                                foreach ($pro_datas as $pro_data) {
                                    echo $pro_data['pdt_name'];
                                }
                                ?>
                            </span></li>
                    </ul>
                </nav>


            </div>

            <div class="container">
                <div class="page-contain single-product">
                    <div class="container">

                        <!-- Main content -->
                        <div id="main-content" class="main-content">

                            <?php
                            foreach ($pro_datas as $pro_data) {


                                ?>



                                <div>
                                    <!-- summary info -->
                                    <form action="addtocart.php" method="POST">

                                        <?php
                                        $pdt_id = $pro_data['pdt_id'];
                                        $gallery_images = array();
                                        $multi_result = $obj->display_product_images($pdt_id);
                                        if ($multi_result) {
                                            while ($img = mysqli_fetch_assoc($multi_result)) {
                                                $gallery_images[] = $img;
                                            }
                                        }
                                        ?>
                                        <div class="sumary-product single-layout">
                                            <div class="media">
                                            <ul class="biolife-carousel slider-for" 
data-slick='{"arrows":false,"dots":false,"slidesMargin":30,"slidesToShow":1,"slidesToScroll":1,"fade":true,"asNavFor":".slider-nav"}'>

    <!-- Main image -->
    <li>
        <img src="admin/uploads/<?php echo $pro_data['pdt_img'] ?>" width="500">
    </li>

    <!-- Multiple images -->
    <?php foreach ($gallery_images as $img) { ?>
        <li>
            <img src="admin/uploads/<?php echo $img['img_name']; ?>" width="500">
        </li>
    <?php } ?>

</ul>
                                            <?php if (!empty($gallery_images)) { ?>
                                                <ul class="biolife-carousel slider-nav"
                                                    data-slick='{"arrows":false,"dots":false,"slidesMargin":10,"slidesToShow":4,"slidesToScroll":1,"asNavFor":".slider-for","focusOnSelect":true}'>
                                                    <li>
                                                        <img src="admin/uploads/<?php echo $pro_data['pdt_img'] ?>" width="110">
                                                    </li>
                                                    <?php foreach ($gallery_images as $img) { ?>
                                                        <li>
                                                            <img src="admin/uploads/<?php echo $img['img_name']; ?>" width="110">
                                                        </li>
                                                    <?php } ?>
                                                </ul>
                                            <?php } ?>

                                            </div>
                                            <div class="product-attribute">
                                                <h3 class="title"><?php echo $pro_data['pdt_name'] ?></h3>
                                                <div class="rating" style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 8px;">
                                                    <span style="background: #fef2f2; color: #d32f2f; font-weight: 800; font-size: 13px; padding: 3px 8px; border-radius: 6px; border: 1px solid #fecaca; display: inline-flex; align-items: center; gap: 4px;">
                                                        <i class="fa fa-star" style="color: #f59e0b;"></i> <?php echo number_format($rating_summary['avg'], 1); ?>
                                                    </span>
                                                    <span class="review-count" style="font-size: 13px; color: #64748b; font-weight: 600;">(<?php echo $rating_summary['total']; ?> Customer Reviews)</span>
                                                    <span style="color: #cbd5e1;">|</span>
                                                    <b class="category" style="color: #475569; font-size: 13px;"><i class="fa fa-tag" style="color: #d32f2f;"></i> <?php echo $pro_data['ctg_name'] ?></b>
                                                </div>
                                                <span class="sku">Sku: POSTIC-<?php echo str_pad($pro_data['pdt_id'], 4, '0', STR_PAD_LEFT); ?></span>
                                                <?php $stock_qty = (int)$pro_data['product_stock']; ?>
                                                <?php if ($stock_qty > 0) { ?>
                                                    <span class="stock" style="margin-left: 15px; background: #ecfdf5; color: #047857; font-weight: 700; font-size: 12px; padding: 4px 10px; border-radius: 20px; border: 1px solid #a7f3d0; display: inline-flex; align-items: center; gap: 5px;">
                                                        <i class="fa fa-check-circle"></i> In Stock (<?php echo $stock_qty; ?> ready)
                                                    </span>
                                                <?php } else { ?>
                                                    <span class="stock" style="margin-left: 15px; background: #fef2f2; color: #b91c1c; font-weight: 700; font-size: 12px; padding: 4px 10px; border-radius: 20px; border: 1px solid #fecaca; display: inline-flex; align-items: center; gap: 5px;">
                                                        <i class="fa fa-times-circle"></i> Sold Out
                                                    </span>
                                                <?php } ?>

                                                <p class="excerpt"><?php echo $pro_data['pdt_des'] ?></p>
                                                <div class="price">
                                                    <ins><span class="price-amount"><span class="currencySymbol">₹ </span><span id="dyn-unit-display"><?php echo $pro_data['pdt_price'] ?></span></span></ins>
                                                </div>

                                                <div class="shipping-info">
                                                    <p class="shipping-day">3-Day Express Shipping</p>
                                                    <p class="for-today">100% Roasted Natural Makhana</p>
                                                </div>
                                            </div>

                                            <div class="action-form" style="margin-top: 20px;">
                                                <!-- Net Weight / Pack Size Info -->
                                                <?php 
                                                    $disp_weight = !empty($pro_data['pdt_weight']) ? $pro_data['pdt_weight'] : '55g';
                                                ?>
                                                <div style="margin-bottom: 20px; display: inline-flex; align-items: center; gap: 10px; background: #fff5f5; padding: 8px 16px; border-radius: 20px; border: 1px solid #fee2e2;">
                                                    <span style="font-weight: 700; color: #1e293b; font-size: 13px;"><i class="fa fa-balance-scale" style="color: #d32f2f; margin-right: 4px;"></i> Pack Net Weight:</span>
                                                    <span style="background: #d32f2f; color: #fff; font-weight: 800; font-size: 13px; padding: 2px 10px; border-radius: 12px;"><?php echo htmlspecialchars($disp_weight); ?></span>
                                                </div>

                                                <!-- Quantity Selector -->
                                                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px; flex-wrap: wrap;">
                                                    <span style="font-weight: 700; color: #222; font-size: 15px;">Quantity:</span>
                                                    <div style="display: inline-flex; align-items: center; border: 2px solid #e1e1e1; border-radius: 8px; overflow: hidden; background: #fff;">
                                                        <button type="button" id="qty-minus" style="width: 38px; height: 38px; border: none; background: #f8f9fa; font-size: 18px; font-weight: bold; cursor: pointer; color: #333; line-height: 1;">-</button>
                                                        <input type="number" id="pdt-qty" name="quantity" value="1" min="1" max="<?php echo max(1, min(10, $stock_qty)); ?>" readonly style="width: 48px; height: 38px; text-align: center; border: none; font-size: 16px; font-weight: 700; color: #222; background: #fff;">
                                                        <button type="button" id="qty-plus" style="width: 38px; height: 38px; border: none; background: #f8f9fa; font-size: 18px; font-weight: bold; cursor: pointer; color: #333; line-height: 1;">+</button>
                                                    </div>
                                                    <div class="total-price-contain" style="margin-bottom: 0;">
                                                        <span class="title">Total:</span>
                                                        <p class="price" style="font-size: 24px; font-weight: 800; color: #d32f2f;">₹ <span id="dyn-total-price"><?php echo $pro_data['pdt_price']; ?></span></p>
                                                    </div>
                                                </div>

                                                <!-- Hidden Fields -->
                                                <input type="hidden" id="pdt-name-val" name="pdt_name" value="<?php echo htmlspecialchars($pro_data['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>">
                                                <input type="hidden" id="base-price-val" value="<?php echo (int) $pro_data['pdt_price']; ?>">
                                                <input type="hidden" id="unit-price" name="pdt_price" value="<?php echo (int) $pro_data['pdt_price']; ?>">
                                                <input type="hidden" id="pdt-weight-input" name="pdt_weight" value="<?php echo htmlspecialchars($disp_weight, ENT_QUOTES, 'UTF-8'); ?>">
                                                <input type="hidden" name="pdt_img" value="<?php echo htmlspecialchars($pro_data['pdt_img'], ENT_QUOTES, 'UTF-8'); ?>">
                                                <input type="hidden" name="pdt_id" value="<?php echo (int) $pro_data['pdt_id']; ?>">

                                                <!-- Action Buttons: Add to Cart & Buy Now -->
                                                <?php if ($stock_qty > 0) { ?>
                                                    <div style="display: flex; gap: 12px; margin-bottom: 14px; flex-wrap: wrap;">
                                                        <button type="submit" name="addtocart" class="btn postic-single-addtocart" style="flex: 1; min-width: 140px; padding: 12px 18px; font-weight: 700; border-radius: 8px; font-size: 15px; background: #d32f2f; border: 1px solid #d32f2f; color: #ffffff; display: inline-flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 14px rgba(211,47,47,0.25);">
                                                            <i class="fa fa-shopping-cart"></i> Add To Cart
                                                        </button>
                                                        <button type="submit" name="buynow" class="btn" style="flex: 1; min-width: 140px; padding: 12px 18px; font-weight: 700; border-radius: 8px; font-size: 15px; background: #1e293b; border: 1px solid #0f172a; color: #ffffff; display: inline-flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 14px rgba(15,23,42,0.2);">
                                                            <i class="fa fa-bolt" style="color: #fbbf24;"></i> Buy Now
                                                        </button>
                                                    </div>
                                                <?php } else { ?>
                                                    <div style="margin-bottom: 14px;">
                                                        <button type="button" disabled class="btn btn-block" style="background: #94a3b8; color: #fff; font-weight: 700; padding: 12px 18px; border-radius: 8px; font-size: 15px; cursor: not-allowed; border: none;">
                                                            <i class="fa fa-ban"></i> Currently Out of Stock
                                                        </button>
                                                    </div>
                                                <?php } ?>

                                                
                                            </div>
                                        </form>

                                        <!-- Pincode Delivery Estimator Box -->
                                        <div class="pincode-checker-box" style="background: #fdfaf9; border: 1px dashed #fecaca; border-radius: 10px; padding: 14px 16px; margin-bottom: 20px;">
                                            <p style="font-weight: 700; margin-bottom: 8px; color: #1e293b; font-size: 13px;"><i class="fa fa-map-marker" style="color: #d32f2f; margin-right: 5px;"></i> Check Delivery to Your Pincode</p>
                                            <div style="display: flex; gap: 8px;">
                                                <input type="text" id="pincodeInput" maxlength="6" placeholder="Enter 6-digit Pincode" class="form-control" style="max-width: 190px; height: 36px; font-size: 13px;">
                                                <button type="button" id="checkPinBtn" class="btn" style="height: 36px; padding: 0 16px; font-size: 13px; font-weight: 700; border-radius: 6px; background: #d32f2f; color: #fff; border: none;">Check</button>
                                            </div>
                                            <div id="pincodeResult" style="margin-top: 8px; font-size: 12px; display: none;"></div>
                                        </div>

                                        <!-- Trust & Quality Badges -->
                                        <div class="product-trust-badges" style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; padding: 14px; background: #fef2f2; border-radius: 10px; border: 1px solid #fee2e2;">
                                            <div style="font-size: 12px; color: #991b1b; display: flex; align-items: center; gap: 6px; font-weight: 600;"><i class="fa fa-check-circle" style="font-size: 15px; color: #d32f2f;"></i> 100% Roasted Makhana</div>
                                            <div style="font-size: 12px; color: #991b1b; display: flex; align-items: center; gap: 6px; font-weight: 600;"><i class="fa fa-leaf" style="font-size: 15px; color: #d32f2f;"></i> No Preservatives</div>
                                            <div style="font-size: 12px; color: #991b1b; display: flex; align-items: center; gap: 6px; font-weight: 600;"><i class="fa fa-truck" style="font-size: 15px; color: #d32f2f;"></i> All India Delivery</div>
                                            <div style="font-size: 12px; color: #991b1b; display: flex; align-items: center; gap: 6px; font-weight: 600;"><i class="fa fa-shield" style="font-size: 15px; color: #d32f2f;"></i> Safe &amp; Secure Pay</div>
                                        </div>

                                    <div class="social-media">
                                        <ul class="social-list">
                                            <li><a href="https://wa.me/919216398316?text=Hi%20Postic" target="_blank" class="social-link" title="Share on WhatsApp"><i class="fa fa-whatsapp" aria-hidden="true" style="color: #25D366;"></i></a></li>
                                            <li><a href="https://www.facebook.com/p/Postic-Snacks-61583351282686/" target="_blank" class="social-link" title="Postic on Facebook"><i class="fa fa-facebook" aria-hidden="true" style="color: #1877f2;"></i></a></li>
                                            <li><a href="https://www.instagram.com/postic_snacks" target="_blank" class="social-link" title="Postic on Instagram"><i class="fa fa-instagram" aria-hidden="true" style="color: #e1306c;"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="acepted-payment-methods">
                                        <ul class="payment-methods">
                                            <li><img src="assets/images/card1.jpg" alt="" width="51" height="36"></li>
                                            <li><img src="assets/images/card2.jpg" alt="" width="51" height="36"></li>
                                            <li><img src="assets/images/card3.jpg" alt="" width="51" height="36"></li>
                                            <li><img src="assets/images/card4.jpg" alt="" width="51" height="36"></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            </form>

                            <!-- Tab info -->
                            <div class="product-tabs single-layout biolife-tab-contain">
                                <div class="tab-head">
                                    <ul class="tabs">
                                        <li class="tab-element active"><a href="#tab_1st" class="tab-link">Products
                                                Descriptions</a></li>

                                        <li class="tab-element"><a href="#tab_3rd" class="tab-link">Shipping & Delivery</a>
                                        </li>
                                        <li class="tab-element"><a href="#tab_4th" class="tab-link">Customer Reviews
                                                <sup>(3)</sup></a></li>
                                    </ul>
                                </div>
                                <div class="tab-content">
                                    <div id="tab_1st" class="tab-contain desc-tab active">
                                        <p class="desc">Postic brings you premium roasted Fox Nuts (Makhana) sourced directly from the finest harvesting regions and slow-roasted to crunchy perfection in Udaipur, Rajasthan. Flavored with authentic, natural Indian herbs and spices, our Makhana is 100% free of palm oil, trans fats, and artificial preservatives. Whether you are working, enjoying tea time, or powering through a workout, Postic is your perfect guilt-free superfood snack.
                                        </p>
                                        <div class="desc-expand">
                                            <span class="title">The Postic Superfood Advantage</span>
                                            <ul class="list">
                                                <li>100% slow-roasted, never deep fried (Zero palm oil)</li>
                                                <li>Rich in plant-based protein, dietary fiber, and essential minerals</li>
                                                <li>Gluten-free, vegan-friendly, with zero chemical preservatives or MSG</li>
                                                <li>Sealed fresh in moisture-proof, food-grade airtight packaging</li>
                                            </ul>
                                        </div>
                                    </div>

                                    <div id="tab_3rd" class="tab-contain shipping-delivery-tab">
                                        <div class="accodition-tab biolife-accodition">
                                            <ul class="tabs">
                                                <li class="tab-item">
                                                    <span class="title btn-expand">How long will it take to receive my
                                                        order?</span>
                                                    <div class="content">
                                                        <p>Orders placed before 3pm eastern time will normally be processed
                                                            and shipped by the following business day. For orders received
                                                            after 3pm, they will generally be processed and shipped on the
                                                            second business day. For example if you place your order after
                                                            3pm on Monday the order will ship on Wednesday. Business days do
                                                            not include Saturday and Sunday and all Holidays. Please allow
                                                            additional processing time if you order is placed on a weekend
                                                            or holiday. Once an order is processed, speed of delivery will
                                                            be determined as follows based on the shipping mode selected:
                                                        </p>
                                                        <div class="desc-expand">
                                                            <span class="title">Shipping mode</span>
                                                            <ul class="list">
                                                                <li>Standard (in transit 3-5 business days)</li>
                                                                <li>Priority (in transit 2-3 business days)</li>
                                                                <li>Express (in transit 1-2 business days)</li>
                                                                <li>Gift Card Orders are shipped via USPS First Class Mail.
                                                                    First Class mail will be delivered within 8 business
                                                                    days</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="tab-item">
                                                    <span class="title btn-expand">How is the shipping cost
                                                        calculated?</span>
                                                    <div class="content">
                                                        <p>You will pay a shipping rate based on the weight and size of the
                                                            order. Large or heavy items may include an oversized handling
                                                            fee. Total shipping fees are shown in your shopping cart. Please
                                                            refer to the following shipping table:</p>
                                                        <p>Note: Shipping weight calculated in cart may differ from weights
                                                            listed on product pages due to size and actual weight of the
                                                            item.</p>
                                                    </div>
                                                </li>
                                                <li class="tab-item">
                                                    <span class="title btn-expand">Why Didn’t My Order Qualify for FREE
                                                        shipping?</span>
                                                    <div class="content">
                                                        <p>We do not deliver to P.O. boxes or military (APO, FPO, PSC)
                                                            boxes. We deliver to all 50 states plus Puerto Rico. Certain
                                                            items may be excluded for delivery to Puerto Rico. This will be
                                                            indicated on the product page.</p>
                                                    </div>
                                                </li>
                                                <li class="tab-item">
                                                    <span class="title btn-expand">Shipping Restrictions?</span>
                                                    <div class="content">
                                                        <p>We do not deliver to P.O. boxes or military (APO, FPO, PSC)
                                                            boxes. We deliver to all 50 states plus Puerto Rico. Certain
                                                            items may be excluded for delivery to Puerto Rico. This will be
                                                            indicated on the product page.</p>
                                                    </div>
                                                </li>
                                                <li class="tab-item">
                                                    <span class="title btn-expand">Undeliverable Packages?</span>
                                                    <div class="content">
                                                        <p>Occasionally packages are returned to us as undeliverable by the
                                                            carrier. When the carrier returns an undeliverable package to
                                                            us, we will cancel the order and refund the purchase price less
                                                            the shipping charges. Here are a few reasons packages may be
                                                            returned to us as undeliverable:</p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div id="tab_4th" class="tab-contain review-tab">
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
                                                    <div class="rating-info" style="background: #ffffff; border: 1px solid #f1f5f9; border-radius: 12px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
                                                        <p class="index" style="margin-bottom: 6px;"><strong class="rating" style="font-size: 38px; font-weight: 800; color: #1e293b;"><?php echo number_format($rating_summary['avg'], 1); ?></strong> <span style="font-size: 15px; color: #64748b;">out of 5</span></p>
                                                        <div class="rating" style="margin-bottom: 12px;">
                                                            <div style="font-size: 20px; color: #f59e0b; letter-spacing: 2px;">
                                                                <?php 
                                                                $rounded_stars = round($rating_summary['avg']);
                                                                echo str_repeat('★', $rounded_stars) . str_repeat('☆', 5 - $rounded_stars);
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <p class="see-all" style="font-size: 13px; font-weight: 700; color: #475569; margin-bottom: 16px;">Based on <?php echo $rating_summary['total']; ?> verified reviews</p>
                                                        
                                                        <?php 
                                                        $total_rev = max(1, $rating_summary['total']);
                                                        $pct_5 = round(($rating_summary['stars_5'] / $total_rev) * 100);
                                                        $pct_4 = round(($rating_summary['stars_4'] / $total_rev) * 100);
                                                        $pct_3 = round(($rating_summary['stars_3'] / $total_rev) * 100);
                                                        $pct_2 = round(($rating_summary['stars_2'] / $total_rev) * 100);
                                                        $pct_1 = round(($rating_summary['stars_1'] / $total_rev) * 100);
                                                        ?>
                                                        <ul class="options" style="margin: 0; padding: 0; list-style: none;">
                                                            <li style="margin-bottom: 8px;">
                                                                <div class="detail-for" style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                                                    <span class="option-name" style="width: 45px; font-weight: 600;">5 Stars</span>
                                                                    <div style="flex: 1; height: 8px; background: #f1f5f9; border-radius: 4px; overflow: hidden;">
                                                                        <div style="height: 100%; width: <?php echo $pct_5; ?>%; background: #16a34a; border-radius: 4px;"></div>
                                                                    </div>
                                                                    <span class="number" style="width: 25px; text-align: right; color: #64748b; font-weight: 700;"><?php echo $rating_summary['stars_5']; ?></span>
                                                                </div>
                                                            </li>
                                                            <li style="margin-bottom: 8px;">
                                                                <div class="detail-for" style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                                                    <span class="option-name" style="width: 45px; font-weight: 600;">4 Stars</span>
                                                                    <div style="flex: 1; height: 8px; background: #f1f5f9; border-radius: 4px; overflow: hidden;">
                                                                        <div style="height: 100%; width: <?php echo $pct_4; ?>%; background: #22c55e; border-radius: 4px;"></div>
                                                                    </div>
                                                                    <span class="number" style="width: 25px; text-align: right; color: #64748b; font-weight: 700;"><?php echo $rating_summary['stars_4']; ?></span>
                                                                </div>
                                                            </li>
                                                            <li style="margin-bottom: 8px;">
                                                                <div class="detail-for" style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                                                    <span class="option-name" style="width: 45px; font-weight: 600;">3 Stars</span>
                                                                    <div style="flex: 1; height: 8px; background: #f1f5f9; border-radius: 4px; overflow: hidden;">
                                                                        <div style="height: 100%; width: <?php echo $pct_3; ?>%; background: #eab308; border-radius: 4px;"></div>
                                                                    </div>
                                                                    <span class="number" style="width: 25px; text-align: right; color: #64748b; font-weight: 700;"><?php echo $rating_summary['stars_3']; ?></span>
                                                                </div>
                                                            </li>
                                                            <li style="margin-bottom: 8px;">
                                                                <div class="detail-for" style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                                                    <span class="option-name" style="width: 45px; font-weight: 600;">2 Stars</span>
                                                                    <div style="flex: 1; height: 8px; background: #f1f5f9; border-radius: 4px; overflow: hidden;">
                                                                        <div style="height: 100%; width: <?php echo $pct_2; ?>%; background: #f97316; border-radius: 4px;"></div>
                                                                    </div>
                                                                    <span class="number" style="width: 25px; text-align: right; color: #64748b; font-weight: 700;"><?php echo $rating_summary['stars_2']; ?></span>
                                                                </div>
                                                            </li>
                                                            <li style="margin-bottom: 8px;">
                                                                <div class="detail-for" style="display: flex; align-items: center; gap: 8px; font-size: 12px;">
                                                                    <span class="option-name" style="width: 45px; font-weight: 600;">1 Star</span>
                                                                    <div style="flex: 1; height: 8px; background: #f1f5f9; border-radius: 4px; overflow: hidden;">
                                                                        <div style="height: 100%; width: <?php echo $pct_1; ?>%; background: #ef4444; border-radius: 4px;"></div>
                                                                    </div>
                                                                    <span class="number" style="width: 25px; text-align: right; color: #64748b; font-weight: 700;"><?php echo $rating_summary['stars_1']; ?></span>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>

                                                <div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
                                                    <?php if (isset($_SESSION['user_id'])) { ?>
                                                        <div class="review-form-wrapper" style="background: #fff; border: 1px solid #f1f5f9; border-radius: 12px; padding: 22px; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
                                                            <h4 style="margin: 0 0 14px 0; font-size: 18px; font-weight: 800; color: #1e293b;"><i class="fa fa-pencil" style="color: #d32f2f; margin-right: 6px;"></i> Write a Customer Review</h4>
                                                            <?php
                                                            if (isset($cmt_msg)) {
                                                                echo '<div class="alert alert-success" style="background:#ecfdf5; border:1px solid #a7f3d0; color:#047857; border-radius:8px; padding:10px 14px; font-weight:600; margin-bottom:14px;"><i class="fa fa-check-circle"></i> ' . htmlspecialchars($cmt_msg) . '</div>';
                                                            }
                                                            ?>
                                                            <form action="" method="post">
                                                                <!-- Star Rating Widget -->
                                                                <div style="margin-bottom: 14px;">
                                                                    <label style="font-weight: 700; color: #1e293b; display: block; margin-bottom: 6px;">Your Overall Rating: <span style="color: #d32f2f;">*</span></label>
                                                                    <div style="display: flex; align-items: center; gap: 10px;">
                                                                        <div id="starPickerContainer" style="font-size: 28px; cursor: pointer; color: #f59e0b; user-select: none;">
                                                                            <span class="star-pick" data-val="1">★</span><span class="star-pick" data-val="2">★</span><span class="star-pick" data-val="3">★</span><span class="star-pick" data-val="4">★</span><span class="star-pick" data-val="5">★</span>
                                                                        </div>
                                                                        <span id="ratingTextFeedback" style="font-weight: 700; color: #d32f2f; font-size: 13px; background: #fef2f2; padding: 3px 10px; border-radius: 12px; border: 1px solid #fecaca;">5 out of 5 Stars</span>
                                                                        <input type="hidden" name="rating" id="reviewRatingInput" value="5">
                                                                    </div>
                                                                </div>

                                                                <input type="hidden" value="<?php echo $_SESSION['user_id'] ?>" name="user_id">
                                                                <input type="hidden" value="<?php echo htmlspecialchars($_SESSION['username'] ?? 'Customer', ENT_QUOTES, 'UTF-8'); ?>" name="user_name">
                                                                <input type="hidden" value="<?php echo (int) $pdtId; ?>" name="pdt_id">

                                                                <div style="margin-bottom: 14px;">
                                                                    <label style="font-weight: 700; color: #1e293b; display: block; margin-bottom: 6px;">Your Review &amp; Comments:</label>
                                                                    <textarea name="comment" id="txt-comment" rows="4" class="form-control" placeholder="Share your experience regarding crunch, flavor, and quality..." required style="border-radius: 8px; border: 1px solid #cbd5e1;"></textarea>
                                                                </div>

                                                                <button type="submit" name="post_comment" class="btn" style="background: #d32f2f; color: #ffffff; font-weight: 700; padding: 10px 24px; border-radius: 8px; border: none; box-shadow: 0 4px 12px rgba(211,47,47,0.25);">
                                                                    <i class="fa fa-paper-plane"></i> Submit Review
                                                                </button>
                                                            </form>
                                                        </div>
                                                    <?php } else { ?>
                                                        <div style="background: #f8fafc; border: 2px dashed #cbd5e1; border-radius: 12px; padding: 30px; text-align: center;">
                                                            <i class="fa fa-user-circle" style="font-size: 38px; color: #94a3b8; margin-bottom: 10px; display: block;"></i>
                                                            <h4 style="margin: 0 0 6px 0; font-size: 16px; font-weight: 700; color: #1e293b;">Share Your Review &amp; Rating</h4>
                                                            <p style="color: #64748b; font-size: 13px; margin-bottom: 16px;">Please log in to your Postic account to rate this Makhana flavor and share your feedback with other snack lovers.</p>
                                                            <a href="user_login.php" class="btn" style="background: #d32f2f; color: #fff; font-weight: 700; padding: 10px 24px; border-radius: 8px; font-size: 13px; text-decoration: none; display: inline-block;">
                                                                <i class="fa fa-sign-in"></i> Log In to Write a Review
                                                            </a>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div id="comments" style="margin-top: 30px;">
                                                <h4 style="font-size: 18px; font-weight: 800; color: #1e293b; margin-bottom: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 10px;">
                                                    <i class="fa fa-comments" style="color: #d32f2f; margin-right: 6px;"></i> Verified Customer Reviews (<?php echo count($comment_datas); ?>)
                                                </h4>

                                                <?php if (empty($comment_datas)) { ?>
                                                    <div style="text-align: center; padding: 30px; background: #fff; border-radius: 10px; border: 1px dashed #cbd5e1;">
                                                        <i class="fa fa-comment-o" style="font-size: 32px; color: #94a3b8; margin-bottom: 8px; display: block;"></i>
                                                        <p style="color: #64748b; font-size: 14px; margin: 0;">No reviews yet. Be the first to taste and review this healthy Makhana!</p>
                                                    </div>
                                                <?php } else { ?>
                                                    <ol class="commentlist" style="list-style: none; padding: 0; margin: 0;">
                                                        <?php foreach ($comment_datas as $cmtinfo) { 
                                                            $c_rating = isset($cmtinfo['rating']) ? max(1, min(5, (int)$cmtinfo['rating'])) : 5;
                                                        ?>
                                                            <li class="review" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 16px 20px; margin-bottom: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
                                                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;">
                                                                    <div style="display: flex; align-items: center; gap: 10px;">
                                                                        <div style="width: 36px; height: 36px; border-radius: 50%; background: #fef2f2; color: #d32f2f; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 14px; border: 1px solid #fecaca;">
                                                                            <?php echo strtoupper(substr($cmtinfo['user_name'] ?? 'U', 0, 1)); ?>
                                                                        </div>
                                                                        <div>
                                                                            <strong style="color: #0f172a; font-size: 14px;"><?php echo htmlspecialchars($cmtinfo['user_name']); ?></strong>
                                                                            <span style="background: #ecfdf5; color: #047857; font-size: 10px; padding: 2px 7px; border-radius: 10px; font-weight: 700; margin-left: 6px; border: 1px solid #a7f3d0;"><i class="fa fa-check-circle"></i> Verified Buyer</span>
                                                                        </div>
                                                                    </div>
                                                                    <div style="display: flex; align-items: center; gap: 8px;">
                                                                        <div style="color: #f59e0b; font-size: 16px; letter-spacing: 1px;">
                                                                            <?php echo str_repeat('★', $c_rating) . str_repeat('☆', 5 - $c_rating); ?>
                                                                        </div>
                                                                        <span style="font-size: 12px; color: #94a3b8;"><?php echo htmlspecialchars($cmtinfo['comment_date']); ?></span>
                                                                    </div>
                                                                </div>
                                                                <p style="color: #334155; font-size: 14px; line-height: 1.6; margin: 0; padding-left: 46px;">
                                                                    <?php echo nl2br(htmlspecialchars($cmtinfo['comment'])); ?>
                                                                </p>
                                                            </li>
                                                        <?php } ?>
                                                    </ol>
                                                <?php } ?>
                                                <div class="biolife-panigations-block version-2">
                                                    <ul class="panigation-contain">
                                                        <li><span class="current-page">1</span></li>
                                                        <li><a href="#" class="link-page">2</a></li>
                                                        <li><a href="#" class="link-page">3</a></li>
                                                        <li><span class="sep">....</span></li>
                                                        <li><a href="#" class="link-page">20</a></li>
                                                        <li><a href="#" class="link-page next"><i class="fa fa-angle-right"
                                                                    aria-hidden="true"></i></a></li>
                                                    </ul>
                                                    <div class="result-count">
                                                        <p class="txt-count"><b>1-5</b> of <b>126</b> reviews</p>
                                                        <a href="#" class="link-to">See all<i class="fa fa-caret-right"
                                                                aria-hidden="true"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- related products -->
                            <div class="product-related-box single-layout">
                                <div class="biolife-title-box lg-margin-bottom-26px-im">
                                    <span class="biolife-icon icon-organic"></span>
                                    <span class="subtitle">All the best item for You</span>
                                    <h3 class="main-title">Related Products</h3>
                                </div>
                                <ul class="products-list biolife-carousel nav-center-02 nav-none-on-mobile"
                                    data-slick='{"rows":1,"arrows":true,"dots":false,"infinite":false,"speed":400,"slidesMargin":0,"slidesToShow":5, "responsive":[{"breakpoint":1200, "settings":{ "slidesToShow": 4}},{"breakpoint":992, "settings":{ "slidesToShow": 3, "slidesMargin":20 }},{"breakpoint":768, "settings":{ "slidesToShow": 2, "slidesMargin":10}}]}'>


                                    <?php while ($r_pro = mysqli_fetch_assoc($rel_pro)) { ?>

                                        <li class="product-item">
                                            <div class="contain-product layout-default">
                                                <div class="product-thumb">
                                                    <a href="single_product.php?status=singleproduct&id=<?php echo $r_pro['pdt_id'] ?>"
                                                        class="link-to-product">
                                                        <img src="admin/uploads/<?php echo $r_pro['pdt_img'] ?>" alt="<?php echo htmlspecialchars($r_pro['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>"
                                                            width="270" height="270" class="product-thumnail" style="object-fit:cover;">
                                                    </a>
                                                </div>
                                                <div class="info">
                                                    <b class="categories"><?php echo $r_pro['ctg_name'] ?></b>
                                                    <h4 class="product-title"><a
                                                            href="single_product.php?status=singleproduct&id=<?php echo $r_pro['pdt_id'] ?>"
                                                            class="pr-name"> <?php echo htmlspecialchars($r_pro['pdt_name'], ENT_QUOTES, 'UTF-8'); ?> </a></h4>
                                                    <div class="price">
                                                        <ins><span class="price-amount"><span class="currencySymbol">₹ </span>
                                                                <?php echo $r_pro['pdt_price'] ?>
                                                            </span></ins>

                                                    </div>
                                                    <div class="slide-down-box">
                                                        <p class="message">All products are carefully selected to ensure food
                                                            safety.</p>

                                                    </div>
                                                </div>
                                            </div>
                                        </li>

                                    <?php } ?>
                                </ul>
                            </div>
                        </div>




                    <?php } ?>
                </div>
            </div>
        </div>

    </div>



    </div>
    </div>

    <!-- FOOTER -->

    <?php
    include_once ("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once ("includes/mobile_footer.php");
    ?>

    <?php
    include_once ("includes/mobile_global.php")
        ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once ("includes/script.php")
    ?>

    <script>
    $(document).ready(function() {
        var basePrice = parseInt($("#base-price-val").val()) || parseInt($("#unit-price").val()) || 0;
        var currentWeight = $("#pdt-weight-input").val() || "55g";
        var pdtName = $("#pdt-name-val").val() || "";

        function updateTotals() {
            var qty = parseInt($("#pdt-qty").val()) || 1;
            if (qty < 1) qty = 1;
            if (qty > 10) qty = 10;
            $("#pdt-qty").val(qty);

            var unitPrice = basePrice;
            $("#unit-price").val(unitPrice);
            $("#dyn-unit-display").text(unitPrice);

            var total = unitPrice * qty;
            $("#dyn-total-price").text(total);

            // Update WhatsApp Link
            var waMsg = "Hi Postic, I want to order " + pdtName + " [" + currentWeight + "] (Qty: " + qty + ", Total: INR " + total + ")";
            var waUrl = "https://api.whatsapp.com/send?phone=919216398316&text=" + encodeURIComponent(waMsg);
            $("#wa-order-link").attr("href", waUrl);
        }

        // Quantity Plus / Minus
        $("#qty-plus").on("click", function() {
            var current = parseInt($("#pdt-qty").val()) || 1;
            if (current < 10) {
                $("#pdt-qty").val(current + 1);
                updateTotals();
            }
        });

        $("#qty-minus").on("click", function() {
            var current = parseInt($("#pdt-qty").val()) || 1;
            if (current > 1) {
                $("#pdt-qty").val(current - 1);
                updateTotals();
            }
        });

        // Interactive 5-Star Rating Picker
        $(".star-pick").on("mouseenter", function() {
            var val = parseInt($(this).data("val")) || 5;
            $(".star-pick").each(function() {
                var sVal = parseInt($(this).data("val"));
                if (sVal <= val) {
                    $(this).css("color", "#f59e0b");
                } else {
                    $(this).css("color", "#cbd5e1");
                }
            });
        }).on("mouseleave", function() {
            var selected = parseInt($("#reviewRatingInput").val()) || 5;
            $(".star-pick").each(function() {
                var sVal = parseInt($(this).data("val"));
                if (sVal <= selected) {
                    $(this).css("color", "#f59e0b");
                } else {
                    $(this).css("color", "#cbd5e1");
                }
            });
        }).on("click", function() {
            var val = parseInt($(this).data("val")) || 5;
            $("#reviewRatingInput").val(val);
            $("#ratingTextFeedback").text(val + " out of 5 Stars");
        });

        // Pincode Delivery Estimator
        $("#checkPinBtn").on("click", function() {
            var pin = $.trim($("#pincodeInput").val());
            var resBox = $("#pincodeResult");
            if (/^[1-9][0-9]{5}$/.test(pin)) {
                resBox.css("color", "#2e7d32").html('<i class="fa fa-check-circle"></i> <strong>Delivery Available</strong> to PIN <strong>' + pin + '</strong>. Express delivery within 2-4 business days. Free shipping eligible.').slideDown();
            } else {
                resBox.css("color", "#d32f2f").html('<i class="fa fa-exclamation-triangle"></i> Please enter a valid 6-digit Indian Pincode (e.g. 313001).').slideDown();
            }
        });

        $("#pincodeInput").on("keypress", function(e) {
            if (e.which === 13) {
                e.preventDefault();
                $("#checkPinBtn").click();
            }
        });

        // Initialize defaults
        updateTotals();
    });
    </script>
</body>

</html>
