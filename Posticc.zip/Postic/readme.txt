========================================================================
                      POSTIC PROJECT GUIDE & DOCUMENTATION
========================================================================

------------------------------------------------------------------------
1. DATABASE CONFIGURATION (Database Connection Details)
------------------------------------------------------------------------
Current Database Settings (Live Hosting):
- Database Host : localhost
- Database Name : oktgaunq_postic
- Database User : oktgaunq_postic1
- Password      : h2hpCARGgxnbQwP9VXRk

Agar future mein Database Name, User ya Password change karna ho,
toh aapko KISI BHI AUR FILE mein change karne ki zaroorat nahi hai.
SIRF ek hi file mein jaakar update karein:
-> config/database.php

Is file mein line 3 se 6 par values change kar dein:
  define('DB_HOST', 'localhost');
  define('DB_USER', 'your_username');
  define('DB_PASS', 'your_password');
  define('DB_NAME', 'your_dbname');


------------------------------------------------------------------------
2. DATABASE IMPORT (SQL File)
------------------------------------------------------------------------
phpMyAdmin mein import karne ke liye single clean master file:
-> oktgaunq_postic.sql
Is file mein sirf aur sirf Postic Makhana ka data hai (fruits/vegetables ka sara purana template data hata diya gaya hai).
Is file se saare DEFINER errors hata diye gaye hain, bina kisi error ke 
direct 1-click import ho jayegi.


------------------------------------------------------------------------
3. ADMIN PANEL ACCESS (Admin Login)
------------------------------------------------------------------------
Admin Panel URL : yourdomain.com/admin/
- Email    : admin@gmail.com   (ya postic@gmail.com)
- Password : 1234


------------------------------------------------------------------------
4. FRONTEND / CUSTOMER SIDE PAGES (Inhe change karne se Customer site change hogi)
------------------------------------------------------------------------
A. Root Files:
- index.php                  : Home Page (Main landing page)
- all_product.php            : All Products List Page
- catagory.php               : Category wise product view page
- single_product.php         : Product Detail Page (Images, description, price)
- search_product.php         : Search results page
- addtocart.php              : Shopping Cart & Checkout Page
- user_login.php             : Customer Login page
- user_register.php          : Customer Sign-up / Registration page
- userprofile.php            : Customer Profile & Order history
- exist_order.php            : Customer Existing orders view
- user_password_recover.php  : Forgot password recovery page
- user_password_update.php   : Reset password link page

B. Header & Footer (includes/ Folder):
- includes/head.php          : Page Head, Fonts & CSS links
- includes/preloader.php     : Loading screen animation (Fast dismissed)
- includes/header_top.php    : Header Top bar (Email, Phone, Currency)
- includes/header_middle.php : Header Middle (Logo, Search, Cart icon)
- includes/header_bottom.php : Main Navigation Menu & Category Dropdown
- includes/slider_main.php   : Main Home Banner Slider
- includes/banner_slider.php : Secondary Promo Banners
- includes/home_related_product.php : Home page tabbed category products
- includes/deals_ofthe_day.php      : Deals of the day section
- includes/top_rated_product.php    : Top rated product widget
- includes/footer.php        : Footer section, links & contact info
- includes/script.php        : JavaScript libraries & footer scripts


------------------------------------------------------------------------
5. BACKEND / ADMIN SIDE PAGES (Inhe change karne se Admin control hogi)
------------------------------------------------------------------------
Admin Files (admin/ folder):
- admin/index.php            : Admin Login Page
- admin/dashboard.php        : Admin Dashboard (Sales, Orders overview)
- admin/template.php         : Master Layout / Sidebar / Admin Navigation

A. Sliders / Banners Management:
- admin/manage_slider.php    : View all home banners/sliders
- admin/views/edit_slider_view.php : Edit Slider image, title, buttons
  (NOTE: Any image dimensions allowed! Strict 1920x550 rule removed)

B. Products Management:
- admin/manage_product.php   : View, search & delete all products
- admin/add_product.php      : Add new product & gallery images
  (NOTE: Strict 800px size rule removed, any dimension image accepted)
- admin/edit_product.php     : Edit product name, price, stock & photos

C. Categories & Logo Management:
- admin/manage_cata.php      : Manage categories (Add / Edit / Delete)
- admin/add_cata.php         : Add new category
- admin/edit_cata.php        : Edit category
- admin/add_logo.php         : Website Logo settings
- admin/edit_logo.php        : Change website logo image

D. Orders, Coupons & Customers:
- admin/manage_order.php     : View & update customer orders
- admin/manage_coupon.php    : Add & manage discount coupons
- admin/customer_feedback.php: View reviews & comments from customers
- admin/make_report.php      : Generate sales & order reports
- admin/manage_user.php      : View registered customers
- admin/class/adminback.php  : Main backend PHP logic & database queries


------------------------------------------------------------------------
6. RECENT PERFORMANCE & UPLOAD IMPROVEMENTS
------------------------------------------------------------------------
1. Slider Dimensions: Removed strict width:1920px & height:550px constraint.
   Ab aap kisi bhi size / resolution ki image upload kar sakte hain.
2. Product Dimensions: Removed 800px constraint. WebP, PNG, JPG supported up to 10MB.
3. Fast Loading:
   - Added .htaccess with GZIP compression & browser caching.
   - Preloader dismisses immediately upon page load (within ~200ms).
   - Removed duplicate jQuery and consolidated Google Fonts.
   - Stopped repeated ALTER TABLE queries on every page request.
4. Favicon icons integrated across frontend and admin panel.

------------------------------------------------------------------------
7. BRAND & STORE IDENTITY (Postic - Healthy Roasted Makhana)
------------------------------------------------------------------------
- Brand Name       : Postic
- Core Products    : Roasted & Flavored Makhana (Fox Nuts)
- Store Address    : Udaipur, Rajasthan - 313001, India
- Phone / Support  : +91 9216398316
- Official Email   : care@postic.in
- Currency         : Indian Rupee (₹) throughout the website
- Floating Widget  : Direct 1-tap WhatsApp chat button (+91 9216398316)
- Mobile Navigation: Responsive 5-icon bottom bar (Home, Shop, Cart, Account, Menu)

------------------------------------------------------------------------
8. RECOMMENDED NEXT STEPS FOR PRODUCTION E-COMMERCE
------------------------------------------------------------------------
1. Razorpay Online Payment:
   - File: config/razorpay.php
   - Set 'enabled' => true and add your live key_id and key_secret
   - Customers will be able to pay via UPI (GPay/PhonePe/Paytm), Cards, NetBanking.
2. WhatsApp Ordering:
   - Already configured with +91 9216398316. Customers can directly order or query.
3. Mandatory Legal Pages for Payment Gateway KYC:
   - Add Privacy Policy, Terms & Conditions, Shipping & Return Policy pages.
========================================================================

