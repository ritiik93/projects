<?php
session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
if ($cata_info) {
    while ($data = mysqli_fetch_assoc($cata_info)) {
        $cataDatas[] = $data;
    }
}

include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->
    <?php include_once("includes/preloader.php"); ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">
        <?php
        include_once("includes/header_top.php");
        include_once("includes/header_middle.php");
        include_once("includes/header_bottom.php");
        ?>
    </header>

    <!-- Page Contain -->
    <div class="page-contain">
        <div id="main-content" class="main-content">

            <!-- Hero Banner -->
            <div class="postic-hero-banner" style="background: linear-gradient(135deg, #b71c1c 0%, #d32f2f 100%); padding: 50px 0 45px 0; color: #ffffff; text-align: center; margin-bottom: 40px; box-shadow: 0 4px 20px rgba(211,47,47,0.15);">
                <div class="container">
                    <span style="background: rgba(255,255,255,0.18); color: #fff; padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 10px;">
                        The Postic Story
                    </span>
                    <h1 style="font-size: 34px; font-weight: 800; margin: 0 0 10px 0; color: #ffffff;">About Postic Foods</h1>
                    <p style="font-size: 16px; color: #ffebee; max-width: 700px; margin: 0 auto; line-height: 1.6;">
                        Crafting 100% slow-roasted, guilt-free Makhana superfoods in the heritage city of Udaipur, Rajasthan.
                    </p>
                </div>
            </div>

            <div class="container" style="margin-bottom: 60px;">
                <!-- Brand Story Section -->
                <div class="row" style="align-items: center; margin-bottom: 60px;">
                    <div class="col-lg-6 col-md-6 col-sm-12" style="margin-bottom: 25px;">
                        <span style="color: #d32f2f; font-weight: 700; text-transform: uppercase; font-size: 13px; letter-spacing: 1px;">Who We Are</span>
                        <h2 style="font-size: 28px; font-weight: 800; color: #1e293b; margin: 8px 0 16px 0; line-height: 1.3;">
                            Snacking Reimagined: Pure, Crunchy &amp; Naturally Nourishing
                        </h2>
                        <p style="color: #475569; font-size: 15px; line-height: 1.8; margin-bottom: 14px;">
                            At <strong>Postic</strong>, we started with a simple belief: <em>Healthy snacking shouldn't feel like a compromise, and delicious food shouldn't ruin your health.</em>
                        </p>
                        <p style="color: #475569; font-size: 15px; line-height: 1.8; margin-bottom: 14px;">
                            Rooted in Udaipur, Rajasthan, Postic specializes in premium hand-harvested <strong>Phool Makhana (Fox Nuts)</strong>. Instead of deep-frying in industrial palm oils, we slow dry-roast each batch using gentle heat and season them with cold-pressed natural oils, genuine herbs, and vibrant Indian spices.
                        </p>
                        <p style="color: #475569; font-size: 15px; line-height: 1.8;">
                            From tangy <strong>Cheese Tomato</strong> and creamy <strong>Cream &amp; Onion</strong> to zesty <strong>Lemon</strong>, royal <strong>Coriander</strong>, and nostalgic <strong>Pani Puri</strong>, every pouch delivers an irresistible crunch packed with natural plant protein.
                        </p>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <div style="background: #ffffff; border-radius: 16px; padding: 30px; border: 1px solid #e2e8f0; box-shadow: 0 10px 30px rgba(0,0,0,0.06); text-align: center;">
                            <img src="assets/images/favicon.png" alt="Postic Foods" style="max-height: 90px; margin-bottom: 16px;">
                            <h3 style="font-size: 22px; font-weight: 800; color: #d32f2f; margin-bottom: 6px;">100% Roasted In Udaipur</h3>
                            <p style="color: #64748b; font-size: 14px; margin-bottom: 20px;">Lake City Heritage &bull; Traditional Roasting &bull; Modern Food Science</p>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; text-align: left;">
                                <div style="background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px solid #f1f5f9;">
                                    <strong style="color: #0f172a; font-size: 14px; display: block;">Zero Palm Oil</strong>
                                    <span style="color: #64748b; font-size: 12px;">Only cold-pressed natural edible oils.</span>
                                </div>
                                <div style="background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px solid #f1f5f9;">
                                    <strong style="color: #0f172a; font-size: 14px; display: block;">Zero Preservatives</strong>
                                    <span style="color: #64748b; font-size: 12px;">No artificial chemicals or MSG.</span>
                                </div>
                                <div style="background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px solid #f1f5f9;">
                                    <strong style="color: #0f172a; font-size: 14px; display: block;">High Protein</strong>
                                    <span style="color: #64748b; font-size: 12px;">Plant power for daily fitness.</span>
                                </div>
                                <div style="background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px solid #f1f5f9;">
                                    <strong style="color: #0f172a; font-size: 14px; display: block;">Gluten-Free</strong>
                                    <span style="color: #64748b; font-size: 12px;">Gentle on gut and digestion.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 4 Pillars Section -->
                <div style="background: #f8fafc; border-radius: 16px; padding: 45px 30px; margin-bottom: 60px; border: 1px solid #e2e8f0;">
                    <div style="text-align: center; margin-bottom: 35px;">
                        <span style="color: #d32f2f; font-weight: 700; text-transform: uppercase; font-size: 12px; letter-spacing: 1px;">The Postic Standard</span>
                        <h2 style="font-size: 26px; font-weight: 800; color: #1e293b; margin: 4px 0 0 0;">Why India Loves Postic Makhana</h2>
                    </div>

                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6" style="margin-bottom: 20px;">
                            <div style="background: #fff; border-radius: 12px; padding: 24px; height: 100%; border: 1px solid #e2e8f0; text-align: center;">
                                <div style="width: 50px; height: 50px; border-radius: 50%; background: #fef2f2; color: #d32f2f; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 14px;">
                                    <i class="fa fa-fire"></i>
                                </div>
                                <h4 style="font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 8px;">Dry Roasted Perfection</h4>
                                <p style="font-size: 13px; color: #64748b; line-height: 1.6; margin: 0;">We roast our fox nuts with continuous temperature control to preserve crunch without burning.</p>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-sm-6" style="margin-bottom: 20px;">
                            <div style="background: #fff; border-radius: 12px; padding: 24px; height: 100%; border: 1px solid #e2e8f0; text-align: center;">
                                <div style="width: 50px; height: 50px; border-radius: 50%; background: #eff6ff; color: #2563eb; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 14px;">
                                    <i class="fa fa-heartbeat"></i>
                                </div>
                                <h4 style="font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 8px;">Cardio &amp; Diabetes Friendly</h4>
                                <p style="font-size: 13px; color: #64748b; line-height: 1.6; margin: 0;">Low glycemic index and low sodium make it an ideal snack for fitness, diet, and all ages.</p>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-sm-6" style="margin-bottom: 20px;">
                            <div style="background: #fff; border-radius: 12px; padding: 24px; height: 100%; border: 1px solid #e2e8f0; text-align: center;">
                                <div style="width: 50px; height: 50px; border-radius: 50%; background: #fef3c7; color: #d97706; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 14px;">
                                    <i class="fa fa-shield"></i>
                                </div>
                                <h4 style="font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 8px;">Airtight Freshness</h4>
                                <p style="font-size: 13px; color: #64748b; line-height: 1.6; margin: 0;">Multi-layered moisture-barrier pouches keep every bite ultra-crispy from our roastery to your hands.</p>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 col-sm-6" style="margin-bottom: 20px;">
                            <div style="background: #fff; border-radius: 12px; padding: 24px; height: 100%; border: 1px solid #e2e8f0; text-align: center;">
                                <div style="width: 50px; height: 50px; border-radius: 50%; background: #ecfdf5; color: #059669; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 14px;">
                                    <i class="fa fa-truck"></i>
                                </div>
                                <h4 style="font-size: 16px; font-weight: 700; color: #0f172a; margin-bottom: 8px;">Direct Roastery Dispatch</h4>
                                <p style="font-size: 13px; color: #64748b; line-height: 1.6; margin: 0;">Shipped directly across all Indian states with express couriers and fast doorstep tracking.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Call to Action Banner -->
                <div style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border-radius: 16px; padding: 40px; color: #ffffff; text-align: center;">
                    <h3 style="font-size: 24px; font-weight: 800; color: #ffffff; margin-bottom: 8px;">Ready to Upgrade Your Daily Snacking?</h3>
                    <p style="font-size: 15px; color: #94a3b8; max-width: 600px; margin: 0 auto 24px auto;">
                        Taste the crunch of 100% natural, slow-roasted Makhana in your favorite savory flavors.
                    </p>
                    <div style="display: flex; justify-content: center; gap: 14px; flex-wrap: wrap;">
                        <a href="all_product.php" class="btn" style="background: #d32f2f; color: #fff; font-weight: 700; padding: 12px 28px; border-radius: 25px; text-decoration: none; font-size: 14px;">
                            <i class="fa fa-shopping-basket"></i> Explore All Flavors
                        </a>
                        <a href="https://wa.me/919216398316?text=Hi%20Postic,%20I%20want%20to%20know%20more%20about%20your%20products" target="_blank" class="btn" style="background: #25D366; color: #fff; font-weight: 700; padding: 12px 28px; border-radius: 25px; text-decoration: none; font-size: 14px;">
                            <i class="fa fa-whatsapp"></i> Chat on WhatsApp
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- FOOTER -->
    <?php
    include_once("includes/footer.php");
    include_once("includes/mobile_footer.php");
    include_once("includes/mobile_global.php");
    ?>

    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>
    <?php include_once("includes/script.php"); ?>
</body>
</html>
