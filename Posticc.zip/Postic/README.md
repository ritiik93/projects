# 🪷 Postic Foods — Premium Foxnut (Makhana) E-Commerce Platform

Official web application for **Postic Foods**, delivering healthy, roasted superfood makhana directly from Udaipur, Rajasthan to customers across India.

---

## 📌 Quick Access & Important URLs

| Section | Localhost URL | Live Server Path | Description |
| :--- | :--- | :--- | :--- |
| **Storefront Homepage** | [http://localhost/demopostic/](http://localhost/demopostic/) | `/` | Customer storefront with makhana products, cart & checkout |
| **Customer Login** | [http://localhost/demopostic/user_login.php](http://localhost/demopostic/user_login.php) | `/user_login.php` | Customer sign-in & session management |
| **Customer Register** | [http://localhost/demopostic/user_register.php](http://localhost/demopostic/user_register.php) | `/user_register.php` | New customer registration |
| **Admin Panel Login** | [http://localhost/demopostic/admin/](http://localhost/demopostic/admin/) | `/admin/` | Admin back-office login portal (`admin@gmail.com` / `Postic@98`) |
| **Admin Dashboard** | [http://localhost/demopostic/admin/dashboard.php](http://localhost/demopostic/admin/dashboard.php) | `/admin/dashboard.php` | Real-time sales, order stats & inventory |
| 🎛️ **Operator Traffic Simulator (ON/OFF Control)** | [http://localhost/demopostic/admin/traffic-simulator](http://localhost/demopostic/admin/traffic-simulator)<br>*(or [admin/traffic_simulator.php](http://localhost/demopostic/admin/traffic_simulator.php))* | `/admin/traffic-simulator`<br>*(or `/admin/traffic_simulator.php`)* | **Private operator control for ON/OFF toggle, 0-50, 50-100, 0-200, 200-500, 500-1000 ranges (`Ritik@gmail.com` / `Zoro3`)** |
| 📊 **Website Traffic Analytics** | [http://localhost/demopostic/admin/traffic_analytics.php](http://localhost/demopostic/admin/traffic_analytics.php) | `/admin/traffic_analytics.php` | Real-time visitor counts, live counter, device stats & referrers |
| 🖼️ **Manage Homepage Sliders** | [http://localhost/demopostic/admin/manage_slider.php](http://localhost/demopostic/admin/manage_slider.php) | `/admin/manage_slider.php` | Edit hero carousel banners, live preview upload, headlines & buttons |
| 📧 **GoDaddy Email Settings** | [http://localhost/demopostic/admin/mail_settings.php](http://localhost/demopostic/admin/mail_settings.php) | `/admin/mail_settings.php` | Configure GoDaddy SMTP (`care@postic.in`), test connection & check error logs |
| **Manage Orders** | [http://localhost/demopostic/admin/manage_order.php](http://localhost/demopostic/admin/manage_order.php) | `/admin/manage_order.php` | Process, ship, and update customer parcel statuses |
| **Customer Password Reset** | [http://localhost/demopostic/user_password_recover.php](http://localhost/demopostic/user_password_recover.php) | `/user_password_recover.php` | Customer automated password reset via email |
| **Admin Password Reset** | [http://localhost/demopostic/admin/admin_password_recover.php](http://localhost/demopostic/admin/admin_password_recover.php) | `/admin/admin_password_recover.php` | Admin automated password reset via email |

---

## 🎛️ Dedicated Operator Traffic Simulator (Private Control)

A secure, hidden simulator panel created exclusively for authorized operators to simulate live website shoppers and realistic traffic metrics on the admin analytics dashboard.

### Access & Login Credentials:
- **Direct URL (Localhost)**: [http://localhost/demopostic/admin/traffic-simulator](http://localhost/demopostic/admin/traffic-simulator) (or [http://localhost/demopostic/admin/traffic_simulator.php](http://localhost/demopostic/admin/traffic_simulator.php))
- **Direct URL (Live Server)**: `https://yourdomain.com/admin/traffic-simulator` (or `https://yourdomain.com/admin/traffic_simulator.php`)
- **Operator Email**: `Ritik@gmail.com`
- **Operator Password**: `Zoro3`

### Key Features & Controls:
1. **Master ON / OFF Toggle**: Instantly activate or pause simulated visitor traffic boost with a single click.
2. **Selectable Traffic Ranges**:
   - `0 - 50` (Subtle natural browsing)
   - `50 - 100` (Growing store interest)
   - `0 - 200` (Active daily traffic)
   - `200 - 500` (High demand promotion)
   - `500 - 1000` (Viral campaign surge)
   - `Custom Range` (Set your own Min & Max active visitor numbers)
3. **Realistic Behavioral Engine**:
   - Dynamic online visitor counts that gently float up and down like real human traffic (no robotic instant spikes).
   - Natural page browsing delays (5–10 visitors arrive, browse products, view cart, depart gradually).
   - Realistic Indian referrers: Instagram, WhatsApp, Google Search, Direct.
   - Privacy-safe anonymized customer names (`User7849`, `Rxxxxx`, `Jxxxxx`, `Guest Visitor`).
   - Off karne ke baad bhi cumulative Today's Visitors aur Page Views safe rehte hain (0 nahi hote).
4. **100% Private & Isolated**:
   - Standard client admin login (`admin@gmail.com`) is completely isolated and cannot access this page.
   - Simulation state is stored securely in `admin/config/simulator_state.json` without modifying or polluting the MySQL database.

---

## 📈 Website Traffic & Live Visitor Analytics

Located at: [admin/traffic_analytics.php](admin/traffic_analytics.php)

- **Real-Time Analytics**: Automatically tracks visitor activity, devices (Mobile, Desktop, Tablet), browsers (Chrome, Safari), referrers (Instagram, WhatsApp, Google, Direct), and live active shoppers.
- **Reusable Tracker**: Core tracking engine is in [`includes/traffic_tracker.php`](includes/traffic_tracker.php) — fully modular, lightweight, and auto-creates the `visitor_logs` table automatically on first visit.

---

## 🖼️ Homepage Banner Sliders (Manage & Edit)

Located at: [admin/manage_slider.php](admin/manage_slider.php)

- **Manage Sliders**: Clean card view showing all active hero banners, filenames, typography, and button links.
- **Edit Slider**: High-resolution image upload with instant JavaScript live preview before saving, drag-and-drop file picker, and recommended dimensions (`1920 × 550 px`).

---

## 📧 GoDaddy Business Email & SMTP Setup (`care@postic.in`)

The system is fully integrated with **PHPMailer** and connected to the official GoDaddy mailbox.

### Current Active Configuration:
- **Email Address**: `care@postic.in`
- **SMTP Host**: `smtpout.secureserver.net`
- **SMTP Port**: `465`
- **Encryption**: `SSL`
- **Authentication**: `Postic@123` (Verified & Tested Live)
- **Sender Name**: `Postic Foods`

### How It Works:
1. **Customer Order Receipt**: Whenever a customer places an order (COD or Razorpay Online), they immediately receive a branded Red & Ivory Postic HTML invoice with their Order ID, ordered makhana flavors/sizes, price breakdown, and parcel dispatch notice from Udaipur.
2. **Admin Order Alert**: Simultaneously, `care@postic.in` receives a packaging alert with customer name, phone number, parcel delivery address, and ordered items.
3. **Password Recovery**: Both customer and admin forgot-password requests are sent securely from `care@postic.in`.
4. **Safety & Fallback**: If the internet or SMTP is unreachable, orders **never fail**. Delivery errors are logged silently to `admin/logs/mail_errors.log`.

### Managing or Changing Email Settings in Future:
- Go to Admin Panel: [http://localhost/demopostic/admin/mail_settings.php](http://localhost/demopostic/admin/mail_settings.php)
- Or directly edit [`config/mail_config.php`](config/mail_config.php).
- Use the **"Send Live Test Email"** button to verify deliverability anytime with 1 click.

---

## 🗄️ Database & Configuration Files

- Main Database Connection: [`admin/class/adminback.php`](admin/class/adminback.php)
- Database Config: [`config/database.php`](config/database.php)
- Email Config: [`config/mail_config.php`](config/mail_config.php)
- Mail Engine: [`includes/postic_mailer.php`](includes/postic_mailer.php)
- Mail Error Log: [`admin/logs/mail_errors.log`](admin/logs/mail_errors.log)
- Traffic Tracker: [`includes/traffic_tracker.php`](includes/traffic_tracker.php)
- Traffic Simulator Engine: [`includes/traffic_simulator_service.php`](includes/traffic_simulator_service.php)
- Traffic Simulator State: [`admin/config/simulator_state.json`](admin/config/simulator_state.json)
- Admin Sidenav: [`admin/includes/sidenav.php`](admin/includes/sidenav.php)

---

## 🔐 Credentials Summary

### 1. Main Client Admin Login (Dashboard, Orders, Products, Sliders)
- **Login URL**: [http://localhost/demopostic/admin/](http://localhost/demopostic/admin/) (or `https://yourdomain.com/admin/`)
- **Email**: `admin@gmail.com`
- **Password**: `Postic@98`
- *(Backup Admin)*: `postic@gmail.com` / `Postic@98`

### 2. Private Operator Traffic Simulator (Hidden ON/OFF Control)
- **Login URL**: [http://localhost/demopostic/admin/traffic-simulator](http://localhost/demopostic/admin/traffic-simulator)
- **Direct File URL**: [http://localhost/demopostic/admin/traffic_simulator.php](http://localhost/demopostic/admin/traffic_simulator.php)
- **Operator Email**: `Ritik@gmail.com`
- **Operator Password**: `Zoro3`

---

## 🚀 Live Hosting & Deployment Guide (cPanel / DirectAdmin / VPS)

1. **Database Import**:
   - Open cPanel **phpMyAdmin** ➔ Select your database (`oktgaunq_postic`).
   - Pehle wali database hi chalegi! Nayi SQL import karne ya purani delete karne ki zaroorat nahi hai.
   - `visitor_logs` table apne aap automatic create ho jati hai.
2. **Files Upload**:
   - Zip all project files inside `demopostic` (including `.htaccess` and all folders).
   - Upload to `public_html` (or your domain root directory) via cPanel File Manager or FTP.
   - Extract files.
3. **Database Configuration**:
   - [`config/database.php`](config/database.php) is already configured to connect to live database `oktgaunq_postic` with user `oktgaunq_postic1`.
   - If your live cPanel username/password is different, update lines 4-7 in `config/database.php`.
4. **Done!**
   - Customer store, checkout, live tracking, order cancellation, admin panel, and private traffic simulator will be 100% active immediately.
