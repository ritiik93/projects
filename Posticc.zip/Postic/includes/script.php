    <script>if (typeof jQuery === 'undefined') { document.write('<script src="assets/js/jquery-3.4.1.min.js"><\/script>'); }</script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.countdown.min.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/jquery.nicescroll.min.js"></script>
    <script src="assets/js/slick.min.js"></script>
    <script src="assets/js/biolife.framework.js"></script>
    <script src="assets/js/functions.js"></script>
<style>
@keyframes posticSlideInRight {
    from { opacity: 0; transform: translateX(40px); }
    to { opacity: 1; transform: translateX(0); }
}
.postic-toast-item {
    animation: posticSlideInRight 0.28s cubic-bezier(0.16, 1, 0.3, 1);
}
</style>
<script>
$(document).ready(function() {
    // Global toast container
    if ($("#postic-toast-container").length === 0) {
        $("body").append('<div id="postic-toast-container" style="position: fixed; top: 24px; right: 24px; z-index: 999999; display: flex; flex-direction: column; gap: 10px; pointer-events: none; max-width: 90vw;"></div>');
    }

    function showPosticCartToast(productName, cartCount, cartTotal) {
        var toastId = "postic-toast-" + Date.now();
        var toastHtml = '<div id="' + toastId + '" class="postic-toast-item" style="pointer-events: auto; background: #ffffff; color: #1e293b; border: 1px solid #e2e8f0; border-left: 5px solid #16a34a; border-radius: 12px; padding: 12px 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.15); display: flex; align-items: center; gap: 12px; min-width: 300px; max-width: 400px;">' +
            '<div style="width: 36px; height: 36px; border-radius: 50%; background: #dcfce7; color: #16a34a; display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0;"><i class="fa fa-check"></i></div>' +
            '<div style="flex: 1; overflow: hidden;">' +
                '<strong style="font-size: 13px; color: #0f172a; display: block; line-height: 1.2;">Added to Cart!</strong>' +
                '<span style="font-size: 12px; color: #64748b; display: block; margin-top: 2px; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">' + (productName || "Product") + '</span>' +
            '</div>' +
            '<a href="addtocart.php" style="background: #c8102e; color: #ffffff; font-size: 11px; font-weight: 800; padding: 6px 12px; border-radius: 20px; text-decoration: none; white-space: nowrap; flex-shrink: 0; box-shadow: 0 2px 6px rgba(200,16,46,0.25);">View Cart</a>' +
            '<button type="button" onclick="$(\'#' + toastId + '\').fadeOut(200, function(){ $(this).remove(); });" style="background: none; border: none; color: #94a3b8; font-size: 16px; cursor: pointer; padding: 0 4px; line-height: 1;">&times;</button>' +
        '</div>';

        $("#postic-toast-container").append(toastHtml);
        setTimeout(function() {
            $("#" + toastId).fadeOut(350, function() { $(this).remove(); });
        }, 4000);
    }

    function updateHeaderCartBadges(count, total) {
        // Desktop Header Count
        var $countBadge = $(".postic-cart-count-badge");
        if ($countBadge.length) {
            $countBadge.text(count);
            $countBadge.css("transform", "scale(1.3)");
            setTimeout(function() { $countBadge.css("transform", "scale(1)"); }, 220);
        }

        // Desktop Header Total
        var $totalBadge = $(".postic-cart-total-badge");
        if ($totalBadge.length) {
            $totalBadge.text("₹" + total).show();
        }

        // Mobile Footer Count
        var $mbCount = $(".block-minicart .link-to-cart span:not(.fa):not(.text)");
        if ($mbCount.length) {
            $mbCount.text(count);
        } else if (count > 0) {
            $(".block-minicart .link-to-cart").append('<span style="position:absolute; top:-3px; right:20%; background:#e74c3c; color:#fff; border-radius:50%; font-size:10px; min-width:16px; height:16px; line-height:16px; text-align:center; font-weight:700; padding:0 3px; display:inline-block;">' + count + '</span>');
        }
        var $mbBadge = $(".postic-mb-cart-badge");
        if ($mbBadge.length) {
            $mbBadge.text(count).css("display", count > 0 ? "inline-block" : "none");
        }
    }

    // Product Card Stepper [- 1 +]
    $(document).on("click", ".postic-card-qty-btn.minus", function(e) {
        e.preventDefault();
        var $input = $(this).siblings(".postic-card-qty-val");
        var val = parseInt($input.val(), 10) || 1;
        if (val > 1) {
            $input.val(val - 1);
        }
    });

    $(document).on("click", ".postic-card-qty-btn.plus", function(e) {
        e.preventDefault();
        var $input = $(this).siblings(".postic-card-qty-val");
        var val = parseInt($input.val(), 10) || 1;
        if (val < 10) {
            $input.val(val + 1);
        }
    });

    // Notification Bell Dropdown Toggle
    $(document).on("click", "#posticNotifyBellBtn", function(e) {
        e.stopPropagation();
        $("#posticNotifyDropdown").fadeToggle(180);
    });

    $(document).on("click", "#posticMarkReadBtn", function(e) {
        e.preventDefault();
        e.stopPropagation();
        $("#posticNotifyBadge").fadeOut(200);
        $(this).text("All caught up!").css("color", "#16a34a").css("textDecoration", "none");
    });

    // Account Dropdown in Desktop Nav
    $(document).on("click", ".postic-account-nav-item > a", function(e) {
        e.preventDefault();
        e.stopPropagation();
        $(this).siblings(".postic-account-dropdown-menu").fadeToggle(150);
    });

    // Global click outside to dismiss popups
    $(document).on("click", function(e) {
        if (!$(e.target).closest("#posticNotifyBellBtn, #posticNotifyDropdown").length) {
            $("#posticNotifyDropdown").fadeOut(150);
        }
        if (!$(e.target).closest(".postic-account-nav-item").length) {
            $(".postic-account-dropdown-menu").fadeOut(150);
        }
    });

    // Mobile Slide-in Drawer open/close
    function openPosticMobileDrawer() {
        $("#posticDrawerOverlay").fadeIn(200);
        $("#posticMobileDrawer").css("left", "0");
        $("body").css("overflow", "hidden");
    }

    function closePosticMobileDrawer() {
        $("#posticDrawerOverlay").fadeOut(200);
        $("#posticMobileDrawer").css("left", "-310px");
        $("body").css("overflow", "");
    }

    $(document).on("click", "#posticMobileMenuToggle, #posticMbFooterMenuBtn", function(e) {
        e.preventDefault();
        openPosticMobileDrawer();
    });

    $(document).on("click", "#posticDrawerCloseBtn, #posticDrawerOverlay", function(e) {
        e.preventDefault();
        closePosticMobileDrawer();
    });

    // Intercept product card Add-to-Cart form submissions
    $(document).on("submit", ".postic-ajax-cart-form", function(e) {
        e.preventDefault();
        var $form = $(this);
        var $btn = $form.find(".postic-add-to-cart-btn, button[type='submit']");
        var origHtml = $btn.html();
        var origBg = $btn.css("background");

        $btn.prop("disabled", true).html('<i class="fa fa-spinner fa-spin"></i> Adding...');

        $.ajax({
            url: "addtocart.php",
            type: "POST",
            data: $form.serialize() + "&ajax=1",
            dataType: "json",
            success: function(resp) {
                if (resp && resp.status === "success") {
                    $btn.html('<i class="fa fa-check"></i> Added!').css("background", "#16a34a");
                    updateHeaderCartBadges(resp.cart_count, resp.cart_total);
                    showPosticCartToast(resp.pdt_name, resp.cart_count, resp.cart_total);
                    setTimeout(function() {
                        $btn.prop("disabled", false).html(origHtml).css("background", origBg);
                    }, 1600);
                } else {
                    $form.off("submit").submit();
                }
            },
            error: function() {
                $form.off("submit").submit();
            }
        });
    });

    // Intercept single_product.php Add To Cart button
    $(document).on("click", "button[name='addtocart'].postic-single-addtocart", function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $form = $btn.closest("form");
        var origHtml = $btn.html();
        var origBg = $btn.css("background");
        var origBorder = $btn.css("borderColor");

        $btn.prop("disabled", true).html('<i class="fa fa-spinner fa-spin"></i> Adding...');

        $.ajax({
            url: "addtocart.php",
            type: "POST",
            data: $form.serialize() + "&addtocart=1&ajax=1",
            dataType: "json",
            success: function(resp) {
                if (resp && resp.status === "success") {
                    $btn.html('<i class="fa fa-check"></i> Added to Cart!').css("background", "#16a34a").css("borderColor", "#16a34a");
                    updateHeaderCartBadges(resp.cart_count, resp.cart_total);
                    showPosticCartToast(resp.pdt_name, resp.cart_count, resp.cart_total);
                    setTimeout(function() {
                        $btn.prop("disabled", false).html(origHtml).css("background", origBg).css("borderColor", origBorder);
                    }, 1600);
                } else {
                    $btn.off("click").click();
                }
            },
            error: function() {
                $btn.off("click").click();
            }
        });
    });
});
</script>
