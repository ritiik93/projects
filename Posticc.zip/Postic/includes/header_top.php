<?php 
// Postic Clean Top Announcement Bar
if (!isset($obj)) {
    $obj = new adminback();
}
$links = $obj->display_links();
$link = ($links && mysqli_num_rows($links) > 0) ? mysqli_fetch_assoc($links) : array();
$header_email = !empty($link['email']) ? $link['email'] : 'care@postic.in';
$header_phone = !empty($link['phone']) ? $link['phone'] : '+91 9216398316';
?>
<div class="postic-top-announcement-bar" style="background: #c8102e; color: #ffffff; padding: 7px 0; font-size: 12px; font-weight: 700; border-bottom: 1px solid #991b1b; letter-spacing: 0.2px;">
    <div class="container">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="font-size: 12px; font-weight: 800; color: #ffffff; display: inline-flex; align-items: center; gap: 6px;">
                    <i class="fa fa-truck" style="color: #fde047;"></i> Free shipping on orders over ₹299
                </span>
            </div>
            <div class="hidden-xs" style="display: flex; align-items: center; gap: 16px; font-size: 12px;">
                <a href="tel:<?php echo htmlspecialchars($header_phone); ?>" style="color: #ffffff; text-decoration: none;">
                    <i class="fa fa-phone" style="color: #fde047;"></i> <?php echo htmlspecialchars($header_phone); ?>
                </a>
                <a href="#partner-section" style="color: #ffffff; text-decoration: underline; font-weight: 800;">
                    <i class="fa fa-handshake-o" style="color: #fde047;"></i> Partner Desk
                </a>
                <?php if (isset($_SESSION['user_id'])) { 
                    $display_username = !empty($_SESSION['username']) ? $_SESSION['username'] : 'Account';
                ?>
                    <a href="userprofile.php" style="color: #ffffff; text-decoration: none;"><i class="fa fa-user"></i> <?php echo htmlspecialchars($display_username); ?></a>
                    <a href="userprofile.php?logout=logout" style="color: #ffffff; text-decoration: none; opacity: 0.85;"><i class="fa fa-sign-out"></i> Logout</a>
                <?php } else { ?>
                    <a href="user_login.php" style="color: #ffffff; text-decoration: none;"><i class="fa fa-user-circle"></i> Login</a>
                <?php } ?>
            </div>
        </div>
    </div>
</div>