<?php
// Postic Clean D2C Quality & Craft Pillars (Theme Matched to Postic Warm Ivory & Crimson)
?>
<div class="postic-highlights-strip" style="background: #fbf8f2; padding: 40px 0; border-top: 1px solid #ede8df; border-bottom: 1px solid #ede8df; overflow: hidden;">
    <div class="container">
        <div class="postic-pillars-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; align-items: stretch;">
            <!-- Pillar 1 -->
            <div class="postic-pillar-card" style="background: #ffffff; border: 1px solid #ede8df; border-radius: 14px; padding: 22px 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02); display: flex; flex-direction: column;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: #fef2f2; color: #c8102e; display: flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 14px;">
                    🔥
                </div>
                <h4 style="font-size: 16px; font-weight: 800; color: #1c1917; margin: 0 0 6px 0; line-height: 1.3;">100% Hot-Air Roasted</h4>
                <p style="font-size: 13px; color: #78716c; margin: 0; line-height: 1.5;">Never deep-fried in reheated oils. Zero palm oil, zero trans fat, and zero greasy fingers.</p>
            </div>

            <!-- Pillar 2 -->
            <div class="postic-pillar-card" style="background: #ffffff; border: 1px solid #ede8df; border-radius: 14px; padding: 22px 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02); display: flex; flex-direction: column;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: #fef3c7; color: #d97706; display: flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 14px;">
                    🌿
                </div>
                <h4 style="font-size: 16px; font-weight: 800; color: #1c1917; margin: 0 0 6px 0; line-height: 1.3;">All-Natural Spices</h4>
                <p style="font-size: 13px; color: #78716c; margin: 0; line-height: 1.5;">Tossed in cold-pressed oils with royal Rajasthani herbs &amp; spices. No MSG or artificial chemicals.</p>
            </div>

            <!-- Pillar 3 -->
            <div class="postic-pillar-card" style="background: #ffffff; border: 1px solid #ede8df; border-radius: 14px; padding: 22px 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02); display: flex; flex-direction: column;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: #fef2f2; color: #c8102e; display: flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 14px;">
                    💪
                </div>
                <h4 style="font-size: 16px; font-weight: 800; color: #1c1917; margin: 0 0 6px 0; line-height: 1.3;">Plant Protein &amp; Fiber</h4>
                <p style="font-size: 13px; color: #78716c; margin: 0; line-height: 1.5;">Ancient sacred lotus seeds naturally loaded with iron, calcium, and antioxidants for daily vitality.</p>
            </div>

            <!-- Pillar 4 -->
            <div class="postic-pillar-card" style="background: #ffffff; border: 1px solid #ede8df; border-radius: 14px; padding: 22px 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02); display: flex; flex-direction: column;">
                <div style="width: 44px; height: 44px; border-radius: 12px; background: #fef3c7; color: #d97706; display: flex; align-items: center; justify-content: center; font-size: 20px; margin-bottom: 14px;">
                    🏰
                </div>
                <h4 style="font-size: 16px; font-weight: 800; color: #1c1917; margin: 0 0 6px 0; line-height: 1.3;">Royal Udaipur Roastery</h4>
                <p style="font-size: 13px; color: #78716c; margin: 0; line-height: 1.5;">Freshly roasted and packed in airtight 55g pouches in Udaipur, Rajasthan &bull; Shipped pan-India.</p>
            </div>
        </div>
    </div>
</div>
