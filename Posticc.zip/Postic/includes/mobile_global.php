<div class="mobile-block-global">
    <div class="biolife-mobile-panels">
        <span class="biolife-current-panel-title">Postic Quick Links</span>
        <a class="biolife-close-btn" data-object="global-panel-opened" href="#">&times;</a>
    </div>
    <div class="block-global-contain">
        <div class="glb-item my-account">
            <b class="title">My Account</b>
            <ul class="list">
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <li class="list-item"><a href="userprofile.php"><i class="fa fa-user"></i> My Profile & Cart</a></li>
                    <li class="list-item"><a href="exist_order.php"><i class="fa fa-list"></i> My Orders</a></li>
                    <li class="list-item"><a href="user_login.php?logout=true"><i class="fa fa-sign-out"></i> Logout</a></li>
                <?php } else { ?>
                    <li class="list-item"><a href="user_login.php"><i class="fa fa-sign-in"></i> Login</a></li>
                    <li class="list-item"><a href="user_register.php"><i class="fa fa-user-plus"></i> Register</a></li>
                    <li class="list-item"><a href="addtocart.php"><i class="fa fa-shopping-cart"></i> View Cart</a></li>
                <?php } ?>
            </ul>
        </div>
        <div class="glb-item currency">
            <b class="title">Currency</b>
            <ul class="list">
                <li class="list-item"><a href="#" style="font-weight:700; color:#d32f2f;">₹ INR (Indian Rupee)</a></li>
            </ul>
        </div>
        <div class="glb-item contact-quick" style="margin-top:15px; padding-top:15px; border-top:1px solid #eee;">
            <b class="title">Direct Contact</b>
            <p style="font-size:13px; color:#555; margin:6px 0;"><i class="fa fa-map-marker"></i> Udaipur, Rajasthan, India</p>
            <p style="font-size:13px; color:#555; margin:6px 0;"><i class="fa fa-phone"></i> <a href="tel:+919216398316">+91 9216398316</a></p>
            <p style="font-size:13px; color:#555; margin:6px 0;"><i class="fa fa-envelope"></i> <a href="mailto:care@postic.in">care@postic.in</a></p>
        </div>
    </div>
</div>