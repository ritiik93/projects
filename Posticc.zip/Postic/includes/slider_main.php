<?php
// Postic High-Resolution Banner Slider (Full Artwork Visible, No Cropping/Clipping)
if (!isset($obj)) {
    $obj = new adminback();
}
$rows = $obj->SlideShow();
$slides = array();
if ($rows && mysqli_num_rows($rows) > 0) {
    while ($row = mysqli_fetch_assoc($rows)) {
        if (!empty($row['slider_img'])) {
            $slides[] = $row['slider_img'];
        }
    }
}
if (empty($slides)) {
    $slides = array('ct-banner1.png', 'co-banner4.png', 'pp-banner3.png', 'ct-ppbanner2.png');
}
?>
<div class="postic-hero-slider-wrap" style="position: relative; overflow: hidden; background: #fffdfa; width: 100%;">
    <ul class="biolife-carousel nav-center-03" data-slick='{"arrows": true, "dots": true, "slidesMargin": 0, "slidesToShow": 1, "infinite": true, "autoplay": true, "autoplaySpeed": 5000, "speed": 600, "adaptiveHeight": true}'>
        <?php foreach ($slides as $slide_img) { ?>
            <li style="margin: 0; padding: 0; outline: none;">
                <a href="all_product.php" style="display: block; width: 100%; text-decoration: none; outline: none;">
                    <img src="admin/uploads/<?php echo htmlspecialchars($slide_img); ?>" alt="Postic Makhana Banner" style="width: 100%; height: auto; display: block; margin: 0 auto; border-radius: 0;">
                </a>
            </li>
        <?php } ?>
    </ul>
</div>