<div class="header-search-bar layout-01" style="position: relative;">
    <form action="search_product.php" class="form-search" name="desktop-search" method="get" autocomplete="off" style="position: relative;">
        <input type="text" name="keyword" id="postic-search-input" class="input-text" placeholder="Search delicious Makhana (Cheese, Cream, Onion...)" autocomplete="off">
        <input type="submit" class="btn-submit" value="Search" name="search" style="margin-top: 8px;">
        <div id="postic-search-dropdown" class="postic-search-dropdown" style="display: none;"></div>
    </form>
</div>

<style>
.postic-search-dropdown {
    position: absolute;
    top: calc(100% + 5px);
    left: 0;
    right: 0;
    background: #ffffff;
    border-radius: 8px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.18);
    border: 1px solid #e5e7eb;
    z-index: 999999;
    max-height: 420px;
    overflow-y: auto;
    font-family: inherit;
    text-align: left;
}
.postic-search-item {
    display: flex;
    align-items: center;
    padding: 10px 14px;
    text-decoration: none !important;
    border-bottom: 1px solid #f3f4f6;
    transition: background 0.15s ease-in-out;
}
.postic-search-item:last-child {
    border-bottom: none;
}
.postic-search-item:hover, .postic-search-item:focus {
    background: #f8fafc;
}
.postic-search-thumb {
    width: 46px;
    height: 46px;
    object-fit: cover;
    border-radius: 6px;
    border: 1px solid #e5e7eb;
    margin-right: 12px;
    flex-shrink: 0;
    background: #fff;
}
.postic-search-info {
    flex-grow: 1;
    min-width: 0;
}
.postic-search-title {
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
    margin: 0 0 2px 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.postic-search-badge {
    display: inline-block;
    font-size: 11px;
    padding: 1px 8px;
    background: #fef2f2;
    color: #b91c1c;
    border: 1px solid #fee2e2;
    border-radius: 10px;
    font-weight: 600;
    margin-right: 6px;
}
.postic-search-price {
    font-size: 14px;
    font-weight: 700;
    color: #d32f2f;
    margin-left: 10px;
    flex-shrink: 0;
}
.postic-search-footer {
    padding: 10px 14px;
    background: #fef2f2;
    text-align: center;
    border-top: 1px solid #fee2e2;
}
.postic-search-footer a {
    color: #b71c1c;
    font-weight: 700;
    font-size: 13px;
    text-decoration: none;
}
.postic-search-footer a:hover {
    text-decoration: underline;
    color: #991b1b;
}
.postic-search-empty {
    padding: 20px;
    text-align: center;
    color: #6b7280;
    font-size: 13px;
}
</style>

<script>
(function() {
    function setupSearch(inputId, dropdownId) {
        var input = document.getElementById(inputId);
        var dropdown = document.getElementById(dropdownId);
        if (!input || !dropdown) return;

        var debounceTimer = null;

        input.addEventListener('input', function() {
            var query = this.value.trim();
            clearTimeout(debounceTimer);

            if (query.length < 1) {
                dropdown.style.display = 'none';
                dropdown.innerHTML = '';
                return;
            }

            debounceTimer = setTimeout(function() {
                fetch('json/live_search.php?query=' + encodeURIComponent(query))
                    .then(function(res) { return res.json(); })
                    .then(function(response) {
                        if (response.status === 'success' && response.data && response.data.length > 0) {
                            var html = '';
                            response.data.forEach(function(item) {
                                var imgSrc = 'admin/uploads/' + encodeURIComponent(item.img);
                                var categoryBadge = item.category ? '<span class="postic-search-badge">' + escapeHtml(item.category) + '</span>' : '';
                                html += '<a href="' + escapeHtml(item.url) + '" class="postic-search-item">' +
                                    '<img src="' + imgSrc + '" class="postic-search-thumb" alt="' + escapeHtml(item.name) + '" onerror="this.src=\'admin/uploads/logo.png\'">' +
                                    '<div class="postic-search-info">' +
                                        '<p class="postic-search-title">' + escapeHtml(item.name) + '</p>' +
                                        categoryBadge +
                                    '</div>' +
                                    '<span class="postic-search-price">₹ ' + item.price + '</span>' +
                                '</a>';
                            });
                            html += '<div class="postic-search-footer">' +
                                '<a href="search_product.php?keyword=' + encodeURIComponent(query) + '&search=search">' +
                                    'View all results for "<strong>' + escapeHtml(query) + '</strong>" &rarr;' +
                                '</a>' +
                            '</div>';
                            dropdown.innerHTML = html;
                            dropdown.style.display = 'block';
                        } else {
                            dropdown.innerHTML = '<div class="postic-search-empty">No Makhana found matching "<strong>' + escapeHtml(query) + '</strong>".<br><small>Try searching Cheese, Lemon, Coriander, or Onion</small></div>';
                            dropdown.style.display = 'block';
                        }
                    })
                    .catch(function(err) {
                        console.error('Postic Live Search error:', err);
                    });
            }, 250);
        });

        document.addEventListener('click', function(e) {
            if (!input.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.style.display = 'none';
            }
        });

        input.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                dropdown.style.display = 'none';
            }
        });

        input.addEventListener('focus', function() {
            if (this.value.trim().length >= 1 && dropdown.innerHTML.trim() !== '') {
                dropdown.style.display = 'block';
            }
        });

        function escapeHtml(text) {
            if (!text) return '';
            var div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    }

    function initPosticSearch() {
        setupSearch('postic-search-input', 'postic-search-dropdown');
        setupSearch('postic-mobile-search-input', 'postic-mobile-search-dropdown');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPosticSearch);
    } else {
        initPosticSearch();
    }
})();
</script>