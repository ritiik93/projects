<?php
// Postic Verified Customer Reviews & Social Proof
?>
<section class="postic-reviews-section" style="padding: 55px 0 50px 0; background: #ffffff; border-top: 1px solid #ede8df;">
    <div class="container">
        <div class="text-center" style="margin-bottom: 35px;">
            <div style="display: inline-flex; align-items: center; gap: 6px; margin-bottom: 8px;">
                <span style="color: #f59e0b; font-size: 14px;">★★★★★</span>
                <span style="font-size: 12px; font-weight: 800; color: #166534; text-transform: uppercase; letter-spacing: 1px;">4.9 / 5 Rating</span>
            </div>
            <h2 style="font-size: 32px; font-weight: 900; color: #1c1917; margin: 0 0 10px 0; letter-spacing: -0.6px;">
                Loved by Snackers Across Bharat
            </h2>
            <p style="font-size: 14px; color: #78716c; max-width: 540px; margin: 0 auto;">
                Read what health-conscious foodies and families say about Postic's hot-air roasted crunch.
            </p>
        </div>

        <div class="row">
            <!-- Review 1 -->
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="margin-bottom: 20px;">
                <div style="background: #fdfbf7; border: 1px solid #ede8df; border-radius: 16px; padding: 22px 20px; height: 100%; display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                        <span style="color: #f59e0b; font-size: 14px;">★★★★★</span>
                        <span style="font-size: 11px; color: #166534; font-weight: 800; background: #f0fdf4; padding: 2px 8px; border-radius: 10px;">Verified Buyer</span>
                    </div>
                    <p style="font-size: 14px; color: #44403c; line-height: 1.6; margin: 0 0 16px 0; flex-grow: 1;">
                        "The Cheese Tomato flavor is absolutely unbeatable. The best part is zero oily residue on fingers while working at my desk. 10/10 recommend!"
                    </p>
                    <div style="display: flex; align-items: center; gap: 10px; border-top: 1px solid #ede8df; padding-top: 12px;">
                        <div style="width: 36px; height: 36px; border-radius: 50%; background: #fee2e2; color: #c8102e; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 13px;">
                            PS
                        </div>
                        <div>
                            <strong style="font-size: 13px; color: #1c1917; display: block;">Priya Sharma</strong>
                            <span style="font-size: 11px; color: #78716c;">Jaipur, Rajasthan</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Review 2 -->
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="margin-bottom: 20px;">
                <div style="background: #fdfbf7; border: 1px solid #ede8df; border-radius: 16px; padding: 22px 20px; height: 100%; display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                        <span style="color: #f59e0b; font-size: 14px;">★★★★★</span>
                        <span style="font-size: 11px; color: #166534; font-weight: 800; background: #f0fdf4; padding: 2px 8px; border-radius: 10px;">Verified Buyer</span>
                    </div>
                    <p style="font-size: 14px; color: #44403c; line-height: 1.6; margin: 0 0 16px 0; flex-grow: 1;">
                        "Finally a snack brand where you don't have to worry about palm oil. Cream &amp; Onion has that perfect subtle sour-cream tang. My kids love it."
                    </p>
                    <div style="display: flex; align-items: center; gap: 10px; border-top: 1px solid #ede8df; padding-top: 12px;">
                        <div style="width: 36px; height: 36px; border-radius: 50%; background: #ecfdf5; color: #166534; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 13px;">
                            AM
                        </div>
                        <div>
                            <strong style="font-size: 13px; color: #1c1917; display: block;">Amit Mehta</strong>
                            <span style="font-size: 11px; color: #78716c;">Mumbai, Maharashtra</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Review 3 -->
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12" style="margin-bottom: 20px;">
                <div style="background: #fdfbf7; border: 1px solid #ede8df; border-radius: 16px; padding: 22px 20px; height: 100%; display: flex; flex-direction: column;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
                        <span style="color: #f59e0b; font-size: 14px;">★★★★★</span>
                        <span style="font-size: 11px; color: #166534; font-weight: 800; background: #f0fdf4; padding: 2px 8px; border-radius: 10px;">Verified Buyer</span>
                    </div>
                    <p style="font-size: 14px; color: #44403c; line-height: 1.6; margin: 0 0 16px 0; flex-grow: 1;">
                        "Super fast delivery direct from Udaipur roastery. Pouch was sealed tight and the crunch was so loud my colleagues wanted a bite. Ordered the 6-pack!"
                    </p>
                    <div style="display: flex; align-items: center; gap: 10px; border-top: 1px solid #ede8df; padding-top: 12px;">
                        <div style="width: 36px; height: 36px; border-radius: 50%; background: #fef3c7; color: #d97706; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 13px;">
                            NV
                        </div>
                        <div>
                            <strong style="font-size: 13px; color: #1c1917; display: block;">Neha Verma</strong>
                            <span style="font-size: 11px; color: #78716c;">Delhi NCR</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
