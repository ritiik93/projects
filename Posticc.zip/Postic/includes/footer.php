<?php 
if (!isset($obj)) {
    $obj = new adminback();
}
$links = $obj->display_links();
$link = ($links && mysqli_num_rows($links) > 0) ? mysqli_fetch_assoc($links) : array();
$footer_phone = !empty($link['phone']) ? $link['phone'] : '+91 9216398316';
$footer_email = !empty($link['email']) ? $link['email'] : 'care@postic.in';
?>

<footer id="footer" class="postic-main-footer" style="background: #18181b; color: #a1a1aa; padding: 60px 0 30px 0; border-top: 1px solid #27272a; font-size: 14px; position: relative;">
    <div class="container">
        <div class="row">
            <!-- Col 1: Brand Info -->
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="margin-bottom: 35px;">
                <div style="margin-bottom: 16px;">
                    <a href="index.php" style="display: inline-block;">
                        <img src="admin/uploads/logo.png" alt="Postic Makhana Logo" style="height: 52px; width: auto;">
                    </a>
                </div>
                <p style="font-size: 13px; line-height: 1.7; color: #d4d4d8; max-width: 340px; margin-bottom: 20px;">
                    Handpicked lotus seeds slow-roasted using precision hot air in the royal city of lakes—Udaipur, Rajasthan. 100% natural, zero palm oil, and high plant protein.
                </p>
                <div style="font-size: 13px; line-height: 1.8; color: #d4d4d8;">
                    <p style="margin: 0 0 6px 0;">
                        <i class="fa fa-map-marker" style="color: #ef4444; width: 20px;"></i>
                        Udaipur, Rajasthan - 313001, India
                    </p>
                    <p style="margin: 0 0 6px 0;">
                        <i class="fa fa-phone" style="color: #fbbf24; width: 20px;"></i>
                        <a href="tel:<?php echo htmlspecialchars($footer_phone); ?>" style="color: #ffffff; text-decoration: none; font-weight: 700;">
                            <?php echo htmlspecialchars($footer_phone); ?>
                        </a>
                    </p>
                    <p style="margin: 0;">
                        <i class="fa fa-envelope" style="color: #38bdf8; width: 20px;"></i>
                        <a href="mailto:<?php echo htmlspecialchars($footer_email); ?>" style="color: #ffffff; text-decoration: none;">
                            <?php echo htmlspecialchars($footer_email); ?>
                        </a>
                    </p>
                </div>
            </div>

            <!-- Col 2: The Collection -->
            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-6" style="margin-bottom: 30px;">
                <h4 style="font-size: 14px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 16px 0;">
                    Our Flavours
                </h4>
                <ul style="list-style: none; padding: 0; margin: 0; line-height: 2; font-size: 13px;">
                    <li><a href="all_product.php" style="color: #a1a1aa; text-decoration: none; transition: color 0.2s;">All Makhana</a></li>
                    <li><a href="all_product.php?search=Cheese" style="color: #a1a1aa; text-decoration: none; transition: color 0.2s;">Cheese Tomato</a></li>
                    <li><a href="all_product.php?search=Cream" style="color: #a1a1aa; text-decoration: none; transition: color 0.2s;">Cream &amp; Onion</a></li>
                    <li><a href="all_product.php?search=Coriander" style="color: #a1a1aa; text-decoration: none; transition: color 0.2s;">Coriander Mint</a></li>
                    <li><a href="all_product.php?search=Lemon" style="color: #a1a1aa; text-decoration: none; transition: color 0.2s;">Tangy Lemon</a></li>
                    <li><a href="all_product.php?search=Pani" style="color: #a1a1aa; text-decoration: none; transition: color 0.2s;">Street Pani Puri</a></li>
                </ul>
            </div>

            <!-- Col 3: Quick Links & Partners -->
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6" style="margin-bottom: 30px;">
                <h4 style="font-size: 14px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 16px 0;">
                    Brand &amp; Wholesale
                </h4>
                <ul style="list-style: none; padding: 0; margin: 0; line-height: 2; font-size: 13px;">
                    <li><a href="about_us.php" style="color: #a1a1aa; text-decoration: none;">About Roastery</a></li>
                    <li><a href="index.php#partner-section" style="color: #fca5a5; text-decoration: none; font-weight: 700;"><i class="fa fa-handshake-o"></i> Wholesale / B2B Desk</a></li>
                    <li><a href="exist_order.php" style="color: #a1a1aa; text-decoration: none;">Track Order Status</a></li>
                    <li><a href="userprofile.php" style="color: #a1a1aa; text-decoration: none;">My Account</a></li>
                    <li><a href="privacy_policy.php" style="color: #a1a1aa; text-decoration: none;">Privacy Policy</a></li>
                    <li><a href="https://wa.me/919216398316?text=Hi%20Postic,%20I%20have%20a%20question" target="_blank" style="color: #25D366; text-decoration: none;"><i class="fa fa-whatsapp"></i> WhatsApp Support</a></li>
                </ul>
            </div>

            <!-- Col 4: Newsletter & Social -->
            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12" style="margin-bottom: 30px;">
                <h4 style="font-size: 14px; font-weight: 800; color: #ffffff; text-transform: uppercase; letter-spacing: 1px; margin: 0 0 16px 0;">
                    Join Postic Club
                </h4>
                <p style="font-size: 13px; color: #a1a1aa; line-height: 1.5; margin-bottom: 12px;">
                    Get direct roastery offers, festive discount drops &amp; healthy snacking tips.
                </p>
                <form action="#" method="post" onsubmit="alert('Thank you for subscribing to Postic Club!'); return false;" style="position: relative; margin-bottom: 20px;">
                    <input type="email" placeholder="Your email address..." required style="width: 100%; height: 42px; border-radius: 22px; border: 1px solid #3f3f46; padding: 0 45px 0 16px; font-size: 13px; background: #27272a; color: #fff; outline: none;">
                    <button type="submit" style="position: absolute; right: 4px; top: 4px; width: 34px; height: 34px; border-radius: 50%; background: #c8102e; color: #fff; border: none; font-size: 13px; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-arrow-right"></i>
                    </button>
                </form>

                <div style="display: flex; gap: 10px; align-items: center;">
                    <a href="https://wa.me/919216398316?text=Hi%20Postic" target="_blank" title="WhatsApp Postic" style="width: 38px; height: 38px; border-radius: 50%; background: #25D366; color: #fff; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 17px; transition: transform 0.2s ease;">
                        <i class="fa fa-whatsapp"></i>
                    </a>
                    <a href="https://www.instagram.com/postic_snacks" target="_blank" title="Instagram: postic_snacks" style="width: 38px; height: 38px; border-radius: 50%; background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); color: #fff; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 17px; transition: transform 0.2s ease;">
                        <i class="fa fa-instagram"></i>
                    </a>
                    <a href="https://www.facebook.com/p/Postic-Snacks-61583351282686/" target="_blank" title="Facebook: Postic Snacks" style="width: 38px; height: 38px; border-radius: 50%; background: #1877f2; color: #fff; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 17px; transition: transform 0.2s ease;">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a href="tel:+919216398316" title="Call Us" style="width: 38px; height: 38px; border-radius: 50%; background: #27272a; color: #fff; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 15px; transition: transform 0.2s ease;">
                        <i class="fa fa-phone"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Footer Bottom Row -->
        <div style="border-top: 1px solid #27272a; padding-top: 24px; margin-top: 15px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;">
            <div>
                <p style="margin: 0; font-size: 12px; color: #71717a;">
                    &copy; <?php echo date('Y'); ?> <strong>Postic Foods</strong> &bull; Udaipur, Rajasthan. Handcrafted with <span style="color: #ef4444;">&hearts;</span> in India.
                </p>
                <p style="margin: 2px 0 0 0; font-size: 11px; color: #52525b;">
                    Developed by <a href="https://psoft.solutions/" target="_blank" rel="noopener noreferrer" style="color: #a1a1aa; text-decoration: none;">Psoft Solutions</a>
                </p>
            </div>
            <div>
                <span style="font-size: 11px; color: #71717a; margin-right: 10px;">100% Safe Payments:</span>
                <span style="font-size: 12px; color: #a1a1aa; font-weight: 700;">UPI &bull; RuPay &bull; Cards &bull; COD</span>
            </div>
        </div>
    </div>
</footer>

<!-- Floating WhatsApp Order/Support Button -->
<a href="https://wa.me/919216398316?text=Hi%20Postic,%20I%20want%20to%20order%20healthy%20makhana" target="_blank" class="postic-whatsapp-float" title="Chat with Postic on WhatsApp" style="position: fixed; bottom: 30px; right: 24px; z-index: 9999; width: 54px; height: 54px; background-color: #25D366; color: #ffffff; border-radius: 50%; font-size: 28px; box-shadow: 0 6px 20px rgba(37,211,102,0.4); display: flex; align-items: center; justify-content: center; text-decoration: none; transition: transform 0.25s ease;">
    <i class="fa fa-whatsapp" style="color: #ffffff;"></i>
</a>