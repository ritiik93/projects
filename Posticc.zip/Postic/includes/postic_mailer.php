<?php
/**
 * =========================================================================================
 * POSTIC EMAIL NOTIFICATION SYSTEM (POWERED BY PHPMAILER)
 * =========================================================================================
 * Handles authenticated SMTP email delivery via GoDaddy (care@postic.in).
 * Sends order receipts to customers & dispatch alerts to the store owner.
 * =========================================================================================
 */

require_once dirname(__DIR__) . '/config/mail_config.php';
require_once dirname(__DIR__) . '/PHPMailer/src/Exception.php';
require_once dirname(__DIR__) . '/PHPMailer/src/PHPMailer.php';
require_once dirname(__DIR__) . '/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class PosticMailer
{
    /**
     * Initializes a pre-configured PHPMailer instance with GoDaddy SMTP.
     */
    private static function create_mailer()
    {
        $mail = new PHPMailer(true);

        // Server settings
        $mail->isSMTP();
        $mail->Host       = defined('SMTP_HOST') ? SMTP_HOST : 'smtpout.secureserver.net';
        $mail->SMTPAuth   = true;
        $mail->Username   = defined('SMTP_USER') ? SMTP_USER : 'care@postic.in';
        $mail->Password   = defined('SMTP_PASS') ? SMTP_PASS : '';
        $mail->Port       = defined('SMTP_PORT') ? (int)SMTP_PORT : 465;

        $enc = defined('SMTP_ENCRYPTION') ? strtolower(SMTP_ENCRYPTION) : 'ssl';
        if ($enc === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($enc === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }

        $mail->Timeout    = 15;
        $mail->CharSet    = 'UTF-8';
        $mail->SMTPDebug  = defined('SMTP_DEBUG') ? (int)SMTP_DEBUG : 0;

        // SSL options to prevent local certificate mismatch issues on XAMPP
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer'       => false,
                'verify_peer_name'  => false,
                'allow_self_signed' => true
            )
        );

        $from_email = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'care@postic.in';
        $from_name  = defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Postic Foods';
        $mail->setFrom($from_email, $from_name);
        $mail->addReplyTo($from_email, $from_name);

        return $mail;
    }

    /**
     * Sends both Customer Receipt and Admin Alert when an order is placed.
     *
     * @param array $data Order details
     * @return array Status of sends: ['customer' => bool, 'admin' => bool]
     */
    public static function send_order_notifications($data)
    {
        $results = array(
            'customer' => false,
            'admin'    => false,
        );

        // If password is still placeholder, skip sending to avoid blocking execution
        if (defined('SMTP_PASS') && SMTP_PASS === 'YOUR_GODADDY_EMAIL_PASSWORD') {
            self::log_error("SMTP Password is not configured in config/mail_config.php. Skipping email send for Order #" . ($data['order_id'] ?? ''));
            return $results;
        }

        // 1. Send Customer Order Receipt
        if (!empty($data['customer_email'])) {
            $results['customer'] = self::send_customer_receipt($data);
        }

        // 2. Send Admin New Order Notification
        $admin_email = defined('ADMIN_NOTIFICATION_EMAIL') ? ADMIN_NOTIFICATION_EMAIL : 'care@postic.in';
        if (!empty($admin_email)) {
            $results['admin'] = self::send_admin_order_alert($data, $admin_email);
        }

        return $results;
    }

    /**
     * Send formatted receipt to Customer.
     */
    private static function send_customer_receipt($data)
    {
        try {
            $mail = self::create_mailer();
            $mail->addAddress($data['customer_email'], $data['customer_name'] ?? 'Valued Customer');

            $order_code = '#INV-POSTIC-' . str_pad($data['order_id'], 5, '0', STR_PAD_LEFT);
            $mail->isHTML(true);
            $mail->Subject = "Order Confirmed $order_code - Postic Healthy Foods";
            $mail->Body    = self::build_customer_html_template($data, $order_code);
            $mail->AltBody = "Thank you for your order $order_code with Postic Foods! Total: Rs. " . number_format($data['total_amount'], 2);

            $mail->send();
            return true;
        } catch (\Exception $e) {
            self::log_error("Customer Email Failed (Order #" . ($data['order_id'] ?? '') . "): " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send alert to Admin (care@postic.in) for parcel preparation.
     */
    private static function send_admin_order_alert($data, $admin_email)
    {
        try {
            $mail = self::create_mailer();
            $mail->addAddress($admin_email, 'Postic Orders Desk');

            $order_code = '#INV-POSTIC-' . str_pad($data['order_id'], 5, '0', STR_PAD_LEFT);
            $total_fmt  = '₹' . number_format($data['total_amount'], 2);

            $mail->isHTML(true);
            $mail->Subject = "🚨 New Order $order_code Received ($total_fmt) - Pack & Dispatch";
            $mail->Body    = self::build_admin_html_template($data, $order_code);
            $mail->AltBody = "New Order $order_code from " . ($data['customer_name'] ?? 'Customer') . " for $total_fmt. Phone: " . ($data['mobile'] ?? '');

            $mail->send();
            return true;
        } catch (\Exception $e) {
            self::log_error("Admin Email Failed (Order #" . ($data['order_id'] ?? '') . "): " . $e->getMessage());
            return false;
        }
    }

    /**
     * Generates Customer HTML Email Template.
     */
    private static function build_customer_html_template($data, $order_code)
    {
        $items_html = '';
        foreach ($data['items'] as $item) {
            $items_html .= '
            <tr>
                <td style="padding: 12px 14px; border-bottom: 1px solid #eef2f6;">
                    <strong style="color: #0f172a; font-size: 14px;">' . htmlspecialchars($item['name']) . '</strong><br>
                    <span style="font-size: 11px; color: #d32f2f; background: #fef2f2; padding: 2px 8px; border-radius: 4px; display: inline-block; margin-top: 4px; font-weight: 600;">' . htmlspecialchars($item['weight']) . '</span>
                </td>
                <td style="padding: 12px 14px; border-bottom: 1px solid #eef2f6; text-align: center; color: #334155; font-weight: 600;">' . (int)$item['qty'] . '</td>
                <td style="padding: 12px 14px; border-bottom: 1px solid #eef2f6; text-align: right; color: #64748b;">₹' . number_format($item['price'], 2) . '</td>
                <td style="padding: 12px 14px; border-bottom: 1px solid #eef2f6; text-align: right; font-weight: 700; color: #d32f2f;">₹' . number_format($item['total'], 2) . '</td>
            </tr>';
        }

        $coupon_html = '';
        if (!empty($data['coupon']) && !empty($data['coupon_discount'])) {
            $coupon_html = '
            <tr>
                <td colspan="3" style="padding: 10px 14px; text-align: right; color: #16a34a; font-weight: 600; font-size: 13px;">Coupon Discount (' . htmlspecialchars($data['coupon']) . ' - ' . (int)$data['coupon_discount'] . '%):</td>
                <td style="padding: 10px 14px; text-align: right; color: #16a34a; font-weight: 700;">Applied</td>
            </tr>';
        }

        return '<!DOCTYPE html>
        <html>
        <head><meta charset="utf-8"></head>
        <body style="font-family: Arial, -apple-system, sans-serif; background: #f8fafc; padding: 24px 10px; margin: 0; color: #334155;">
            <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 620px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 8px 30px rgba(0,0,0,0.06);">
                <tr>
                    <td style="background: linear-gradient(135deg, #b71c1c 0%, #d32f2f 100%); padding: 30px; text-align: left; color: #ffffff;">
                        <h1 style="margin: 0; font-size: 26px; font-weight: 800; letter-spacing: 1px;">POSTIC<span style="color: #fecaca;">.</span></h1>
                        <p style="margin: 4px 0 0 0; font-size: 13px; color: #fee2e2;">100% Roasted Natural Fox Nuts &bull; Udaipur, Rajasthan</p>
                    </td>
                </tr>
                <tr>
                    <td style="padding: 32px 30px;">
                        <h2 style="margin: 0 0 8px 0; color: #0f172a; font-size: 20px; font-weight: 800;">
                            Thank You for Your Order, ' . htmlspecialchars($data['customer_name'] ?? 'Friend') . '!
                        </h2>
                        <p style="margin: 0 0 24px 0; color: #64748b; font-size: 14px; line-height: 1.5;">
                            Your order <strong>' . $order_code . '</strong> has been received! Our kitchen in Udaipur is preparing your fresh, slow-roasted Makhana parcel for express dispatch.
                        </p>

                        <!-- Items Table -->
                        <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse; margin-bottom: 24px; font-size: 13px;">
                            <thead>
                                <tr style="background: #f8fafc; color: #64748b; text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px;">
                                    <th style="padding: 10px 14px; text-align: left; border-bottom: 2px solid #e2e8f0;">Product</th>
                                    <th style="padding: 10px 14px; text-align: center; border-bottom: 2px solid #e2e8f0;">Qty</th>
                                    <th style="padding: 10px 14px; text-align: right; border-bottom: 2px solid #e2e8f0;">Price</th>
                                    <th style="padding: 10px 14px; text-align: right; border-bottom: 2px solid #e2e8f0;">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                ' . $items_html . '
                                ' . $coupon_html . '
                                <tr>
                                    <td colspan="3" style="padding: 14px; text-align: right; font-size: 15px; font-weight: 800; color: #0f172a; border-top: 2px solid #cbd5e1;">Final Amount:</td>
                                    <td style="padding: 14px; text-align: right; font-size: 20px; font-weight: 800; color: #d32f2f; border-top: 2px solid #cbd5e1;">₹' . number_format($data['total_amount'], 2) . '</td>
                                </tr>
                            </tbody>
                        </table>

                        <!-- Shipping & Payment Info -->
                        <table width="100%" cellpadding="0" cellspacing="0" style="background: #f8fafc; border-radius: 10px; margin-bottom: 24px; font-size: 13px; border: 1px solid #e2e8f0;">
                            <tr>
                                <td width="55%" valign="top" style="padding: 16px 18px; border-right: 1px solid #e2e8f0;">
                                    <strong style="color: #0f172a; display: block; margin-bottom: 4px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">Delivery Address:</strong>
                                    <span style="color: #334155; line-height: 1.4;">' . nl2br(htmlspecialchars($data['address'] ?? '')) . '</span><br>
                                    <strong style="color: #0f172a; display: inline-block; margin-top: 8px;">Phone:</strong> ' . htmlspecialchars($data['mobile'] ?? '') . '
                                </td>
                                <td width="45%" valign="top" style="padding: 16px 18px;">
                                    <strong style="color: #0f172a; display: block; margin-bottom: 4px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">Payment Mode:</strong>
                                    <span style="color: #334155; font-weight: 700; text-transform: uppercase;">' . htmlspecialchars($data['payment_method'] ?? 'COD') . '</span><br><br>
                                    <strong style="color: #0f172a; display: block; margin-bottom: 4px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">Order Status:</strong>
                                    <span style="background: #fef3c7; color: #b45309; font-weight: 700; padding: 3px 10px; border-radius: 12px; font-size: 11px;">PROCESSING DISPATCH</span>
                                </td>
                            </tr>
                        </table>

                        <!-- Support Strip -->
                        <div style="text-align: center; border-top: 1px solid #f1f5f9; padding-top: 20px;">
                            <p style="margin: 0 0 6px 0; font-size: 13px; color: #64748b;">Need help or have special delivery instructions?</p>
                            <p style="margin: 0; font-size: 13px; color: #0f172a;">
                                <strong>WhatsApp:</strong> <a href="https://wa.me/919216398316" style="color: #16a34a; text-decoration: none;">+91 9216398316</a> &nbsp;&bull;&nbsp; 
                                <strong>Email:</strong> <a href="mailto:care@postic.in" style="color: #d32f2f; text-decoration: none;">care@postic.in</a>
                            </p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="background: #0f172a; color: #94a3b8; padding: 18px 24px; text-align: center; font-size: 11px; line-height: 1.5;">
                        &copy; ' . date('Y') . ' Postic Foods. All Rights Reserved.<br>
                        Madri Industrial Area, Udaipur, Rajasthan - 313003, India
                    </td>
                </tr>
            </table>
        </body>
        </html>';
    }

    /**
     * Generates Admin HTML Alert Template.
     */
    private static function build_admin_html_template($data, $order_code)
    {
        $items_list_html = '';
        foreach ($data['items'] as $item) {
            $items_list_html .= '
            <li style="margin-bottom: 8px; padding-bottom: 8px; border-bottom: 1px dashed #e2e8f0; display: flex; justify-content: space-between;">
                <span><strong>' . htmlspecialchars($item['name']) . '</strong> (' . htmlspecialchars($item['weight']) . ') &times; ' . (int)$item['qty'] . '</span>
                <strong style="color: #d32f2f;">₹' . number_format($item['total'], 2) . '</strong>
            </li>';
        }

        return '<!DOCTYPE html>
        <html>
        <head><meta charset="utf-8"></head>
        <body style="font-family: Arial, sans-serif; background: #f1f5f9; padding: 20px; margin: 0; color: #1e293b;">
            <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; border: 1px solid #cbd5e1; box-shadow: 0 4px 20px rgba(0,0,0,0.06);">
                <tr>
                    <td style="background: #0f172a; padding: 20px 24px; color: #ffffff; border-bottom: 3px solid #d32f2f;">
                        <span style="background: #d32f2f; color: #fff; font-size: 11px; font-weight: bold; padding: 3px 8px; border-radius: 4px; text-transform: uppercase;">New Order Received</span>
                        <h2 style="margin: 8px 0 0 0; font-size: 22px; color: #ffffff;">Order ' . $order_code . '</h2>
                    </td>
                </tr>
                <tr>
                    <td style="padding: 24px;">
                        <p style="margin: 0 0 16px 0; font-size: 14px; color: #475569;">
                            A new order has been placed on <strong>Postic.in</strong>. Please roast/pack the fresh batch and prepare courier label.
                        </p>

                        <!-- Customer Details Box -->
                        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-bottom: 20px; font-size: 13px;">
                            <strong style="display: block; font-size: 14px; color: #0f172a; margin-bottom: 8px;">Customer &amp; Shipping Details:</strong>
                            <p style="margin: 0 0 4px 0;"><strong>Name:</strong> ' . htmlspecialchars($data['customer_name'] ?? 'N/A') . '</p>
                            <p style="margin: 0 0 4px 0;"><strong>Phone:</strong> <a href="tel:' . htmlspecialchars($data['mobile'] ?? '') . '" style="color: #2563eb; font-weight: bold;">' . htmlspecialchars($data['mobile'] ?? '') . '</a></p>
                            <p style="margin: 0 0 4px 0;"><strong>Email:</strong> ' . htmlspecialchars($data['customer_email'] ?? 'N/A') . '</p>
                            <p style="margin: 0 0 4px 0;"><strong>Address:</strong> ' . nl2br(htmlspecialchars($data['address'] ?? '')) . '</p>
                            <p style="margin: 8px 0 0 0;"><strong>Payment:</strong> <span style="text-transform: uppercase; font-weight: bold; color: #059669;">' . htmlspecialchars($data['payment_method'] ?? 'COD') . ' (' . htmlspecialchars($data['payment_status'] ?? 'pending') . ')</span></p>
                        </div>

                        <!-- Ordered Items -->
                        <div style="margin-bottom: 20px;">
                            <strong style="display: block; font-size: 14px; color: #0f172a; margin-bottom: 10px;">Items to Pack:</strong>
                            <ul style="list-style: none; padding: 0; margin: 0; font-size: 13px;">
                                ' . $items_list_html . '
                            </ul>
                            <div style="text-align: right; padding-top: 10px; font-size: 16px; font-weight: 800; color: #0f172a;">
                                Total Amount: <span style="color: #d32f2f;">₹' . number_format($data['total_amount'], 2) . '</span>
                            </div>
                        </div>

                        <!-- Action Button -->
                        <div style="text-align: center; margin-top: 24px;">
                            <a href="http://localhost/demopostic/admin/manage_order.php" style="background: #d32f2f; color: #ffffff; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 14px; display: inline-block;">
                                Open Order in Admin Panel &rarr;
                            </a>
                        </div>
                    </td>
                </tr>
            </table>
        </body>
        </html>';
    }

    /**
     * Send Password Reset Email.
     */
    public static function send_password_reset_email($to_email, $user_name, $reset_link)
    {
        try {
            $mail = self::create_mailer();
            $mail->addAddress($to_email, $user_name);
            $mail->isHTML(true);
            $mail->Subject = "Reset Your Password - Postic Foods";
            $mail->Body = '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;background:#f8fafc;padding:20px;color:#333;"><div style="max-width:540px;margin:0 auto;background:#fff;border-radius:12px;padding:28px;border:1px solid #e2e8f0;"><h2 style="color:#d32f2f;margin-top:0;">Password Reset Request</h2><p>Dear ' . htmlspecialchars($user_name) . ',</p><p>We received a request to reset your password for your Postic account.</p><p style="margin:24px 0;"><a href="' . htmlspecialchars($reset_link) . '" style="background:#d32f2f;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;display:inline-block;">Reset Password &rarr;</a></p><p style="font-size:12px;color:#64748b;">Or copy this link in your browser: <br>' . htmlspecialchars($reset_link) . '</p><hr style="border:none;border-top:1px solid #eee;margin:20px 0;"><p style="font-size:11px;color:#94a3b8;">Postic Foods &bull; Udaipur, Rajasthan</p></div></body></html>';
            $mail->AltBody = "Dear $user_name, reset your password using this link: $reset_link";
            $mail->send();
            return true;
        } catch (\Exception $e) {
            self::log_error("Password Reset Email Failed: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Send Order Status Update Email to Customer.
     */
    public static function send_order_status_update($customer_email, $customer_name, $order_id, $status_code, $product_name = '')
    {
        if (empty($customer_email) || !filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }

        $status_map = array(
            0 => array('title' => 'Order Received & Pending Confirmation', 'color' => '#e11d48', 'desc' => 'We have received your order details and are preparing it for roasting.'),
            1 => array('title' => 'Packed at Udaipur Roastery (In Progress)', 'color' => '#d97706', 'desc' => 'Your batch of roasted makhana is freshly sealed, packed and ready for dispatch at our Udaipur facility.'),
            2 => array('title' => 'Dispatched from Udaipur & In Transit', 'color' => '#2563eb', 'desc' => 'Your parcel has been handed over to courier from Udaipur, Rajasthan and is moving towards your delivery address.'),
            3 => array('title' => 'Delivered Successfully', 'color' => '#059669', 'desc' => 'Your parcel has been delivered! We hope you enjoy the authentic crunch of Postic superfood makhana.'),
            4 => array('title' => 'Order Cancelled', 'color' => '#dc2626', 'desc' => 'Your order has been marked as cancelled. If this was a mistake, please reach out to care@postic.in.')
        );

        $st = isset($status_map[(int)$status_code]) ? $status_map[(int)$status_code] : $status_map[0];

        try {
            $mail = self::create_mailer();
            $mail->addAddress($customer_email, $customer_name);
            $mail->isHTML(true);
            $mail->Subject = "Order #{$order_id} Update: " . $st['title'] . " - Postic Foods";

            $html = '<!DOCTYPE html><html><body style="margin:0;padding:20px;background:#f8fafc;font-family:Arial,sans-serif;color:#333;">';
            $html .= '<div style="max-width:600px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e2e8f0;box-shadow:0 4px 14px rgba(0,0,0,0.05);">';
            $html .= '<div style="background:#d32f2f;padding:24px;text-align:center;color:#fff;">';
            $html .= '<h1 style="margin:0;font-size:24px;letter-spacing:1px;">POSTIC FOODS</h1>';
            $html .= '<p style="margin:4px 0 0 0;font-size:12px;opacity:0.9;">100% Roasted Superfood Makhana &bull; Udaipur</p>';
            $html .= '</div>';
            $html .= '<div style="padding:28px;">';
            $html .= '<h2 style="color:#0f172a;margin-top:0;font-size:18px;">Hello ' . htmlspecialchars($customer_name) . ',</h2>';
            $html .= '<p style="font-size:14px;color:#475569;line-height:1.6;">There is a new update regarding your Postic Makhana Order <strong>#' . $order_id . '</strong>' . (!empty($product_name) ? ' (' . htmlspecialchars($product_name) . ')' : '') . ':</p>';
            $html .= '<div style="background:#fef2f2;border-left:4px solid ' . $st['color'] . ';padding:16px 20px;border-radius:6px;margin:20px 0;">';
            $html .= '<div style="font-size:16px;font-weight:bold;color:' . $st['color'] . ';">' . $st['title'] . '</div>';
            $html .= '<p style="margin:6px 0 0 0;font-size:13px;color:#334155;line-height:1.5;">' . $st['desc'] . '</p>';
            $html .= '</div>';
            $html .= '<p style="font-size:13px;color:#64748b;line-height:1.5;">You can track your order status live anytime from your Postic customer account.</p>';
            $html .= '<div style="text-align:center;margin:26px 0;">';
            $html .= '<a href="http://localhost/demopostic/exist_order.php" style="background:#d32f2f;color:#fff;text-decoration:none;font-weight:bold;padding:12px 26px;border-radius:8px;display:inline-block;font-size:14px;">Track Order Live &rarr;</a>';
            $html .= '</div>';
            $html .= '<hr style="border:none;border-top:1px solid #e2e8f0;margin:25px 0;">';
            $html .= '<p style="font-size:12px;color:#94a3b8;margin:0;text-align:center;">Need help? WhatsApp us at <a href="https://wa.me/919216398316" style="color:#25D366;font-weight:bold;text-decoration:none;">+91 9216398316</a> or email <a href="mailto:care@postic.in" style="color:#d32f2f;text-decoration:none;">care@postic.in</a></p>';
            $html .= '</div>';
            $html .= '</div>';
            $html .= '</body></html>';

            $mail->Body = $html;
            $mail->AltBody = "Hello $customer_name, your Postic order #$order_id status is now: " . $st['title'] . ". Track your order at http://localhost/demopostic/exist_order.php";
            $mail->send();
            return true;
        } catch (\Exception $e) {
            self::log_error("Order Status Update Email Failed for #{$order_id}: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Sends 6-digit OTP email to customer for Flipkart-style fast registration.
     *
     * @param string $customer_email Recipient email
     * @param string $customer_name Recipient full name
     * @param string $otp 6-digit numeric OTP code
     * @return array Status ['success' => bool, 'message' => string]
     */
    public static function send_registration_otp($customer_email, $customer_name, $otp)
    {
        $customer_name = !empty($customer_name) ? trim($customer_name) : 'Valued Customer';

        // Always log OTP for development/fallback visibility
        self::log_error("Registration OTP generated for {$customer_email} ({$customer_name}): [{$otp}]");

        try {
            $mail = self::create_mailer();
            $mail->addAddress($customer_email, $customer_name);
            $mail->isHTML(true);
            $mail->Subject = "{$otp} is your Postic Verification Code";

            $html = '<!DOCTYPE html><html><body style="margin:0;padding:24px;background:#f8fafc;font-family:\'Segoe UI\',Arial,sans-serif;color:#1e293b;">';
            $html .= '<div style="max-width:540px;margin:0 auto;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #e2e8f0;box-shadow:0 8px 30px rgba(15,23,42,0.06);">';
            
            // Header
            $html .= '<div style="background:linear-gradient(135deg, #b91c1c 0%, #dc2626 50%, #ef4444 100%);padding:28px 24px;text-align:center;color:#ffffff;">';
            $html .= '<h1 style="margin:0;font-size:24px;letter-spacing:1.5px;font-weight:900;text-transform:uppercase;">POSTIC FOODS</h1>';
            $html .= '<p style="margin:6px 0 0 0;font-size:12px;opacity:0.95;letter-spacing:0.8px;font-weight:600;">100% Roasted Superfoods &bull; Udaipur</p>';
            $html .= '</div>';
            
            // Body
            $html .= '<div style="padding:32px 28px;">';
            $html .= '<h2 style="color:#0f172a;margin-top:0;font-size:19px;font-weight:800;">Hello ' . htmlspecialchars($customer_name, ENT_QUOTES, 'UTF-8') . ',</h2>';
            $html .= '<p style="font-size:14px;color:#475569;line-height:1.6;margin-bottom:20px;">Welcome to Postic Foods! Thank you for signing up. Please enter the one-time verification code (OTP) below to activate your account:</p>';
            
            // OTP Highlight Box
            $html .= '<div style="background:#fef2f2;border:2px dashed #f87171;border-radius:12px;padding:22px;text-align:center;margin:24px 0;">';
            $html .= '<div style="font-size:11px;font-weight:800;color:#991b1b;text-transform:uppercase;letter-spacing:2px;margin-bottom:6px;">Your One-Time Password (OTP)</div>';
            $html .= '<div style="font-size:38px;font-weight:900;letter-spacing:10px;color:#b91c1c;font-family:\'Courier New\',Courier,monospace;padding-left:10px;">' . htmlspecialchars($otp, ENT_QUOTES, 'UTF-8') . '</div>';
            $html .= '<div style="font-size:12px;color:#64748b;margin-top:8px;font-weight:600;"><i style="font-style:normal;">&#x23F1;</i> Valid for 10 minutes &bull; Please do not share this code</div>';
            $html .= '</div>';

            $html .= '<p style="font-size:13px;color:#64748b;line-height:1.6;margin-top:20px;">After creating your account, you can quickly auto-detect your delivery location and track orders live from your personal dashboard.</p>';
            
            $html .= '<hr style="border:none;border-top:1px solid #f1f5f9;margin:26px 0;">';
            $html .= '<p style="font-size:12px;color:#94a3b8;margin:0;text-align:center;line-height:1.6;">If you did not request this OTP, please ignore this email.<br>Need assistance? Contact us at <a href="mailto:care@postic.in" style="color:#dc2626;text-decoration:none;font-weight:600;">care@postic.in</a> or WhatsApp <a href="https://wa.me/919216398316" style="color:#16a34a;text-decoration:none;font-weight:700;">+91 9216398316</a></p>';
            $html .= '</div>';
            $html .= '</div>';
            $html .= '</body></html>';

            $mail->Body = $html;
            $mail->AltBody = "Hello {$customer_name},\n\nYour Postic account verification OTP is: {$otp}\nThis code is valid for 10 minutes.\n\nPostic Foods - 100% Roasted Superfoods, Udaipur";
            
            $mail->send();
            return array('success' => true, 'message' => "Verification OTP sent to {$customer_email}");
        } catch (\Exception $e) {
            self::log_error("Registration OTP Email Failed for {$customer_email}: " . $e->getMessage());
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    /**
     * Test SMTP Connection and credentials.
     */
    public static function test_smtp_connection($test_recipient = null)
    {
        $recipient = $test_recipient ?: (defined('ADMIN_NOTIFICATION_EMAIL') ? ADMIN_NOTIFICATION_EMAIL : 'care@postic.in');

        try {
            $mail = self::create_mailer();
            $mail->addAddress($recipient);
            $mail->isHTML(true);
            $mail->Subject = "Postic GoDaddy SMTP Test Email (" . date('d-M-Y H:i:s') . ")";
            $mail->Body    = "<h2>Great News!</h2><p>Your GoDaddy SMTP configuration (care@postic.in) on Postic is <strong>working 100% properly!</strong></p><p>You will now receive automatic notifications for all incoming orders.</p>";
            $mail->AltBody = "Your GoDaddy SMTP configuration on Postic is working 100%!";

            $mail->send();
            return array('success' => true, 'message' => "Test email sent successfully to $recipient!");
        } catch (\Exception $e) {
            self::log_error("SMTP Test Failed: " . $e->getMessage());
            return array('success' => false, 'message' => "SMTP Error: " . $e->getMessage());
        }
    }

    /**
     * Error logger helper.
     */
    private static function log_error($msg)
    {
        $log_dir = dirname(__DIR__) . '/admin/logs';
        if (!is_dir($log_dir)) {
            @mkdir($log_dir, 0755, true);
        }
        $log_file = $log_dir . '/mail_errors.log';
        $entry = "[" . date('Y-m-d H:i:s') . "] " . $msg . PHP_EOL;
        @file_put_contents($log_file, $entry, FILE_APPEND);
    }
}
