<?php
// Postic Premium D2C Flavor Bar (Subtle Warm Cream & Postic Red Accents)
?>
<div class="postic-flavor-strip-section" style="background: #fdfbf7; padding: 16px 0; border-top: 1px solid #ede8df; border-bottom: 1px solid #ede8df; overflow: hidden;">
    <div class="container">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="background: #c8102e; color: #fff; font-size: 11px; font-weight: 800; padding: 3px 9px; border-radius: 12px; text-transform: uppercase; letter-spacing: 0.5px;">6 Flavours</span>
                <span style="font-size: 14px; font-weight: 800; color: #1c1917; text-transform: uppercase; letter-spacing: 0.5px;">Pick Your Crunch Mood</span>
            </div>
            <span style="font-size: 12px; color: #78716c; font-weight: 700;">100% Dry-Roasted &bull; 55g Pouches &bull; Flat ₹130</span>
        </div>

        <div class="postic-flavor-pills-row" style="display: flex; gap: 10px; overflow-x: auto; padding: 4px 2px 8px 2px; -webkit-overflow-scrolling: touch; scrollbar-width: none;">
            <a href="all_product.php" class="postic-flavor-pill-card active-pill" style="flex: 0 0 auto; background: #c8102e; color: #ffffff; border-radius: 25px; padding: 8px 16px; text-decoration: none; display: flex; align-items: center; gap: 8px; box-shadow: 0 2px 8px rgba(200,16,46,0.25); transition: all 0.2s ease;">
                <span style="font-size: 14px;">✨</span>
                <span style="font-size: 13px; font-weight: 800;">All Flavours</span>
            </a>

            <a href="all_product.php?flavor=Cheese" class="postic-flavor-pill-card" style="flex: 0 0 auto; background: #ffffff; color: #1c1917; border-radius: 25px; padding: 8px 16px; text-decoration: none; display: flex; align-items: center; gap: 8px; border: 1px solid #ede8df; box-shadow: 0 1px 4px rgba(0,0,0,0.03); transition: all 0.2s ease;">
                <span style="font-size: 14px;">🧀</span>
                <span style="font-size: 13px; font-weight: 700;">Cheese Tomato</span>
            </a>

            <a href="all_product.php?flavor=Cream" class="postic-flavor-pill-card" style="flex: 0 0 auto; background: #ffffff; color: #1c1917; border-radius: 25px; padding: 8px 16px; text-decoration: none; display: flex; align-items: center; gap: 8px; border: 1px solid #ede8df; box-shadow: 0 1px 4px rgba(0,0,0,0.03); transition: all 0.2s ease;">
                <span style="font-size: 14px;">🧅</span>
                <span style="font-size: 13px; font-weight: 700;">Cream &amp; Onion</span>
            </a>

            <a href="all_product.php?flavor=Coriander" class="postic-flavor-pill-card" style="flex: 0 0 auto; background: #ffffff; color: #1c1917; border-radius: 25px; padding: 8px 16px; text-decoration: none; display: flex; align-items: center; gap: 8px; border: 1px solid #ede8df; box-shadow: 0 1px 4px rgba(0,0,0,0.03); transition: all 0.2s ease;">
                <span style="font-size: 14px;">🌿</span>
                <span style="font-size: 13px; font-weight: 700;">Coriander Mint</span>
            </a>

            <a href="all_product.php?flavor=Lemon" class="postic-flavor-pill-card" style="flex: 0 0 auto; background: #ffffff; color: #1c1917; border-radius: 25px; padding: 8px 16px; text-decoration: none; display: flex; align-items: center; gap: 8px; border: 1px solid #ede8df; box-shadow: 0 1px 4px rgba(0,0,0,0.03); transition: all 0.2s ease;">
                <span style="font-size: 14px;">🍋</span>
                <span style="font-size: 13px; font-weight: 700;">Tangy Lemon</span>
            </a>

            <a href="all_product.php?flavor=Pani" class="postic-flavor-pill-card" style="flex: 0 0 auto; background: #ffffff; color: #1c1917; border-radius: 25px; padding: 8px 16px; text-decoration: none; display: flex; align-items: center; gap: 8px; border: 1px solid #ede8df; box-shadow: 0 1px 4px rgba(0,0,0,0.03); transition: all 0.2s ease;">
                <span style="font-size: 14px;">🌶️</span>
                <span style="font-size: 13px; font-weight: 700;">Street Pani Puri</span>
            </a>

            <a href="all_product.php?flavor=Raw" class="postic-flavor-pill-card" style="flex: 0 0 auto; background: #ffffff; color: #1c1917; border-radius: 25px; padding: 8px 16px; text-decoration: none; display: flex; align-items: center; gap: 8px; border: 1px solid #ede8df; box-shadow: 0 1px 4px rgba(0,0,0,0.03); transition: all 0.2s ease;">
                <span style="font-size: 14px;">⚪</span>
                <span style="font-size: 13px; font-weight: 700;">Raw Jumbo Phool</span>
            </a>
        </div>
    </div>
</div>
