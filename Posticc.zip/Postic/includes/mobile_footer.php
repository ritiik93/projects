<?php
if (session_status() == PHP_SESSION_NONE) {
    @session_start();
}
$mb_cart_count = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $c_item) {
        $mb_cart_count += isset($c_item['quantity']) ? (int)$c_item['quantity'] : 1;
    }
}
$cur_script = basename($_SERVER['PHP_SELF'] ?? '');
?>
<!-- Postic Modern Fixed Bottom App Bar -->
<div class="mobile-footer" style="background: #ffffff; border-top: 1px solid #ede8df; position: fixed; left: 0; right: 0; bottom: 0; z-index: 9999; box-shadow: 0 -3px 14px rgba(0,0,0,0.06); height: 58px; padding: 0;">
    <div class="mobile-footer-inner" style="display: flex; align-items: center; justify-content: space-around; height: 100%; margin: 0; padding: 0;">
        <!-- Home -->
        <div class="mobile-block" style="flex: 1; text-align: center;">
            <a href="index.php" style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-decoration: none; padding: 4px 0; color: <?php echo ($cur_script === 'index.php' || empty($cur_script)) ? '#c8102e' : '#64748b'; ?>;">
                <span class="fa fa-home" style="font-size: 19px; line-height: 1.1; margin-bottom: 2px;"></span>
                <span class="text" style="font-size: 11px; font-weight: <?php echo ($cur_script === 'index.php') ? '800' : '600'; ?>;">Home</span>
            </a>
        </div>

        <!-- Shop / All Products -->
        <div class="mobile-block" style="flex: 1; text-align: center;">
            <a href="all_product.php" style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-decoration: none; padding: 4px 0; color: <?php echo ($cur_script === 'all_product.php' || $cur_script === 'catagory.php' || $cur_script === 'single_product.php') ? '#c8102e' : '#64748b'; ?>;">
                <span class="fa fa-th-large" style="font-size: 18px; line-height: 1.1; margin-bottom: 2px;"></span>
                <span class="text" style="font-size: 11px; font-weight: <?php echo ($cur_script === 'all_product.php') ? '800' : '600'; ?>;">Shop</span>
            </a>
        </div>

        <!-- Cart with Live Counter -->
        <div class="mobile-block block-minicart" style="flex: 1; text-align: center;">
            <a class="link-to-cart" href="addtocart.php" style="display: flex; flex-direction: column; align-items: center; justify-content: center; position: relative; text-decoration: none; padding: 4px 0; color: <?php echo ($cur_script === 'addtocart.php') ? '#c8102e' : '#64748b'; ?>;">
                <div style="position: relative; display: inline-block;">
                    <span class="fa fa-shopping-cart" style="font-size: 19px; line-height: 1.1; margin-bottom: 2px;"></span>
                    <span class="postic-mb-cart-badge" style="position: absolute; top: -6px; right: -10px; background: #c8102e; color: #ffffff; border-radius: 50%; font-size: 10px; min-width: 17px; height: 17px; line-height: 17px; text-align: center; font-weight: 800; padding: 0 3px; display: <?php echo ($mb_cart_count > 0) ? 'inline-block' : 'none'; ?>; border: 1.5px solid #fff;">
                        <?php echo $mb_cart_count; ?>
                    </span>
                </div>
                <span class="text" style="font-size: 11px; font-weight: <?php echo ($cur_script === 'addtocart.php') ? '800' : '600'; ?>;">Cart</span>
            </a>
        </div>

        <!-- Login / Account -->
        <div class="mobile-block" style="flex: 1; text-align: center;">
            <a href="<?php echo isset($_SESSION['user_id']) ? 'userprofile.php' : 'user_login.php'; ?>" style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-decoration: none; padding: 4px 0; color: <?php echo ($cur_script === 'userprofile.php' || $cur_script === 'user_login.php' || $cur_script === 'user_register.php') ? '#c8102e' : '#64748b'; ?>;">
                <span class="fa fa-user" style="font-size: 19px; line-height: 1.1; margin-bottom: 2px;"></span>
                <span class="text" style="font-size: 11px; font-weight: <?php echo (in_array($cur_script, ['userprofile.php', 'user_login.php'])) ? '800' : '600'; ?>;">
                    <?php echo isset($_SESSION['user_id']) ? 'Account' : 'Login'; ?>
                </span>
            </a>
        </div>

        <!-- Menu Drawer Toggle -->
        <div class="mobile-block block-menu-main" style="flex: 1; text-align: center;">
            <a class="menu-bar menu-toggle btn-toggle" id="posticMbFooterMenuBtn" data-object="open-mobile-menu" href="javascript:void(0)" style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-decoration: none; padding: 4px 0; color: #64748b;">
                <span class="fa fa-bars" style="font-size: 19px; line-height: 1.1; margin-bottom: 2px;"></span>
                <span class="text" style="font-size: 11px; font-weight: 600;">Menu</span>
            </a>
        </div>
    </div>
</div>
<style>
@media (max-width: 768px) {
    .mobile-footer { display: block !important; }
    body.biolife-body { padding-bottom: 64px !important; }
    .postic-whatsapp-float { bottom: 72px !important; }
    .btn-scroll-top { bottom: 72px !important; }
}
</style>