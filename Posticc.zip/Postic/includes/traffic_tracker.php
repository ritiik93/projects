<?php
/**
 * =========================================================================================
 * POSTIC STANDALONE REUSABLE WEBSITE TRAFFIC & VISITOR TRACKER
 * =========================================================================================
 * Designed for Postic E-Commerce & 100% PORTABLE for ANY other PHP Website / Project!
 * 
 * -----------------------------------------------------------------------------------------
 * HOW TO REUSE THIS IN ANY OTHER PHP PROJECT (KISI BHI DOOSRE PROJECT MEIN KAISE USE KAREIN):
 * -----------------------------------------------------------------------------------------
 * Step 1: Copy this file (traffic_tracker.php) into your project (e.g. /includes/traffic_tracker.php).
 * Step 2: In your common header / head.php file, simply add these 2 lines:
 * 
 *          require_once __DIR__ . '/traffic_tracker.php';
 *          track_visitor();
 * 
 * Step 3: That's it! The tracker will:
 *          - Automatically create the `visitor_logs` database table (Zero manual SQL needed).
 *          - Log visitor IP, device (Mobile/Desktop/Tablet), browser, OS, referrer, and page.
 *          - Automatically detect logged-in users if $_SESSION['user_id'] is present.
 *          - Filter out bots & crawlers (Googlebot, Bing, etc.) so stats remain 100% accurate.
 * 
 * Step 4: To display traffic stats in any Admin Dashboard:
 *          $tracker = new PosticTrafficTracker();
 *          $stats = $tracker->get_summary();
 *          $recent_visitors = $tracker->get_recent_visits(15);
 * =========================================================================================
 */

if (!class_exists('PosticTrafficTracker')) {

    class PosticTrafficTracker
    {
        private $db;
        private static $table_ensured = false;

        /**
         * Constructor: accepts an optional existing mysqli connection.
         * If none provided, it attempts to load get_db_connection() or creates one.
         */
        public function __construct($custom_connection = null)
        {
            if ($custom_connection instanceof mysqli) {
                $this->db = $custom_connection;
            } elseif (function_exists('get_db_connection')) {
                $this->db = get_db_connection();
            } else {
                // Standalone fallback: include project database config if available
                $db_config_file = dirname(__DIR__) . '/config/database.php';
                if (file_exists($db_config_file)) {
                    require_once $db_config_file;
                    if (function_exists('get_db_connection')) {
                        $this->db = get_db_connection();
                    }
                }

                // If still null, try standard localhost
                if (!$this->db && defined('DB_HOST') && defined('DB_USER')) {
                    $this->db = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
                }
            }

            if ($this->db) {
                $this->ensure_table();
            }
        }

        /**
         * Auto-migration: Creates `visitor_logs` table automatically on the first run.
         */
        private function ensure_table()
        {
            if (self::$table_ensured || !$this->db) {
                return;
            }

            $query = "CREATE TABLE IF NOT EXISTS `visitor_logs` (
                `id` bigint(20) NOT NULL AUTO_INCREMENT,
                `session_id` varchar(64) NOT NULL,
                `visitor_ip` varchar(45) NOT NULL,
                `user_id` int(11) DEFAULT NULL,
                `customer_name` varchar(100) DEFAULT NULL,
                `page_url` varchar(255) NOT NULL,
                `page_title` varchar(150) NOT NULL DEFAULT '',
                `referrer` varchar(255) DEFAULT NULL,
                `device_type` varchar(20) NOT NULL DEFAULT 'Desktop',
                `browser` varchar(50) NOT NULL DEFAULT 'Other',
                `os` varchar(50) NOT NULL DEFAULT 'Other',
                `user_agent` varchar(350) DEFAULT NULL,
                `visit_date` date NOT NULL,
                `visit_time` datetime NOT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_visit_date` (`visit_date`),
                KEY `idx_device` (`device_type`),
                KEY `idx_session` (`session_id`),
                KEY `idx_user` (`user_id`),
                KEY `idx_time` (`visit_time`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

            @mysqli_query($this->db, $query);
            self::$table_ensured = true;
        }

        /**
         * Records a visitor visit.
         *
         * @param string|null $custom_title Optional friendly page name.
         * @return bool True if logged, false if skipped (bot, admin, or throttled).
         */
        public function track($custom_title = null)
        {
            if (!$this->db) {
                return false;
            }

            // 1. Skip admin panel requests to avoid skewing public traffic
            $uri = $_SERVER['REQUEST_URI'] ?? '';
            if (strpos($uri, '/admin/') !== false || strpos($uri, '/admin') !== false) {
                return false;
            }

            // 2. Skip common assets / AJAX polling endpoints
            $script_name = $_SERVER['SCRIPT_NAME'] ?? '';
            $disallowed_scripts = array('dashboard_json.php', 'live_search.php', 'favicon.ico');
            foreach ($disallowed_scripts as $dis) {
                if (strpos($uri, $dis) !== false || strpos($script_name, $dis) !== false) {
                    return false;
                }
            }

            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

            // 3. Skip automated search crawlers / bots
            if ($this->is_bot($user_agent)) {
                return false;
            }

            // 4. Ensure session exists for unique visitor tracking
            if (session_status() === PHP_SESSION_NONE) {
                @session_start();
            }

            if (empty($_SESSION['postic_visitor_session'])) {
                $_SESSION['postic_visitor_session'] = bin2hex(random_bytes(16));
            }
            $session_id = $_SESSION['postic_visitor_session'];

            // 5. Anti-Refresh Throttling: If the exact same page was visited < 3 seconds ago by this session, skip
            $current_time = time();
            if (isset($_SESSION['postic_last_visit_time']) && isset($_SESSION['postic_last_visit_uri'])) {
                if ($_SESSION['postic_last_visit_uri'] === $uri && ($current_time - (int)$_SESSION['postic_last_visit_time']) < 3) {
                    return false;
                }
            }
            $_SESSION['postic_last_visit_time'] = $current_time;
            $_SESSION['postic_last_visit_uri'] = $uri;

            // 6. Extract visitor details
            $ip = $this->get_client_ip();
            $device = $this->detect_device($user_agent);
            $browser = $this->detect_browser($user_agent);
            $os = $this->detect_os($user_agent);
            $referrer = $this->get_clean_referrer();

            // Detect logged-in customer info if available
            $user_id = null;
            $customer_name = null;
            if (!empty($_SESSION['user_id'])) {
                $user_id = (int)$_SESSION['user_id'];
                if (!empty($_SESSION['username'])) {
                    $customer_name = $_SESSION['username'];
                } elseif (!empty($_SESSION['user_name'])) {
                    $customer_name = $_SESSION['user_name'];
                }
            }

            // Derive friendly page title if not passed
            if (empty($custom_title)) {
                $custom_title = $this->derive_page_title($uri);
            }

            // Sanitize inputs for database
            $session_id_clean = mysqli_real_escape_string($this->db, $session_id);
            $ip_clean = mysqli_real_escape_string($this->db, $ip);
            $page_url_clean = mysqli_real_escape_string($this->db, substr($uri, 0, 255));
            $page_title_clean = mysqli_real_escape_string($this->db, substr($custom_title, 0, 150));
            $referrer_clean = $referrer ? "'" . mysqli_real_escape_string($this->db, substr($referrer, 0, 255)) . "'" : "NULL";
            $device_clean = mysqli_real_escape_string($this->db, $device);
            $browser_clean = mysqli_real_escape_string($this->db, $browser);
            $os_clean = mysqli_real_escape_string($this->db, $os);
            $ua_clean = mysqli_real_escape_string($this->db, substr($user_agent, 0, 350));
            $user_id_sql = $user_id !== null ? $user_id : "NULL";
            $customer_name_sql = $customer_name ? "'" . mysqli_real_escape_string($this->db, substr($customer_name, 0, 100)) . "'" : "NULL";

            $insert_query = "INSERT INTO `visitor_logs` 
                (`session_id`, `visitor_ip`, `user_id`, `customer_name`, `page_url`, `page_title`, `referrer`, `device_type`, `browser`, `os`, `user_agent`, `visit_date`, `visit_time`)
                VALUES 
                ('$session_id_clean', '$ip_clean', $user_id_sql, $customer_name_sql, '$page_url_clean', '$page_title_clean', $referrer_clean, '$device_clean', '$browser_clean', '$os_clean', '$ua_clean', CURDATE(), NOW())";

            return (bool) @mysqli_query($this->db, $insert_query);
        }

        /**
         * Detect client real IP with proxy & Cloudflare support.
         */
        public function get_client_ip()
        {
            $ip_headers = array(
                'HTTP_CF_CONNECTING_IP',
                'HTTP_X_REAL_IP',
                'HTTP_X_FORWARDED_FOR',
                'HTTP_CLIENT_IP',
                'REMOTE_ADDR'
            );

            foreach ($ip_headers as $header) {
                if (!empty($_SERVER[$header])) {
                    $ip = trim(explode(',', $_SERVER[$header])[0]);
                    if (filter_var($ip, FILTER_VALIDATE_IP)) {
                        return $ip;
                    }
                }
            }

            return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        }

        /**
         * Detect device type: Mobile, Tablet, or Desktop.
         */
        public function detect_device($user_agent)
        {
            $ua = strtolower($user_agent);

            if (strpos($ua, 'ipad') !== false || strpos($ua, 'tablet') !== false || (strpos($ua, 'android') !== false && strpos($ua, 'mobile') === false)) {
                return 'Tablet';
            }

            if (preg_match('/(android|iphone|ipod|mobile|phone|blackberry|opera mini|iemobile)/i', $ua)) {
                return 'Mobile';
            }

            return 'Desktop';
        }

        /**
         * Detect browser name.
         */
        public function detect_browser($user_agent)
        {
            $ua = $user_agent;

            if (preg_match('/Edg/i', $ua)) {
                return 'Edge';
            }
            if (preg_match('/OPR|Opera/i', $ua)) {
                return 'Opera';
            }
            if (preg_match('/Chrome/i', $ua) && !preg_match('/Edg/i', $ua)) {
                return 'Chrome';
            }
            if (preg_match('/Safari/i', $ua) && !preg_match('/Chrome/i', $ua)) {
                return 'Safari';
            }
            if (preg_match('/Firefox/i', $ua)) {
                return 'Firefox';
            }
            if (preg_match('/MSIE|Trident/i', $ua)) {
                return 'Internet Explorer';
            }

            return 'Other';
        }

        /**
         * Detect operating system.
         */
        public function detect_os($user_agent)
        {
            $ua = $user_agent;

            if (preg_match('/windows|win32/i', $ua)) {
                return 'Windows';
            }
            if (preg_match('/android/i', $ua)) {
                return 'Android';
            }
            if (preg_match('/iphone|ipad|ipod/i', $ua)) {
                return 'iOS';
            }
            if (preg_match('/macintosh|mac os x/i', $ua)) {
                return 'macOS';
            }
            if (preg_match('/linux/i', $ua)) {
                return 'Linux';
            }

            return 'Other';
        }

        /**
         * Checks if the user-agent is a search engine spider / bot.
         */
        public function is_bot($user_agent)
        {
            if (empty($user_agent)) {
                return false;
            }
            $bot_pattern = '/(bot|crawl|spider|slurp|facebookexternalhit|bingbot|googlebot|yandex|duckduckbot|baiduspider|headless|ahrefs|semrush)/i';
            return (bool) preg_match($bot_pattern, $user_agent);
        }

        /**
         * Cleans and classifies referrer (Direct, Google, Facebook, WhatsApp, etc.)
         */
        public function get_clean_referrer()
        {
            if (empty($_SERVER['HTTP_REFERER'])) {
                return 'Direct Visit';
            }

            $ref = $_SERVER['HTTP_REFERER'];
            $host = parse_url($ref, PHP_URL_HOST);

            // Self-referrals are considered internal navigation
            if ($host && isset($_SERVER['HTTP_HOST']) && $host === $_SERVER['HTTP_HOST']) {
                return 'Direct / Internal';
            }

            if (strpos($ref, 'google') !== false) {
                return 'Google Search';
            }
            if (strpos($ref, 'bing') !== false) {
                return 'Bing Search';
            }
            if (strpos($ref, 'facebook') !== false) {
                return 'Facebook';
            }
            if (strpos($ref, 'instagram') !== false) {
                return 'Instagram';
            }
            if (strpos($ref, 'whatsapp') !== false || strpos($ref, 'api.whatsapp.com') !== false) {
                return 'WhatsApp';
            }
            if (strpos($ref, 'youtube') !== false) {
                return 'YouTube';
            }

            return $host ? $host : substr($ref, 0, 40);
        }

        /**
         * Automatically derives human-friendly page names from URI.
         */
        public function derive_page_title($uri)
        {
            $path = parse_url($uri, PHP_URL_PATH);
            $filename = basename($path);

            if (empty($filename) || $filename === 'demopostic' || $filename === 'index.php') {
                return 'Home Page';
            }

            switch ($filename) {
                case 'single_product.php':
                    return 'Product Details';
                case 'all_product.php':
                    return 'All Products Catalog';
                case 'catagory.php':
                    return 'Flavor Category';
                case 'addtocart.php':
                    return 'Shopping Cart';
                case 'userprofile.php':
                    return 'Checkout & Payment';
                case 'exist_order.php':
                    return 'My Orders & Account';
                case 'user_login.php':
                    return 'Customer Login';
                case 'user_register.php':
                    return 'Customer Registration';
                case 'search_product.php':
                    return 'Product Search Results';
                case 'print_invoice.php':
                    return 'Order Invoice';
                default:
                    $title = str_replace(array('.php', '_', '-'), array('', ' ', ' '), $filename);
                    return ucwords($title);
            }
        }

        /**
         * =========================================================================
         * ANALYTICS REPORTING METHODS FOR ADMIN DASHBOARD
         * =========================================================================
         */

        /**
         * Comprehensive traffic overview summary.
         */
        public function get_summary()
        {
            if (!$this->db) {
                return $this->get_empty_summary();
            }

            // 1. Today's stats
            $today_q = "SELECT 
                COUNT(*) as total_hits,
                COUNT(DISTINCT session_id) as unique_visitors,
                COUNT(DISTINCT visitor_ip) as unique_ips,
                COUNT(DISTINCT user_id) as logged_customers
            FROM `visitor_logs` WHERE `visit_date` = CURDATE()";
            $today_res = @mysqli_query($this->db, $today_q);
            $today = $today_res ? mysqli_fetch_assoc($today_res) : array();

            // 2. Currently active visitors (last 15 minutes)
            $active_q = "SELECT COUNT(DISTINCT session_id) as active_now FROM `visitor_logs` WHERE `visit_time` >= (NOW() - INTERVAL 15 MINUTE)";
            $active_res = @mysqli_query($this->db, $active_q);
            $active_row = $active_res ? mysqli_fetch_assoc($active_res) : array();

            // 3. This week & this month
            $week_q = "SELECT COUNT(DISTINCT session_id) as week_unique, COUNT(*) as week_hits FROM `visitor_logs` WHERE `visit_date` >= (CURDATE() - INTERVAL 7 DAY)";
            $week_res = @mysqli_query($this->db, $week_q);
            $week = $week_res ? mysqli_fetch_assoc($week_res) : array();

            $month_q = "SELECT COUNT(DISTINCT session_id) as month_unique, COUNT(*) as month_hits FROM `visitor_logs` WHERE `visit_date` >= (CURDATE() - INTERVAL 30 DAY)";
            $month_res = @mysqli_query($this->db, $month_q);
            $month = $month_res ? mysqli_fetch_assoc($month_res) : array();

            // 4. All time totals
            $all_q = "SELECT COUNT(DISTINCT session_id) as all_unique, COUNT(*) as all_hits FROM `visitor_logs`";
            $all_res = @mysqli_query($this->db, $all_q);
            $all = $all_res ? mysqli_fetch_assoc($all_res) : array();

            // 5. Device Breakdown (Mobile vs Desktop vs Tablet)
            $dev_q = "SELECT `device_type`, COUNT(*) as cnt FROM `visitor_logs` GROUP BY `device_type`";
            $dev_res = @mysqli_query($this->db, $dev_q);
            $mobile_cnt = 0;
            $desktop_cnt = 0;
            $tablet_cnt = 0;
            $total_dev = 0;

            if ($dev_res) {
                while ($r = mysqli_fetch_assoc($dev_res)) {
                    $cnt = (int)$r['cnt'];
                    $total_dev += $cnt;
                    if (strtolower($r['device_type']) === 'mobile') {
                        $mobile_cnt = $cnt;
                    } elseif (strtolower($r['device_type']) === 'tablet') {
                        $tablet_cnt = $cnt;
                    } else {
                        $desktop_cnt += $cnt;
                    }
                }
            }

            $mobile_pct = $total_dev > 0 ? round(($mobile_cnt / $total_dev) * 100) : 0;
            $desktop_pct = $total_dev > 0 ? round(($desktop_cnt / $total_dev) * 100) : 0;
            $tablet_pct = $total_dev > 0 ? round(($tablet_cnt / $total_dev) * 100) : 0;

            return array(
                'today_pageviews'    => (int)($today['total_hits'] ?? 0),
                'today_visitors'     => (int)($today['unique_visitors'] ?? 0),
                'today_customers'    => (int)($today['logged_customers'] ?? 0),
                'active_now'         => (int)($active_row['active_now'] ?? 0),
                'week_visitors'      => (int)($week['week_unique'] ?? 0),
                'week_pageviews'     => (int)($week['week_hits'] ?? 0),
                'month_visitors'     => (int)($month['month_unique'] ?? 0),
                'month_pageviews'    => (int)($month['month_hits'] ?? 0),
                'all_visitors'       => (int)($all['all_unique'] ?? 0),
                'all_pageviews'      => (int)($all['all_hits'] ?? 0),
                'devices' => array(
                    'mobile_pct'  => $mobile_pct,
                    'desktop_pct' => $desktop_pct,
                    'tablet_pct'  => $tablet_pct,
                    'mobile_cnt'  => $mobile_cnt,
                    'desktop_cnt' => $desktop_cnt,
                    'tablet_cnt'  => $tablet_cnt,
                )
            );
        }

        /**
         * Fetch recent live visitor arrivals.
         */
        public function get_recent_visits($limit = 15)
        {
            if (!$this->db) {
                return array();
            }

            $limit = (int)$limit;
            $query = "SELECT * FROM `visitor_logs` ORDER BY `id` DESC LIMIT $limit";
            $res = @mysqli_query($this->db, $query);
            $visits = array();

            if ($res) {
                while ($row = mysqli_fetch_assoc($res)) {
                    $row['time_ago'] = $this->time_elapsed_string($row['visit_time']);
                    $visits[] = $row;
                }
            }

            return $visits;
        }

        /**
         * Fetch top visited pages.
         */
        public function get_top_pages($limit = 5)
        {
            if (!$this->db) {
                return array();
            }

            $limit = (int)$limit;
            $query = "SELECT `page_title`, `page_url`, COUNT(*) as views, COUNT(DISTINCT session_id) as visitors 
                      FROM `visitor_logs` 
                      GROUP BY `page_title`, `page_url` 
                      ORDER BY views DESC LIMIT $limit";
            $res = @mysqli_query($this->db, $query);
            $pages = array();

            if ($res) {
                while ($row = mysqli_fetch_assoc($res)) {
                    $pages[] = $row;
                }
            }

            return $pages;
        }

        /**
         * Helper: Converts datetime string to "x mins ago" format.
         */
        public function time_elapsed_string($datetime, $full = false)
        {
            $tz = new DateTimeZone('Asia/Kolkata');
            $now = new DateTime('now', $tz);
            $ago = new DateTime($datetime, $tz);
            $diff = $now->diff($ago);

            if ($diff->invert === 0 && ($diff->s > 5 || $diff->i > 0 || $diff->h > 0 || $diff->d > 0)) {
                return 'Just now';
            }

            $weeks = (int) floor($diff->d / 7);
            $days = $diff->d - ($weeks * 7);

            $units = array(
                array($diff->y, 'year'),
                array($diff->m, 'month'),
                array($weeks, 'week'),
                array($days, 'day'),
                array($diff->h, 'hour'),
                array($diff->i, 'min'),
                array($diff->s, 'sec'),
            );

            $result = array();
            foreach ($units as $u) {
                $val = $u[0];
                $name = $u[1];
                if ($val > 0) {
                    $result[] = $val . ' ' . $name . ($val > 1 ? 's' : '');
                }
            }

            if (!$full) {
                $result = array_slice($result, 0, 1);
            }
            return !empty($result) ? implode(', ', $result) . ' ago' : 'Just now';
        }

        private function get_empty_summary()
        {
            return array(
                'today_pageviews' => 0,
                'today_visitors'  => 0,
                'today_customers' => 0,
                'active_now'      => 0,
                'week_visitors'   => 0,
                'week_pageviews'  => 0,
                'month_visitors'  => 0,
                'month_pageviews' => 0,
                'all_visitors'    => 0,
                'all_pageviews'   => 0,
                'devices'         => array('mobile_pct' => 0, 'desktop_pct' => 0, 'tablet_pct' => 0, 'mobile_cnt' => 0, 'desktop_cnt' => 0, 'tablet_cnt' => 0)
            );
        }
    }
}

/**
 * =========================================================================
 * GLOBAL CONVENIENCE FUNCTION FOR PLUG-AND-PLAY USAGE
 * =========================================================================
 * Simply call track_visitor() on any page to log the visit!
 */
if (!function_exists('track_visitor')) {
    function track_visitor($custom_page_title = null, $connection = null)
    {
        try {
            static $tracker_instance = null;
            if ($tracker_instance === null) {
                $tracker_instance = new PosticTrafficTracker($connection);
            }
            return $tracker_instance->track($custom_page_title);
        } catch (Exception $e) {
            // Silently ignore to guarantee frontend never crashes
            return false;
        }
    }
}
