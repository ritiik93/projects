<?php 
ini_set("display_errors", "off");

if (isset($_POST['remove_product'])) {
    foreach ($_SESSION['cart'] as $key => $value) {
        if ($value['pdt_name'] == $_POST['remove_pdt_name']) {
            unset($_SESSION['cart'][$key]);
            $_SESSION['cart'] = array_values($_SESSION['cart']);
        }
    }
}

if (!isset($obj)) {
    $obj = new adminback();
}
$logo_info = $obj->display_logo();
$logo = $logo_info ? mysqli_fetch_assoc($logo_info) : null;

$cart_count = 0;
$cart_total = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $q = isset($item['quantity']) ? (int)$item['quantity'] : 1;
        $cart_count += $q;
        $cart_total += ($item['pdt_price'] * $q);
    }
}
?>

<div class="postic-main-navbar" style="background: #ffffff; border-bottom: 1px solid #ede8df; position: sticky; top: 0; z-index: 1000; box-shadow: 0 2px 10px rgba(0,0,0,0.03);">
    <div class="container">
        <div style="display: flex; align-items: center; justify-content: space-between; height: 68px;">
            <!-- Brand Logo -->
            <div style="display: flex; align-items: center;">
                <a href="index.php" style="display: inline-block; line-height: 1;">
                    <?php if ($logo && !empty($logo['img'])) { ?>
                        <img src="admin/uploads/<?php echo htmlspecialchars($logo['img']); ?>" alt="Postic Makhana Logo" style="height: 48px; width: auto; max-width: 150px; object-fit: contain;">
                    <?php } else { ?>
                        <img src="admin/uploads/logo.png" alt="Postic Logo" style="height: 48px; width: auto;">
                    <?php } ?>
                </a>
            </div>

            <!-- Desktop Navigation Menu -->
            <div class="hidden-sm hidden-xs" style="display: flex; align-items: center;">
                <ul class="postic-nav-links clone-main-menu" style="display: flex; list-style: none; margin: 0; padding: 0; gap: 24px; align-items: center;">
                    <li><a href="index.php" style="font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; transition: color 0.2s ease;">Home</a></li>
                    <li><a href="all_product.php" style="font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; transition: color 0.2s ease;">All Makhana</a></li>
                    <li><a href="about_us.php" style="font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; transition: color 0.2s ease;">About Us</a></li>
                    <li><a href="index.php#partner-section" style="font-size: 14px; font-weight: 700; color: #c8102e; text-decoration: none; transition: color 0.2s ease;"><i class="fa fa-handshake-o"></i> Wholesale &amp; Bulk</a></li>
                    <li><a href="exist_order.php" style="font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; transition: color 0.2s ease;"><i class="fa fa-truck" style="color: #c8102e;"></i> Track Order</a></li>
                    <?php if (isset($_SESSION['user_id'])) { 
                        $sess_user = !empty($_SESSION['username']) ? $_SESSION['username'] : 'Account';
                    ?>
                        <li class="postic-account-nav-item" style="position: relative;">
                            <a href="userprofile.php" style="font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; padding: 6px 10px; border-radius: 8px; background: #fdfbf7; border: 1px solid #ede8df;">
                                <i class="fa fa-user-circle" style="color: #c8102e; font-size: 16px;"></i>
                                <span><?php echo htmlspecialchars($sess_user); ?></span>
                                <i class="fa fa-angle-down" style="font-size: 11px; color: #78716c;"></i>
                            </a>
                            <ul class="postic-account-dropdown-menu" style="display: none; position: absolute; top: calc(100% + 4px); right: 0; background: #ffffff; border: 1px solid #ede8df; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); padding: 8px 0; min-width: 175px; list-style: none; z-index: 10002;">
                                <li><a href="userprofile.php" style="display: flex; align-items: center; gap: 8px; padding: 8px 16px; font-size: 13px; color: #1c1917; text-decoration: none; font-weight: 600;"><i class="fa fa-user" style="color: #c8102e; width: 16px;"></i> My Profile</a></li>
                                <li><a href="exist_order.php" style="display: flex; align-items: center; gap: 8px; padding: 8px 16px; font-size: 13px; color: #1c1917; text-decoration: none; font-weight: 600;"><i class="fa fa-list-alt" style="color: #c8102e; width: 16px;"></i> My Orders</a></li>
                                <li style="border-top: 1px solid #f1f5f9; margin-top: 4px; padding-top: 4px;"><a href="userprofile.php?logout=logout" style="display: flex; align-items: center; gap: 8px; padding: 8px 16px; font-size: 13px; color: #ef4444; text-decoration: none; font-weight: 700;"><i class="fa fa-sign-out" style="width: 16px;"></i> Logout</a></li>
                            </ul>
                        </li>
                    <?php } else { ?>
                        <li>
                            <a href="user_login.php" style="font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 8px; background: #fdfbf7; border: 1px solid #ede8df; transition: all 0.2s ease;">
                                <i class="fa fa-user-circle-o" style="color: #c8102e; font-size: 15px;"></i> Login / Account
                            </a>
                        </li>
                    <?php } ?>
                </ul>
            </div>

            <!-- Header Right: Search, Notification Bell & Cart Pill -->
            <div style="display: flex; align-items: center; gap: 12px;">
                <!-- Desktop Search Pill -->
                <div class="hidden-xs" style="position: relative;">
                    <form action="search_product.php" method="get" autocomplete="off" style="margin: 0; display: flex; align-items: center;">
                        <input type="text" name="keyword" placeholder="Search flavours..." autocomplete="off" style="width: 170px; height: 38px; border-radius: 20px; border: 1px solid #ede8df; padding: 0 35px 0 14px; font-size: 12px; background: #fdfbf7; outline: none; transition: all 0.2s ease;" onfocus="this.style.width='210px'; this.style.borderColor='#c8102e';" onblur="this.style.width='170px'; this.style.borderColor='#ede8df';">
                        <button type="submit" style="position: absolute; right: 8px; background: none; border: none; color: #78716c; cursor: pointer; font-size: 13px;">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>
                </div>

                <!-- Bell Icon for Notifications (Offers, Products, Company) -->
                <div class="postic-notify-wrap" style="position: relative;">
                    <button type="button" id="posticNotifyBellBtn" aria-label="Notifications" title="Postic Notifications & Offers" style="width: 38px; height: 38px; border-radius: 50%; border: 1px solid #ede8df; background: #ffffff; color: #1c1917; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 16px; position: relative; transition: all 0.2s ease; box-shadow: 0 1px 4px rgba(0,0,0,0.04);">
                        <i class="fa fa-bell-o" style="color: #1c1917;"></i>
                        <span id="posticNotifyBadge" style="position: absolute; top: -3px; right: -3px; background: #c8102e; color: #ffffff; border-radius: 50%; width: 18px; height: 18px; font-size: 10px; font-weight: 900; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 6px rgba(200,16,46,0.35); border: 2px solid #ffffff;">3</span>
                    </button>

                    <!-- Notifications Dropdown Box -->
                    <div id="posticNotifyDropdown" style="display: none; position: absolute; right: 0; top: calc(100% + 12px); width: 330px; max-width: calc(100vw - 24px); background: #ffffff; border: 1px solid #ede8df; border-radius: 14px; box-shadow: 0 16px 36px rgba(0,0,0,0.15); z-index: 10005; overflow: hidden; animation: posticNotifyFadeIn 0.2s ease;">
                        <div style="background: #fdfbf7; padding: 12px 16px; border-bottom: 1px solid #ede8df; display: flex; align-items: center; justify-content: space-between;">
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <i class="fa fa-bell" style="color: #c8102e; font-size: 14px;"></i>
                                <span style="font-weight: 800; font-size: 13px; color: #1c1917; text-transform: uppercase; letter-spacing: 0.5px;">Notifications</span>
                            </div>
                            <span id="posticMarkReadBtn" style="font-size: 11px; font-weight: 700; color: #c8102e; cursor: pointer; text-decoration: underline;">Mark read</span>
                        </div>
                        <div style="max-height: 340px; overflow-y: auto; padding: 8px 0;">
                            <!-- Offer 1 -->
                            <a href="all_product.php" class="postic-notify-item" style="display: flex; gap: 12px; padding: 12px 16px; text-decoration: none; border-bottom: 1px solid #f8fafc; transition: background 0.15s ease;">
                                <div style="width: 36px; height: 36px; border-radius: 50%; background: #fef2f2; color: #c8102e; display: flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0;">
                                    <i class="fa fa-tag"></i>
                                </div>
                                <div style="flex: 1;">
                                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 2px;">
                                        <span style="font-size: 12px; font-weight: 800; color: #1c1917;">Flat 15% OFF Special Deal</span>
                                        <span style="font-size: 10px; color: #94a3b8;">Today</span>
                                    </div>
                                    <p style="font-size: 11px; color: #64748b; margin: 0; line-height: 1.4;">Use coupon <strong>POSTIC15</strong> at checkout on all roasted fox nut flavours! Free shipping on ₹299+.</p>
                                </div>
                            </a>

                            <!-- Product Update 2 -->
                            <a href="all_product.php" class="postic-notify-item" style="display: flex; gap: 12px; padding: 12px 16px; text-decoration: none; border-bottom: 1px solid #f8fafc; transition: background 0.15s ease;">
                                <div style="width: 36px; height: 36px; border-radius: 50%; background: #f0fdf4; color: #166534; display: flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0;">
                                    <i class="fa fa-leaf"></i>
                                </div>
                                <div style="flex: 1;">
                                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 2px;">
                                        <span style="font-size: 12px; font-weight: 800; color: #1c1917;">Fresh Roasted Batch Ready</span>
                                        <span style="font-size: 10px; color: #94a3b8;">Just now</span>
                                    </div>
                                    <p style="font-size: 11px; color: #64748b; margin: 0; line-height: 1.4;">Cheese Tomato &amp; Pani Puri packs roasted fresh today in Udaipur with 100% natural spices.</p>
                                </div>
                            </a>

                            <!-- Company News 3 -->
                            <a href="about_us.php" class="postic-notify-item" style="display: flex; gap: 12px; padding: 12px 16px; text-decoration: none; transition: background 0.15s ease;">
                                <div style="width: 36px; height: 36px; border-radius: 50%; background: #eff6ff; color: #1d4ed8; display: flex; align-items: center; justify-content: center; font-size: 15px; flex-shrink: 0;">
                                    <i class="fa fa-handshake-o"></i>
                                </div>
                                <div style="flex: 1;">
                                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 2px;">
                                        <span style="font-size: 12px; font-weight: 800; color: #1c1917;">Wholesale Desk Open</span>
                                        <span style="font-size: 10px; color: #94a3b8;">1d ago</span>
                                    </div>
                                    <p style="font-size: 11px; color: #64748b; margin: 0; line-height: 1.4;">PAN-India distribution and bulk orders now available with direct factory pricing.</p>
                                </div>
                            </a>
                        </div>
                        <div style="background: #fdfbf7; padding: 10px 16px; text-align: center; border-top: 1px solid #ede8df;">
                            <a href="all_product.php" style="font-size: 12px; font-weight: 800; color: #c8102e; text-decoration: none;">Shop All Makhana Flavours &rarr;</a>
                        </div>
                    </div>
                </div>

                <!-- Modern Cart Pill Button -->
                <a href="addtocart.php" class="postic-cart-pill" style="background: #c8102e; color: #ffffff; padding: 8px 16px; border-radius: 22px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; font-weight: 800; font-size: 13px; box-shadow: 0 2px 10px rgba(200,16,46,0.25); transition: all 0.2s ease;">
                    <i class="fa fa-shopping-cart" style="font-size: 14px;"></i>
                    <span class="hidden-xs">Cart</span>
                    <span class="postic-cart-count-badge" style="background: #ffffff; color: #c8102e; border-radius: 50%; width: 20px; height: 20px; display: inline-flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 900; transition: transform 0.2s ease;">
                        <?php echo $cart_count; ?>
                    </span>
                    <span class="hidden-xs postic-cart-total-badge" style="font-size: 12px; opacity: 0.9; <?php echo ($cart_total > 0) ? '' : 'display: none;'; ?>">₹<?php echo $cart_total; ?></span>
                </a>

                <!-- Mobile Menu Hamburger Button -->
                <div class="visible-sm visible-xs">
                    <button type="button" id="posticMobileMenuToggle" aria-label="Open Mobile Menu" style="font-size: 20px; color: #1c1917; background: none; border: none; padding: 6px; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Mobile Slide-In Navigation Drawer -->
<div id="posticDrawerOverlay" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 100000; backdrop-filter: blur(2px); transition: opacity 0.3s ease;"></div>
<div id="posticMobileDrawer" style="position: fixed; top: 0; left: -310px; width: 300px; height: 100%; background: #ffffff; z-index: 100001; box-shadow: 4px 0 20px rgba(0,0,0,0.2); transition: left 0.3s cubic-bezier(0.16, 1, 0.3, 1); display: flex; flex-direction: column; overflow-y: auto;">
    <!-- Drawer Header -->
    <div style="padding: 18px 20px; background: #c8102e; color: #ffffff; display: flex; align-items: center; justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 10px;">
            <img src="admin/uploads/logo.png" alt="Postic Logo" style="height: 38px; width: auto; filter: brightness(0) invert(1);">
            <span style="font-size: 14px; font-weight: 800; letter-spacing: 0.5px;">POSTIC SNACKS</span>
        </div>
        <button type="button" id="posticDrawerCloseBtn" aria-label="Close Menu" style="background: none; border: none; color: #ffffff; font-size: 22px; cursor: pointer; padding: 0 4px; line-height: 1;">&times;</button>
    </div>

    <!-- User Profile Bar -->
    <div style="padding: 14px 20px; background: #fdfbf7; border-bottom: 1px solid #ede8df; display: flex; align-items: center; justify-content: space-between;">
        <?php if (isset($_SESSION['user_id'])) { 
            $m_user = !empty($_SESSION['username']) ? $_SESSION['username'] : 'Customer';
        ?>
            <div>
                <span style="font-size: 11px; color: #78716c; display: block;">Welcome back,</span>
                <strong style="font-size: 14px; color: #1c1917;"><?php echo htmlspecialchars($m_user); ?></strong>
            </div>
            <a href="userprofile.php" style="background: #c8102e; color: #fff; font-size: 11px; font-weight: 800; padding: 5px 12px; border-radius: 14px; text-decoration: none;">Account</a>
        <?php } else { ?>
            <div>
                <span style="font-size: 11px; color: #78716c; display: block;">Hello, Snack Lover!</span>
                <strong style="font-size: 13px; color: #1c1917;">Sign in to your account</strong>
            </div>
            <a href="user_login.php" style="background: #c8102e; color: #fff; font-size: 11px; font-weight: 800; padding: 5px 12px; border-radius: 14px; text-decoration: none;">Login</a>
        <?php } ?>
    </div>

    <!-- Navigation List -->
    <div style="padding: 12px 0; flex: 1;">
        <ul style="list-style: none; margin: 0; padding: 0;">
            <li><a href="index.php" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-home" style="width: 18px; color: #c8102e;"></i> Home</a></li>
            <li><a href="all_product.php" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-th-large" style="width: 18px; color: #c8102e;"></i> All Makhana Flavours</a></li>
            <li><a href="about_us.php" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-info-circle" style="width: 18px; color: #c8102e;"></i> About Us</a></li>
            <li><a href="index.php#partner-section" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-handshake-o" style="width: 18px; color: #c8102e;"></i> Wholesale &amp; Bulk Desk</a></li>
            <li><a href="exist_order.php" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-truck" style="width: 18px; color: #c8102e;"></i> Track Order Status</a></li>
            <li><a href="addtocart.php" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-shopping-cart" style="width: 18px; color: #c8102e;"></i> Shopping Cart (<?php echo $cart_count; ?>)</a></li>
            <?php if (isset($_SESSION['user_id'])) { ?>
                <li><a href="userprofile.php" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-user" style="width: 18px; color: #c8102e;"></i> My Profile</a></li>
                <li><a href="userprofile.php?logout=logout" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #ef4444; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-sign-out" style="width: 18px;"></i> Logout</a></li>
            <?php } else { ?>
                <li><a href="user_login.php" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-sign-in" style="width: 18px; color: #c8102e;"></i> Login</a></li>
                <li><a href="user_register.php" style="display: flex; align-items: center; gap: 14px; padding: 12px 22px; font-size: 14px; font-weight: 700; color: #1c1917; text-decoration: none; border-bottom: 1px solid #f8fafc;"><i class="fa fa-user-plus" style="width: 18px; color: #c8102e;"></i> Register</a></li>
            <?php } ?>
        </ul>
    </div>

    <!-- Drawer Footer: Social Links -->
    <div style="padding: 16px 20px; background: #fdfbf7; border-top: 1px solid #ede8df;">
        <span style="font-size: 11px; font-weight: 800; color: #78716c; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 10px;">Connect with Postic</span>
        <div style="display: flex; gap: 10px;">
            <a href="https://www.instagram.com/postic_snacks" target="_blank" title="Instagram: postic_snacks" style="width: 34px; height: 34px; border-radius: 50%; background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); color: #fff; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 15px;">
                <i class="fa fa-instagram"></i>
            </a>
            <a href="https://www.facebook.com/p/Postic-Snacks-61583351282686/" target="_blank" title="Facebook: Postic Snacks" style="width: 34px; height: 34px; border-radius: 50%; background: #1877f2; color: #fff; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 15px;">
                <i class="fa fa-facebook"></i>
            </a>
            <a href="https://wa.me/919216398316?text=Hi%20Postic" target="_blank" title="WhatsApp: Postic Support" style="width: 34px; height: 34px; border-radius: 50%; background: #25D366; color: #fff; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 15px;">
                <i class="fa fa-whatsapp"></i>
            </a>
            <a href="tel:+919216398316" title="Call Us" style="width: 34px; height: 34px; border-radius: 50%; background: #1e293b; color: #fff; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 14px;">
                <i class="fa fa-phone"></i>
            </a>
        </div>
    </div>
</div>

