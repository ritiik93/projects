 <!-- Preloader -->
 <div id="biof-loading">
        <div class="biof-loading-center">
            <div class="biof-loading-center-absolute">
                <div class="dot dot-one"></div>
                <div class="dot dot-two"></div>
                <div class="dot dot-three"></div>
            </div>
        </div>
 </div>
 <script>
    (function(){
        function hidePreloader(){
            var p = document.getElementById('biof-loading');
            if(p){
                p.style.transition = 'opacity 0.25s ease-out';
                p.style.opacity = '0';
                p.style.pointerEvents = 'none';
                setTimeout(function(){
                    if(p && p.parentNode) p.parentNode.removeChild(p);
                }, 260);
            }
        }
        if(document.readyState === 'interactive' || document.readyState === 'complete'){
            setTimeout(hidePreloader, 100);
        } else {
            document.addEventListener('DOMContentLoaded', function(){
                setTimeout(hidePreloader, 150);
            });
            window.addEventListener('load', hidePreloader);
            setTimeout(hidePreloader, 800);
        }
    })();
 </script>