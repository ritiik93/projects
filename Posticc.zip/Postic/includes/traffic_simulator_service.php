<?php
/**
 * =========================================================================================
 * POSTIC DEDICATED TRAFFIC SIMULATION ENGINE & STATE MANAGER
 * =========================================================================================
 * - Handles persistent simulator configuration (ON/OFF, preset & custom ranges).
 * - Implements gradual dynamic count changes, irregular intervals, zero-lull periods.
 * - Generates realistic visitor arrivals/departures, pageviews, and session durations.
 * - Zero database pollution: Real tracking logs remain 100% separate & unpolluted.
 * =========================================================================================
 */

if (!class_exists('PosticTrafficSimulator')) {

    class PosticTrafficSimulator
    {
        private static $instance = null;
        private $state_file;
        private $config_dir;

        public function __construct()
        {
            $this->config_dir = dirname(__DIR__) . '/admin/config';
            $this->state_file = $this->config_dir . '/simulator_state.json';
            $this->ensure_storage();
        }

        public static function get_instance()
        {
            if (self::$instance === null) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Ensures the secure storage directory and .htaccess protection exist
         */
        private function ensure_storage()
        {
            if (!is_dir($this->config_dir)) {
                @mkdir($this->config_dir, 0755, true);
            }

            // Secure the config directory from direct HTTP access
            $htaccess_file = $this->config_dir . '/.htaccess';
            if (!file_exists($htaccess_file)) {
                @file_put_contents($htaccess_file, "# Deny all direct web access\nRequire all denied\n");
            }
        }

        /**
         * Default simulator configuration state
         */
        public function get_default_state()
        {
            return array(
                'enabled' => false,
                'range_type' => '0-200',
                'custom_min' => 50,
                'custom_max' => 250,
                'current_active' => 0,
                'target_active' => 45,
                'today_simulated_visitors' => 0,
                'today_simulated_pageviews' => 0,
                'simulated_avg_duration_sec' => 175,
                'last_tick_time' => time(),
                'last_updated_date' => date('Y-m-d'),
                'zero_lull_active' => false,
                'zero_lull_ticks' => 0,
                'preview_combined' => true,
                'live_stream' => array()
            );
        }

        /**
         * Load persistent state from JSON storage
         */
        public function get_state()
        {
            if (!file_exists($this->state_file)) {
                $default = $this->get_default_state();
                $this->save_state($default);
                return $default;
            }

            $raw = @file_get_contents($this->state_file);
            if (!$raw) {
                return $this->get_default_state();
            }

            $state = @json_decode($raw, true);
            if (!is_array($state)) {
                return $this->get_default_state();
            }

            // Merge with defaults to ensure all keys exist
            $default = $this->get_default_state();
            $merged = array_merge($default, $state);

            // Auto-reset daily counters if date has changed
            $today = date('Y-m-d');
            if ($merged['last_updated_date'] !== $today) {
                $merged['today_simulated_visitors'] = 0;
                $merged['today_simulated_pageviews'] = 0;
                $merged['last_updated_date'] = $today;
                $this->save_state($merged);
            }

            return $merged;
        }

        /**
         * Persist state to file atomically
         */
        public function save_state($state)
        {
            $this->ensure_storage();
            $tmp_file = $this->state_file . '.tmp.' . bin2hex(random_bytes(4));
            $json = json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

            if (@file_put_contents($tmp_file, $json) !== false) {
                @rename($tmp_file, $this->state_file);
                return true;
            }
            return false;
        }

        /**
         * Get boundary minimum and maximum numbers for the currently selected range
         */
        public function get_range_bounds($state = null)
        {
            if ($state === null) {
                $state = $this->get_state();
            }

            $range_type = $state['range_type'] ?? '0-200';

            switch ($range_type) {
                case '0-50':
                    return array('min' => 0, 'max' => 50, 'label' => '0 – 50 Visitors');
                case '50-100':
                    return array('min' => 50, 'max' => 100, 'label' => '50 – 100 Visitors');
                case '0-200':
                    return array('min' => 0, 'max' => 200, 'label' => '0 – 200 Visitors');
                case '200-500':
                    return array('min' => 200, 'max' => 500, 'label' => '200 – 500 Visitors');
                case '500-1000':
                    return array('min' => 500, 'max' => 1000, 'label' => '500 – 1000 Visitors');
                case 'custom':
                    $min = max(0, (int)($state['custom_min'] ?? 50));
                    $max = max($min + 1, (int)($state['custom_max'] ?? 250));
                    return array('min' => $min, 'max' => $max, 'label' => "Custom ({$min} – {$max})");
                default:
                    return array('min' => 0, 'max' => 50, 'label' => '0 – 50 Visitors');
            }
        }

        /**
         * Update simulator ON/OFF status
         */
        public function set_enabled($enabled)
        {
            $state = $this->get_state();
            $state['enabled'] = (bool) $enabled;

            $bounds = $this->get_range_bounds($state);

            if ($state['enabled']) {
                // When turned ON, seed initial active count gradually if currently 0
                if ($state['current_active'] <= 0 || $state['current_active'] < $bounds['min'] || $state['current_active'] > $bounds['max']) {
                    $init_max = max(1, min($bounds['max'], (int) round($bounds['min'] + ($bounds['max'] - $bounds['min']) * 0.25)));
                    $state['current_active'] = rand(max(1, $bounds['min']), max(1, $init_max));
                }
                $state['target_active'] = rand(max(1, $bounds['min']), max(1, min($bounds['max'], $state['current_active'] + 3)));
                $state['last_tick_time'] = time();

                // If today's count is 0 or exceeds range max, set a realistic baseline
                if ($state['today_simulated_visitors'] <= 0 || $state['today_simulated_visitors'] > $bounds['max']) {
                    $base_visitors = $this->get_baseline_visitors_for_range($bounds['min'], $bounds['max'], $state['current_active']);
                    $state['today_simulated_visitors'] = $base_visitors;
                    $state['today_simulated_pageviews'] = (int) round($base_visitors * (rand(170, 195) / 100));
                }
            } else {
                // When turned OFF, clear active simulated visitors
                $state['current_active'] = 0;
                $state['target_active'] = 0;
                $state['zero_lull_active'] = false;
            }

            $this->save_state($state);
            return $state;
        }

        /**
         * Calculate a realistic starting visitor baseline proportional to range and active count
         */
        public function get_baseline_visitors_for_range($min, $max, $current_active = 3)
        {
            if ($max <= 10) {
                return max($min + 1, rand(2, min($max, 5)));
            } elseif ($max <= 50) {
                // For 0-50 range: 7 to 15 visitors
                return max($current_active + 2, rand(max(6, $min + 3), min($max, 15)));
            } elseif ($max <= 100) {
                // For 50-100 range: 35 to 60 visitors
                return max($current_active + 5, rand(max(30, $min + 5), min($max, 60)));
            } elseif ($max <= 200) {
                // For 0-200 range: 65 to 105 visitors
                return max($current_active + 10, rand(max(55, $min + 10), min($max, 105)));
            } elseif ($max <= 500) {
                // For 200-500 range: 210 to 320 visitors
                return rand(max(200, $min + 15), min($max, 320));
            } else {
                // For 500-1000 range: 510 to 720 visitors
                return rand(max(500, $min + 30), min($max, 740));
            }
        }

        /**
         * Update selected range option (0-50, 50-100, 0-200, 200-500, 500-1000, or custom)
         */
        public function set_range($range_type, $custom_min = null, $custom_max = null)
        {
            $valid_ranges = array('0-50', '50-100', '0-200', '200-500', '500-1000', 'custom');
            if (!in_array($range_type, $valid_ranges, true)) {
                return array('success' => false, 'error' => 'Invalid range type selected.');
            }

            $state = $this->get_state();
            $old_range = $state['range_type'] ?? '';
            $state['range_type'] = $range_type;

            if ($range_type === 'custom') {
                if ($custom_min === null || $custom_max === null) {
                    return array('success' => false, 'error' => 'Custom minimum and maximum values are required.');
                }
                $c_min = (int) $custom_min;
                $c_max = (int) $custom_max;

                if ($c_min < 0) {
                    return array('success' => false, 'error' => 'Minimum visitor count must be 0 or greater.');
                }
                if ($c_max <= $c_min) {
                    return array('success' => false, 'error' => 'Maximum visitor count must be strictly greater than minimum.');
                }
                if ($c_max > 50000) {
                    return array('success' => false, 'error' => 'Maximum visitor count cannot exceed 50,000.');
                }

                $state['custom_min'] = $c_min;
                $state['custom_max'] = $c_max;
            }

            // Immediately adjust target and bounds
            $bounds = $this->get_range_bounds($state);
            $min = $bounds['min'];
            $max = $bounds['max'];

            // Set a realistic target within the new range
            $state['target_active'] = rand($min, max($min + 1, min($max, (int) round($min + ($max - $min) * 0.35))));

            if ($state['enabled']) {
                // Smooth clamp current active into the new bounds
                if ($state['current_active'] < $min) {
                    $state['current_active'] = $min === 0 ? rand(1, min(4, $max)) : $min;
                } elseif ($state['current_active'] > $max) {
                    $state['current_active'] = $max;
                }
            }

            // Auto-scale today's cumulative visitors and pageviews to fit the selected range!
            if ($old_range !== $range_type || $state['today_simulated_visitors'] > $max || $state['today_simulated_visitors'] < $min) {
                $base_visitors = $this->get_baseline_visitors_for_range($min, $max, $state['current_active']);
                $state['today_simulated_visitors'] = $base_visitors;
                $state['today_simulated_pageviews'] = (int) round($base_visitors * (rand(170, 195) / 100));
            }

            $this->save_state($state);
            return array('success' => true, 'state' => $state);
        }

        /**
         * Core Stochastic Simulation Algorithm:
         * Calculates realistic gradual visitor fluctuations, arrivals, departures, and occasional zero-lulls.
         */
        public function simulate_tick()
        {
            $state = $this->get_state();

            if (!$state['enabled']) {
                $state['current_active'] = 0;
                $this->save_state($state);
                return $state;
            }

            $bounds = $this->get_range_bounds($state);
            $min = $bounds['min'];
            $max = $bounds['max'];
            $range_span = max(1, $max - $min);

            // Step size proportional to the range (gradual, not jarring)
            $base_step = max(1, (int) round($range_span * 0.04));
            $max_step  = max(2, (int) round($range_span * 0.08));

            // Check / manage occasional zero-count lull period (only when min is 0)
            if ($min === 0) {
                if ($state['zero_lull_active']) {
                    $state['zero_lull_ticks']--;
                    if ($state['zero_lull_ticks'] <= 0) {
                        $state['zero_lull_active'] = false;
                        $state['target_active'] = rand(max(5, (int)($max * 0.15)), min($max, (int)($max * 0.45)));
                    } else {
                        // Accelerate downward towards 0
                        $state['target_active'] = 0;
                    }
                } else {
                    // Occasional lull: trigger quiet period if currently low
                    if ($state['current_active'] <= ($min + 15) && rand(1, 100) <= 6) {
                        $state['zero_lull_active'] = true;
                        $state['zero_lull_ticks'] = rand(3, 6);
                        $state['target_active'] = 0;
                    }
                }
            }

            // Periodic 5-minute traffic wave (natural ebb and flow: 5-10 users enter, then quiet down, then rise again)
            if (!isset($state['wave_counter'])) {
                $state['wave_counter'] = 0;
                $state['wave_phase'] = 'flow';
            }
            $state['wave_counter']++;

            if ($state['wave_counter'] >= rand(25, 40)) { // roughly every 3-5 minutes
                $state['wave_counter'] = 0;
                if ($state['wave_phase'] === 'flow') {
                    // Enter quiet/ebb phase: drop active target gently by 3-6 users
                    $state['wave_phase'] = 'ebb';
                    $drop = rand(3, 6);
                    $state['target_active'] = max($min, $state['current_active'] - $drop);
                } else {
                    // Enter flow phase: pick fresh active target
                    $state['wave_phase'] = 'flow';
                    $state['target_active'] = rand($min, $max);
                }
            }

            // If reached or very close to target, gently adjust target within bounds
            if (abs($state['current_active'] - $state['target_active']) <= 1 && !$state['zero_lull_active']) {
                $span_third = max(2, (int) round($range_span * 0.25));
                $state['target_active'] = rand(max($min, $state['current_active'] - $span_third), min($max, $state['current_active'] + $span_third));
            }

            // Smooth gradual stepping: active count moves by only 0 or 1 per tick
            $current = $state['current_active'];
            $target  = $state['target_active'];

            $step = 0;
            if ($target > $current) {
                $step = (rand(1, 100) <= 65) ? 1 : 0;
            } elseif ($target < $current) {
                $step = (rand(1, 100) <= 60) ? -1 : 0;
            } else {
                // Subtle random wobble when at target
                $r = rand(1, 100);
                if ($r <= 15 && $current < $max) $step = 1;
                elseif ($r >= 85 && $current > $min) $step = -1;
            }

            $new_active = max($min, min($max, $current + $step));
            $state['current_active'] = $new_active;

            // Cumulative Today's Visitors: Paced realistically (not every tick!)
            // Rate scales with current active count:
            // When 2-4 users online (e.g. 0-50 range), arrival probability is only ~4% (~once every 3 minutes).
            // When 50 users online, arrival probability is ~20%.
            $arrival_prob = max(3, min(22, (int) round($new_active * 1.2)));
            if ($state['wave_phase'] === 'ebb') {
                $arrival_prob = max(2, (int) round($arrival_prob * 0.5));
            }

            // Increment visitor only if within range max
            if (rand(1, 100) <= $arrival_prob && $state['today_simulated_visitors'] < $max) {
                $state['today_simulated_visitors'] += 1;
                // 1 new visitor views 1 or 2 pages initially
                $state['today_simulated_pageviews'] += (rand(1, 10) <= 7) ? 1 : 2;

                // Add realistic visitor arrival event to live stream
                $new_event = $this->generate_simulated_event();
                if (!isset($state['live_stream']) || !is_array($state['live_stream'])) {
                    $state['live_stream'] = array();
                }
                array_unshift($state['live_stream'], $new_event);
                $state['live_stream'] = array_slice($state['live_stream'], 0, 15);
            } else {
                // Active user page exploration:
                // An active user occasionally navigates to another page (+1 pageview)
                if ($new_active > 0 && rand(1, 100) <= min(14, (int) round($new_active * 2.2))) {
                    // Maximum pageviews ratio: capped at ~2.1x of total visitors
                    if ($state['today_simulated_pageviews'] < ($state['today_simulated_visitors'] * 2.1)) {
                        $state['today_simulated_pageviews'] += 1;
                    }
                }
            }

            $state['simulated_avg_duration_sec'] = rand(150, 240);
            $state['last_tick_time'] = time();

            $this->save_state($state);
            return $state;
        }

        /**
         * Generates a realistic mock visitor activity stream entry:
         * Masked identities (Rxxxxx Sxxxxx, User_849588, Visitor_4829)
         * Short clean sources: Instagram, WhatsApp, Google, Direct
         */
        private function generate_simulated_event()
        {
            $identities = array(
                array('name' => 'Rxxxxx Sxxxxx', 'code' => 'User #84920'),
                array('name' => 'Pxxxxx Sxxxxx', 'code' => 'User #71842'),
                array('name' => 'Axxxxx Pxxxxx', 'code' => 'User #92408'),
                array('name' => 'Kxxxxx Jxxxxx', 'code' => 'User #63820'),
                array('name' => 'Sxxxxx Rxxxxx', 'code' => 'User #51733'),
                array('name' => 'Axxxxx Mxxxxx', 'code' => 'User #39201'),
                array('name' => 'Vxxxxx Sxxxxx', 'code' => 'User #84195'),
                array('name' => 'Rxxxxx Axxxxx', 'code' => 'User #28419'),
                array('name' => 'Dxxxxx Kxxxxx', 'code' => 'User #90142'),
                array('name' => 'User_849588',   'code' => 'Verified Session'),
                array('name' => 'User_391402',   'code' => 'Verified Session'),
                array('name' => 'User_728419',   'code' => 'Verified Session'),
                array('name' => 'Visitor_4829',  'code' => 'Verified Session'),
                array('name' => 'Visitor_9103',  'code' => 'Verified Session'),
                array('name' => 'Visitor_3582',  'code' => 'Verified Session'),
            );

            $cities = array(
                'Mumbai', 'Delhi NCR', 'Bengaluru', 'Ahmedabad', 'Pune',
                'Jaipur', 'Udaipur', 'Hyderabad', 'Kolkata', 'Chandigarh',
                'Surat', 'Indore', 'Lucknow', 'Chennai', 'Nagpur'
            );

            $pages = array(
                array('title' => 'Postic Roasted Makhana - Peri Peri (55g)', 'url' => 'single_product.php?pdt_id=2'),
                array('title' => 'Postic Cream & Onion Crunchy Makhana (55g)', 'url' => 'single_product.php?pdt_id=3'),
                array('title' => 'Tangy Tomato Roasted Lotus Seeds (55g)', 'url' => 'single_product.php?pdt_id=4'),
                array('title' => 'Postic All Flavours Party Combo Pack', 'url' => 'all_product.php'),
                array('title' => 'Shopping Cart', 'url' => 'addtocart.php'),
                array('title' => 'All Products Catalog', 'url' => 'all_product.php'),
                array('title' => 'Home Page', 'url' => 'index.php')
            );

            // Sources: strictly Instagram, WhatsApp, Google, Direct (clean, no extra labels)
            $sources_pool = array(
                'Instagram',
                'Instagram',
                'Instagram',
                'Instagram',
                'WhatsApp',
                'WhatsApp',
                'WhatsApp',
                'Google',
                'Direct'
            );

            $devices = array('Mobile', 'Mobile', 'Mobile', 'Mobile', 'Desktop');
            $browsers_mobile = array('Chrome Mobile', 'Safari Mobile', 'Instagram Browser');
            $browsers_desktop = array('Chrome', 'Edge', 'Safari');

            $c = $identities[array_rand($identities)];
            $p = $pages[array_rand($pages)];
            $city = $cities[array_rand($cities)];
            $src = $sources_pool[array_rand($sources_pool)];
            $dev = $devices[array_rand($devices)];
            $brw = ($dev === 'Mobile') ? $browsers_mobile[array_rand($browsers_mobile)] : $browsers_desktop[array_rand($browsers_desktop)];
            $os  = ($dev === 'Mobile') ? ((rand(1, 10) <= 6) ? 'Android' : 'iOS') : 'Windows';

            return array(
                'id' => bin2hex(random_bytes(6)),
                'customer_name' => $c['name'],
                'user_id' => $c['code'],
                'city' => $city,
                'page_title' => $p['title'],
                'page_url' => $p['url'],
                'device_type' => $dev,
                'device' => $dev,
                'browser' => $brw,
                'os' => $os,
                'source' => $src,
                'referrer' => $src,
                'visitor_ip' => '103.24.' . rand(10, 240) . '.' . rand(10, 240),
                'time' => date('H:i:s'),
                'time_ago' => 'Just now'
            );
        }

        /**
         * Get blended recent visits for dashboard and traffic analytics view:
         * When simulation is active (or has run today), blends realistic Instagram/WhatsApp
         * customer visits so the admin sees a lively e-commerce stream.
         */
        public function get_blended_recent_visits($raw_recent_visits = array(), $limit = 15)
        {
            $state = $this->get_state();

            // If simulator is disabled AND today's simulated count is 0, return raw SQL logs
            if (empty($state['enabled']) && empty($state['today_simulated_visitors'])) {
                return $raw_recent_visits;
            }

            // Generate realistic stream of customers from Instagram, WhatsApp, and Google
            $mock_visits = array();
            $times = array(
                'Just now', '1 min ago', '2 mins ago', '4 mins ago', '6 mins ago',
                '9 mins ago', '13 mins ago', '18 mins ago', '24 mins ago', '32 mins ago',
                '41 mins ago', '53 mins ago', '1 hour ago', '1 hour ago', '2 hours ago'
            );

            // Seed deterministic or stored stream items
            $existing_stream = $state['live_stream'] ?? array();

            for ($i = 0; $i < $limit; $i++) {
                if (isset($existing_stream[$i])) {
                    $ev = $existing_stream[$i];
                    $ev['time_ago'] = $times[$i] ?? "{$i} mins ago";
                    $mock_visits[] = $ev;
                } else {
                    $ev = $this->generate_simulated_event();
                    $ev['time_ago'] = $times[$i] ?? "{$i} mins ago";
                    $mock_visits[] = $ev;
                }
            }

            return $mock_visits;
        }

        /**
         * Reset today's cumulative simulated stats
         */
        public function reset_today_stats()
        {
            $state = $this->get_state();
            $state['today_simulated_visitors'] = 0;
            $state['today_simulated_pageviews'] = 0;
            $state['live_stream'] = array();
            $state['wave_counter'] = 0;
            $this->save_state($state);
            return $state;
        }

        /**
         * Non-Destructive Analytics Integration:
         * Blends simulated numbers with real database analytics ONLY in-memory for preview display.
         * The MySQL `visitor_logs` table remains 100% UNTOUCHED!
         *
         * @param array $real_summary The raw SQL summary array from PosticTrafficTracker::get_summary()
         * @return array Combined summary array
         */
        public function apply_preview_to_summary($real_summary)
        {
            $state = $this->get_state();
            $is_enabled = !empty($state['enabled']);

            // Live active visitors: active only when simulation is broadcasting
            $sim_active = $is_enabled ? (int) ($state['current_active'] ?? 0) : 0;

            // Cumulative stats for today: retain today's accumulated visits even if paused
            $sim_today_visitors = (int) ($state['today_simulated_visitors'] ?? 0);
            $sim_today_pageviews = (int) ($state['today_simulated_pageviews'] ?? 0);

            $combined = $real_summary;
            $combined['active_now'] = (int)($real_summary['active_now'] ?? 0) + $sim_active;
            $combined['today_visitors'] = (int)($real_summary['today_visitors'] ?? 0) + $sim_today_visitors;
            $combined['today_pageviews'] = (int)($real_summary['today_pageviews'] ?? 0) + $sim_today_pageviews;
            $combined['month_visitors'] = (int)($real_summary['month_visitors'] ?? 0) + $sim_today_visitors;
            $combined['month_pageviews'] = (int)($real_summary['month_pageviews'] ?? 0) + $sim_today_pageviews;

            // Realistic Device Distribution blending (avoids 0% Mobile from localhost)
            if ($combined['today_visitors'] > 0) {
                // If real data has 0% mobile or is on localhost, provide realistic mobile e-commerce distribution
                if (empty($combined['devices']['mobile_pct']) || $combined['devices']['mobile_pct'] == 0) {
                    $combined['devices'] = array(
                        'mobile' => (int) round($combined['today_visitors'] * 0.74),
                        'desktop' => (int) round($combined['today_visitors'] * 0.23),
                        'tablet' => (int) round($combined['today_visitors'] * 0.03),
                        'mobile_pct' => 74,
                        'desktop_pct' => 23,
                        'tablet_pct' => 3
                    );
                }
            }

            // Realistic Average Session Duration
            $sec = $state['simulated_avg_duration_sec'] ?? 165;
            $combined['avg_session'] = floor($sec / 60) . 'm ' . ($sec % 60) . 's';

            // Flags for UI preview badges and controls
            $combined['_simulator_active'] = $is_enabled;
            $combined['_simulated_active'] = $sim_active;
            $combined['_simulated_today_visitors'] = $sim_today_visitors;
            $combined['_simulated_today_pageviews'] = $sim_today_pageviews;
            $combined['_simulated_range'] = $state['range_type'];
            $bounds = $this->get_range_bounds($state);
            $combined['_simulated_range_label'] = $bounds['label'];

            return $combined;
        }
    }
}
