<?php
require_once __DIR__ . '/traffic_tracker.php';
track_visitor();
?>
<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Postic | 100% Roasted Natural Makhana & Healthy Snacks</title>
    <meta name="description" content="Postic offers premium slow-roasted Makhana (Fox Nuts) in delicious flavors like Cheese Tomato, Cream & Onion, Lemon, Coriander. 100% natural, roasted fresh in Udaipur, Rajasthan.">
    <meta name="keywords" content="Postic, Makhana, Roasted Fox Nuts, Healthy Snacks, Phool Makhana, Flavored Makhana, Udaipur, Rajasthan, Indian Snacks">
    <meta name="theme-color" content="#d32f2f">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Postic | 100% Roasted Natural Makhana & Healthy Snacks">
    <meta property="og:description" content="Delicious, crispy roasted Makhana crafted with natural spices. No preservatives, zero trans fat. Order online across India.">
    <meta property="og:image" content="assets/images/favicon.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cairo:400,600,700|Poppins:600|Playfair+Display:400i,700i|Ubuntu:400,700&amp;display=swap" rel="stylesheet">
    <!-- Favicon icons -->
    <link rel="icon" type="image/png" href="favicon/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/svg+xml" href="favicon/favicon.svg">
    <link rel="shortcut icon" href="favicon/favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon.png">
    <link rel="manifest" href="favicon/site.webmanifest">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/slick.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/main-color.css">
    <link rel="stylesheet" href="assets/css/postic-theme.css">
    <script src="assets/js/jquery-3.4.1.min.js"></script>
</head>