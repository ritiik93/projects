<?php
// Header bottom kept clean to prevent old multi-tier header clutter
?>