<?php
// Postic Master D2C Product Collection (Clean, Premium & Theme Matched)
if (!isset($obj)) {
    $obj = new adminback();
}

$all_pdt_res = $obj->display_product();
$products_list = array();
if ($all_pdt_res) {
    while ($p = mysqli_fetch_assoc($all_pdt_res)) {
        if (isset($p['pdt_status']) && (int)$p['pdt_status'] === 1) {
            $products_list[] = $p;
        }
    }
}

// Fallback items if DB is offline or empty
if (empty($products_list)) {
    $products_list = array(
        array('pdt_id' => 1, 'pdt_name' => 'Cheese Tomato Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'CheesTomotoM1.png', 'ctg_name' => 'Cheesy & Tangy', 'ctg_id' => 1),
        array('pdt_id' => 2, 'pdt_name' => 'Cream & Onion Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'Cream&OnionM1.png', 'ctg_name' => 'Savory Herb', 'ctg_id' => 2),
        array('pdt_id' => 3, 'pdt_name' => 'Coriander Mint Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'CorinderM1.png', 'ctg_name' => 'Farm Herbs', 'ctg_id' => 3),
        array('pdt_id' => 4, 'pdt_name' => 'Tangy Lemon Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'LemonM1.png', 'ctg_name' => 'Zesty Citrus', 'ctg_id' => 4),
        array('pdt_id' => 5, 'pdt_name' => 'Street Pani Puri Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'PaniPuniM1.png', 'ctg_name' => 'Street Craving', 'ctg_id' => 5),
    );
}

// Get categories for filter pills
$cata_res = $obj->p_display_catagory();
$filter_categories = array();
if ($cata_res) {
    while ($c = mysqli_fetch_assoc($cata_res)) {
        $filter_categories[] = $c;
    }
}
?>

<section class="postic-collection-section" style="padding: 60px 0 50px 0; background: #ffffff;">
    <div class="container">
        <!-- Section Header -->
        <div class="text-center" style="margin-bottom: 35px;">
            <div style="display: inline-flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #c8102e;"></span>
                <span style="font-size: 12px; font-weight: 800; color: #c8102e; text-transform: uppercase; letter-spacing: 1.5px;">The Postic Collection</span>
                <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #c8102e;"></span>
            </div>
            <h2 style="font-size: 34px; font-weight: 900; color: #1c1917; margin: 0 0 10px 0; letter-spacing: -0.8px;">
                Slow-Roasted Artisanal Makhana
            </h2>
            <p style="font-size: 15px; color: #57534e; max-width: 600px; margin: 0 auto; line-height: 1.6;">
                100% dry-roasted in small batches in royal Udaipur. Zero palm oil, gluten-free, with authentic Indian herbs.
            </p>
        </div>

        <!-- Filter Category Tabs -->
        <div class="postic-filter-pills" style="display: flex; justify-content: center; flex-wrap: wrap; gap: 8px; margin-bottom: 35px;">
            <button type="button" class="postic-filter-btn active" data-filter="all" style="background: #c8102e; color: #ffffff; border: 1px solid #c8102e; border-radius: 25px; padding: 8px 20px; font-weight: 800; font-size: 13px; cursor: pointer; transition: all 0.2s ease;">
                All Flavours (<?php echo count($products_list); ?>)
            </button>
            <?php foreach ($filter_categories as $cat_item) { ?>
                <button type="button" class="postic-filter-btn" data-filter="<?php echo $cat_item['ctg_id']; ?>" style="background: #fdfbf7; color: #1c1917; border: 1px solid #ede8df; border-radius: 25px; padding: 8px 18px; font-weight: 700; font-size: 13px; cursor: pointer; transition: all 0.2s ease;">
                    <?php echo htmlspecialchars($cat_item['ctg_name'], ENT_QUOTES, 'UTF-8'); ?>
                </button>
            <?php } ?>
        </div>

        <!-- Products Grid Row -->
        <div class="row postic-grid-row" id="postic-flavor-container" style="display: flex; flex-wrap: wrap;">
            <?php 
            foreach ($products_list as $pdt) {
                $pdt_id = (int)$pdt['pdt_id'];
                $cat_id = (int)($pdt['ctg_id'] ?? $pdt['pdt_ctg'] ?? 0);
                $price = (int)$pdt['pdt_price'];
                $weight = !empty($pdt['pdt_weight']) ? $pdt['pdt_weight'] : '55g';
                $mrp = round($price * 1.25);
            ?>
            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-6 postic-product-col" data-cat="<?php echo $cat_id; ?>" style="margin-bottom: 25px;">
                <div class="postic-product-card" style="background: #ffffff; border: 1px solid #ede8df; border-radius: 16px; padding: 18px 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.03); transition: all 0.3s ease; height: 100%; display: flex; flex-direction: column; position: relative;">
                    <!-- Badges -->
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <span style="background: #fef2f2; color: #c8102e; font-size: 10px; font-weight: 800; padding: 3px 8px; border-radius: 8px; text-transform: uppercase;">
                            <?php echo htmlspecialchars($pdt['ctg_name'] ?? 'Roasted'); ?>
                        </span>
                        <span style="background: #f0fdf4; color: #166534; font-size: 10px; font-weight: 800; padding: 3px 8px; border-radius: 8px;">
                            <?php echo htmlspecialchars($weight); ?> Pouch
                        </span>
                    </div>

                    <!-- Pack Image -->
                    <div class="postic-card-img-wrap" style="height: 180px; display: flex; align-items: center; justify-content: center; margin-bottom: 12px; position: relative;">
                        <a href="single_product.php?status=singleproduct&id=<?php echo $pdt_id; ?>" style="display: flex; align-items: center; justify-content: center; width: 100%; height: 100%;">
                            <img src="admin/uploads/<?php echo htmlspecialchars($pdt['pdt_img']); ?>" alt="<?php echo htmlspecialchars($pdt['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>" style="max-height: 170px; max-width: 100%; object-fit: contain; filter: drop-shadow(0 8px 14px rgba(0,0,0,0.12)); transition: transform 0.3s ease;">
                        </a>
                    </div>

                    <!-- Product Title -->
                    <h4 class="postic-card-title" style="font-size: 14px; font-weight: 800; margin: 0 0 6px 0; line-height: 1.35; height: 38px; overflow: hidden;">
                        <a href="single_product.php?status=singleproduct&id=<?php echo $pdt_id; ?>" style="color: #1c1917; text-decoration: none;">
                            <?php echo htmlspecialchars($pdt['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>
                        </a>
                    </h4>

                    <!-- Rating -->
                    <div style="display: flex; align-items: center; gap: 4px; font-size: 11px; margin-bottom: 10px;">
                        <span style="color: #f59e0b;">&#9733;&#9733;&#9733;&#9733;&#9733;</span>
                        <span style="font-weight: 800; color: #1c1917;">4.9</span>
                        <span style="color: #78716c;">(100+ Reviews)</span>
                    </div>

                    <!-- Price Row -->
                    <div style="display: flex; align-items: baseline; gap: 6px; margin-bottom: 14px; margin-top: auto;">
                        <span style="font-size: 21px; font-weight: 900; color: #c8102e;">₹ <?php echo $price; ?></span>
                        <del style="font-size: 13px; color: #a8a29e;">₹ <?php echo $mrp; ?></del>
                        <span style="font-size: 11px; font-weight: 800; color: #166534; background: #f0fdf4; padding: 1px 5px; border-radius: 4px;">25% OFF</span>
                    </div>

                    <!-- Action Buttons: [- 1 +] Stepper, Add to Cart & View Details -->
                    <div style="margin-top: auto;">
                        <form action="addtocart.php" method="POST" class="postic-ajax-cart-form" style="margin: 0; width: 100%;">
                            <input type="hidden" name="pdt_id" value="<?php echo $pdt_id; ?>">
                            <input type="hidden" name="pdt_name" value="<?php echo htmlspecialchars($pdt['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>">
                            <input type="hidden" name="pdt_price" value="<?php echo $price; ?>">
                            <input type="hidden" name="pdt_img" value="<?php echo htmlspecialchars($pdt['pdt_img'], ENT_QUOTES, 'UTF-8'); ?>">
                            <input type="hidden" name="pdt_weight" value="<?php echo htmlspecialchars($weight); ?>">
                            <input type="hidden" name="addtocart" value="1">

                            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 6px;">
                                <!-- Stepper [- 1 +] -->
                                <div class="postic-card-qty-stepper" style="display: inline-flex; align-items: center; border: 1.5px solid #ede8df; border-radius: 8px; background: #ffffff; height: 36px; overflow: hidden; flex-shrink: 0;">
                                    <button type="button" class="postic-card-qty-btn minus" style="width: 26px; height: 100%; border: none; background: #fdfbf7; font-size: 14px; font-weight: 800; cursor: pointer; color: #1c1917; display: flex; align-items: center; justify-content: center; user-select: none;">&minus;</button>
                                    <input type="number" name="quantity" class="postic-card-qty-val" value="1" min="1" max="10" readonly style="width: 28px; height: 100%; border: none; text-align: center; font-size: 13px; font-weight: 800; color: #1c1917; background: transparent; padding: 0;">
                                    <button type="button" class="postic-card-qty-btn plus" style="width: 26px; height: 100%; border: none; background: #fdfbf7; font-size: 14px; font-weight: 800; cursor: pointer; color: #1c1917; display: flex; align-items: center; justify-content: center; user-select: none;">&#43;</button>
                                </div>
                                <!-- Add Button -->
                                <button type="submit" class="btn postic-add-to-cart-btn" style="flex: 1; height: 36px; background: #c8102e; color: #ffffff; font-weight: 800; font-size: 12px; border-radius: 8px; border: none; display: inline-flex; align-items: center; justify-content: center; gap: 4px; box-shadow: 0 3px 10px rgba(200,16,46,0.22); transition: all 0.2s ease; cursor: pointer; padding: 0 8px; white-space: nowrap;">
                                    <i class="fa fa-shopping-cart"></i> Add
                                </button>
                            </div>
                            <a href="single_product.php?status=singleproduct&id=<?php echo $pdt_id; ?>" style="display: block; width: 100%; text-align: center; font-size: 11px; font-weight: 700; color: #78716c; text-decoration: none; padding: 2px 0; transition: color 0.15s ease;">
                                <i class="fa fa-eye"></i> View Details
                            </a>
                        </form>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>

<script>
document.addEventListener("DOMContentLoaded", function() {
    var filterBtns = document.querySelectorAll('.postic-filter-btn');
    var pdtCols = document.querySelectorAll('.postic-product-col');

    filterBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            filterBtns.forEach(function(b) { 
                b.style.background = '#fdfbf7';
                b.style.color = '#1c1917';
                b.style.borderColor = '#ede8df';
            });
            this.style.background = '#c8102e';
            this.style.color = '#ffffff';
            this.style.borderColor = '#c8102e';

            var filter = this.getAttribute('data-filter');
            pdtCols.forEach(function(col) {
                if (filter === 'all' || col.getAttribute('data-cat') === filter) {
                    col.style.display = 'block';
                } else {
                    col.style.display = 'none';
                }
            });
        });
    });
});
</script>
