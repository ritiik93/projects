<?php
// Postic Premium Wholesale & Partner Desk (Theme Matched to Postic Charcoal, Crimson & Gold)
?>
<section class="postic-partner-contact-section" id="partner-section" style="padding: 50px 0 60px 0; background: #fdfbf7; border-top: 1px solid #ede8df; overflow: hidden;">
    <div class="container">
        <div class="postic-partner-card" style="background: linear-gradient(135deg, #1c1917 0%, #292524 100%); border-radius: 24px; padding: 45px 40px; color: #ffffff; position: relative; overflow: hidden; box-shadow: 0 16px 40px rgba(28,25,23,0.18); border: 1px solid rgba(255,255,255,0.08);">
            <!-- Subtle Brand Red Ambient Glow -->
            <div style="position: absolute; top: -60px; right: -60px; width: 240px; height: 240px; border-radius: 50%; background: rgba(200,16,46,0.22); filter: blur(70px); pointer-events: none;"></div>

            <div class="row" style="display: flex; align-items: center; flex-wrap: wrap;">
                <!-- Left: Partner Details -->
                <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12" style="margin-bottom: 25px; z-index: 2;">
                    <span style="background: rgba(200,16,46,0.2); color: #fca5a5; border: 1px solid rgba(200,16,46,0.4); font-size: 11px; font-weight: 800; padding: 4px 12px; border-radius: 14px; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 12px;">
                        Wholesale &bull; Retail &bull; Distribution
                    </span>

                    <h2 style="font-size: 32px; font-weight: 900; color: #ffffff; margin: 0 0 10px 0; line-height: 1.2; letter-spacing: -0.6px;">
                        Stock Postic in Your Store
                    </h2>

                    <h4 style="font-size: 16px; font-weight: 700; color: #fbbf24; margin: 0 0 14px 0;">
                        Direct Roastery Pricing &bull; Postic Foods Hub, Udaipur
                    </h4>

                    <p style="font-size: 14px; color: #d6d3d1; line-height: 1.6; margin-bottom: 20px; max-width: 520px;">
                        Looking for bulk cartons, supermarket retail display, gym &amp; cafe stocking, or festive corporate gifting? Partner directly with Rajasthan’s fastest-growing roasted Makhana brand.
                    </p>

                    <div style="margin-bottom: 24px; font-size: 13px; color: #e7e5e4; line-height: 1.8;">
                        <p style="margin: 0 0 4px 0;">
                            <i class="fa fa-map-marker" style="color: #ef4444; width: 20px; font-size: 15px;"></i>
                            <strong>Facility:</strong> Udaipur, Rajasthan - 313001, India
                        </p>
                        <p style="margin: 0 0 4px 0;">
                            <i class="fa fa-phone" style="color: #fbbf24; width: 20px; font-size: 15px;"></i>
                            <strong>Direct Helpline:</strong> <a href="tel:919216398316" style="color: #ffffff; text-decoration: underline; font-weight: 800;">+91 9216398316</a>
                        </p>
                        <p style="margin: 0;">
                            <i class="fa fa-envelope" style="color: #38bdf8; width: 20px; font-size: 15px;"></i>
                            <strong>Partner Desk:</strong> <a href="mailto:care@postic.in" style="color: #ffffff; text-decoration: underline; font-weight: 800;">care@postic.in</a>
                        </p>
                    </div>

                    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                        <a href="https://api.whatsapp.com/send?phone=919216398316&text=Hi%20Postic,%20I%20am%20interested%20in%20becoming%20a%20Retail%20or%20Distribution%20Partner%20for%20Makhana" target="_blank" class="btn" style="background: #25D366; color: #ffffff; padding: 12px 24px; border-radius: 25px; font-weight: 800; font-size: 13px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 4px 15px rgba(37,211,102,0.3); border: none;">
                            <i class="fa fa-whatsapp" style="font-size: 18px;"></i> WhatsApp Partner Desk
                        </a>
                        <a href="tel:919216398316" class="btn" style="background: rgba(255,255,255,0.1); color: #ffffff; padding: 12px 20px; border-radius: 25px; font-weight: 800; font-size: 13px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; border: 1px solid rgba(255,255,255,0.2);">
                            <i class="fa fa-phone"></i> Call Roastery
                        </a>
                    </div>
                </div>

                <!-- Right: Clean Postic Packs Display -->
                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12" style="display: flex; align-items: center; justify-content: center; z-index: 1;">
                    <div style="display: flex; align-items: center; justify-content: center; gap: 14px; max-width: 320px; width: 100%;">
                        <div style="flex: 1; max-width: 150px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 14px; padding: 12px; text-align: center;">
                            <img src="admin/uploads/CheesTomotoM1.png" alt="Cheese Tomato Pack" style="width: 100%; height: auto; filter: drop-shadow(0 8px 14px rgba(0,0,0,0.3));">
                            <span style="font-size: 11px; font-weight: 800; color: #fca5a5; display: block; margin-top: 6px;">Cheese Tomato</span>
                        </div>
                        <div style="flex: 1; max-width: 150px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 14px; padding: 12px; text-align: center;">
                            <img src="admin/uploads/Cream&OnionM1.png" alt="Cream & Onion Pack" style="width: 100%; height: auto; filter: drop-shadow(0 8px 14px rgba(0,0,0,0.3));">
                            <span style="font-size: 11px; font-weight: 800; color: #86efac; display: block; margin-top: 6px;">Cream &amp; Onion</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
