<?php
// Postic Clean & Editorial Story Section (Theme Matched to Postic Crimson & Warm Stone)
?>
<section class="postic-story-section" style="padding: 60px 0; background: #ffffff; overflow: hidden; border-top: 1px solid #ede8df;">
    <div class="container">
        <div class="row" style="display: flex; align-items: center; flex-wrap: wrap;">
            <!-- Left: Brand Narrative -->
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="margin-bottom: 30px;">
                <div style="max-width: 520px;">
                    <div style="display: inline-flex; align-items: center; gap: 8px; margin-bottom: 12px; background: #fef2f2; padding: 4px 14px; border-radius: 20px; border: 1px solid #fee2e2;">
                        <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #c8102e;"></span>
                        <span style="font-size: 12px; font-weight: 800; color: #c8102e; text-transform: uppercase; letter-spacing: 1.2px;">Our Roastery Heritage</span>
                    </div>

                    <h2 style="font-size: 34px; font-weight: 900; color: #1c1917; line-height: 1.2; margin: 0 0 16px 0; letter-spacing: -0.8px;">
                        Crafted in the Royal City of Lakes &bull; <span style="color: #c8102e;">Udaipur</span>
                    </h2>

                    <p style="font-size: 15px; color: #57534e; line-height: 1.7; margin-bottom: 14px;">
                        We started Postic with one simple question: why do everyday evening snacks have to be deep-fried junk drenched in toxic palm oil and artificial flavor enhancers?
                    </p>

                    <p style="font-size: 15px; color: #57534e; line-height: 1.7; margin-bottom: 24px;">
                        We took sacred, handpicked Fox Nuts (Phool Makhana) and perfected slow hot-air dry roasting. Tossed fresh with authentic Rajasthani herbs and cold-pressed spices, Postic delivers India’s crunchiest guilt-free snack at flat ₹130.
                    </p>

                    <div style="margin-bottom: 25px; padding-left: 16px; border-left: 3px solid #c8102e;">
                        <p style="font-size: 14px; font-weight: 700; color: #1c1917; margin: 0 0 2px 0;">
                            "Snacking should nourish your family, not slow them down."
                        </p>
                        <span style="font-size: 12px; color: #78716c;">— Ritik Joshi &amp; The Postic Roastery Team</span>
                    </div>

                    <div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap;">
                        <a href="all_product.php" class="btn" style="background: #c8102e; color: #ffffff; padding: 12px 28px; border-radius: 25px; font-weight: 800; font-size: 13px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 4px 15px rgba(200,16,46,0.25); border: none;">
                            Explore All Flavours &rarr;
                        </a>
                        <a href="#partner-section" style="font-size: 13px; font-weight: 700; color: #1c1917; text-decoration: none; padding: 10px 16px; border-radius: 25px; background: #fdfbf7; border: 1px solid #ede8df;">
                            <i class="fa fa-handshake-o" style="color: #c8102e;"></i> Partner Desk
                        </a>
                    </div>
                </div>
            </div>

            <!-- Right: Roastery Showcase Banner with Badges -->
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" style="margin-bottom: 30px;">
                <div style="background: #fdfbf7; border: 1px solid #ede8df; border-radius: 20px; padding: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.04);">
                    <div style="height: 240px; border-radius: 14px; overflow: hidden; margin-bottom: 16px; background: #fff;">
                        <img src="admin/uploads/ct-ppbanner2.png" alt="Postic Roastery Craft" style="width: 100%; height: 100%; object-fit: cover;">
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; text-align: center;">
                        <div style="background: #ffffff; border: 1px solid #ede8df; border-radius: 10px; padding: 10px 6px;">
                            <strong style="font-size: 13px; color: #c8102e; display: block; font-weight: 900;">0% Palm Oil</strong>
                            <span style="font-size: 11px; color: #78716c;">Dry Roasted</span>
                        </div>
                        <div style="background: #ffffff; border: 1px solid #ede8df; border-radius: 10px; padding: 10px 6px;">
                            <strong style="font-size: 13px; color: #1c1917; display: block; font-weight: 900;">55g Pouches</strong>
                            <span style="font-size: 11px; color: #78716c;">Aroma Sealed</span>
                        </div>
                        <div style="background: #ffffff; border: 1px solid #ede8df; border-radius: 10px; padding: 10px 6px;">
                            <strong style="font-size: 13px; color: #166534; display: block; font-weight: 900;">Flat ₹130</strong>
                            <span style="font-size: 11px; color: #78716c;">Direct Roastery</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
