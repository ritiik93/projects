<?php
/**
 * Dedicated Traffic Simulator Operator Authentication Helper
 * Completely isolated from main admin authentication & database tables.
 */

require_once dirname(__DIR__) . '/config/env.php';

if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    @session_start();
}

/**
 * Get configured operator credentials from environment or fallbacks
 */
function get_operator_config()
{
    $email = env_get('TRAFFIC_OPERATOR_EMAIL', 'Ritik@gmail.com');
    $pass  = env_get('TRAFFIC_OPERATOR_PASSWORD', 'Zoro3');

    return array(
        'email' => trim($email),
        'password' => (string) $pass
    );
}

/**
 * Check if the current session has an authenticated operator
 */
function operator_is_authenticated()
{
    return !empty($_SESSION['traffic_operator_auth']) &&
           $_SESSION['traffic_operator_auth'] === true &&
           !empty($_SESSION['traffic_operator_email']);
}

/**
 * Authenticate operator credentials with constant-time verification & brute-force throttle
 */
function operator_authenticate($input_email, $input_pass)
{
    // Rate limit check: max 10 failed attempts within 15 minutes
    $now = time();
    if (!isset($_SESSION['operator_login_attempts'])) {
        $_SESSION['operator_login_attempts'] = 0;
        $_SESSION['operator_login_throttle_time'] = $now;
    }

    if ($_SESSION['operator_login_attempts'] >= 10) {
        if ($now - $_SESSION['operator_login_throttle_time'] < 900) {
            $rem_mins = ceil((900 - ($now - $_SESSION['operator_login_throttle_time'])) / 60);
            return array(
                'success' => false,
                'error' => "Too many failed attempts. Please try again in {$rem_mins} minute(s)."
            );
        } else {
            $_SESSION['operator_login_attempts'] = 0;
            $_SESSION['operator_login_throttle_time'] = $now;
        }
    }

    $config = get_operator_config();
    $input_email = trim((string)$input_email);
    $input_pass  = (string)$input_pass;

    // Check email (case-insensitive)
    $email_match = (strcasecmp($config['email'], $input_email) === 0);

    // Check password (supports bcrypt hash or timing-safe plaintext comparison)
    $pass_match = false;
    $expected_pass = $config['password'];

    if (strpos($expected_pass, '$2y$') === 0 || strpos($expected_pass, '$2a$') === 0 || strpos($expected_pass, '$argon2') === 0) {
        $pass_match = password_verify($input_pass, $expected_pass);
    } else {
        $pass_match = hash_equals($expected_pass, $input_pass);
    }

    if ($email_match && $pass_match) {
        // Successful login
        $_SESSION['operator_login_attempts'] = 0;
        unset($_SESSION['operator_login_throttle_time']);

        // Regenerate session ID for security
        if (function_exists('session_regenerate_id')) {
            @session_regenerate_id(true);
        }

        // Set operator session flags (isolated from $_SESSION['admin_id'])
        $_SESSION['traffic_operator_auth'] = true;
        $_SESSION['traffic_operator_email'] = $config['email'];
        $_SESSION['traffic_operator_login_time'] = time();

        return array('success' => true);
    }

    // Failed login
    $_SESSION['operator_login_attempts']++;
    $_SESSION['operator_login_throttle_time'] = $now;

    return array(
        'success' => false,
        'error' => 'Invalid operator email or password.'
    );
}

/**
 * Log out operator safely
 */
function operator_logout()
{
    unset($_SESSION['traffic_operator_auth']);
    unset($_SESSION['traffic_operator_email']);
    unset($_SESSION['traffic_operator_login_time']);
    unset($_SESSION['traffic_operator_csrf']);
}

/**
 * CSRF token generation and validation for operator actions
 */
function operator_get_csrf_token()
{
    if (empty($_SESSION['traffic_operator_csrf'])) {
        $_SESSION['traffic_operator_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['traffic_operator_csrf'];
}

function operator_verify_csrf_token($token)
{
    if (empty($_SESSION['traffic_operator_csrf']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['traffic_operator_csrf'], (string)$token);
}
