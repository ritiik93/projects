<?php

session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}

$logo_info = $obj->display_logo();
$logo = $logo_info ? mysqli_fetch_assoc($logo_info) : null;
$logo_img = $logo ? $logo['img'] : 'logo.png';

if (isset($_SESSION['user_id'])) {
    header("location:userprofile.php");
    exit();
}


if (isset($_POST['u_pass_recover'])) {
    $recover_email = $_POST['recover_email'];
    $rec_row = $obj->user_password_recover($recover_email);

    $num_row = mysqli_num_rows($rec_row);
    $rec_msg = "";

    if ($num_row > 0) {
        $rec_result = mysqli_fetch_assoc($rec_row);

        $rec_id = $rec_result['user_id'];
        $rec_name = $rec_result['user_firstname'];
        $rec_email = $rec_result['user_email'];
        $rec_pass = $rec_result['user_password'];

        $to_email = $rec_email;
        $subject = "Recover Password From Postic";
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
        $base_dir = rtrim(str_replace('\\', '/', dirname($_SERVER['PHP_SELF'])), '/');
        $reset_link = "{$protocol}://{$host}{$base_dir}/user_password_update.php?status=update&id={$rec_id}";
        $body = "Dear {$rec_name}".PHP_EOL. "Please visit this link to reset your password: {$reset_link}".PHP_EOL."Thank you,".PHP_EOL."Postic Team (Udaipur, Rajasthan)";
        require_once __DIR__ . '/includes/postic_mailer.php';
        if (PosticMailer::send_password_reset_email($to_email, $rec_name, $reset_link)) {
            $rec_msg = "Please check your email ($to_email) and follow the link to reset your password.";
        } else {
            // Fallback to native mail if SMTP not yet configured
            $headers = "From: care@postic.in";
            if (@mail($to_email, $subject, $body, $headers)) {
                $rec_msg = "Please check your email and reset your password.";
            } else {
                $rec_msg = "Password reset link generated: <a href='$reset_link' style='color:#d32f2f;font-weight:bold;'>Click Here to Reset Password</a>";
            }
        }


    } else {
        $rec_msg = "Sorry !!! you have no account";
    }
}


?>


<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->

    <?php
    include_once("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once("includes/header_top.php");
        ?>

        <?php
        include_once("includes/header_middle.php");
        ?>

        <?php
        include_once("includes/header_bottom.php");
        ?>

    </header>

    <!-- Centered Clean D2C Auth Card Section -->
    <div class="postic-auth-page">
        <div class="postic-auth-box">
            <div class="postic-auth-card-clean">
                
                <!-- Logo & Brand Header -->
                <div class="postic-auth-top">
                    <a href="index.php">
                        <img src="admin/uploads/<?php echo htmlspecialchars($logo_img); ?>" alt="Postic Foods" class="postic-auth-logo">
                    </a>
                    <span class="postic-auth-brand-tag">100% Roasted Superfoods &bull; Udaipur</span>
                    
                    <h3 style="font-size: 20px; font-weight: 800; color: #1e293b; margin: 15px 0 6px 0;">Reset Your Password</h3>
                    <p style="font-size: 13px; color: #64748b; margin: 0 0 15px 0; line-height: 1.5;">
                        Enter your registered email address and we'll send you a link to reset your password.
                    </p>
                </div>

                <!-- Notification -->
                <?php if (!empty($rec_msg)) { 
                    $is_success = (stripos($rec_msg, 'check your email') !== false || stripos($rec_msg, 'successfully') !== false || stripos($rec_msg, 'link generated') !== false);
                    $alert_bg = $is_success ? '#ecfdf5' : '#fef2f2';
                    $alert_border = $is_success ? '#a7f3d0' : '#fecaca';
                    $alert_color = $is_success ? '#065f46' : '#991b1b';
                    $alert_icon = $is_success ? 'fa-check-circle' : 'fa-exclamation-circle';
                ?>
                    <div class="alert alert-dismissible" role="alert" style="border-radius: 10px; background: <?php echo $alert_bg; ?>; border: 1px solid <?php echo $alert_border; ?>; color: <?php echo $alert_color; ?>; font-size: 13px; padding: 12px 14px; margin-bottom: 20px;">
                        <i class="fa <?php echo $alert_icon; ?>" style="margin-right: 6px;"></i>
                        <?php echo $rec_msg; ?>
                        <button type="button" class="close" data-dismiss="alert" style="color: <?php echo $alert_color; ?>;">&times;</button>
                    </div>
                <?php } ?>

                <!-- Form -->
                <form action="" name="frm-recover" method="post" autocomplete="on">
                    <div class="postic-form-group">
                        <label class="postic-form-label" for="recover_email">
                            Registered Email Address <span class="req">*</span>
                        </label>
                        <input type="email" id="recover_email" name="recover_email" class="postic-form-input" placeholder="e.g. name@gmail.com" value="<?php echo htmlspecialchars($_POST['recover_email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required autofocus>
                    </div>

                    <button type="submit" name="u_pass_recover" class="postic-submit-btn">
                        Send Password Reset Link &rarr;
                    </button>
                </form>

                <div style="text-align: center; margin-top: 20px; padding-top: 15px; border-top: 1px solid #f1f5f9; font-size: 13px;">
                    <span style="color: #64748b;">Remember your password?</span>
                    <a href="user_login.php" style="color: #d32f2f; font-weight: 700; text-decoration: none; margin-left: 4px;">Sign In &rarr;</a>
                </div>

                <!-- Footer Trust Strip -->
                <div class="postic-auth-footer-trust">
                    <span><i class="fa fa-shield"></i> 256-Bit SSL Secure</span>
                    <span><i class="fa fa-leaf"></i> 100% Roasted</span>
                    <span><i class="fa fa-truck"></i> Fast Delivery</span>
                </div>

            </div>
        </div>
    </div>

    <!-- FOOTER -->

    <?php
    include_once("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>