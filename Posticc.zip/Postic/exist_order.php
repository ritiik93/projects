<?php

session_start();

include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}

// if (isset($_POST['user_login_btn'])) {
//     $logmsg = $obj->user_login($_POST);
// }

if (empty($_SESSION['user_id'])) {
    $_SESSION['flash_error'] = "Please sign in to view and track your orders live.";
    header("location:user_login.php");
    exit();
}

$userid = $_SESSION['user_id'];
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

if (isset($_GET['logout'])) {
    if ($_GET['logout'] == "logout") {
        $obj->user_logout();
    }
}

if(isset($_SESSION['user_id'])){
    $id = (int)$_SESSION['user_id'];
    $order_query = $obj->order_details_by_id($id);
    $all_user_orders = [];
    if ($order_query && mysqli_num_rows($order_query) > 0) {
        while ($row = mysqli_fetch_assoc($order_query)) {
            $all_user_orders[] = $row;
        }
    }
    
    $count_all = count($all_user_orders);
    $count_active = 0;
    $count_delivered = 0;
    $count_cancelled = 0;
    foreach ($all_user_orders as $ord) {
        $st = (int)$ord['order_status'];
        if ($st == 3) {
            $count_delivered++;
        } elseif ($st == 4) {
            $count_cancelled++;
        } else {
            $count_active++;
        }
    }
}else{
    header("location:user_login.php");
    exit();
}

// Handle Saved Address updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_address_btn'])) {
    $addr_type = isset($_POST['address_type']) && $_POST['address_type'] === 'office' ? 'office' : 'home';
    $new_addr = isset($_POST['new_address']) ? trim($_POST['new_address']) : '';
    if (!empty($new_addr)) {
        $obj->update_user_saved_address($userid, $addr_type, $new_addr);
        $_SESSION['flash_success'] = ucfirst($addr_type) . " address saved successfully!";
    } else {
        $_SESSION['flash_error'] = "Address cannot be empty.";
    }
    header("location:exist_order.php");
    exit();
}

// Handle Customer Order Cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_order_btn'])) {
    $cancel_order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;
    $cancel_reason = isset($_POST['cancel_reason']) ? trim($_POST['cancel_reason']) : '';
    $cancel_res = $obj->customer_cancel_order($userid, $cancel_order_id, $cancel_reason);
    if ($cancel_res['success']) {
        $_SESSION['flash_success'] = $cancel_res['message'];
    } else {
        $_SESSION['flash_error'] = $cancel_res['message'];
    }
    header("location:exist_order.php");
    exit();
}

// Handle Profile Details update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile_btn'])) {
    $prof_res = $obj->update_customer_profile($userid, $_POST);
    if ($prof_res['success']) {
        $_SESSION['flash_success'] = $prof_res['message'];
    } else {
        $_SESSION['flash_error'] = $prof_res['message'];
    }
    header("location:exist_order.php");
    exit();
}

$user_profile = $obj->get_user_profile($userid);
$saved_home = !empty($user_profile['home_address']) ? $user_profile['home_address'] : (!empty($_SESSION['home_address']) ? $_SESSION['home_address'] : '');
$saved_office = !empty($user_profile['office_address']) ? $user_profile['office_address'] : (!empty($_SESSION['office_address']) ? $_SESSION['office_address'] : '');
$saved_default = !empty($user_profile['user_address']) ? $user_profile['user_address'] : (isset($_SESSION['address']) ? $_SESSION['address'] : '');


?>


<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->

    <?php
    include_once("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once("includes/header_top.php");
        ?>

        <?php
        include_once("includes/header_middle.php");
        ?>

        <?php
        include_once("includes/header_bottom.php");
        ?>

    </header>

    <!-- Page Contain -->
    <div class="page-contain">

        <!-- Main content -->
        <div id="main-content" class="main-content">




            <div class="container">

                <?php if (!empty($_SESSION['flash_success'])) { ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($_SESSION['flash_success'], ENT_QUOTES, 'UTF-8'); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <script>
                        alert(<?php echo json_encode($_SESSION['flash_success']); ?>);
                    </script>
                    <?php unset($_SESSION['flash_success']); ?>
                <?php } ?>

                <?php if (!empty($_SESSION['flash_error'])) { ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo htmlspecialchars($_SESSION['flash_error'], ENT_QUOTES, 'UTF-8'); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php unset($_SESSION['flash_error']); ?>
                <?php } ?>


                <div class="row" style="margin-top: 30px; margin-bottom: 50px;">
                    <!-- User Account Sidebar -->
                    <div class="col-lg-3 col-md-4 col-sm-12" style="margin-bottom: 25px;">
                        <div class="postic-user-sidebar">
                            <div class="postic-user-avatar">
                                <i class="fa fa-user"></i>
                            </div>
                            <h3 style="font-size: 18px; font-weight: 700; color: #1e293b; margin: 0 0 4px 0;">
                                <?php echo htmlspecialchars(isset($username) ? strtoupper($username) : 'CUSTOMER', ENT_QUOTES, 'UTF-8'); ?>
                            </h3>
                            <p style="font-size: 12px; color: #64748b; margin-bottom: 16px;">
                                <span style="background: #fef2f2; color: #d32f2f; padding: 2px 10px; border-radius: 12px; font-weight: 600; border: 1px solid #fecaca;">
                                    <i class="fa fa-check-circle"></i> Postic Customer
                                </span>
                            </p>
                            <hr style="margin: 14px 0; border-top: 1px solid #f1f5f9;">
                            <div style="display: flex; flex-direction: column; gap: 8px;">
                                <a href="all_product.php" class="btn btn-sm" style="background: #d32f2f; color: #fff; font-weight: 700; border-radius: 8px; padding: 10px; text-decoration: none;">
                                    <i class="fa fa-shopping-basket"></i> Shop Makhana
                                </a>
                                <a href="addtocart.php" class="btn btn-sm" style="background: #f8fafc; color: #334155; font-weight: 600; border-radius: 8px; padding: 9px; border: 1px solid #e2e8f0; text-decoration: none;">
                                    <i class="fa fa-shopping-cart"></i> View Cart
                                </a>
                                <a href="?logout=logout" class="btn btn-sm" style="background: #fff; color: #dc2626; font-weight: 600; border-radius: 8px; padding: 9px; border: 1px solid #fecaca; text-decoration: none; margin-top: 10px;">
                                    <i class="fa fa-sign-out"></i> Logout
                                </a>
                            </div>
                        </div>

                        <!-- Profile & Contact Details Card -->
                        <div class="postic-dashboard-card" style="margin-top: 20px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                                <h4 style="font-size: 15px; font-weight: 700; color: #1e293b; margin: 0; display: flex; align-items: center; gap: 6px;">
                                    <i class="fa fa-id-card-o" style="color: #d32f2f;"></i> Profile Details
                                </h4>
                                <button type="button" class="btn btn-sm" onclick="$('#edit-profile-form').slideToggle(200);" style="padding: 2px 8px; font-size: 11px; background: #fff; border: 1px solid #cbd5e1; border-radius: 4px; color: #475569;">
                                    <i class="fa fa-pencil"></i> Edit Profile
                                </button>
                            </div>

                            <div style="font-size: 12px; color: #475569; line-height: 1.6;">
                                <div style="margin-bottom: 4px;">
                                    <strong>Name:</strong> <?php echo htmlspecialchars(trim(($user_profile['user_firstname'] ?? '') . ' ' . ($user_profile['user_lastname'] ?? '')) ?: $username); ?>
                                </div>
                                <div style="margin-bottom: 4px;">
                                    <strong>Email:</strong> <?php echo htmlspecialchars($user_profile['user_email'] ?? ($_SESSION['email'] ?? '')); ?>
                                </div>
                                <div style="margin-bottom: 4px;">
                                    <strong>Phone:</strong> <?php echo !empty($user_profile['user_mobile']) ? htmlspecialchars($user_profile['user_mobile']) : '<span style="color:#94a3b8;font-style:italic;">Not added</span>'; ?>
                                </div>
                                <div>
                                    <strong>Delivery Address:</strong><br>
                                    <?php echo !empty($saved_default) ? nl2br(htmlspecialchars($saved_default)) : '<span style="color:#94a3b8;font-style:italic;">No delivery address added</span>'; ?>
                                </div>
                            </div>

                            <!-- Edit Profile Slide-down Form -->
                            <div id="edit-profile-form" style="display: none; margin-top: 14px; border-top: 1px dashed #cbd5e1; padding-top: 14px;">
                                <form method="POST" action="">
                                    <div class="form-group" style="margin-bottom: 8px;">
                                        <label style="font-size: 11px; font-weight: 700; color: #334155; margin-bottom: 2px;">First Name *</label>
                                        <input type="text" name="user_firstname" class="form-control" style="font-size: 12px; height: 34px;" value="<?php echo htmlspecialchars($user_profile['user_firstname'] ?? ''); ?>" required>
                                    </div>
                                    <div class="form-group" style="margin-bottom: 8px;">
                                        <label style="font-size: 11px; font-weight: 700; color: #334155; margin-bottom: 2px;">Last Name</label>
                                        <input type="text" name="user_lastname" class="form-control" style="font-size: 12px; height: 34px;" value="<?php echo htmlspecialchars($user_profile['user_lastname'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group" style="margin-bottom: 8px;">
                                        <label style="font-size: 11px; font-weight: 700; color: #334155; margin-bottom: 2px;">Email Address *</label>
                                        <input type="email" name="user_email" class="form-control" style="font-size: 12px; height: 34px;" value="<?php echo htmlspecialchars($user_profile['user_email'] ?? ''); ?>" required>
                                    </div>
                                    <div class="form-group" style="margin-bottom: 8px;">
                                        <label style="font-size: 11px; font-weight: 700; color: #334155; margin-bottom: 2px;">Mobile Number</label>
                                        <input type="tel" name="user_mobile" class="form-control" style="font-size: 12px; height: 34px;" placeholder="10-digit mobile" pattern="[0-9]{10}" value="<?php echo htmlspecialchars($user_profile['user_mobile'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group" style="margin-bottom: 12px;">
                                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2px;">
                                            <label style="font-size: 11px; font-weight: 700; color: #334155; margin: 0;">Delivery Address</label>
                                            <button type="button" id="btnAutoDetectProfile" class="btn btn-xs" style="font-size: 10px; padding: 2px 6px; background: #fef2f2; border: 1px solid #fecaca; color: #d32f2f; border-radius: 4px; font-weight: 600;">
                                                <i class="fa fa-crosshairs"></i> Auto-detect Location
                                            </button>
                                        </div>
                                        <textarea name="user_address" id="profileAddressInput" class="form-control" rows="2" style="font-size: 12px;" placeholder="Flat / House No, Area, City, PIN"><?php echo htmlspecialchars($saved_default); ?></textarea>
                                    </div>
                                    <button type="submit" name="update_profile_btn" class="btn btn-sm btn-block" style="background: #d32f2f; color: #fff; font-size: 12px; font-weight: 700; border-radius: 6px; padding: 8px;">
                                        Save Profile Changes
                                    </button>
                                </form>
                            </div>
                        </div>

                        <!-- Saved Addresses Manager Card -->
                        <div class="postic-dashboard-card" style="margin-top: 20px;">
                            <h4 style="font-size: 15px; font-weight: 700; color: #1e293b; margin-bottom: 12px; display: flex; align-items: center; gap: 6px;">
                                <i class="fa fa-address-book" style="color: #d32f2f;"></i> Saved Addresses
                            </h4>

                            <!-- Home Address -->
                            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 12px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                    <strong style="font-size: 13px; color: #1e293b;"><i class="fa fa-home" style="color: #d32f2f;"></i> Home</strong>
                                    <button type="button" class="btn btn-sm" onclick="$('#edit-home-form').slideToggle(200);" style="padding: 2px 8px; font-size: 11px; background: #fff; border: 1px solid #cbd5e1; border-radius: 4px; color: #475569;">
                                        <i class="fa fa-pencil"></i> Edit
                                    </button>
                                </div>
                                <p style="font-size: 12px; color: #64748b; margin: 0; line-height: 1.4;">
                                    <?php echo !empty($saved_home) ? nl2br(htmlspecialchars($saved_home)) : '<em>No home address saved yet.</em>'; ?>
                                </p>
                                <div id="edit-home-form" style="display: none; margin-top: 10px; border-top: 1px dashed #cbd5e1; padding-top: 10px;">
                                    <form method="POST" action="">
                                        <input type="hidden" name="address_type" value="home">
                                        <textarea name="new_address" class="form-control" rows="2" style="font-size: 12px; margin-bottom: 8px;" placeholder="Flat / House No, Street, City, Pincode" required><?php echo htmlspecialchars($saved_home); ?></textarea>
                                        <button type="submit" name="update_address_btn" class="btn btn-sm btn-block" style="background: #d32f2f; color: #fff; font-size: 12px; font-weight: 700; border-radius: 4px;">Save Home Address</button>
                                    </form>
                                </div>
                            </div>

                            <!-- Office Address -->
                            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px;">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                                    <strong style="font-size: 13px; color: #1e293b;"><i class="fa fa-building" style="color: #2563eb;"></i> Office</strong>
                                    <button type="button" class="btn btn-sm" onclick="$('#edit-office-form').slideToggle(200);" style="padding: 2px 8px; font-size: 11px; background: #fff; border: 1px solid #cbd5e1; border-radius: 4px; color: #475569;">
                                        <i class="fa fa-pencil"></i> Edit
                                    </button>
                                </div>
                                <p style="font-size: 12px; color: #64748b; margin: 0; line-height: 1.4;">
                                    <?php echo !empty($saved_office) ? nl2br(htmlspecialchars($saved_office)) : '<em>No office address saved yet.</em>'; ?>
                                </p>
                                <div id="edit-office-form" style="display: none; margin-top: 10px; border-top: 1px dashed #cbd5e1; padding-top: 10px;">
                                    <form method="POST" action="">
                                        <input type="hidden" name="address_type" value="office">
                                        <textarea name="new_address" class="form-control" rows="2" style="font-size: 12px; margin-bottom: 8px;" placeholder="Company Name, Floor, Street, City, Pincode" required><?php echo htmlspecialchars($saved_office); ?></textarea>
                                        <button type="submit" name="update_address_btn" class="btn btn-sm btn-block" style="background: #2563eb; color: #fff; font-size: 12px; font-weight: 700; border-radius: 4px;">Save Office Address</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Orders & Live Tracking Section -->
                    <div class="col-lg-9 col-md-8 col-sm-12">
                        <!-- Top Header & Filter Tabs -->
                        <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px 24px; margin-bottom: 24px; box-shadow: 0 4px 15px rgba(0,0,0,0.03);">
                            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; border-bottom: 1px solid #f1f5f9; padding-bottom: 16px; margin-bottom: 16px;">
                                <div>
                                    <h2 style="font-size: 22px; font-weight: 800; color: #1e293b; margin: 0; display: flex; align-items: center; gap: 8px;">
                                        <i class="fa fa-truck" style="color: #d32f2f;"></i> Live Order Tracking &amp; History
                                    </h2>
                                    <p style="font-size: 13px; color: #64748b; margin: 4px 0 0 0;">
                                        Track real-time roasting, packing, and courier transit from Udaipur directly to your doorstep.
                                    </p>
                                </div>
                                <a href="all_product.php" class="btn btn-sm" style="background: #d32f2f; color: #ffffff; font-weight: 700; border-radius: 20px; padding: 8px 18px; text-decoration: none; display: inline-flex; align-items: center; gap: 6px;">
                                    <i class="fa fa-shopping-basket"></i> Order More Makhana &rarr;
                                </a>
                            </div>

                            <!-- Filter Tabs -->
                            <div style="display: flex; gap: 8px; flex-wrap: wrap;" id="postic-order-filters">
                                <button type="button" class="postic-order-filter-btn active" onclick="filterOrders('all', this)" style="background: #d32f2f; color: #fff; border: 1px solid transparent; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; cursor: pointer; transition: all 0.2s;">
                                    All Orders (<?php echo $count_all; ?>)
                                </button>
                                <button type="button" class="postic-order-filter-btn" onclick="filterOrders('active', this)" style="background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;">
                                    <i class="fa fa-refresh" style="color: #0284c7;"></i> Active / In-Transit (<?php echo $count_active; ?>)
                                </button>
                                <button type="button" class="postic-order-filter-btn" onclick="filterOrders('delivered', this)" style="background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;">
                                    <i class="fa fa-check-circle" style="color: #16a34a;"></i> Delivered (<?php echo $count_delivered; ?>)
                                </button>
                                <?php if ($count_cancelled > 0) { ?>
                                <button type="button" class="postic-order-filter-btn" onclick="filterOrders('cancelled', this)" style="background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;">
                                    <i class="fa fa-ban" style="color: #94a3b8;"></i> Cancelled (<?php echo $count_cancelled; ?>)
                                </button>
                                <?php } ?>
                            </div>
                        </div>

                        <?php if (empty($all_user_orders)) { ?>
                            <!-- Empty State -->
                            <div class="postic-order-card" style="text-align: center; padding: 60px 20px;">
                                <div style="width: 80px; height: 80px; background: #fee2e2; color: #d32f2f; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 34px; margin-bottom: 16px;">
                                    <i class="fa fa-shopping-bag"></i>
                                </div>
                                <h3 style="font-weight: 800; color: #1e293b; margin-bottom: 8px;">No Orders Placed Yet</h3>
                                <p style="color: #64748b; font-size: 14px; max-width: 480px; margin: 0 auto 20px auto; line-height: 1.5;">
                                    You haven't ordered any crunchy, roasted Makhana yet. Taste our authentic Peri Peri, Mint, Cheese, Himalayan Pink Salt &amp; Raw Pari Makhana!
                                </p>
                                <a href="all_product.php" class="btn btn-sm" style="background: #d32f2f; color: #fff; padding: 10px 28px; border-radius: 24px; font-weight: 700; text-decoration: none; box-shadow: 0 4px 14px rgba(211,47,47,0.3);">
                                    Explore Makhana Flavors &rarr;
                                </a>
                            </div>
                        <?php } else { ?>

                            <?php foreach ($all_user_orders as $order_info) { 
                                $st = (int)$order_info['order_status'];
                                $category = ($st == 3) ? 'delivered' : (($st == 4) ? 'cancelled' : 'active');
                                $formatted_order_id = 'POSTIC-' . str_pad($order_info['order_id'], 5, '0', STR_PAD_LEFT);
                                
                                // Stepper progress fill percentage
                                $fill_percent = '12%';
                                if ($st == 1) $fill_percent = '42%';
                                elseif ($st == 2) $fill_percent = '72%';
                                elseif ($st >= 3) $fill_percent = '100%';
                                
                                $whatsapp_msg = "Hello Postic Team, I would like to get a tracking update for my Order #" . $order_info['order_id'] . " (" . $order_info['product_name'] . ").";
                                $whatsapp_url = "https://api.whatsapp.com/send?phone=919414157321&text=" . urlencode($whatsapp_msg);
                            ?>
                                <div class="postic-order-card" data-status-category="<?php echo $category; ?>">
                                    <!-- Card Header -->
                                    <div class="postic-order-header">
                                        <div>
                                            <div class="postic-order-id-tag">
                                                <i class="fa fa-cube" style="color: #d32f2f;"></i>
                                                <span>Order #<?php echo $order_info['order_id']; ?></span>
                                                <span style="font-size: 11px; background: #f1f5f9; color: #475569; padding: 2px 8px; border-radius: 4px; font-weight: 600;">
                                                    <?php echo $formatted_order_id; ?>
                                                </span>
                                            </div>
                                            <div class="postic-order-meta">
                                                <i class="fa fa-calendar-o"></i> Placed on <?php echo htmlspecialchars($order_info['order_time'] ?: $order_info['order_date'], ENT_QUOTES, 'UTF-8'); ?>
                                                <?php if (!empty($order_info['trans_id'])) { ?>
                                                    &bull; <span title="Transaction Ref"><i class="fa fa-hashtag"></i> Txn: <?php echo htmlspecialchars($order_info['trans_id'], ENT_QUOTES, 'UTF-8'); ?></span>
                                                <?php } ?>
                                            </div>
                                        </div>

                                        <div class="postic-order-badges">
                                            <!-- Total Amount -->
                                            <div style="font-size: 17px; font-weight: 800; color: #1e293b; margin-right: 6px;">
                                                ₹<?php echo number_format($order_info['amount'], 2); ?>
                                            </div>

                                            <!-- Payment Badge -->
                                            <?php 
                                            $is_paid = (isset($order_info['payment_status']) && strtolower($order_info['payment_status']) === 'paid') || (isset($order_info['payment_method']) && in_array(strtolower($order_info['payment_method']), ['razorpay', 'upi', 'card']));
                                            if ($is_paid) { ?>
                                                <span class="postic-badge postic-badge-paid">
                                                    <i class="fa fa-check-circle"></i> Paid Online
                                                </span>
                                            <?php } elseif (isset($order_info['payment_method']) && strtolower($order_info['payment_method']) === 'cod') { ?>
                                                <span class="postic-badge postic-badge-cod">
                                                    <i class="fa fa-money"></i> Cash On Delivery
                                                </span>
                                            <?php } else { ?>
                                                <span class="postic-badge postic-badge-cod">
                                                    <i class="fa fa-credit-card"></i> <?php echo htmlspecialchars($order_info['payment_method'] ?: 'Payment Pending', ENT_QUOTES, 'UTF-8'); ?>
                                                </span>
                                            <?php } ?>

                                            <!-- Status Badge -->
                                            <?php if ($st == 0) { ?>
                                                <span class="postic-badge postic-badge-pending">
                                                    <i class="fa fa-clock-o"></i> Pending Confirmation
                                                </span>
                                            <?php } elseif ($st == 1) { ?>
                                                <span class="postic-badge postic-badge-processing">
                                                    <i class="fa fa-refresh fa-spin"></i> Processing &amp; Packing
                                                </span>
                                            <?php } elseif ($st == 2) { ?>
                                                <span class="postic-badge postic-badge-shipped">
                                                    <i class="fa fa-truck"></i> Shipped / In Transit
                                                </span>
                                            <?php } elseif ($st == 3) { ?>
                                                <span class="postic-badge postic-badge-delivered">
                                                    <i class="fa fa-check"></i> Delivered
                                                </span>
                                            <?php } elseif ($st == 4) { ?>
                                                <span class="postic-badge postic-badge-cancelled">
                                                    <i class="fa fa-ban"></i> Cancelled
                                                </span>
                                            <?php } ?>
                                        </div>
                                    </div>

                                    <!-- Visual Stepper Tracker -->
                                    <?php if ($st != 4) { ?>
                                        <div class="postic-tracker-wrapper">
                                            <div class="postic-stepper-progress-bg"></div>
                                            <div class="postic-stepper-progress-fill" style="width: <?php echo $fill_percent; ?>;"></div>
                                            
                                            <div class="postic-stepper">
                                                <!-- Step 1: Placed -->
                                                <div class="postic-step <?php echo ($st >= 0 ? ($st == 0 ? 'active completed' : 'completed') : ''); ?>">
                                                    <div class="postic-step-icon">
                                                        <i class="fa fa-clipboard"></i>
                                                    </div>
                                                    <div>
                                                        <div class="postic-step-title">Order Placed</div>
                                                        <div class="postic-step-subtitle">Order confirmed &amp; verified</div>
                                                    </div>
                                                </div>

                                                <!-- Step 2: Processing & Packing -->
                                                <div class="postic-step <?php echo ($st >= 1 ? ($st == 1 ? 'active completed' : 'completed') : ''); ?>">
                                                    <div class="postic-step-icon">
                                                        <i class="fa fa-archive"></i>
                                                    </div>
                                                    <div>
                                                        <div class="postic-step-title">Roasted &amp; Packed</div>
                                                        <div class="postic-step-subtitle">Fresh batch packed (Udaipur)</div>
                                                    </div>
                                                </div>

                                                <!-- Step 3: Shipped -->
                                                <div class="postic-step <?php echo ($st >= 2 ? ($st == 2 ? 'active completed' : 'completed') : ''); ?>">
                                                    <div class="postic-step-icon">
                                                        <i class="fa fa-truck"></i>
                                                    </div>
                                                    <div>
                                                        <div class="postic-step-title">Dispatched</div>
                                                        <div class="postic-step-subtitle">In transit with courier</div>
                                                    </div>
                                                </div>

                                                <!-- Step 4: Delivered -->
                                                <div class="postic-step <?php echo ($st >= 3 ? 'completed active' : ''); ?>">
                                                    <div class="postic-step-icon">
                                                        <i class="fa fa-gift"></i>
                                                    </div>
                                                    <div>
                                                        <div class="postic-step-title">Delivered</div>
                                                        <div class="postic-step-subtitle">Enjoy crunchy Postic Makhana!</div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Live Note Strip -->
                                            <div style="margin-top: 18px; padding-top: 14px; border-top: 1px dashed #cbd5e1; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
                                                <div style="font-size: 12px; color: #475569; display: flex; align-items: center; gap: 6px;">
                                                    <span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: #22c55e;"></span>
                                                    <strong>Current Status:</strong>
                                                    <?php 
                                                    if ($st == 0) echo "Order received! Our Udaipur facility is queuing your batch for fresh roasting.";
                                                    elseif ($st == 1) echo "Order is currently being roasted, quality-checked, and sealed at our Udaipur facility.";
                                                    elseif ($st == 2) echo "Dispatched! Your Makhana parcel is on the move with our logistics partner.";
                                                    elseif ($st == 3) echo "Delivered! Thank you for choosing Postic Foods. Have a healthy snack!";
                                                    ?>
                                                </div>
                                                <span style="font-size: 11px; color: #94a3b8;"><i class="fa fa-shield"></i> Postic Freshness Guarantee</span>
                                            </div>
                                        </div>
                                    <?php } else { ?>
                                        <!-- Cancelled Alert -->
                                        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #94a3b8; border-radius: 8px; padding: 14px 18px; margin-bottom: 20px; display: flex; align-items: center; gap: 12px;">
                                            <i class="fa fa-info-circle" style="font-size: 20px; color: #64748b;"></i>
                                            <div style="font-size: 13px; color: #475569;">
                                                <strong>This order has been cancelled.</strong> If an online payment was deducted, your refund will be processed within 5-7 working days. For instant assistance, chat with us on WhatsApp.
                                            </div>
                                        </div>
                                    <?php } ?>

                                    <!-- Product & Shipping Details Row -->
                                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px; background: #ffffff; border: 1px solid #f1f5f9; border-radius: 10px; padding: 16px; margin-bottom: 18px;">
                                        <!-- Item info -->
                                        <div>
                                            <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.5px; margin-bottom: 6px;">
                                                Ordered Items
                                            </div>
                                            <div style="font-size: 14px; font-weight: 700; color: #0f172a; margin-bottom: 4px;">
                                                <?php echo htmlspecialchars($order_info['product_name'], ENT_QUOTES, 'UTF-8'); ?>
                                            </div>
                                            <div style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center; font-size: 12px; color: #475569;">
                                                <?php if (!empty($order_info['pdt_weight'])) { ?>
                                                    <span style="background: #fef2f2; color: #d32f2f; font-weight: 700; padding: 2px 8px; border-radius: 12px; border: 1px solid #fecaca; font-size: 11px;">
                                                        <i class="fa fa-cubes"></i> <?php echo htmlspecialchars($order_info['pdt_weight'], ENT_QUOTES, 'UTF-8'); ?>
                                                    </span>
                                                <?php } ?>
                                                <span><strong>Qty:</strong> <?php echo (int)$order_info['pdt_quantity']; ?></span>
                                                <?php if (!empty($order_info['uses_coupon'])) { ?>
                                                    <span style="background: #f1f5f9; color: #334155; padding: 2px 8px; border-radius: 4px; font-weight: 600; font-size: 11px;">
                                                        <i class="fa fa-tag"></i> <?php echo htmlspecialchars($order_info['uses_coupon'], ENT_QUOTES, 'UTF-8'); ?>
                                                    </span>
                                                <?php } ?>
                                            </div>
                                        </div>

                                        <!-- Delivery Address info -->
                                        <div>
                                            <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.5px; margin-bottom: 6px;">
                                                Delivery Address &amp; Contact
                                            </div>
                                            <div style="font-size: 13px; color: #334155; line-height: 1.4;">
                                                <?php if (!empty($order_info['shiping'])) { ?>
                                                    <i class="fa fa-map-marker" style="color: #d32f2f;"></i> <?php echo htmlspecialchars($order_info['shiping'], ENT_QUOTES, 'UTF-8'); ?>
                                                <?php } else { ?>
                                                    <em>Registered customer address</em>
                                                <?php } ?>
                                            </div>
                                            <?php if (!empty($order_info['Shipping_mobile'])) { ?>
                                                <div style="font-size: 12px; color: #64748b; margin-top: 3px;">
                                                    <i class="fa fa-phone"></i> Contact: +91 <?php echo htmlspecialchars($order_info['Shipping_mobile'], ENT_QUOTES, 'UTF-8'); ?>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>

                                    <!-- Action Buttons -->
                                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; padding-top: 6px;">
                                        <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                                            <a href="print_invoice.php?order_id=<?php echo $order_info['order_id']; ?>" target="_blank" class="postic-btn-invoice">
                                                <i class="fa fa-print"></i> Download Tax Invoice
                                            </a>
                                            <a href="<?php echo $whatsapp_url; ?>" target="_blank" class="btn btn-sm" style="background: #25D366; color: #ffffff; font-weight: 700; border-radius: 6px; padding: 6px 14px; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; font-size: 12px;">
                                                <i class="fa fa-whatsapp" style="font-size: 14px;"></i> Track on WhatsApp
                                            </a>
                                            <?php if ($st === 0 || $st === 1) { ?>
                                                <button type="button" class="btn btn-sm" onclick="$('#cancel-panel-<?php echo $order_info['order_id']; ?>').slideToggle(200);" style="background: #ffffff; color: #dc2626; border: 1px solid #fecaca; border-radius: 6px; font-weight: 700; padding: 6px 14px; font-size: 12px; display: inline-flex; align-items: center; gap: 5px;">
                                                    <i class="fa fa-times-circle"></i> Cancel Order
                                                </button>
                                            <?php } ?>
                                        </div>
                                        <div>
                                            <a href="all_product.php" class="btn btn-sm" style="background: #f8fafc; color: #334155; border: 1px solid #cbd5e1; border-radius: 6px; font-weight: 600; padding: 6px 14px; text-decoration: none; font-size: 12px;">
                                                <i class="fa fa-repeat"></i> Buy Makhana Again
                                            </a>
                                        </div>
                                    </div>

                                    <?php if ($st === 0 || $st === 1) { ?>
                                        <!-- Inline Cancellation Confirmation Form -->
                                        <div id="cancel-panel-<?php echo $order_info['order_id']; ?>" style="display: none; margin-top: 16px; background: #fff5f5; border: 1px solid #fecaca; border-radius: 10px; padding: 16px 18px;">
                                            <form method="POST" action="" onsubmit="return confirm('Are you sure you want to cancel this order? This action cannot be reversed.');">
                                                <input type="hidden" name="order_id" value="<?php echo $order_info['order_id']; ?>">
                                                <div style="display: flex; align-items: center; gap: 8px; font-weight: 800; color: #991b1b; font-size: 14px; margin-bottom: 6px;">
                                                    <i class="fa fa-exclamation-triangle"></i> Cancel Order #<?php echo $order_info['order_id']; ?>
                                                </div>
                                                <p style="font-size: 12px; color: #7f1d1d; margin-bottom: 10px; line-height: 1.4;">
                                                    Your Makhana has not been shipped yet and can be cancelled. Please select your reason:
                                                </p>
                                                <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
                                                    <select name="cancel_reason" class="form-control" style="font-size: 12px; max-width: 320px; height: 36px; padding: 4px 10px; border-radius: 6px; border: 1px solid #fca5a5;" required>
                                                        <option value="Ordered by mistake">Ordered by mistake</option>
                                                        <option value="Want to change flavor or quantity">Want to change flavor or quantity</option>
                                                        <option value="Incorrect shipping address / phone">Incorrect shipping address / phone</option>
                                                        <option value="Delivery time too long">Delivery time too long</option>
                                                        <option value="Found another snack option">Found another snack option</option>
                                                        <option value="Other reason">Other reason</option>
                                                    </select>
                                                    <button type="submit" name="cancel_order_btn" class="btn btn-sm btn-danger" style="background: #dc2626; color: #ffffff; font-weight: 700; border-radius: 6px; padding: 7px 18px; font-size: 12px; border: none;">
                                                        Confirm Cancellation
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-light" onclick="$('#cancel-panel-<?php echo $order_info['order_id']; ?>').slideUp(200);" style="font-size: 12px; border: 1px solid #cbd5e1; border-radius: 6px; padding: 7px 14px;">
                                                        Don't Cancel
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    <?php } ?>
                                </div>
                            <?php } ?>

                        <?php } ?>

                    </div>
                </div>

                <script>
                function filterOrders(category, btn) {
                    var buttons = document.querySelectorAll('.postic-order-filter-btn');
                    buttons.forEach(function(b) {
                        b.style.background = '#f1f5f9';
                        b.style.color = '#475569';
                        b.style.borderColor = '#e2e8f0';
                        b.classList.remove('active');
                    });
                    btn.style.background = '#d32f2f';
                    btn.style.color = '#ffffff';
                    btn.style.borderColor = 'transparent';
                    btn.classList.add('active');

                    var cards = document.querySelectorAll('.postic-order-card[data-status-category]');
                    cards.forEach(function(card) {
                        if (category === 'all') {
                            card.style.display = 'block';
                        } else if (card.getAttribute('data-status-category') === category) {
                            card.style.display = 'block';
                        } else {
                            card.style.display = 'none';
                        }
                    });
                }

                // Auto-detect location for Profile Address
                $(document).ready(function() {
                    $("#btnAutoDetectProfile").on("click", function() {
                        var $btn = $(this);
                        if (!navigator.geolocation) {
                            alert("Geolocation is not supported by your browser.");
                            return;
                        }
                        var originalHtml = $btn.html();
                        $btn.html('<i class="fa fa-spinner fa-spin"></i> Detecting...').prop('disabled', true);

                        navigator.geolocation.getCurrentPosition(function(position) {
                            var lat = position.coords.latitude;
                            var lng = position.coords.longitude;
                            var url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=" + lat + "&lon=" + lng;
                            $.ajax({
                                url: url,
                                method: "GET",
                                dataType: "json",
                                success: function(res) {
                                    if (res && res.display_name) {
                                        $("#profileAddressInput").val(res.display_name);
                                    } else {
                                        $("#profileAddressInput").val("Lat: " + lat.toFixed(5) + ", Lng: " + lng.toFixed(5));
                                    }
                                    $btn.html(originalHtml).prop('disabled', false);
                                },
                                error: function() {
                                    $("#profileAddressInput").val("Lat: " + lat.toFixed(5) + ", Lng: " + lng.toFixed(5));
                                    $btn.html(originalHtml).prop('disabled', false);
                                }
                            });
                        }, function(err) {
                            alert("Location access was denied or unavailable. Please enter your address manually.");
                            $btn.html(originalHtml).prop('disabled', false);
                        }, { timeout: 10000 });
                    });
                });
                </script>
            </div>






        </div>
    </div>
    <br>
    <!-- FOOTER -->

    <?php
    include_once("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>
