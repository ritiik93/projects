-- phpMyAdmin SQL Dump
-- Postic - Premium Roasted Makhana (Fox Nuts) eCommerce Store
-- Database: `oktgaunq_postic`
-- Cleaned and Optimized for Direct Import

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+05:30";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `add_logo`
--

DROP TABLE IF EXISTS `add_logo`;
CREATE TABLE `add_logo` (
  `id` int(10) NOT NULL,
  `img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `add_logo` (`id`, `img`) VALUES
(2, 'logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

DROP TABLE IF EXISTS `admin_info`;
CREATE TABLE `admin_info` (
  `admin_id` int(11) NOT NULL,
  `admin_email` varchar(60) NOT NULL,
  `admin_pass` varchar(60) NOT NULL,
  `role` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_info` (`admin_id`, `admin_email`, `admin_pass`, `role`) VALUES
(1, 'admin@gmail.com', 'bbcf25c47c19fccc1a38fd212ab94990', 1),
(10, 'postic@gmail.com', 'bbcf25c47c19fccc1a38fd212ab94990', 1);

-- --------------------------------------------------------

--
-- Table structure for table `catagory`
--

DROP TABLE IF EXISTS `catagory`;
CREATE TABLE `catagory` (
  `ctg_id` int(11) NOT NULL,
  `ctg_name` varchar(60) NOT NULL,
  `ctg_des` varchar(150) NOT NULL,
  `ctg_status` tinyint(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `catagory` (`ctg_id`, `ctg_name`, `ctg_des`, `ctg_status`) VALUES
(1, 'Cheese Tomato Makhana', 'Deliciously roasted Fox Nuts seasoned with rich cheese and tangy tomato flavor.', 1),
(9, 'Cream & Onion Makhana', 'Crunchy Makhana blended with classic creamy herbs and mild savory onion.', 1),
(10, 'Coriander Roasted Makhana', 'Traditional authentic blend of roasted coriander and aromatic Indian spices.', 1),
(11, 'Tangy Lemon Makhana', 'Zesty citrus kick combined with superfood crunchy roasted fox nuts.', 1),
(12, 'Pani Puri Makhana', 'Iconic Indian street-food tang and zest packed into healthy roasted Makhana.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cupon`
--

DROP TABLE IF EXISTS `cupon`;
CREATE TABLE `cupon` (
  `cupon_id` int(11) NOT NULL,
  `cupon_code` varchar(25) NOT NULL,
  `description` varchar(255) NOT NULL,
  `discount` int(5) NOT NULL,
  `status` int(2) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cupon` (`cupon_id`, `cupon_code`, `description`, `discount`, `status`) VALUES
(1, 'posticspecial', 'Special 15% discount on all roasted Makhana flavors', 15, 1),
(2, 'POSTIC10', 'Welcome 10% off for healthy snacking lovers', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_feedback`
--

DROP TABLE IF EXISTS `customer_feedback`;
CREATE TABLE `customer_feedback` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `pdt_id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `rating` int(1) NOT NULL DEFAULT 5,
  `comment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `customer_feedback` (`id`, `user_id`, `user_name`, `pdt_id`, `comment`, `rating`, `comment_date`) VALUES
(1, 1, 'Pooja Sharma', 1, 'Best Cheese Tomato Makhana! Crispy, fresh and 100% guilt-free snacking.', 5, '2026-03-15'),
(2, 5, 'Rahul Verma', 16, 'Cream & Onion is my favorite evening snack. Love the crunch and flavor.', 5, '2026-03-20'),
(3, 9, 'Amit Joshi', 18, 'Pani Puri flavor is unbelievable! Tastes just like street golgappe.', 5, '2026-04-01');

-- --------------------------------------------------------

--
-- Table structure for table `header_info`
--

DROP TABLE IF EXISTS `header_info`;
CREATE TABLE `header_info` (
  `id` int(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tweeter` varchar(500) NOT NULL,
  `fb_link` varchar(500) NOT NULL,
  `pinterest` varchar(500) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `header_info` (`id`, `email`, `tweeter`, `fb_link`, `pinterest`, `phone`) VALUES
(10, 'care@postic.in', 'https://twitter.com/posticfoods', 'https://facebook.com/posticfoods', 'https://pinterest.com/posticfoods', '+91 9216398316');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(6) NOT NULL,
  `user_name` varchar(60) NOT NULL,
  `user_firstname` varchar(60) NOT NULL,
  `user_lastname` varchar(60) NOT NULL,
  `user_email` varchar(60) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_mobile` varchar(20) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `home_address` text DEFAULT NULL,
  `office_address` text DEFAULT NULL,
  `user_roles` tinyint(4) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `users` (`user_id`, `user_name`, `user_firstname`, `user_lastname`, `user_email`, `user_password`, `user_mobile`, `user_address`, `home_address`, `office_address`, `user_roles`, `created_at`, `modified_at`) VALUES
(1, 'Ritik', 'Ritik', 'Joshi', 'jhrithik@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '9216398316', 'Fateh Sagar, Udaipur, Rajasthan - 313001', 'Fateh Sagar, Near Lake, Udaipur, Rajasthan - 313001', 'Postic Foods Hub, Madri Industrial Area, Udaipur - 313003', 5, '2026-01-10 10:00:00', '2026-01-10 10:00:00'),
(5, 'karim', 'Karim', 'Khan', 'karim@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', '9829012345', 'Malviya Nagar, Jaipur, Rajasthan - 302017', 'Malviya Nagar, Jaipur, Rajasthan - 302017', '', 5, '2026-02-15 11:30:00', '2026-02-15 11:30:00'),
(9, 'aashu', 'Ashish', 'Joshi', 'asiii@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '9414056789', 'Gogunda, Udaipur, Rajasthan - 313705', 'Gogunda, Udaipur, Rajasthan - 313705', '', 5, '2026-03-30 10:10:59', '2026-03-30 10:10:59'),
(10, 'pavan89', 'Pavan', 'Sonawat', 'pavan@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '9876543210', 'Hiran Magri Sector 4, Udaipur, Rajasthan - 313002', 'Hiran Magri Sector 4, Udaipur, Rajasthan - 313002', '', 5, '2026-03-31 06:19:19', '2026-03-31 06:19:19');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `pdt_id` int(255) NOT NULL,
  `pdt_name` varchar(200) NOT NULL,
  `pdt_price` int(255) NOT NULL,
  `pdt_weight` varchar(100) NOT NULL DEFAULT '55g',
  `pdt_des` varchar(250) NOT NULL,
  `pdt_ctg` int(200) NOT NULL,
  `pdt_img` varchar(250) NOT NULL,
  `product_stock` int(5) NOT NULL,
  `pdt_status` tinyint(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `products` (`pdt_id`, `pdt_name`, `pdt_price`, `pdt_weight`, `pdt_des`, `pdt_ctg`, `pdt_img`, `product_stock`, `pdt_status`) VALUES
(1, 'Cheese Tomato Makhana', 130, '55g', 'Postic premium crunchy roasted Cheese Tomato Fox Nuts, 100% natural, healthy, and roasted fresh in Udaipur, Rajasthan.', 1, 'CheesTomotoM1.png', 25, 0),
(2, 'Cheese Tomato Makhana', 130, '55g', 'Postic crunchy roasted Cheese Tomato Makhana, crispy, tasty and perfect on-the-go snack.', 1, 'CheesTomotoM1.png', 35, 1),
(3, 'Coriander Roasted Makhana', 130, '55g', 'Postic roasted Coriander Makhana prepared with farm-fresh coriander and natural Indian herbs.', 10, 'CorinderM1.png', 30, 1),
(16, 'Cream & Onion Makhana', 130, '55g', 'Postic Cream & Onion Fox Nuts - crunchy roasted superfood snack in savory herb seasoning.', 9, 'Cream&OnionM1.png', 40, 1),
(17, 'Tangy Lemon Makhana', 130, '55g', 'Postic Lemon Makhana - zesty citrus tang with crisp roasted fox nut crunch.', 11, 'LemonM1.png', 30, 1),
(18, 'Pani Puri Makhana', 130, '55g', 'Postic Pani Puri Makhana - irresistible authentic street food flavor in a healthy superfood.', 12, 'PaniPuniM1.png', 30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `pdt_id` int(255) NOT NULL,
  `img_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `product_images` (`id`, `pdt_id`, `img_name`) VALUES
(1, 1, 'CheesTomotoM2.png'),
(2, 1, 'CheesTomotoM3.png'),
(3, 3, 'CorinderM2.png'),
(4, 3, 'CorinderM3.png'),
(5, 16, 'Cream&OnionM2.png'),
(6, 16, 'Cream&OnionM3.png'),
(7, 17, 'LemonM2.png'),
(8, 17, 'LemonM3.png'),
(9, 18, 'PaniPuniM2.png'),
(10, 18, 'PaniPuniM3.png');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
CREATE TABLE `slider` (
  `slider_id` int(11) NOT NULL,
  `first_line` varchar(255) NOT NULL,
  `second_line` varchar(255) NOT NULL,
  `third_line` varchar(255) NOT NULL,
  `btn_left` varchar(25) NOT NULL,
  `btn_right` varchar(25) NOT NULL,
  `slider_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `slider` (`slider_id`, `first_line`, `second_line`, `third_line`, `btn_left`, `btn_right`, `slider_img`) VALUES
(1, '100% Slow Roasted', 'Cheese Tomato Makhana', 'Crunchy, tangy, and roasted fresh in Udaipur with zero palm oil.', 'Shop Now', 'Explore All', 'ct-banner1.png'),
(2, 'Authentic Chaat Flavor', 'Pani Puri Makhana', 'The street food crunch you love, now in a healthy guilt-free superfood.', 'Order Now', 'View Deals', 'pp-banner3.png'),
(3, 'Creamy & Savory Herbs', 'Cream & Onion Makhana', 'Golden roasted fox nuts seasoned with creamy herbs and spices.', 'Shop Now', 'All Flavors', 'co-banner4.png'),
(4, 'Tangy & Zesty Duo', 'Cheese Tomato & Pani Puri Duo', 'Double the crunch and flavor with our best-selling roasted Makhana packs.', 'Shop Combo', 'View All', 'ct-ppbanner2.png');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

DROP TABLE IF EXISTS `order_details`;
CREATE TABLE `order_details` (
  `order_id` int(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `pdt_weight` varchar(50) NOT NULL DEFAULT '55g',
  `pdt_quantity` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `uses_coupon` varchar(35) NOT NULL,
  `order_status` int(3) NOT NULL,
  `trans_id` varchar(100) NOT NULL,
  `Shipping_mobile` varchar(20) NOT NULL,
  `shiping` varchar(255) NOT NULL,
  `payment_method` varchar(30) NOT NULL DEFAULT 'manual',
  `payment_status` varchar(30) NOT NULL DEFAULT 'pending',
  `gateway_order_id` varchar(100) NOT NULL DEFAULT '',
  `order_time` timestamp NULL DEFAULT current_timestamp(),
  `order_date` date DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `order_details` (`order_id`, `user_id`, `product_name`, `pdt_weight`, `pdt_quantity`, `amount`, `uses_coupon`, `order_status`, `trans_id`, `Shipping_mobile`, `shiping`, `payment_method`, `payment_status`, `gateway_order_id`, `order_time`, `order_date`) VALUES
(1, 1, 'Cheese Tomato Makhana', '55g', 1, 130, '', 2, 'TXN98231', '9216398316', 'Fateh Sagar, Udaipur, Rajasthan - 313001', 'manual', 'paid', '', '2026-04-01 10:15:00', '2026-04-01'),
(2, 1, 'Cream & Onion Makhana', '55g', 2, 260, 'posticspecial', 2, 'TXN98245', '9216398316', 'Fateh Sagar, Udaipur, Rajasthan - 313001', 'manual', 'paid', '', '2026-04-02 11:20:00', '2026-04-02'),
(3, 5, 'Pani Puri Makhana', '55g', 1, 130, '', 1, 'TXN98288', '9829012345', 'Malviya Nagar, Jaipur, Rajasthan - 302017', 'manual', 'paid', '', '2026-04-03 14:45:00', '2026-04-03'),
(4, 9, 'Coriander Roasted Makhana', '55g', 3, 390, '', 0, 'TXN98310', '9414056789', 'Gogunda, Udaipur, Rajasthan - 313705', 'manual', 'pending', '', '2026-04-05 09:30:00', '2026-04-05'),
(5, 10, 'Cheese Tomato Makhana', '55g', 2, 260, 'posticspecial', 0, 'TXN98350', '9876543210', 'Hiran Magri Sector 4, Udaipur, Rajasthan - 313002', 'manual', 'pending', '', '2026-04-06 12:00:00', '2026-04-06');

-- --------------------------------------------------------

--
-- Table structure for table `user_address`
--

DROP TABLE IF EXISTS `user_address`;
CREATE TABLE `user_address` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_address` varchar(100) NOT NULL,
  `postal_code` varchar(8) NOT NULL,
  `city` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_payment`
--

DROP TABLE IF EXISTS `user_payment`;
CREATE TABLE `user_payment` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment_type` varchar(20) NOT NULL,
  `provider` varchar(35) NOT NULL,
  `account_no` int(11) DEFAULT NULL,
  `expiry` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `visitor_logs`
--

DROP TABLE IF EXISTS `visitor_logs`;
CREATE TABLE `visitor_logs` (
  `id` bigint(20) NOT NULL,
  `session_id` varchar(64) NOT NULL,
  `visitor_ip` varchar(45) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `page_url` varchar(255) NOT NULL,
  `page_title` varchar(150) NOT NULL DEFAULT '',
  `referrer` varchar(255) DEFAULT NULL,
  `device_type` varchar(20) NOT NULL DEFAULT 'Desktop',
  `browser` varchar(50) NOT NULL DEFAULT 'Other',
  `os` varchar(50) NOT NULL DEFAULT 'Other',
  `user_agent` varchar(350) DEFAULT NULL,
  `visit_date` date NOT NULL,
  `visit_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `visitor_logs` (`id`, `session_id`, `visitor_ip`, `user_id`, `customer_name`, `page_url`, `page_title`, `referrer`, `device_type`, `browser`, `os`, `user_agent`, `visit_date`, `visit_time`) VALUES
(1, 'sess_demo_101', '122.161.45.12', 1, 'Ritik', '/single_product.php?status=singleproduct&&id=1', 'Product Details', 'Google Search', 'Mobile', 'Chrome', 'Android', 'Mozilla/5.0 (Linux; Android 13; Mobile)', CURDATE(), NOW()),
(2, 'sess_demo_102', '49.36.128.55', NULL, NULL, '/index.php', 'Home Page', 'Instagram', 'Mobile', 'Safari', 'iOS', 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_5)', CURDATE(), NOW()),
(3, 'sess_demo_103', '152.57.34.89', NULL, NULL, '/all_product.php', 'All Products Catalog', 'Direct Visit', 'Desktop', 'Chrome', 'Windows', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)', CURDATE(), NOW()),
(4, 'sess_demo_104', '103.212.144.20', 5, 'karim', '/addtocart.php', 'Shopping Cart', 'Direct Visit', 'Desktop', 'Firefox', 'Windows', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0)', CURDATE(), NOW());

-- --------------------------------------------------------

--
-- Structure for view `all_order_info`
--

DROP TABLE IF EXISTS `all_order_info`;
DROP VIEW IF EXISTS `all_order_info`;

CREATE VIEW `all_order_info` AS 
SELECT 
  `order_details`.`order_id` AS `order_id`,
  `order_details`.`product_name` AS `product_name`,
  `order_details`.`pdt_weight` AS `pdt_weight`,
  `order_details`.`pdt_quantity` AS `pdt_quantity`,
  `order_details`.`amount` AS `amount`,
  `order_details`.`uses_coupon` AS `uses_coupon`,
  `users`.`user_firstname` AS `customer_name`,
  `order_details`.`Shipping_mobile` AS `Shipping_mobile`,
  `order_details`.`trans_id` AS `trans_id`,
  `order_details`.`shiping` AS `shiping_address`,
  `order_details`.`payment_method` AS `payment_method`,
  `order_details`.`payment_status` AS `payment_status`,
  `order_details`.`gateway_order_id` AS `gateway_order_id`,
  `order_details`.`order_status` AS `order_status`,
  `order_details`.`order_time` AS `order_time`,
  `order_details`.`order_date` AS `order_date`
FROM (`order_details` JOIN `users` ON `users`.`user_id` = `order_details`.`user_id`);

-- --------------------------------------------------------

--
-- Structure for view `product_info_ctg`
--

DROP TABLE IF EXISTS `product_info_ctg`;
DROP VIEW IF EXISTS `product_info_ctg`;

CREATE VIEW `product_info_ctg` AS 
SELECT 
  `products`.`pdt_id` AS `pdt_id`,
  `products`.`pdt_name` AS `pdt_name`,
  `products`.`pdt_price` AS `pdt_price`,
  `products`.`pdt_weight` AS `pdt_weight`,
  `products`.`pdt_des` AS `pdt_des`,
  `products`.`pdt_img` AS `pdt_img`,
  `products`.`product_stock` AS `product_stock`,
  `products`.`pdt_status` AS `pdt_status`,
  `catagory`.`ctg_id` AS `ctg_id`,
  `catagory`.`ctg_name` AS `ctg_name`
FROM (`products` JOIN `catagory` ON `products`.`pdt_ctg` = `catagory`.`ctg_id`);

--
-- Indexes for dumped tables
--

ALTER TABLE `add_logo`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`admin_id`);

ALTER TABLE `catagory`
  ADD PRIMARY KEY (`ctg_id`);

ALTER TABLE `cupon`
  ADD PRIMARY KEY (`cupon_id`);

ALTER TABLE `customer_feedback`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `header_info`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_id`);

ALTER TABLE `products`
  ADD PRIMARY KEY (`pdt_id`);

ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `slider`
  ADD PRIMARY KEY (`slider_id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

ALTER TABLE `user_address`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `user_payment`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `visitor_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visit_date` (`visit_date`),
  ADD KEY `idx_device` (`device_type`),
  ADD KEY `idx_session` (`session_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_time` (`visit_time`);

--
-- AUTO_INCREMENT for dumped tables
--

ALTER TABLE `add_logo`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `admin_info`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `catagory`
  MODIFY `ctg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

ALTER TABLE `cupon`
  MODIFY `cupon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `customer_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `header_info`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `order_details`
  MODIFY `order_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

ALTER TABLE `products`
  MODIFY `pdt_id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `slider`
  MODIFY `slider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `users`
  MODIFY `user_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

ALTER TABLE `user_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `user_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `visitor_logs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
