<?php

session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}




$selected_flavor = isset($_GET['flavor']) ? trim($_GET['flavor']) : (isset($_GET['search']) ? trim($_GET['search']) : 'all');
$selected_cat = isset($_GET['cat_id']) ? (int)$_GET['cat_id'] : 0;

$pdt_info = $obj->view_all_product();
$all_raw_pdts = array();
if ($pdt_info) {
    while ($pdt_fetch = mysqli_fetch_assoc($pdt_info)) {
        $all_raw_pdts[] = $pdt_fetch;
    }
}
if (empty($all_raw_pdts)) {
    $all_raw_pdts = array(
        array('pdt_id' => 1, 'pdt_name' => 'Cheese Tomato Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'CheesTomotoM1.png', 'ctg_name' => 'Cheese Tomato', 'ctg_id' => 1, 'product_stock' => 50),
        array('pdt_id' => 2, 'pdt_name' => 'Cream & Onion Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'Cream&OnionM1.png', 'ctg_name' => 'Cream & Onion', 'ctg_id' => 2, 'product_stock' => 50),
        array('pdt_id' => 3, 'pdt_name' => 'Coriander Mint Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'CorinderM1.png', 'ctg_name' => 'Coriander Mint', 'ctg_id' => 3, 'product_stock' => 50),
        array('pdt_id' => 4, 'pdt_name' => 'Tangy Lemon Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'LemonM1.png', 'ctg_name' => 'Tangy Lemon', 'ctg_id' => 4, 'product_stock' => 50),
        array('pdt_id' => 5, 'pdt_name' => 'Street Pani Puri Roasted Makhana', 'pdt_price' => 130, 'pdt_weight' => '55g', 'pdt_img' => 'PaniPuniM1.png', 'ctg_name' => 'Street Pani Puri', 'ctg_id' => 5, 'product_stock' => 50),
        array('pdt_id' => 6, 'pdt_name' => 'Raw Jumbo Phool Makhana', 'pdt_price' => 240, 'pdt_weight' => '250g', 'pdt_img' => 'raw_makhana.png', 'ctg_name' => 'Raw Jumbo Phool', 'ctg_id' => 6, 'product_stock' => 30),
    );
}

// Filter products based on selected flavor or category
$pdt_datas = array();
foreach ($all_raw_pdts as $p_item) {
    if (!empty($selected_cat)) {
        if ((int)($p_item['ctg_id'] ?? 0) === $selected_cat) {
            $pdt_datas[] = $p_item;
        }
    } elseif (!empty($selected_flavor) && strtolower($selected_flavor) !== 'all') {
        $p_haystack = strtolower(($p_item['pdt_name'] ?? '') . ' ' . ($p_item['ctg_name'] ?? ''));
        if (strpos($p_haystack, strtolower($selected_flavor)) !== false) {
            $pdt_datas[] = $p_item;
        }
    } else {
        $pdt_datas[] = $p_item;
    }
}
?>


<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->

    <?php
    include_once("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once("includes/header_top.php");
        ?>

        <?php
        include_once("includes/header_middle.php");
        ?>

        <?php
        include_once("includes/header_bottom.php");
        ?>

    </header>

    <!-- Page Contain -->
    <div class="page-contain">

        <!-- Main content -->
        <div id="main-content" class="main-content">

            <!-- Hero Banner -->
            <div class="postic-hero-banner">
                <div class="container">
                    <span class="banner-badge" style="background: rgba(255,255,255,0.2); padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 8px;"><i class="fa fa-shopping-bag"></i> Our Collection</span>
                    <h1>All Roasted Makhana</h1>
                    <p>100% Natural, Crunchy &amp; Healthy Superfood Flavors &mdash; Guilt-Free Snacking from Udaipur</p>
                </div>
            </div>

            <!-- Navigation section -->
            <div class="container">
                <nav class="biolife-nav" style="padding: 10px 0 20px 0;">
                    <ul>
                        <li class="nav-item"><a href="index.php" class="permal-link">Home</a></li>
                        <li class="nav-item"><span class="current-page">All Products</span></li>
                    </ul>
                </nav>
            </div>

            <!-- Flavour Quick Filter Pills -->
            <div class="container" style="margin-bottom: 25px;">
                <div style="background: #faf8f5; border: 1px solid #ede8df; border-radius: 16px; padding: 14px 18px;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
                        <span style="font-size: 13px; font-weight: 800; color: #1c1917; text-transform: uppercase; letter-spacing: 0.5px;">
                            <i class="fa fa-fire" style="color: #c8102e; margin-right: 4px;"></i> Select Flavour / Category:
                        </span>
                        <span style="font-size: 12px; font-weight: 700; color: #78716c;">
                            Showing <?php echo count($pdt_datas); ?> of <?php echo count($all_raw_pdts); ?> Products
                        </span>
                    </div>
                    <?php 
                        $flv_match = strtolower($selected_flavor);
                        $is_all_active = (empty($selected_flavor) || $flv_match === 'all') && empty($selected_cat);
                    ?>
                    <div class="postic-flavor-pills-row" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
                        <a href="all_product.php" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 800; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease; <?php echo $is_all_active ? 'background: #c8102e; color: #ffffff; border: 1.5px solid #c8102e; box-shadow: 0 2px 8px rgba(200,16,46,0.25);' : 'background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df;'; ?>">
                            <span>✨</span> All Flavours
                        </a>
                        <a href="all_product.php?flavor=Cheese" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease; <?php echo (strpos($flv_match, 'cheese') !== false) ? 'background: #c8102e; color: #ffffff; border: 1.5px solid #c8102e; box-shadow: 0 2px 8px rgba(200,16,46,0.25); font-weight: 800;' : 'background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df;'; ?>">
                            <span>🧀</span> Cheese Tomato
                        </a>
                        <a href="all_product.php?flavor=Cream" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease; <?php echo (strpos($flv_match, 'cream') !== false) ? 'background: #c8102e; color: #ffffff; border: 1.5px solid #c8102e; box-shadow: 0 2px 8px rgba(200,16,46,0.25); font-weight: 800;' : 'background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df;'; ?>">
                            <span>🧅</span> Cream &amp; Onion
                        </a>
                        <a href="all_product.php?flavor=Coriander" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease; <?php echo (strpos($flv_match, 'coriander') !== false) ? 'background: #c8102e; color: #ffffff; border: 1.5px solid #c8102e; box-shadow: 0 2px 8px rgba(200,16,46,0.25); font-weight: 800;' : 'background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df;'; ?>">
                            <span>🌿</span> Coriander Mint
                        </a>
                        <a href="all_product.php?flavor=Lemon" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease; <?php echo (strpos($flv_match, 'lemon') !== false) ? 'background: #c8102e; color: #ffffff; border: 1.5px solid #c8102e; box-shadow: 0 2px 8px rgba(200,16,46,0.25); font-weight: 800;' : 'background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df;'; ?>">
                            <span>🍋</span> Tangy Lemon
                        </a>
                        <a href="all_product.php?flavor=Pani" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease; <?php echo (strpos($flv_match, 'pani') !== false) ? 'background: #c8102e; color: #ffffff; border: 1.5px solid #c8102e; box-shadow: 0 2px 8px rgba(200,16,46,0.25); font-weight: 800;' : 'background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df;'; ?>">
                            <span>🌶️</span> Street Pani Puri
                        </a>
                        <a href="all_product.php?flavor=Raw" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease; <?php echo (strpos($flv_match, 'raw') !== false) ? 'background: #c8102e; color: #ffffff; border: 1.5px solid #c8102e; box-shadow: 0 2px 8px rgba(200,16,46,0.25); font-weight: 800;' : 'background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df;'; ?>">
                            <span>⚪</span> Raw Jumbo Phool
                        </a>
                    </div>
                </div>
            </div>

            <!-- Product -->
            <div class="container">
                <div class="product-category grid-style">
                    <div class="row">
                        <ul class="products-list">
                            <?php
                            if (empty($pdt_datas)) {
                                echo '<li class="col-xs-12 text-center" style="padding: 60px 15px;">
                                        <div style="max-width: 400px; margin: 0 auto; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 30px;">
                                            <i class="fa fa-shopping-basket" style="font-size: 40px; color: #94a3b8; margin-bottom: 12px; display: block;"></i>
                                            <h4 style="font-weight: 700; color: #1e293b;">No Products Found</h4>
                                            <p style="color: #64748b; font-size: 13px;">Products will appear here once added to stock.</p>
                                        </div>
                                      </li>';
                            } else {
                                foreach ($pdt_datas as $pdt_data) {
                            ?>
                                <li class="product-item col-lg-3 col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb">
                                            <a href="single_product.php?status=singleproduct&id=<?php echo $pdt_data['pdt_id'] ?>" class="link-to-product">
                                                <img src="admin/uploads/<?php echo $pdt_data['pdt_img'] ?>" alt="<?php echo htmlspecialchars($pdt_data['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>" width="270" height="270" class="product-thumnail">
                                            </a>
                                            <?php if (isset($pdt_data['product_stock']) && (int)$pdt_data['product_stock'] <= 0) { ?>
                                                <div class="labels" style="position: absolute; top: 10px; left: 10px;">
                                                    <span class="sale-label" style="background: #ef4444; color: #fff; font-size: 11px; padding: 3px 8px; border-radius: 12px; font-weight: 700;">Sold Out</span>
                                                </div>
                                            <?php } ?>
                                        </div>
                                        <div class="info">
                                            <b class="categories"><?php echo htmlspecialchars($pdt_data['ctg_name'], ENT_QUOTES, 'UTF-8'); ?></b>
                                            <h4 class="product-title"><a href="single_product.php?status=singleproduct&id=<?php echo $pdt_data['pdt_id'] ?>" class="pr-name"><?php echo htmlspecialchars($pdt_data['pdt_name'], ENT_QUOTES, 'UTF-8'); ?></a></h4>
                                            <div class="price" style="display: flex; align-items: center; gap: 8px;">
                                                <ins><span class="price-amount"><span class="currencySymbol">₹ </span><?php echo $pdt_data['pdt_price'] ?></span></ins>
                                                <?php $p_weight = !empty($pdt_data['pdt_weight']) ? $pdt_data['pdt_weight'] : '55g'; ?>
                                                <span style="font-size: 11px; font-weight: 700; color: #d32f2f; background: #fff5f5; border: 1px solid #fee2e2; border-radius: 10px; padding: 1px 8px;"><?php echo htmlspecialchars($p_weight); ?></span>
                                            </div>
                                            <div class="shipping-info" style="font-size: 11px; color: #64748b; margin-bottom: 6px;">
                                                <span><i class="fa fa-check" style="color: #d32f2f;"></i> Fresh Roasted</span> &bull; 
                                                <span>Express Shipping</span>
                                            </div>
                                            <div class="buttons" style="margin-top: auto; width: 100%;">
                                                <form action="addtocart.php" method="POST" class="postic-ajax-cart-form" style="margin: 0; width: 100%;">
                                                    <input type="hidden" name="pdt_id" value="<?php echo $pdt_data['pdt_id']; ?>">
                                                    <input type="hidden" name="pdt_name" value="<?php echo htmlspecialchars($pdt_data['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="pdt_price" value="<?php echo (int)$pdt_data['pdt_price']; ?>">
                                                    <input type="hidden" name="pdt_img" value="<?php echo htmlspecialchars($pdt_data['pdt_img'], ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="pdt_weight" value="<?php echo htmlspecialchars($p_weight); ?>">
                                                    <input type="hidden" name="addtocart" value="1">

                                                    <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 6px;">
                                                        <!-- Stepper [- 1 +] -->
                                                        <div class="postic-card-qty-stepper" style="display: inline-flex; align-items: center; border: 1.5px solid #ede8df; border-radius: 8px; background: #ffffff; height: 36px; overflow: hidden; flex-shrink: 0;">
                                                            <button type="button" class="postic-card-qty-btn minus" style="width: 26px; height: 100%; border: none; background: #fdfbf7; font-size: 14px; font-weight: 800; cursor: pointer; color: #1c1917; display: flex; align-items: center; justify-content: center; user-select: none;">&minus;</button>
                                                            <input type="number" name="quantity" class="postic-card-qty-val" value="1" min="1" max="10" readonly style="width: 28px; height: 100%; border: none; text-align: center; font-size: 13px; font-weight: 800; color: #1c1917; background: transparent; padding: 0;">
                                                            <button type="button" class="postic-card-qty-btn plus" style="width: 26px; height: 100%; border: none; background: #fdfbf7; font-size: 14px; font-weight: 800; cursor: pointer; color: #1c1917; display: flex; align-items: center; justify-content: center; user-select: none;">&#43;</button>
                                                        </div>
                                                        <!-- Add Button -->
                                                        <button type="submit" class="btn postic-add-to-cart-btn" style="flex: 1; height: 36px; background: #c8102e; color: #ffffff; font-weight: 800; font-size: 12px; border-radius: 8px; border: none; display: inline-flex; align-items: center; justify-content: center; gap: 4px; box-shadow: 0 3px 10px rgba(200,16,46,0.22); transition: all 0.2s ease; cursor: pointer; padding: 0 8px; white-space: nowrap;">
                                                            <i class="fa fa-shopping-cart"></i> Add
                                                        </button>
                                                    </div>
                                                    <a href="single_product.php?status=singleproduct&id=<?php echo $pdt_data['pdt_id']; ?>" style="display: block; width: 100%; text-align: center; font-size: 11px; font-weight: 700; color: #78716c; text-decoration: none; padding: 3px 0; border: 1px solid #ede8df; border-radius: 6px; background: #fdfbf7; transition: all 0.15s ease;">
                                                        <i class="fa fa-eye"></i> View Details
                                                    </a>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            <?php 
                                } 
                            }
                            ?>
                        </ul>
                    </div>

                    <?php if (count($pdt_datas) > 12) { ?>
                    <!-- Pagination block -->
                    <div class="biolife-panigations-block">
                        <ul class="panigation-contain">
                            <li><span class="current-page">1</span></li>
                        </ul>
                    </div>
                    <?php } ?>

                </div>





            </div>
        </div>
    </div>

    <!-- FOOTER -->

    <?php
    include_once("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>