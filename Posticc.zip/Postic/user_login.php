<?php
session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
if ($cata_info) {
    while ($data = mysqli_fetch_assoc($cata_info)) {
        $cataDatas[] = $data;
    }
}

$logo_info = $obj->display_logo();
$logo = $logo_info ? mysqli_fetch_assoc($logo_info) : null;
$logo_img = $logo ? $logo['img'] : 'logo.png';

$logmsg = '';
if (isset($_POST['user_login_btn'])) {
    $logmsg = $obj->user_login($_POST);
}

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    if ($userId) {
        header('location:userprofile.php');
        exit();
    }
}

include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->
    <?php include_once("includes/preloader.php"); ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">
        <?php include_once("includes/header_top.php"); ?>
        <?php include_once("includes/header_middle.php"); ?>
        <?php include_once("includes/header_bottom.php"); ?>
    </header>

    <!-- Centered Clean D2C Auth Card Section -->
    <div class="postic-auth-page">
        <div class="postic-auth-box">
            <div class="postic-auth-card-clean">
                
                <!-- Logo & Brand Header -->
                <div class="postic-auth-top">
                    <a href="index.php">
                        <img src="admin/uploads/<?php echo htmlspecialchars($logo_img); ?>" alt="Postic Foods" class="postic-auth-logo">
                    </a>
                    <span class="postic-auth-brand-tag">100% Roasted Superfoods &bull; Udaipur</span>
                    
                    <!-- Segmented Switcher Tabs -->
                    <div class="postic-tab-nav">
                        <a href="user_login.php" class="postic-tab-link active">Sign In</a>
                        <a href="user_register.php" class="postic-tab-link">Create Account</a>
                    </div>
                </div>

                <!-- Flash Success Notification -->
                <?php if (!empty($_SESSION['flash_success'])) { ?>
                    <div class="alert alert-success alert-dismissible" role="alert" style="border-radius: 10px; background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; font-size: 13px; padding: 12px 14px; margin-bottom: 20px;">
                        <i class="fa fa-check-circle" style="margin-right: 6px;"></i>
                        <?php echo htmlspecialchars($_SESSION['flash_success'], ENT_QUOTES, 'UTF-8'); ?>
                        <button type="button" class="close" data-dismiss="alert" style="color: #065f46;">&times;</button>
                    </div>
                    <?php unset($_SESSION['flash_success']); ?>
                <?php } ?>

                <!-- Flash Error Notification -->
                <?php if (!empty($_SESSION['flash_error'])) { ?>
                    <div class="alert alert-danger alert-dismissible" role="alert" style="border-radius: 10px; background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; font-size: 13px; padding: 12px 14px; margin-bottom: 20px;">
                        <i class="fa fa-exclamation-circle" style="margin-right: 6px;"></i>
                        <?php echo htmlspecialchars($_SESSION['flash_error'], ENT_QUOTES, 'UTF-8'); ?>
                        <button type="button" class="close" data-dismiss="alert" style="color: #991b1b;">&times;</button>
                    </div>
                    <?php unset($_SESSION['flash_error']); ?>
                <?php } ?>
                <?php if (!empty($logmsg)) { ?>
                    <div class="alert alert-danger alert-dismissible" role="alert" style="border-radius: 10px; background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; font-size: 13px; padding: 12px 14px; margin-bottom: 20px;">
                        <i class="fa fa-exclamation-circle" style="margin-right: 6px;"></i>
                        <?php echo htmlspecialchars($logmsg, ENT_QUOTES, 'UTF-8'); ?>
                        <button type="button" class="close" data-dismiss="alert" style="color: #991b1b;">&times;</button>
                    </div>
                <?php } ?>

                <!-- Login Form -->
                <form action="" name="frm-login" method="post" autocomplete="on">
                    <!-- Email Field -->
                    <div class="postic-form-group">
                        <label class="postic-form-label" for="user_email">
                            Email Address <span class="req">*</span>
                        </label>
                        <input type="email" id="user_email" name="user_email" class="postic-form-input" placeholder="e.g. ritik@gmail.com" value="<?php echo htmlspecialchars($_POST['user_email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required autofocus>
                    </div>

                    <!-- Password Field -->
                    <div class="postic-form-group">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                            <label class="postic-form-label" for="user_password" style="margin-bottom: 0;">
                                Password <span class="req">*</span>
                            </label>
                            <a href="user_password_recover.php" style="font-size: 12px; color: #d32f2f; font-weight: 600; text-decoration: none;">
                                Forgot password?
                            </a>
                        </div>
                        <div class="postic-pwd-wrap">
                            <input type="password" id="user_password" name="user_password" class="postic-form-input" placeholder="Enter your password" required style="padding-right: 42px !important;">
                            <button type="button" class="postic-eye-btn" id="toggleLoginPwd" tabindex="-1" title="Show / Hide Password">
                                <i class="fa fa-eye" id="toggleLoginIcon"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <button type="submit" name="user_login_btn" class="postic-submit-btn">
                        Sign In to Postic &rarr;
                    </button>
                </form>

                <!-- Footer Trust Strip -->
                <div class="postic-auth-footer-trust">
                    <span><i class="fa fa-shield"></i> 256-Bit SSL Secure</span>
                    <span><i class="fa fa-leaf"></i> 100% Roasted</span>
                    <span><i class="fa fa-truck"></i> Fast Delivery</span>
                </div>

            </div>
        </div>
    </div>

    <!-- Eye Toggle Script -->
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        var btn = document.getElementById("toggleLoginPwd");
        var input = document.getElementById("user_password");
        var icon = document.getElementById("toggleLoginIcon");
        if (btn && input && icon) {
            btn.addEventListener("click", function() {
                if (input.type === "password") {
                    input.type = "text";
                    icon.className = "fa fa-eye-slash";
                } else {
                    input.type = "password";
                    icon.className = "fa fa-eye";
                }
            });
        }
    });
    </script>

    <!-- FOOTER -->
    <?php
    include_once("includes/footer.php");
    include_once("includes/mobile_footer.php");
    include_once("includes/mobile_global.php");
    ?>
</body>
</html>
