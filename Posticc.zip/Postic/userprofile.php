<?php
 
session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();
$razorpay_config = include("config/razorpay.php");
$razorpay_enabled = !empty($razorpay_config['enabled']) && !empty($razorpay_config['key_id']) && !empty($razorpay_config['key_secret']);

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}

// if (isset($_POST['user_login_btn'])) {
//     $logmsg = $obj->user_login($_POST);
// }

if (empty($_SESSION['user_id'])) {
    $_SESSION['flash_error'] = "Please sign in or create an account to proceed with checkout.";
    header("location:user_login.php");
    exit();
}

$userid = $_SESSION['user_id'];
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

if (!function_exists('sync_cart_quantities')) {
    function sync_cart_quantities(&$cart, $quantities)
    {
        if (!is_array($cart) || !is_array($quantities)) {
            return;
        }

        foreach ($cart as $key => $value) {
            if (isset($quantities[$key])) {
                $quantity = (int) $quantities[$key];
                if ($quantity < 1) {
                    $quantity = 1;
                }
                if ($quantity > 10) {
                    $quantity = 10;
                }
                $cart[$key]['quantity'] = $quantity;
            } elseif (!isset($cart[$key]['quantity']) || (int) $cart[$key]['quantity'] < 1) {
                $cart[$key]['quantity'] = 1;
            }
        }
    }
}

if (empty($_SESSION['cart'])) {
    header("location:exist_order.php");
    exit();
}

if (isset($_POST['quantity']) && is_array($_POST['quantity']) && isset($_SESSION['cart'])) {
    sync_cart_quantities($_SESSION['cart'], $_POST['quantity']);
}

if (isset($_POST['remove_product'])) {
    $remove_index = (int) $_POST['remove_product'];
    if (isset($_SESSION['cart'][$remove_index])) {
        unset($_SESSION['cart'][$remove_index]);
        $_SESSION['cart'] = array_values($_SESSION['cart']);
    }

    if (empty($_SESSION['cart'])) {
        unset($_SESSION['cart_pdt_number']);
        unset($_SESSION['subtotal']);
        header("location:exist_order.php");
        exit();
    }
}

if (isset($_GET['logout'])) {
    if ($_GET['logout'] == "logout") {
        $obj->user_logout();
    }
}

if (isset($_POST['confirm_order'])) {
   
    // $obj->place_order($_POST);

    $order_msg = $obj->confirm_order($_POST, $_SESSION['cart']);
}

$user_profile = $obj->get_user_profile($userid);
$saved_home = !empty($user_profile['home_address']) ? $user_profile['home_address'] : (!empty($_SESSION['home_address']) ? $_SESSION['home_address'] : '');
$saved_office = !empty($user_profile['office_address']) ? $user_profile['office_address'] : (!empty($_SESSION['office_address']) ? $_SESSION['office_address'] : '');
$saved_default = !empty($user_profile['user_address']) ? $user_profile['user_address'] : (isset($_SESSION['address']) ? $_SESSION['address'] : '');

$cart_items = array();
$cart_subtotal = 0;
$cart_item_count = 0;
$cart_total_quantity = 0;
$order_names = array();
$coupon_input = isset($_POST['coupon']) ? trim($_POST['coupon']) : '';
$txid_value = isset($_POST['txid']) ? trim($_POST['txid']) : '';
$mobile_value = isset($_POST['shipping_Mobile']) ? trim($_POST['shipping_Mobile']) : (!empty($user_profile['user_mobile']) ? $user_profile['user_mobile'] : (isset($_SESSION['mobile']) ? $_SESSION['mobile'] : ''));
$shipping_value = isset($_POST['shiping']) ? trim($_POST['shiping']) : (!empty($saved_home) ? $saved_home : (!empty($saved_default) ? $saved_default : $saved_office));

if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $key => $value) {
        $quantity = isset($value['quantity']) ? (int) $value['quantity'] : 1;
        if ($quantity < 1) {
            $quantity = 1;
        }

        $line_total = ((int) $value['pdt_price']) * $quantity;
        $cart_subtotal += $line_total;
        $cart_item_count++;
        $cart_total_quantity += $quantity;
        $order_names[] = $value['pdt_name'];

        $value['quantity'] = $quantity;
        $value['line_total'] = $line_total;
        $value['cart_key'] = $key;
        $cart_items[] = $value;
    }
}

$_SESSION['subtotal'] = $cart_subtotal;
$_SESSION['cart_pdt_number'] = $cart_total_quantity;




?>


<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->

    <?php
    include_once("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once("includes/header_top.php");
        ?>

        <?php
        include_once("includes/header_middle.php");
        ?>

        <?php
        include_once("includes/header_bottom.php");
        ?>

    </header>

    <!-- Page Contain -->
    <div class="page-contain">

        <!-- Main content -->
        <div id="main-content" class="main-content">




            <div class="container">
                <style>
                    .checkout-panel {
                        background: #fff;
                        border: 1px solid #ececec;
                        border-radius: 16px;
                        padding: 22px;
                        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
                    }
                    .checkout-panel + .checkout-panel {
                        margin-top: 18px;
                    }
                    .coupon-helper {
                        font-size: 13px;
                        color: #6c757d;
                        margin-top: 8px;
                        display: block;
                    }
                    .cart-qty-input {
                        width: 80px;
                        padding: 8px;
                        border: 1px solid #d9d9d9;
                        border-radius: 8px;
                    }
                    .price-badge {
                        display: inline-block;
                        min-width: 88px;
                    }
                    .checkout-alert {
                        margin-bottom: 18px;
                    }
                    .address-actions {
                        display: flex;
                        gap: 8px;
                        flex-wrap: wrap;
                        margin: 10px 0;
                    }
                    #checkoutMap {
                        height: 420px;
                        width: 100%;
                        border-radius: 8px;
                        border: 1px solid #ddd;
                    }
                    .payment-note {
                        display: block;
                        margin-top: 8px;
                        color: #6c757d;
                        font-size: 13px;
                    }
                </style>
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">

                <?php if (!empty($_SESSION['flash_success'])) { ?>
                    <div class="alert alert-success alert-dismissible fade show checkout-alert" role="alert">
                        <?php echo htmlspecialchars($_SESSION['flash_success'], ENT_QUOTES, 'UTF-8'); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <script>
                        alert(<?php echo json_encode($_SESSION['flash_success']); ?>);
                    </script>
                    <?php unset($_SESSION['flash_success']); ?>
                <?php } ?>

                <?php if (!empty($_SESSION['flash_error'])) { ?>
                    <div class="alert alert-danger alert-dismissible fade show checkout-alert" role="alert">
                        <?php echo htmlspecialchars($_SESSION['flash_error'], ENT_QUOTES, 'UTF-8'); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php unset($_SESSION['flash_error']); ?>
                <?php } ?>

                <!-- Top User Banner -->
                <div style="display: flex; justify-content: space-between; align-items: center; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px 22px; margin-bottom: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); flex-wrap: wrap; gap: 10px;">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <div style="width: 44px; height: 44px; border-radius: 50%; background: #fef2f2; color: #d32f2f; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 700; border: 1px solid #fecaca;">
                            <i class="fa fa-user"></i>
                        </div>
                        <div>
                            <span style="font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: 600;">Welcome,</span>
                            <h4 style="margin: 0; font-size: 16px; font-weight: 700; color: #1e293b;"><?php echo strtoupper($username); ?></h4>
                        </div>
                    </div>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <a href="exist_order.php" class="btn btn-sm" style="background: #f8fafc; color: #334155; font-weight: 600; border: 1px solid #cbd5e1; border-radius: 6px; padding: 6px 14px; text-decoration: none;">
                            <i class="fa fa-list-alt"></i> My Orders
                        </a>
                        <a href="?logout=logout" class="btn btn-sm" style="background: #fff; color: #dc2626; font-weight: 600; border: 1px solid #fecaca; border-radius: 6px; padding: 6px 14px; text-decoration: none;">
                            <i class="fa fa-sign-out"></i> Logout
                        </a>
                    </div>
                </div>

                <form action="userprofile.php" method="POST" id="checkoutForm">
                    <div class="row">
                        <!-- Left Column: Cart Items & Shipping Info -->
                        <div class="col-lg-7 col-md-7 col-sm-12">
                            <div class="checkout-panel">
                                <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 0 0 16px 0; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px;">
                                    <i class="fa fa-shopping-basket" style="color: #d32f2f; margin-right: 6px;"></i> Cart Summary
                                </h3>

                                <?php if (!empty($order_msg)) { ?>
                                    <div class="alert alert-danger"><?php echo $order_msg; ?></div>
                                <?php } ?>

                                <?php if (!empty($cart_items)) { ?>
                                    <div class="table-responsive">
                                        <table class="shop_table cart-form" style="width: 100%;">
                                            <thead>
                                                <tr>
                                                    <th class="product-name">Product</th>
                                                    <th class="product-price">Price</th>
                                                    <th class="product-quantity">Quantity</th>
                                                    <th class="product-subtotal">Total</th>
                                                    <th class="product-quantity">Remove</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($cart_items as $item) { ?>
                                                    <tr class="cart_item js-cart-row">
                                                        <td class="product-thumbnail" data-title="Product">
                                                            <a class="prd-thumb" href="single_product.php?status=singleproduct&&id=<?php echo $item['pdt_id']; ?>">
                                                                <figure><img width="80" height="80" src="admin/uploads/<?php echo $item['pdt_img']; ?>" alt="<?php echo htmlspecialchars($item['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>" style="border-radius: 6px; object-fit: cover;"></figure>
                                                            </a>
                                                            <a class="prd-name" href="single_product.php?status=singleproduct&&id=<?php echo $item['pdt_id']; ?>" style="font-weight: 700; color: #1e293b;"><?php echo htmlspecialchars($item['pdt_name']); ?></a>
                                                            <div style="margin-top: 4px;">
                                                                <span style="background: #fef2f2; color: #d32f2f; border: 1px solid #fecaca; font-size: 11px; padding: 2px 7px; border-radius: 12px; display: inline-flex; align-items: center; gap: 4px; font-weight: 600;">
                                                                    <i class="fa fa-cubes"></i> <?php echo htmlspecialchars($item['pdt_weight'] ?? '55g'); ?>
                                                                </span>
                                                            </div>
                                                        </td>
                                                        <td class="product-price" data-title="Price">
                                                            <span class="price-badge" style="font-weight: 700;">₹<?php echo (int) $item['pdt_price']; ?></span>
                                                            <input type="hidden" class="pdt_price" value="<?php echo (int) $item['pdt_price']; ?>">
                                                        </td>
                                                        <td class="product-quantity" data-title="Quantity">
                                                            <input type="number" name="quantity[<?php echo $item['cart_key']; ?>]" value="<?php echo (int) $item['quantity']; ?>" class="quantity cart-qty-input" min="1" max="10" style="width: 60px; text-align: center; border-radius: 6px;">
                                                        </td>
                                                        <td class="product-subtotal" data-title="Total">
                                                            <div class="price price-contain">
                                                                <ins><span class="price-amount" style="font-weight: 800; color: #d32f2f;">₹<span class="subtotal"><?php echo (int) $item['line_total']; ?></span></span></ins>
                                                            </div>
                                                        </td>
                                                        <td class="product-quantity" data-title="Remove">
                                                            <button type="submit" class="btn btn-sm" style="background: #fee2e2; color: #dc2626; border: 1px solid #fecaca; border-radius: 6px; padding: 4px 10px;" name="remove_product" value="<?php echo $item['cart_key']; ?>">Remove</button>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php } else { ?>
                                    <p>Your cart is empty.</p>
                                <?php } ?>
                            </div>

                            <!-- Shipping Address Panel -->
                            <div class="checkout-panel" style="margin-top: 20px;">
                                <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 0 0 16px 0; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px;">
                                    <i class="fa fa-truck" style="color: #d32f2f; margin-right: 6px;"></i> Delivery Address &amp; Contact
                                </h3>

                                <div class="form-group" style="margin-bottom: 16px;">
                                    <label style="font-weight: 700; color: #1e293b; font-size: 14px;">Mobile Number <span style="color: #d32f2f;">*</span></label>
                                    <input type="text" name="shipping_Mobile" class="form-control" placeholder="10-digit Mobile Number" value="<?php echo htmlspecialchars($mobile_value, ENT_QUOTES, 'UTF-8'); ?>" required style="height: 42px; border-radius: 8px;">
                                </div>

                                <div class="form-group" style="margin-bottom: 16px;">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 6px;">
                                        <label style="font-weight: 700; color: #1e293b; font-size: 14px; margin: 0;">Full Delivery Address <span style="color: #d32f2f;">*</span></label>
                                        <div class="address-actions" style="margin: 0; gap: 6px;">
                                            <?php if (!empty($saved_home)) { ?>
                                                <button type="button" class="btn btn-xs" id="btnUseHome" data-address="<?php echo htmlspecialchars($saved_home, ENT_QUOTES, 'UTF-8'); ?>" style="border-radius: 6px; font-size: 11px; padding: 4px 9px; font-weight: 700; background: #f8fafc; border: 1px solid #cbd5e1; color: #1e293b;"><i class="fa fa-home" style="color: #d32f2f;"></i> Home</button>
                                            <?php } ?>
                                            <?php if (!empty($saved_office)) { ?>
                                                <button type="button" class="btn btn-xs" id="btnUseOffice" data-address="<?php echo htmlspecialchars($saved_office, ENT_QUOTES, 'UTF-8'); ?>" style="border-radius: 6px; font-size: 11px; padding: 4px 9px; font-weight: 700; background: #f8fafc; border: 1px solid #cbd5e1; color: #1e293b;"><i class="fa fa-building" style="color: #d32f2f;"></i> Office</button>
                                            <?php } ?>
                                            <button type="button" class="btn btn-xs btn-default" id="useCurrentLocation" style="border-radius: 6px; font-size: 11px; padding: 4px 8px; font-weight: 600;"><i class="fa fa-crosshairs" style="color: #d32f2f;"></i> Auto-detect</button>
                                            <button type="button" class="btn btn-xs btn-default" data-toggle="modal" data-target="#mapModal" id="openMapPicker" style="border-radius: 6px; font-size: 11px; padding: 4px 8px; font-weight: 600;"><i class="fa fa-map-marker" style="color: #d32f2f;"></i> Choose on Map</button>
                                        </div>
                                    </div>
                                    <textarea name="shiping" id="shippingAddress" class="form-control" rows="4" placeholder="House/Flat No., Street, Landmark, City, State, PIN Code" required style="border-radius: 8px;"><?php echo htmlspecialchars($shipping_value, ENT_QUOTES, 'UTF-8'); ?></textarea>
                                    <input type="hidden" name="location_lat" id="locationLat">
                                    <input type="hidden" name="location_lng" id="locationLng">

                                    <!-- Save Address Option -->
                                    <div style="margin-top: 10px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px 14px;">
                                        <span style="font-weight: 700; font-size: 12px; color: #475569; display: block; margin-bottom: 6px;">
                                            <i class="fa fa-bookmark" style="color: #d32f2f; margin-right: 4px;"></i> Save this delivery address for next time:
                                        </span>
                                        <div style="display: flex; gap: 16px; align-items: center; flex-wrap: wrap;">
                                            <label style="font-weight: 600; font-size: 13px; margin: 0; cursor: pointer; color: #1e293b;">
                                                <input type="radio" name="save_address_type" value="home" style="margin-right: 4px;"> Save as Home Address
                                            </label>
                                            <label style="font-weight: 600; font-size: 13px; margin: 0; cursor: pointer; color: #1e293b;">
                                                <input type="radio" name="save_address_type" value="office" style="margin-right: 4px;"> Save as Office Address
                                            </label>
                                            <label style="font-weight: normal; font-size: 13px; margin: 0; cursor: pointer; color: #64748b;">
                                                <input type="radio" name="save_address_type" value="none" checked style="margin-right: 4px;"> Don't Save
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Right Column: Order Summary & Payment -->
                        <div class="col-lg-5 col-md-5 col-sm-12">
                            <div class="checkout-panel shpcart-subtotal-block" style="position: sticky; top: 20px;">
                                <h3 style="font-size: 18px; font-weight: 800; color: #1e293b; margin: 0 0 16px 0; border-bottom: 1px solid #f1f5f9; padding-bottom: 12px;">
                                    <i class="fa fa-credit-card" style="color: #d32f2f; margin-right: 6px;"></i> Order Summary
                                </h3>

                                <div class="subtotal-line" style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                                    <b class="stt-name" style="font-size: 14px;">Subtotal <span class="sub">(<span id="cartItemCount"><?php echo $cart_total_quantity; ?></span> items)</span></b>
                                    <span class="stt-price" style="font-weight: 700; font-size: 15px;">₹<span id="totalOfall"><?php echo $cart_subtotal; ?></span></span>
                                </div>

                                <div style="margin-bottom: 14px; background: #fdfaf9; border: 1px dashed #fecaca; border-radius: 8px; padding: 12px;">
                                    <label style="font-weight: 700; font-size: 13px; color: #1e293b; margin-bottom: 4px; display: block;">Have a Coupon?</label>
                                    <div style="display: flex; gap: 6px;">
                                        <input type="text" name="coupon" id="couponCode" class="form-control" placeholder="Enter coupon (e.g. POSTIC10)" value="<?php echo htmlspecialchars($coupon_input, ENT_QUOTES, 'UTF-8'); ?>" style="height: 38px; border-radius: 6px; font-size: 13px;">
                                    </div>
                                    <small class="coupon-helper" id="couponStatus" style="font-size: 12px; margin-top: 4px; display: block;">Type coupon code to apply instant savings.</small>
                                </div>

                                <div class="subtotal-line" style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                                    <span style="font-size: 14px; color: #64748b;">Coupon Discount:</span>
                                    <span style="font-weight: 700; color: #16a34a; font-size: 14px;">- ₹<span id="discount">0</span></span>
                                </div>

                                <div class="subtotal-line" style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                                    <span style="font-size: 14px; color: #64748b;">Delivery Charges:</span>
                                    <span style="font-weight: 700; color: #16a34a; font-size: 14px;">FREE</span>
                                </div>

                                <hr style="border-top: 2px dashed #e2e8f0; margin: 14px 0;">

                                <div class="subtotal-line" style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
                                    <b style="font-size: 18px; color: #1e293b;">Final Total:</b>
                                    <span style="font-size: 26px; font-weight: 800; color: #d32f2f;">₹<span id="afterdiscount"><?php echo $cart_subtotal; ?></span></span>
                                </div>

                                <div style="margin-bottom: 16px;">
                                    <label style="font-weight: 700; font-size: 13px; color: #1e293b; margin-bottom: 4px; display: block;">Payment Reference / TXID (Optional)</label>
                                    <input type="text" class="form-control" placeholder="UPI ref / Note (for manual pay)" name="txid" value="<?php echo htmlspecialchars($txid_value, ENT_QUOTES, 'UTF-8'); ?>" style="height: 38px; border-radius: 6px; font-size: 13px;">
                                    <?php if ($razorpay_enabled) { ?>
                                        <small class="payment-note" style="font-size: 11px; color: #64748b;">Razorpay payment par TXID automatically save ho jayega.</small>
                                    <?php } else { ?>
                                        <small class="payment-note" style="font-size: 11px; color: #64748b;">Cash on delivery / manual payment select kar sakte hain.</small>
                                    <?php } ?>
                                </div>

                                <input type="hidden" name="user_id" value="<?php echo (int) $_SESSION['user_id']; ?>">
                                <input type="hidden" name="product_name" value="<?php echo htmlspecialchars(implode(', ', $order_names), ENT_QUOTES, 'UTF-8'); ?>">
                                <input type="hidden" name="product_item" value="<?php echo (int) $cart_item_count; ?>">
                                <input type="hidden" name="amount" id="orderAmountInput" value="<?php echo (int) $cart_subtotal; ?>">
                                <input type="hidden" name="order_status" value="0">
                                <input type="hidden" name="payment_method" value="manual">
                                <input type="hidden" name="payment_status" value="pending">

                                <div class="btn-checkout" style="margin-top: 18px;">
                                    <?php if ($razorpay_enabled) { ?>
                                        <button type="button" class="btn btn-block btn-lg" id="payWithRazorpay" style="background: #d32f2f; color: #fff; font-weight: 800; border-radius: 8px; padding: 14px; font-size: 16px; border: none; box-shadow: 0 4px 15px rgba(211,47,47,0.3);">
                                            <i class="fa fa-lock"></i> Pay with Razorpay
                                        </button>
                                        <input type="submit" class="btn btn-light btn-block" value="Confirm Manually (COD / Transfer)" name="confirm_order" style="margin-top: 10px; border: 1px solid #cbd5e1; border-radius: 8px; font-weight: 600;">
                                    <?php } else { ?>
                                        <input type="submit" class="btn btn-block btn-lg" value="Place Order Now" name="confirm_order" style="background: #d32f2f; color: #fff; font-weight: 800; border-radius: 8px; padding: 14px; font-size: 16px; border: none; box-shadow: 0 4px 15px rgba(211,47,47,0.3);">
                                    <?php } ?>
                                </div>

                                <p class="pickup-info" style="font-size: 12px; color: #64748b; margin-top: 14px; text-align: center;">
                                    <i class="fa fa-shield" style="color: #16a34a;"></i> 100% Safe &amp; Secure Checkout | Udaipur Fast Delivery
                                </p>
                            </div>
                        </div>
                    </div>
                </form>

                <div class="modal fade" id="mapModal" tabindex="-1" role="dialog" aria-labelledby="mapModalLabel">
                    <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="mapModalLabel">Select Delivery Location</h4>
                            </div>
                            <div class="modal-body">
                                <div id="checkoutMap"></div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-success" id="useMapLocation" data-dismiss="modal">Use this location</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>






        </div>
    </div>
    <br>


    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <?php if ($razorpay_enabled) { ?>
        <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <?php } ?>
    <script>
        $(document).ready(function() {
            function formatPrice(value) {
                value = parseInt(value, 10) || 0;
                if (value < 0) {
                    value = 0;
                }
                return value;
            }

            function updateLineTotals() {
                var total = 0;
                var totalItems = 0;

                $(".js-cart-row").each(function() {
                    var price = formatPrice($(this).find(".pdt_price").val());
                    var quantityInput = $(this).find(".quantity");
                    var quantity = formatPrice(quantityInput.val());

                    if (quantity < 1) {
                        quantity = 1;
                    }

                    if (quantity > 10) {
                        quantity = 10;
                    }

                    quantityInput.val(quantity);

                    var lineTotal = price * quantity;
                    $(this).find(".subtotal").text(lineTotal);
                    total += lineTotal;
                    totalItems += quantity;
                });

                $("#totalOfall").text(total);
                $("#cartItemCount").text(totalItems);

                return total;
            }

            function updateCouponSummary() {
                var total = updateLineTotals();
                var couponCode = $.trim($("#couponCode").val());

                if (couponCode === "") {
                    $("#discount").text(0);
                    $("#afterdiscount").text(total);
                    $("#orderAmountInput").val(total);
                    $("#couponStatus").text("Enter your coupon code to see the discount instantly.").css("color", "#6c757d");
                    return;
                }

                $.ajax({
                    url: "json/coupon.php",
                    method: "POST",
                    dataType: "json",
                    data: {
                        action: "load_discount",
                        coupon: couponCode,
                        price: total
                    },
                    success: function(response) {
                        var discountAmount = response && response.discount_amount ? formatPrice(response.discount_amount) : 0;
                        var finalTotal = total - discountAmount;

                        if (finalTotal < 0) {
                            finalTotal = 0;
                        }

                        $("#discount").text(discountAmount);
                        $("#afterdiscount").text(finalTotal);
                        $("#orderAmountInput").val(finalTotal);

                        if (response && response.is_valid) {
                            $("#couponStatus").text(response.discount_percent + "% discount applied successfully.").css("color", "#28a745");
                        } else {
                            $("#couponStatus").text("Coupon code not found or inactive.").css("color", "#dc3545");
                        }
                    },
                    error: function() {
                        $("#discount").text(0);
                        $("#afterdiscount").text(total);
                        $("#orderAmountInput").val(total);
                        $("#couponStatus").text("Coupon could not be checked right now.").css("color", "#dc3545");
                    }
                });
            }

            $(".quantity").on("input change", function() {
                updateCouponSummary();
            });

            $("#couponCode").on("input blur", function() {
                updateCouponSummary();
            });

            updateCouponSummary();

            var selectedLocation = {
                lat: null,
                lng: null,
                address: ""
            };
            var checkoutMap = null;
            var checkoutMarker = null;

            function setAddressFromLocation(lat, lng, address) {
                selectedLocation.lat = lat;
                selectedLocation.lng = lng;
                selectedLocation.address = address || "";

                $("#locationLat").val(lat);
                $("#locationLng").val(lng);

                var mapLink = "https://www.google.com/maps?q=" + lat + "," + lng;
                var addressText = selectedLocation.address ? selectedLocation.address + "\n" : "";
                addressText += "Location: " + lat + ", " + lng + "\nMap: " + mapLink;
                $("#shippingAddress").val(addressText);
            }

            function reverseAddress(lat, lng, callback) {
                $.ajax({
                    url: "https://nominatim.openstreetmap.org/reverse",
                    method: "GET",
                    dataType: "json",
                    data: {
                        format: "jsonv2",
                        lat: lat,
                        lon: lng
                    },
                    success: function(response) {
                        callback(response && response.display_name ? response.display_name : "");
                    },
                    error: function() {
                        callback("");
                    }
                });
            }

            $("#btnUseHome").on("click", function() {
                var addr = $(this).data("address");
                if (addr) {
                    $("#shippingAddress").val(addr);
                }
            });

            $("#btnUseOffice").on("click", function() {
                var addr = $(this).data("address");
                if (addr) {
                    $("#shippingAddress").val(addr);
                }
            });

            $("#useCurrentLocation").on("click", function() {
                if (!navigator.geolocation) {
                    alert("Location is not supported in this browser.");
                    return;
                }

                navigator.geolocation.getCurrentPosition(function(position) {
                    var lat = position.coords.latitude.toFixed(6);
                    var lng = position.coords.longitude.toFixed(6);
                    reverseAddress(lat, lng, function(address) {
                        setAddressFromLocation(lat, lng, address);
                    });
                }, function() {
                    alert("Location permission was not allowed.");
                });
            });

            $("#mapModal").on("shown.bs.modal", function() {
                if (typeof L === "undefined") {
                    alert("Map could not load right now.");
                    return;
                }

                var defaultLat = selectedLocation.lat || 24.5854;
                var defaultLng = selectedLocation.lng || 73.7125;

                if (!checkoutMap) {
                    checkoutMap = L.map("checkoutMap").setView([defaultLat, defaultLng], 13);
                    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                        maxZoom: 19,
                        attribution: "&copy; OpenStreetMap"
                    }).addTo(checkoutMap);

                    checkoutMarker = L.marker([defaultLat, defaultLng], {
                        draggable: true
                    }).addTo(checkoutMap);

                    checkoutMap.on("click", function(event) {
                        checkoutMarker.setLatLng(event.latlng);
                    });
                } else {
                    checkoutMap.setView([defaultLat, defaultLng], 13);
                    checkoutMarker.setLatLng([defaultLat, defaultLng]);
                }

                setTimeout(function() {
                    checkoutMap.invalidateSize();
                }, 200);
            });

            $("#useMapLocation").on("click", function() {
                if (!checkoutMarker) {
                    return;
                }

                var point = checkoutMarker.getLatLng();
                var lat = point.lat.toFixed(6);
                var lng = point.lng.toFixed(6);
                reverseAddress(lat, lng, function(address) {
                    setAddressFromLocation(lat, lng, address);
                });
            });

            <?php if ($razorpay_enabled) { ?>
            $("#payWithRazorpay").on("click", function() {
                if (typeof Razorpay === "undefined") {
                    alert("Razorpay checkout could not load right now.");
                    return;
                }

                var form = document.getElementById("checkoutForm");
                if (!form.checkValidity()) {
                    form.reportValidity();
                    return;
                }

                var $button = $(this);
                $button.prop("disabled", true).text("Creating payment...");

                $.ajax({
                    url: "payment_create.php",
                    method: "POST",
                    dataType: "json",
                    data: $("#checkoutForm").serialize(),
                    success: function(response) {
                        if (!response || !response.success) {
                            alert(response && response.message ? response.message : "Payment could not start.");
                            $button.prop("disabled", false).text("Pay with Razorpay");
                            return;
                        }

                        var options = {
                            key: response.key,
                            amount: response.amount,
                            currency: response.currency,
                            name: response.store_name,
                            order_id: response.order_id,
                            prefill: response.customer,
                            handler: function(paymentResponse) {
                                var verifyForm = $('<form>', {
                                    method: 'POST',
                                    action: 'payment_verify.php'
                                });

                                $.each($("#checkoutForm").serializeArray(), function(_, field) {
                                    verifyForm.append($('<input>', {
                                        type: 'hidden',
                                        name: field.name,
                                        value: field.value
                                    }));
                                });

                                verifyForm.append($('<input>', { type: 'hidden', name: 'razorpay_order_id', value: paymentResponse.razorpay_order_id }));
                                verifyForm.append($('<input>', { type: 'hidden', name: 'razorpay_payment_id', value: paymentResponse.razorpay_payment_id }));
                                verifyForm.append($('<input>', { type: 'hidden', name: 'razorpay_signature', value: paymentResponse.razorpay_signature }));
                                $('body').append(verifyForm);
                                verifyForm.submit();
                            },
                            modal: {
                                ondismiss: function() {
                                    $button.prop("disabled", false).text("Pay with Razorpay");
                                }
                            }
                        };

                        var razorpay = new Razorpay(options);
                        razorpay.open();
                    },
                    error: function() {
                        alert("Payment could not start right now.");
                        $button.prop("disabled", false).text("Pay with Razorpay");
                    }
                });
            });
            <?php } ?>
        });
    </script>
    <!-- FOOTER -->

    <?php
    include_once("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>
