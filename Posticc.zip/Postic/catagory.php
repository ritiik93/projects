<?php
session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}

 
$pdt_datas = array();
$ctg_info = array('ctg_name' => 'Categories');

if (isset($_GET['status']) && $_GET['status'] == 'catView' && isset($_GET['id'])) {
    $cataId = (int) $_GET['id'];
    $pdt_info = $obj->display_product_byCata($cataId);
    
    if ($pdt_info) {
        while ($pdt_fetch = mysqli_fetch_assoc($pdt_info)) {
            $pdt_datas[] = $pdt_fetch;
        }
    }

    $fetched_ctg = $obj->ctg_by_id($cataId);
    if ($fetched_ctg) {
        $ctg_info = $fetched_ctg;
    }
}



?>


<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->

    <?php
    include_once("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once("includes/header_top.php");
        ?>

        <?php
        include_once("includes/header_middle.php");
        ?>

        <?php
        include_once("includes/header_bottom.php");
        ?>

    </header>

    <!-- Page Contain -->
    <div class="page-contain">

        <!-- Main content -->
        <div id="main-content" class="main-content">

            <!-- Hero Banner -->
            <div class="postic-hero-banner">
                <div class="container">
                    <span class="banner-badge" style="background: rgba(255,255,255,0.2); padding: 4px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; display: inline-block; margin-bottom: 8px;"><i class="fa fa-tag"></i> Category</span>
                    <h1><?php echo htmlspecialchars($ctg_info['ctg_name'], ENT_QUOTES, 'UTF-8'); ?></h1>
                    <p>Explore our premium roasted & healthy fox nuts in this collection.</p>
                </div>
            </div>

            <!-- Navigation section -->
            <div class="container">
                <nav class="biolife-nav" style="padding: 10px 0 20px 0;">
                    <ul>
                        <li class="nav-item"><a href="index.php" class="permal-link">Home</a></li>
                        <li class="nav-item"><a href="all_product.php" class="permal-link">All Products</a></li>
                        <li class="nav-item"><span class="current-page"><?php echo htmlspecialchars($ctg_info['ctg_name'], ENT_QUOTES, 'UTF-8'); ?></span></li>
                    </ul>
                </nav>
            </div>

            <!-- Category / Flavour Selector Tabs -->
            <div class="container" style="margin-bottom: 25px;">
                <div style="background: #faf8f5; border: 1px solid #ede8df; border-radius: 16px; padding: 14px 18px;">
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
                        <span style="font-size: 13px; font-weight: 800; color: #1c1917; text-transform: uppercase; letter-spacing: 0.5px;">
                            <i class="fa fa-fire" style="color: #c8102e; margin-right: 4px;"></i> Select Flavour / Category:
                        </span>
                        <span style="font-size: 12px; font-weight: 700; color: #78716c;">
                            Showing <?php echo count($pdt_datas); ?> Products
                        </span>
                    </div>
                    <div class="postic-flavor-pills-row" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center;">
                        <a href="all_product.php" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df; transition: all 0.2s ease;">
                            <span>✨</span> All Flavours
                        </a>
                        <?php foreach ($cataDatas as $c_item) { 
                            $is_active_cat = (isset($cataId) && (int)$cataId === (int)$c_item['ctg_id']);
                        ?>
                            <a href="catagory.php?status=catView&id=<?php echo $c_item['ctg_id']; ?>" style="text-decoration: none; padding: 7px 16px; border-radius: 20px; font-size: 12px; font-weight: 700; display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease; <?php echo $is_active_cat ? 'background: #c8102e; color: #ffffff; border: 1.5px solid #c8102e; box-shadow: 0 2px 8px rgba(200,16,46,0.25); font-weight: 800;' : 'background: #ffffff; color: #1c1917; border: 1.5px solid #ede8df;'; ?>">
                                <span>🏷️</span> <?php echo htmlspecialchars($c_item['ctg_name'], ENT_QUOTES, 'UTF-8'); ?>
                            </a>
                        <?php } ?>
                    </div>
                </div>
            </div>

            <!-- Product -->
            <div class="container">
                <div class="product-category grid-style">
                    <div class="row">
                        <ul class="products-list">
                            <?php
                            if (empty($pdt_datas)) {
                                echo '<li class="col-xs-12 text-center" style="padding: 60px 15px;">
                                        <div style="max-width: 400px; margin: 0 auto; background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 30px;">
                                            <i class="fa fa-folder-open-o" style="font-size: 40px; color: #94a3b8; margin-bottom: 12px; display: block;"></i>
                                            <h4 style="font-weight: 700; color: #1e293b;">No Products Found</h4>
                                            <p style="color: #64748b; font-size: 13px;">No makhana products currently available in this category.</p>
                                            <a href="all_product.php" class="postic-btn-detail" style="margin-top: 15px;">View All Makhana</a>
                                        </div>
                                      </li>';
                            } else {
                                foreach ($pdt_datas as $pdt_data) {
                            ?>
                                <li class="product-item col-lg-3 col-md-3 col-sm-4 col-xs-6">
                                    <div class="contain-product layout-default">
                                        <div class="product-thumb">
                                            <a href="single_product.php?status=singleproduct&id=<?php echo $pdt_data['pdt_id'] ?>" class="link-to-product">
                                                <img src="admin/uploads/<?php echo $pdt_data['pdt_img'] ?>" alt="<?php echo htmlspecialchars($pdt_data['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>" width="270" height="270" class="product-thumnail">
                                            </a>
                                            <?php if (isset($pdt_data['product_stock']) && (int)$pdt_data['product_stock'] <= 0) { ?>
                                                <div class="labels" style="position: absolute; top: 10px; left: 10px;">
                                                    <span class="sale-label" style="background: #ef4444; color: #fff; font-size: 11px; padding: 3px 8px; border-radius: 12px; font-weight: 700;">Sold Out</span>
                                                </div>
                                            <?php } ?>
                                        </div>
                                        <div class="info">
                                            <b class="categories"><?php echo htmlspecialchars($pdt_data['ctg_name'], ENT_QUOTES, 'UTF-8'); ?></b>
                                            <h4 class="product-title"><a href="single_product.php?status=singleproduct&id=<?php echo $pdt_data['pdt_id'] ?>" class="pr-name"><?php echo htmlspecialchars($pdt_data['pdt_name'], ENT_QUOTES, 'UTF-8'); ?></a></h4>
                                            <div class="price" style="display: flex; align-items: center; gap: 8px;">
                                                <ins><span class="price-amount"><span class="currencySymbol">₹ </span><?php echo $pdt_data['pdt_price'] ?></span></ins>
                                                <?php $p_weight = !empty($pdt_data['pdt_weight']) ? $pdt_data['pdt_weight'] : '55g'; ?>
                                                <span style="font-size: 11px; font-weight: 700; color: #d32f2f; background: #fff5f5; border: 1px solid #fee2e2; border-radius: 10px; padding: 1px 8px;"><?php echo htmlspecialchars($p_weight); ?></span>
                                            </div>
                                            <div class="shipping-info" style="font-size: 11px; color: #64748b; margin-bottom: 6px;">
                                                <span><i class="fa fa-check" style="color: #d32f2f;"></i> Fresh Roasted</span> &bull; 
                                                <span>Express Shipping</span>
                                            </div>
                                            <div class="buttons" style="margin-top: auto; width: 100%;">
                                                <form action="addtocart.php" method="POST" class="postic-ajax-cart-form" style="margin: 0; width: 100%;">
                                                    <input type="hidden" name="pdt_id" value="<?php echo $pdt_data['pdt_id']; ?>">
                                                    <input type="hidden" name="pdt_name" value="<?php echo htmlspecialchars($pdt_data['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="pdt_price" value="<?php echo (int)$pdt_data['pdt_price']; ?>">
                                                    <input type="hidden" name="pdt_img" value="<?php echo htmlspecialchars($pdt_data['pdt_img'], ENT_QUOTES, 'UTF-8'); ?>">
                                                    <input type="hidden" name="pdt_weight" value="<?php echo htmlspecialchars($p_weight); ?>">
                                                    <input type="hidden" name="addtocart" value="1">

                                                    <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 6px;">
                                                        <!-- Stepper [- 1 +] -->
                                                        <div class="postic-card-qty-stepper" style="display: inline-flex; align-items: center; border: 1.5px solid #ede8df; border-radius: 8px; background: #ffffff; height: 36px; overflow: hidden; flex-shrink: 0;">
                                                            <button type="button" class="postic-card-qty-btn minus" style="width: 26px; height: 100%; border: none; background: #fdfbf7; font-size: 14px; font-weight: 800; cursor: pointer; color: #1c1917; display: flex; align-items: center; justify-content: center; user-select: none;">&minus;</button>
                                                            <input type="number" name="quantity" class="postic-card-qty-val" value="1" min="1" max="10" readonly style="width: 28px; height: 100%; border: none; text-align: center; font-size: 13px; font-weight: 800; color: #1c1917; background: transparent; padding: 0;">
                                                            <button type="button" class="postic-card-qty-btn plus" style="width: 26px; height: 100%; border: none; background: #fdfbf7; font-size: 14px; font-weight: 800; cursor: pointer; color: #1c1917; display: flex; align-items: center; justify-content: center; user-select: none;">&#43;</button>
                                                        </div>
                                                        <!-- Add Button -->
                                                        <button type="submit" class="btn postic-add-to-cart-btn" style="flex: 1; height: 36px; background: #c8102e; color: #ffffff; font-weight: 800; font-size: 12px; border-radius: 8px; border: none; display: inline-flex; align-items: center; justify-content: center; gap: 4px; box-shadow: 0 3px 10px rgba(200,16,46,0.22); transition: all 0.2s ease; cursor: pointer; padding: 0 8px; white-space: nowrap;">
                                                            <i class="fa fa-shopping-cart"></i> Add
                                                        </button>
                                                    </div>
                                                    <a href="single_product.php?status=singleproduct&id=<?php echo $pdt_data['pdt_id']; ?>" style="display: block; width: 100%; text-align: center; font-size: 11px; font-weight: 700; color: #78716c; text-decoration: none; padding: 3px 0; border: 1px solid #ede8df; border-radius: 6px; background: #fdfbf7; transition: all 0.15s ease;">
                                                        <i class="fa fa-eye"></i> View Details
                                                    </a>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                            <?php 
                                }
                            } 
                            ?>


                        </ul>
                    </div>

                    <?php if (count($pdt_datas) > 12) { ?>
                    <!-- Pagination block -->
                    <div class="biolife-panigations-block">
                        <ul class="panigation-contain">
                            <li><span class="current-page">1</span></li>
                        </ul>
                    </div>
                    <?php } ?>

                </div>





            </div>
        </div>
    </div>

    <!-- FOOTER -->

    <?php
    include_once("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>
