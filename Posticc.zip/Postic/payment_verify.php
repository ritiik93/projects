<?php
session_start();

include_once("admin/class/adminback.php");

$obj = new adminback();
$config = include("config/razorpay.php");

if (empty($_SESSION['user_id'])) {
    $_SESSION['flash_error'] = "Please login before payment.";
    header("location:user_login.php");
    exit();
}

if (empty($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['flash_error'] = "Your cart is empty.";
    header("location:addtocart.php");
    exit();
}

$razorpay_order_id = isset($_POST['razorpay_order_id']) ? trim($_POST['razorpay_order_id']) : '';
$razorpay_payment_id = isset($_POST['razorpay_payment_id']) ? trim($_POST['razorpay_payment_id']) : '';
$razorpay_signature = isset($_POST['razorpay_signature']) ? trim($_POST['razorpay_signature']) : '';

if (empty($config['key_secret']) || $razorpay_order_id == '' || $razorpay_payment_id == '' || $razorpay_signature == '') {
    $_SESSION['flash_error'] = "Payment verification failed. Please try again.";
    header("location:userprofile.php");
    exit();
}

if (empty($_SESSION['razorpay_order_id']) || $_SESSION['razorpay_order_id'] !== $razorpay_order_id) {
    $_SESSION['flash_error'] = "Payment order mismatch. Please try again.";
    header("location:userprofile.php");
    exit();
}

$server_order_id = $_SESSION['razorpay_order_id'];
$expected_signature = hash_hmac('sha256', $server_order_id . '|' . $razorpay_payment_id, $config['key_secret']);
if (!hash_equals($expected_signature, $razorpay_signature)) {
    $_SESSION['flash_error'] = "Payment verification failed. Please contact support if money was deducted.";
    header("location:userprofile.php");
    exit();
}

$_POST['txid'] = $razorpay_payment_id;
$_POST['gateway_order_id'] = $server_order_id;
$_POST['payment_method'] = 'razorpay';
$_POST['payment_status'] = 'paid';
$_POST['order_status'] = 1;
unset($_SESSION['razorpay_order_id']);
unset($_SESSION['razorpay_order_amount']);

$obj->confirm_order($_POST, $_SESSION['cart']);
