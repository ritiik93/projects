<?php
session_start();
include_once("admin/class/adminback.php");
require_once("includes/postic_mailer.php");

$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
if ($cata_info) {
    while ($data = mysqli_fetch_assoc($cata_info)) {
        $cataDatas[] = $data;
    }
}

$logo_info = $obj->display_logo();
$logo = $logo_info ? mysqli_fetch_assoc($logo_info) : null;
$logo_img = $logo ? $logo['img'] : 'logo.png';

// Redirect if already logged in
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
        header('location:userprofile.php');
    } else {
        header('location:exist_order.php');
    }
    exit();
}

$reg_error = '';
$reg_success = '';
$dev_otp_hint = '';

// Handle Change Details / Cancel OTP
if (isset($_GET['action']) && $_GET['action'] === 'change_details') {
    if (isset($_SESSION['postic_reg_pending'])) {
        unset($_SESSION['postic_reg_pending']['otp']);
        unset($_SESSION['postic_reg_pending']['otp_time']);
    }
    header("location:user_register.php");
    exit();
}

// STEP 1: Process Initial Sign Up -> Generate & Send OTP
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_otp_btn'])) {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = strtolower(trim($_POST['user_email'] ?? ''));
    $password = $_POST['user_password'] ?? '';

    if (empty($full_name)) {
        $reg_error = "Please enter your full name.";
    } elseif (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $reg_error = "Please enter a valid email address.";
    } elseif (strlen($password) < 6) {
        $reg_error = "Password must be at least 6 characters.";
    } else {
        // Check if email already registered
        if ($obj->is_user_email_registered($email)) {
            $reg_error = "An account with this email already exists. <a href='user_login.php' style='color: #b91c1c; font-weight: 700; text-decoration: underline;'>Click here to Sign In</a>.";
        } else {
            // Generate 6-digit OTP
            $otp = (string) random_int(100000, 999999);

            $_SESSION['postic_reg_pending'] = array(
                'full_name' => $full_name,
                'email'     => $email,
                'password'  => $password,
                'otp'       => $otp,
                'otp_time'  => time(),
                'attempts'  => 0
            );

            // Send OTP email
            $mail_res = PosticMailer::send_registration_otp($email, $full_name, $otp);

            if ($mail_res['success']) {
                $reg_success = "Verification code sent to <strong>" . htmlspecialchars($email) . "</strong>. Please enter it below to activate your account.";
            } else {
                // If mail server failed (e.g. offline testing on localhost), provide fallback
                $reg_success = "Verification code generated! Please enter it below to activate your account.";
                $dev_otp_hint = $otp; // Available for testing if SMTP is offline
            }
        }
    }
}

// STEP 2: Resend OTP
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resend_otp_btn'])) {
    if (isset($_SESSION['postic_reg_pending']) && !empty($_SESSION['postic_reg_pending']['email'])) {
        $pending = &$_SESSION['postic_reg_pending'];
        
        // Cooldown check: 20 seconds between resends
        if (isset($pending['otp_time']) && (time() - $pending['otp_time']) < 20) {
            $reg_error = "Please wait a few seconds before requesting another code.";
        } else {
            $otp = (string) random_int(100000, 999999);
            $pending['otp'] = $otp;
            $pending['otp_time'] = time();
            $pending['attempts'] = 0;

            $mail_res = PosticMailer::send_registration_otp($pending['email'], $pending['full_name'], $otp);
            if ($mail_res['success']) {
                $reg_success = "A fresh 6-digit verification code has been sent to <strong>" . htmlspecialchars($pending['email']) . "</strong>.";
            } else {
                $reg_success = "A new verification code has been generated.";
                $dev_otp_hint = $otp;
            }
        }
    } else {
        $reg_error = "Session expired. Please fill in your details to get a new code.";
    }
}

// STEP 3: Verify OTP & Create Account
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_otp_btn'])) {
    $entered_otp = trim($_POST['otp'] ?? '');

    if (!isset($_SESSION['postic_reg_pending']) || empty($_SESSION['postic_reg_pending']['otp'])) {
        $reg_error = "Session expired. Please enter your registration details again.";
    } else {
        $pending = &$_SESSION['postic_reg_pending'];

        // Check expiration (15 minutes)
        if ((time() - $pending['otp_time']) > 900) {
            $reg_error = "Verification code has expired. Please click 'Resend Code'.";
        } elseif ($entered_otp !== $pending['otp']) {
            $pending['attempts'] = ($pending['attempts'] ?? 0) + 1;
            if ($pending['attempts'] >= 5) {
                unset($_SESSION['postic_reg_pending']);
                $reg_error = "Too many incorrect attempts. Please start registration again.";
            } else {
                $reg_error = "Invalid verification code. Please check your email and try again.";
            }
        } else {
            // OTP is VALID -> Create user account in database!
            $reg_res = $obj->fast_user_register($pending['full_name'], $pending['email'], $pending['password']);

            if ($reg_res['success']) {
                // Auto-login newly registered customer
                $_SESSION['user_id'] = $reg_res['user_id'];
                $_SESSION['email'] = $reg_res['email'];
                $_SESSION['username'] = $reg_res['user_name'];
                $_SESSION['mobile'] = '';
                $_SESSION['address'] = '';
                $_SESSION['home_address'] = '';
                $_SESSION['office_address'] = '';

                $customer_name = !empty($reg_res['first_name']) ? $reg_res['first_name'] : $reg_res['user_name'];
                $_SESSION['flash_success'] = "Welcome to Postic Foods, " . htmlspecialchars($customer_name) . "! Your account has been verified and created successfully.";

                // Clear pending session
                unset($_SESSION['postic_reg_pending']);

                // Route to cart/checkout or user orders dashboard
                if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
                    header("location:userprofile.php");
                } else {
                    header("location:exist_order.php");
                }
                exit();
            } else {
                $reg_error = $reg_res['message'];
            }
        }
    }
}

// Determine Current Step
$is_otp_step = isset($_SESSION['postic_reg_pending']) && !empty($_SESSION['postic_reg_pending']['otp']);
$pending_email = $is_otp_step ? $_SESSION['postic_reg_pending']['email'] : '';
$pending_name = isset($_SESSION['postic_reg_pending']['full_name']) ? $_SESSION['postic_reg_pending']['full_name'] : ($_POST['full_name'] ?? '');

include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->
    <?php include_once("includes/preloader.php"); ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">
        <?php include_once("includes/header_top.php"); ?>
        <?php include_once("includes/header_middle.php"); ?>
        <?php include_once("includes/header_bottom.php"); ?>
    </header>

    <!-- Centered Clean D2C Auth Card Section (Flipkart Style) -->
    <div class="postic-auth-page">
        <div class="postic-auth-box">
            <div class="postic-auth-card-clean">
                
                <!-- Logo & Brand Header -->
                <div class="postic-auth-top">
                    <a href="index.php">
                        <img src="admin/uploads/<?php echo htmlspecialchars($logo_img); ?>" alt="Postic Foods" class="postic-auth-logo">
                    </a>
                    <span class="postic-auth-brand-tag">100% Roasted Superfoods &bull; Udaipur</span>
                    
                    <!-- Segmented Switcher Tabs -->
                    <div class="postic-tab-nav">
                        <a href="user_login.php" class="postic-tab-link">Sign In</a>
                        <a href="user_register.php" class="postic-tab-link active">Create Account</a>
                    </div>
                </div>

                <!-- Error Notification -->
                <?php if (!empty($reg_error)) { ?>
                    <div class="alert alert-danger alert-dismissible" role="alert" style="border-radius: 10px; background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; font-size: 13px; padding: 12px 14px; margin-bottom: 20px;">
                        <i class="fa fa-exclamation-circle" style="margin-right: 6px;"></i>
                        <?php echo $reg_error; ?>
                        <button type="button" class="close" data-dismiss="alert" style="color: #991b1b;">&times;</button>
                    </div>
                <?php } ?>

                <!-- Success / Info Notification -->
                <?php if (!empty($reg_success)) { ?>
                    <div class="alert alert-success alert-dismissible" role="alert" style="border-radius: 10px; background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; font-size: 13px; padding: 12px 14px; margin-bottom: 20px;">
                        <i class="fa fa-envelope-o" style="margin-right: 6px;"></i>
                        <?php echo $reg_success; ?>
                        <button type="button" class="close" data-dismiss="alert" style="color: #065f46;">&times;</button>
                    </div>
                <?php } ?>

                <!-- Development Offline Fallback Notice (if SMTP is unreachable on localhost) -->
                <?php if (!empty($dev_otp_hint)) { ?>
                    <div style="background: #fffbeb; border: 1px dashed #f59e0b; border-radius: 8px; padding: 10px 14px; margin-bottom: 18px; font-size: 12px; color: #92400e;">
                        <i class="fa fa-info-circle"></i> <strong>Testing Note:</strong> Your verification OTP is: <span style="font-weight: 800; font-size: 15px; letter-spacing: 2px; color: #b45309;"><?php echo htmlspecialchars($dev_otp_hint); ?></span>
                    </div>
                <?php } ?>

                <?php if ($is_otp_step) { ?>
                    <!-- ============================================================== -->
                    <!-- STEP 2: EMAIL OTP VERIFICATION FORM (FLIPKART STYLE)          -->
                    <!-- ============================================================== -->
                    <div style="text-align: center; margin-bottom: 22px;">
                        <div style="width: 54px; height: 54px; border-radius: 50%; background: #fef2f2; color: #d32f2f; display: inline-flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 10px; border: 1px solid #fecaca;">
                            <i class="fa fa-shield"></i>
                        </div>
                        <h3 style="font-size: 19px; font-weight: 800; color: #0f172a; margin: 0 0 6px 0;">Verify Your Email</h3>
                        <p style="font-size: 13px; color: #64748b; margin: 0;">
                            Enter the 6-digit code sent to<br>
                            <strong style="color: #0f172a;"><?php echo htmlspecialchars($pending_email); ?></strong>
                        </p>
                        <a href="user_register.php?action=change_details" style="display: inline-block; margin-top: 6px; font-size: 12px; font-weight: 700; color: #d32f2f; text-decoration: none;">
                            <i class="fa fa-pencil"></i> Change Email
                        </a>
                    </div>

                    <form action="" method="POST" autocomplete="off">
                        <div class="postic-form-group" style="text-align: center;">
                            <label class="postic-form-label" for="reg_otp" style="text-align: center; font-weight: 700; color: #334155;">
                                Enter 6-Digit OTP <span class="req">*</span>
                            </label>
                            <input 
                                type="text" 
                                id="reg_otp" 
                                name="otp" 
                                class="postic-form-input text-center" 
                                placeholder="&bull; &bull; &bull; &bull; &bull; &bull;" 
                                maxlength="6" 
                                pattern="[0-9]{6}" 
                                required 
                                autofocus 
                                style="font-size: 28px; letter-spacing: 12px; font-weight: 800; font-family: monospace; height: 54px; border: 2px solid #cbd5e1; border-radius: 12px;"
                            >
                            <span style="display: block; font-size: 11px; color: #94a3b8; margin-top: 6px;">
                                <i class="fa fa-clock-o"></i> Code expires in 10 minutes
                            </span>
                        </div>

                        <!-- Verify Button -->
                        <button type="submit" name="verify_otp_btn" class="postic-submit-btn" style="height: 48px; font-size: 15px; font-weight: 700; border-radius: 10px;">
                            Verify &amp; Create Account &rarr;
                        </button>
                    </form>

                    <!-- Resend OTP Action -->
                    <div style="text-align: center; margin-top: 18px; border-top: 1px solid #f1f5f9; padding-top: 16px;">
                        <form action="" method="POST" style="display: inline;">
                            <span style="font-size: 13px; color: #64748b;">Didn't receive the email? </span>
                            <button type="submit" name="resend_otp_btn" id="resendBtn" class="btn btn-link" style="padding: 0; font-size: 13px; font-weight: 700; color: #d32f2f; text-decoration: none;">
                                Resend Code
                            </button>
                            <span id="countdownText" style="display: none; font-size: 12px; color: #94a3b8; margin-left: 4px;"></span>
                        </form>
                    </div>

                    <!-- Resend Countdown Script -->
                    <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        var resendBtn = document.getElementById("resendBtn");
                        var countdownText = document.getElementById("countdownText");
                        var timer = 30;

                        if (resendBtn && countdownText) {
                            resendBtn.style.pointerEvents = "none";
                            resendBtn.style.opacity = "0.5";
                            countdownText.style.display = "inline";
                            countdownText.innerText = "(" + timer + "s)";

                            var interval = setInterval(function() {
                                timer--;
                                if (timer <= 0) {
                                    clearInterval(interval);
                                    resendBtn.style.pointerEvents = "auto";
                                    resendBtn.style.opacity = "1";
                                    countdownText.style.display = "none";
                                } else {
                                    countdownText.innerText = "(" + timer + "s)";
                                }
                            }, 1000);
                        }
                    });
                    </script>

                <?php } else { ?>
                    <!-- ============================================================== -->
                    <!-- STEP 1: FAST 3-FIELD REGISTRATION (FLIPKART STYLE)            -->
                    <!-- ============================================================== -->
                    <div style="margin-bottom: 20px; text-align: center;">
                        <h3 style="font-size: 18px; font-weight: 800; color: #0f172a; margin: 0 0 4px 0;">Create Your Free Account</h3>
                        <p style="font-size: 13px; color: #64748b; margin: 0;">
                            Quick signup with email OTP verification. Delivery address &amp; location can be added later when ordering!
                        </p>
                    </div>

                    <form action="" name="frm-fast-register" method="POST" autocomplete="on">
                        
                        <!-- Field 1: Full Name -->
                        <div class="postic-form-group">
                            <label class="postic-form-label" for="full_name">
                                Full Name <span class="req">*</span>
                            </label>
                            <input 
                                type="text" 
                                id="full_name" 
                                name="full_name" 
                                class="postic-form-input" 
                                placeholder="e.g. Rahul Sharma" 
                                value="<?php echo htmlspecialchars($pending_name, ENT_QUOTES, 'UTF-8'); ?>" 
                                required 
                                autofocus
                            >
                        </div>

                        <!-- Field 2: Email Address -->
                        <div class="postic-form-group">
                            <label class="postic-form-label" for="user_email">
                                Email Address <span class="req">*</span>
                            </label>
                            <input 
                                type="email" 
                                id="user_email" 
                                name="user_email" 
                                class="postic-form-input" 
                                placeholder="name@gmail.com" 
                                value="<?php echo htmlspecialchars($_POST['user_email'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" 
                                required
                            >
                            <span style="font-size: 11px; color: #64748b; margin-top: 4px; display: block;">
                                <i class="fa fa-envelope-o" style="color: #d32f2f;"></i> We will send a 6-digit OTP code to verify this email.
                            </span>
                        </div>

                        <!-- Field 3: Create Password -->
                        <div class="postic-form-group">
                            <label class="postic-form-label" for="reg_password">
                                Create Password <span class="req">*</span>
                            </label>
                            <div class="postic-pwd-wrap">
                                <input 
                                    type="password" 
                                    id="reg_password" 
                                    name="user_password" 
                                    class="postic-form-input" 
                                    placeholder="At least 6 characters" 
                                    minlength="6" 
                                    required 
                                    style="padding-right: 42px !important;"
                                >
                                <button type="button" class="postic-eye-btn" id="toggleRegPwd" tabindex="-1" title="Show / Hide Password">
                                    <i class="fa fa-eye" id="toggleRegIcon"></i>
                                </button>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" name="send_otp_btn" class="postic-submit-btn" style="height: 48px; font-size: 15px; font-weight: 700; border-radius: 10px; margin-top: 6px;">
                            Continue &amp; Send OTP &rarr;
                        </button>
                    </form>

                    <!-- Eye Toggle Script -->
                    <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        var btn = document.getElementById("toggleRegPwd");
                        var input = document.getElementById("reg_password");
                        var icon = document.getElementById("toggleRegIcon");
                        if (btn && input && icon) {
                            btn.addEventListener("click", function() {
                                if (input.type === "password") {
                                    input.type = "text";
                                    icon.className = "fa fa-eye-slash";
                                } else {
                                    input.type = "password";
                                    icon.className = "fa fa-eye";
                                }
                            });
                        }
                    });
                    </script>
                <?php } ?>

                <!-- Already have account prompt -->
                <div style="text-align: center; margin-top: 20px; font-size: 13px; color: #64748b;">
                    Already have a Postic account? 
                    <a href="user_login.php" style="color: #d32f2f; font-weight: 700; text-decoration: none;">Sign In</a>
                </div>

                <!-- Footer Trust Strip -->
                <div class="postic-auth-footer-trust" style="margin-top: 24px; padding-top: 18px; border-top: 1px solid #f1f5f9;">
                    <span><i class="fa fa-shield"></i> Email OTP Verified</span>
                    <span><i class="fa fa-leaf"></i> 100% Roasted</span>
                    <span><i class="fa fa-map-marker"></i> Udaipur Roastery</span>
                </div>

            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <?php
    include_once("includes/footer.php");
    include_once("includes/mobile_footer.php");
    include_once("includes/mobile_global.php");
    ?>
</body>
</html>
