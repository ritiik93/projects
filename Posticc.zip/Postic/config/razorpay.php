<?php

return array(
    'enabled' => false,
    'key_id' => '',
    'key_secret' => '',
    'currency' => 'INR',
    'store_name' => 'Postic',
);

