<?php
date_default_timezone_set("Asia/Kolkata");
// Database Configuration
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'oktgaunq_postic1');
if (!defined('DB_PASS')) define('DB_PASS', 'h2hpCARGgxnbQwP9VXRk');
if (!defined('DB_NAME')) define('DB_NAME', 'oktgaunq_postic');

if (!function_exists('get_db_connection')) {
    function get_db_connection()
    {
        static $connection = null;
        if ($connection !== null) {
            return $connection;
        }

        if (function_exists('mysqli_report')) {
            @mysqli_report(MYSQLI_REPORT_OFF);
        }

        // 1. Primary: Live hosting credentials
        $connection = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

        // 2. Fallback: Localhost / XAMPP (if testing locally)
        if (!$connection) {
            $connection = @mysqli_connect('localhost', 'root', '', DB_NAME);
            if (!$connection) {
                $connection = @mysqli_connect('localhost', 'root', '', 'postic');
            }
        }

        if (!$connection) {
            die("Database connection error: " . mysqli_connect_error());
        }

        @mysqli_set_charset($connection, "utf8mb4");
        @mysqli_query($connection, "SET time_zone = '+05:30'");
        return $connection;
    }
}

// Auto-sync root favicon.ico if missing
$root_path = dirname(__DIR__);
if (!file_exists($root_path . '/favicon.ico') && file_exists($root_path . '/favicon/favicon.ico')) {
    @copy($root_path . '/favicon/favicon.ico', $root_path . '/favicon.ico');
}
if (!file_exists($root_path . '/apple-touch-icon.png') && file_exists($root_path . '/favicon/apple-touch-icon.png')) {
    @copy($root_path . '/favicon/apple-touch-icon.png', $root_path . '/apple-touch-icon.png');
}
