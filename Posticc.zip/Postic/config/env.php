<?php
/**
 * Lightweight Environment & Configuration Loader
 * Handles loading from .env file, $_ENV, $_SERVER, or getenv()
 */

if (!function_exists('env_get')) {
    function env_get($key, $default = null)
    {
        static $env_loaded = false;
        static $env_cache = array();

        if (!$env_loaded) {
            $env_file = dirname(__DIR__) . '/.env';
            if (file_exists($env_file) && is_readable($env_file)) {
                $lines = file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                if ($lines !== false) {
                    foreach ($lines as $line) {
                        $line = trim($line);
                        // Skip comments
                        if ($line === '' || strpos($line, '#') === 0 || strpos($line, ';') === 0) {
                            continue;
                        }
                        if (strpos($line, '=') !== false) {
                            list($k, $v) = explode('=', $line, 2);
                            $k = trim($k);
                            $v = trim($v);
                            // Strip enclosing quotes if present
                            if ((strpos($v, '"') === 0 && strrpos($v, '"') === strlen($v) - 1) ||
                                (strpos($v, "'") === 0 && strrpos($v, "'") === strlen($v) - 1)) {
                                $v = substr($v, 1, -1);
                            }
                            $env_cache[$k] = $v;
                        }
                    }
                }
            }
            $env_loaded = true;
        }

        // 1. Check cached .env values
        if (array_key_exists($key, $env_cache)) {
            return $env_cache[$key];
        }

        // 2. Check getenv()
        $val = getenv($key);
        if ($val !== false && $val !== '') {
            return $val;
        }

        // 3. Check $_ENV
        if (isset($_ENV[$key]) && $_ENV[$key] !== '') {
            return $_ENV[$key];
        }

        // 4. Check $_SERVER
        if (isset($_SERVER[$key]) && $_SERVER[$key] !== '') {
            return $_SERVER[$key];
        }

        // 5. Fallback to default
        return $default;
    }
}
