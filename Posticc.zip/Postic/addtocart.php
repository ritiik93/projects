<?php
session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$cata_info = $obj->p_display_catagory();
$cataDatas = array();
while ($data = mysqli_fetch_assoc($cata_info)) {
    $cataDatas[] = $data;
}

$subtotal = 0;
$total_product = 0;

if (isset($_POST['addtocart']) || isset($_POST['buynow'])) {
    $product_id = isset($_POST['pdt_id']) ? (int) $_POST['pdt_id'] : 0;
    $product_weight = isset($_POST['pdt_weight']) && !empty($_POST['pdt_weight']) ? trim($_POST['pdt_weight']) : '55g';
    $input_quantity = isset($_POST['quantity']) ? max(1, min(10, (int) $_POST['quantity'])) : 1;
    $pdt_price = isset($_POST['pdt_price']) ? (int) $_POST['pdt_price'] : 0;

    if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
        $found = false;
        foreach ($_SESSION['cart'] as $key => $value) {
            $existing_weight = isset($value['pdt_weight']) ? $value['pdt_weight'] : '55g';
            if ((int) $value['pdt_id'] === $product_id && $existing_weight === $product_weight) {
                $current_quantity = isset($_SESSION['cart'][$key]['quantity']) ? (int) $_SESSION['cart'][$key]['quantity'] : 1;
                $_SESSION['cart'][$key]['quantity'] = min(10, $current_quantity + $input_quantity);
                $found = true;
                break;
            }
        }
        if (!$found) {
            $_SESSION['cart'][] = array(
                'pdt_name' => $_POST['pdt_name'],
                'pdt_weight' => $product_weight,
                'pdt_price' => $pdt_price,
                'pdt_img' => $_POST['pdt_img'],
                'pdt_id' => $product_id,
                'quantity' => $input_quantity
            );
        }
    } else {
        $_SESSION['cart'] = array(
            array(
                'pdt_name' => $_POST['pdt_name'],
                'pdt_weight' => $product_weight,
                'pdt_price' => $pdt_price,
                'pdt_img' => $_POST['pdt_img'],
                'pdt_id' => $product_id,
                'quantity' => $input_quantity
            )
        );
    }

    $_SESSION['cart_flash'] = "Added " . htmlspecialchars($_POST['pdt_name']) . " (" . htmlspecialchars($product_weight) . ") to your cart!";

    // Handle AJAX request: return JSON immediately without redirecting
    if (!empty($_POST['ajax']) || (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')) {
        $cart_count = 0;
        $cart_total = 0;
        if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                $qty = isset($item['quantity']) ? (int)$item['quantity'] : 1;
                $cart_count += $qty;
                $cart_total += ((int)$item['pdt_price']) * $qty;
            }
        }
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'success',
            'message' => 'Added ' . htmlspecialchars($_POST['pdt_name']) . ' to cart!',
            'cart_count' => $cart_count,
            'cart_total' => $cart_total,
            'pdt_name' => $_POST['pdt_name'],
            'pdt_weight' => $product_weight
        ]);
        exit();
    }

    if (isset($_POST['buynow'])) {
        header("Location: userprofile.php");
        exit();
    }
}

if (isset($_POST['update_cart_qty']) && isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    $cart_idx = isset($_POST['cart_index']) ? (int)$_POST['cart_index'] : -1;
    $new_qty = max(1, min(10, (int)$_POST['update_qty']));
    if ($cart_idx >= 0 && isset($_SESSION['cart'][$cart_idx])) {
        $_SESSION['cart'][$cart_idx]['quantity'] = $new_qty;
        $_SESSION['cart_flash'] = "Updated quantity for " . htmlspecialchars($_SESSION['cart'][$cart_idx]['pdt_name']) . " to " . $new_qty . ".";
    }
}

if (isset($_POST['remove_product']) && isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    $remove_idx = isset($_POST['remove_cart_index']) ? (int)$_POST['remove_cart_index'] : -1;
    if ($remove_idx >= 0 && isset($_SESSION['cart'][$remove_idx])) {
        unset($_SESSION['cart'][$remove_idx]);
        $_SESSION['cart'] = array_values($_SESSION['cart']);
        $_SESSION['cart_flash'] = "Removed item from your cart.";
    } else {
        foreach ($_SESSION['cart'] as $key => $value) {
            if ($value['pdt_name'] == $_POST['remove_pdt_name']) {
                unset($_SESSION['cart'][$key]);
                $_SESSION['cart'] = array_values($_SESSION['cart']);
                $_SESSION['cart_flash'] = "Removed item from your cart.";
                break;
            }
        }
    }
}
?>


<?php
include_once("includes/head.php");
?>

<body class="biolife-body">
    <!-- Preloader -->

    <?php
    include_once("includes/preloader.php");
    ?>

    <!-- HEADER -->
    <header id="header" class="header-area style-01 layout-03">

        <?php
        include_once("includes/header_top.php");
        ?>

        <?php
        include_once("includes/header_middle.php");
        ?>

        <?php
        include_once("includes/header_bottom.php");
        ?>

    </header>

    <!-- Page Contain -->
    <div class="page-contain">

        <!-- Main content -->
        <div id="main-content" class="main-content">

            <br>
            <!-- Product -->
            <div class="container ">

                <!--Cart Table-->
                <div class="shopping-cart-container">
                    <div class="row">
                        <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                            <h3 class="box-title">Your cart items</h3>
                            <?php if (isset($_SESSION['cart_flash'])) { ?>
                                <div class="alert alert-success" style="background:#fef2f2; border:1px solid #fecaca; color:#b91c1c; border-radius:8px; padding:12px 18px; margin-bottom:20px; font-weight:600;">
                                    <i class="fa fa-check-circle" style="margin-right:6px; color: #d32f2f;"></i> <?php echo $_SESSION['cart_flash']; unset($_SESSION['cart_flash']); ?>
                                </div>
                            <?php } ?>
                            <div class="shopping-cart-form">
                                <table class="shop_table cart-form">
                                    <thead>
                                        <tr>
                                            <th class="product-name">Product Name</th>
                                            <th class="product-price">Price (₹)</th>
                                            <th class="product-price">Quantity</th>
                                            <th class="product-price">Total (₹)</th>
                                            <th class="product-quantity">Remove</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php if(isset($_SESSION['cart']) && !empty($_SESSION['cart'])){
                                        foreach($_SESSION['cart'] as $key=> $value){ 
                                            $quantity = isset($value['quantity']) ? (int) $value['quantity'] : 1;
                                            if ($quantity < 1) {
                                                $quantity = 1;
                                            }
                                            $line_total = $value['pdt_price'] * $quantity;
                                            $subtotal = $subtotal + $line_total;
                                            $total_product = $total_product + $quantity;
                                        ?>
                                        <tr class="cart_item">
                                            <td class="product-thumbnail" data-title="Product Name">
                                                <a class="prd-thumb" href="single_product.php?status=singleproduct&&id=<?php echo $value['pdt_id'] ?>">
                                                    <figure><img width="113" height="113" src="admin/uploads/<?php echo $value['pdt_img'] ?>" alt="<?php echo htmlspecialchars($value['pdt_name'], ENT_QUOTES, 'UTF-8'); ?>" style="border-radius: 8px; object-fit: cover;"></figure>
                                                </a>
                                                <a class="prd-name" href="single_product.php?status=singleproduct&&id=<?php echo $value['pdt_id'] ?>" style="font-weight: 700; color: #1e293b;"><?php echo htmlspecialchars($value['pdt_name']); ?></a>
                                                <div style="margin-top: 6px;">
                                                    <span style="background: #fef2f2; color: #d32f2f; border: 1px solid #fecaca; font-size: 11px; padding: 2px 8px; border-radius: 12px; display: inline-flex; align-items: center; gap: 4px; font-weight: 700;">
                                                        <i class="fa fa-cubes"></i> <?php echo htmlspecialchars($value['pdt_weight'] ?? '55g'); ?>
                                                    </span>
                                                </div>
                                            </td>
                                            <td class="product-price" data-title="Price">
                                                <div class="price price-contain">
                                                    <ins><span class="price-amount"><span class="currencySymbol">₹ </span><?php echo $value['pdt_price'] ?></span></ins>
                                                </div>
                                            </td>
                                            <td class="product-price" data-title="Quantity">
                                                <form action="" method="POST" style="display:inline-flex; align-items:center; gap:5px; margin:0;">
                                                    <input type="hidden" name="cart_index" value="<?php echo $key; ?>">
                                                    <input type="hidden" name="update_cart_qty" value="1">
                                                    <button type="submit" onclick="this.form.update_qty.value=Math.max(1, <?php echo $quantity - 1; ?>)" title="Decrease" style="width:28px; height:28px; border:1px solid #cbd5e1; background:#f8fafc; border-radius:4px; font-weight:700; cursor:pointer; color:#334155; line-height:1;">-</button>
                                                    <input type="number" name="update_qty" value="<?php echo $quantity; ?>" min="1" max="10" onchange="this.form.submit()" style="width:42px; text-align:center; height:28px; border:1px solid #cbd5e1; border-radius:4px; font-weight:700; color:#0f172a;">
                                                    <button type="submit" onclick="this.form.update_qty.value=Math.min(10, <?php echo $quantity + 1; ?>)" title="Increase" style="width:28px; height:28px; border:1px solid #cbd5e1; background:#f8fafc; border-radius:4px; font-weight:700; cursor:pointer; color:#334155; line-height:1;">+</button>
                                                </form>
                                            </td>
                                            <td class="product-price" data-title="Total">
                                                <div class="price price-contain">
                                                    <ins><span class="price-amount" style="font-weight: 800; color: #d32f2f;">₹ <?php echo $line_total; ?></span></ins>
                                                </div>
                                            </td>
                                            <td class="product-quantity" data-title="Remove">
                                                <form action="" method="POST">
                                                    <input type="hidden" value="<?php echo $key; ?>" name="remove_cart_index">
                                                    <input type="hidden" value="<?php echo htmlspecialchars($value['pdt_name']); ?>" name="remove_pdt_name">
                                                    <input class="btn" type="submit" value="Remove" name="remove_product" style="font-size: 12px; padding: 6px 12px; border-radius: 6px; background: #fee2e2; border: 1px solid #fecaca; color: #dc2626; font-weight: 600;">
                                                </form>
                                            </td>
                                        </tr>

                                        <?php }}else{ ?>
                                            <tr>
                                                <td colspan="5" style="text-align: center; padding: 45px 20px;">
                                                    <div style="max-width: 350px; margin: 0 auto;">
                                                        <i class="biolife-icon icon-cart" style="font-size: 50px; color: #94a3b8; display: block; margin-bottom: 12px;"></i>
                                                        <h4 style="font-weight: 700; color: #1e293b; margin-bottom: 6px;">Your Cart is Empty</h4>
                                                        <p style="color: #64748b; font-size: 13px; margin-bottom: 18px;">Looks like you haven't added any crunchy roasted makhana yet.</p>
                                                        <a href="all_product.php" class="btn btn-submit" style="background: #d32f2f; color: #fff; padding: 10px 24px; border-radius: 25px; font-weight: 700; text-decoration: none; display: inline-block;">
                                                            Explore Makhana Flavors &rarr;
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php } ?>

                                     
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
                            <div class="shpcart-subtotal-block">
                                <div class="subtotal-line ">
                                    <b class="stt-name">Subtotal <span class="sub">(<?php echo  $total_product . ' Items' ?>)</span></b>
                                    <span class="stt-price">₹ <?php echo $subtotal; ?></span>
                                </div>
                                <!-- <div class="subtotal-line">
                                    <b class="stt-name">Shipping</b>
                                    <span class="stt-price">₹ 0.00</span>
                                </div>
                                <div class="tax-fee">
                                    <p class="title">Est. Taxes & Fees</p>
                                    <p class="desc">Based on 56789</p>
                                </div> -->
                                <div class="btn-checkout">
                                    <?php if (!empty($_SESSION['cart'])) { ?>
                                        <a href="userprofile.php" class="btn checkout">Check out</a>
                                    <?php } else { ?>
                                        <a href="all_product.php" class="btn checkout">Continue Shopping</a>
                                    <?php } ?>
                                </div>
                              
                                <p class="pickup-info"><b>Free Pickup</b> is available as soon as today More about shipping and pickup</p>
                            </div>
                        </div>
                    </div>
                </div>





            </div>

            <br>
        </div>
    </div>

    <!-- FOOTER -->

    <?php
    include_once("includes/footer.php");
    ?>

    <!--Footer For Mobile-->
    <?php
    include_once("includes/mobile_footer.php");
    ?>

    <?php
    include_once("includes/mobile_global.php")
    ?>


    <!-- Scroll Top Button -->
    <a class="btn-scroll-top"><i class="biolife-icon icon-left-arrow"></i></a>

    <?php
    include_once("includes/script.php")
    ?>
</body>

</html>
