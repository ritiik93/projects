<?php 
    include("class/adminback.php");
    $obj= new adminback();

    if(isset($_POST['admin_btn'])){
        $obj->admin_login($_POST);
    }
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if(isset($_SESSION['admin_id'])){
        header("location:dashboard.php");
        exit();
    }

    if (isset($_POST['admin_recover'])) {
        $recover_email = $_POST['recover_email'];
        $rec_row = $obj->admin_password_recover($recover_email);
    
        $num_row = mysqli_num_rows($rec_row);
        $rec_msg = "";
    
        if ($num_row > 0) {
            $rec_result = mysqli_fetch_assoc($rec_row);
            $rec_id = $rec_result['admin_id'];
           
            $rec_email = $rec_result['admin_email'];
            $rec_pass = $rec_result['admin_pass'];
    
            $to_email = $rec_email;
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
            $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
            $reset_link = "{$protocol}://{$host}/demopostic/admin/admin_password_update.php?status=update&&id={$rec_id}";

            require_once(__DIR__ . "/../includes/postic_mailer.php");
            if (PosticMailer::send_password_reset_email($to_email, "Admin", $reset_link)) {
                $rec_msg = "Password reset instructions successfully sent to $to_email via Postic Mailer.";
            } else {
                $subject = "Password Recovery from Postic Admin";
                $body = "Dear Admin," . PHP_EOL . "Please visit this link to reset your Postic admin password: {$reset_link}" . PHP_EOL . "Thank you," . PHP_EOL . "Postic Foods (Udaipur)";
                $headers = "From: care@postic.in";
                if (@mail($to_email, $subject, $body, $headers)) {
                    $rec_msg = "Email successfully sent to $to_email.";
                } else {
                    $rec_msg = "Failed to send email. Please check your SMTP settings in Admin Panel > Email Settings.";
                }
            }
    
    
        } else {
            $rec_msg = "Sorry !!! you have no account";
        }
    }
?>

<?php 
    include ("includes/head.php")
?>

  <body>

  <section class="login p-fixed d-flex text-center bg-primary common-img-bg">
        <!-- Container-fluid starts -->
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <!-- Authentication card start -->
                    <div class="login-card card-block auth-body mr-auto ml-auto">
                        <form action="" method="post" class="md-float-material">
                            <div class="text-center">
                              
                            </div>
                            <div class="auth-box">
                                <div class="row m-b-20">
                                    <div class="col-md-12">
                                        <h3 class="text-left txt-primary">Recover Password</h3>

                                        <p style="color: Black;">
                                            <?php 
                                                if(isset($rec_msg)){
                                                    echo $rec_msg;
                                                }
                                            ?>
                                        </p>
                                    </div>
                                </div>
                                <hr/> <br>
                                <div class="input-group">
                                    <input type="email" class="form-control" placeholder="Your Email Address" name="recover_email" required>
                                    <span class="md-line"></span>
                                </div>

                               
                                
                                <div class="row m-t-30">
                                    <div class="col-md-12">
                                        <input type="submit" name="admin_recover" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20" value="Recover Passsowrd">
                                    </div>
                                </div>

                                <div class="row m-t-10">
                                    <div class="col-md-12">
                                        <a href="index.php" class="btn btn-success btn-md waves-effect text-center m-b-20">Go to Sign In</a>
                                       
                                    </div>
                                </div>
                                <hr/>
                     

                            </div>
                        </form>
                        <!-- end of form -->
                    </div>
                    <!-- Authentication card end -->
                </div>
                <!-- end of col-sm-12 -->
            </div>
            <!-- end of row -->
        </div>
        <!-- end of container-fluid -->
    </section>
	

  

<?php 
    include ("includes/script.php")
?>

