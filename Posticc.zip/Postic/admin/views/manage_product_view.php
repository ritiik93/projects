

<?php 
    $obj = new adminback();
    $search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
    $status_filter = isset($_GET['status_filter']) ? (string) $_GET['status_filter'] : 'all';
    $category_filter = isset($_GET['category_filter']) ? (string) $_GET['category_filter'] : 'all';
    $stock_filter = isset($_GET['stock_filter']) ? (string) $_GET['stock_filter'] : 'all';
    $redirect_params = array();

    if ($search_query !== '') {
        $redirect_params['q'] = $search_query;
    }
    if ($status_filter !== 'all') {
        $redirect_params['status_filter'] = $status_filter;
    }
    if ($category_filter !== 'all') {
        $redirect_params['category_filter'] = $category_filter;
    }
    if ($stock_filter !== 'all') {
        $redirect_params['stock_filter'] = $stock_filter;
    }

    $redirect_url = 'manage_product.php';
    if (!empty($redirect_params)) {
        $redirect_url .= '?' . http_build_query($redirect_params);
    }

    if (isset($_GET['prostatus'], $_GET['id'])) {
        $id = (int) $_GET['id'];

        if ($_GET['prostatus'] == 'published') {
            $action_msg = $obj->published_product($id);
            admin_redirect_with_flash($redirect_url, $action_msg);
        } elseif ($_GET['prostatus'] == 'unpublished') {
            $action_msg = $obj->unpublished_product($id);
            admin_redirect_with_flash($redirect_url, $action_msg);
        } elseif ($_GET['prostatus'] == "delete") {
            $action_msg = $obj->delete_product($id);
            admin_redirect_with_flash($redirect_url, $action_msg, 'info');
        }
    }

    $product_info = $obj->display_product();
    $category_info = $obj->display_catagory();
    $products = array();

    while ($product = mysqli_fetch_assoc($product_info)) {
        if ($search_query !== '' && stripos($product['pdt_name'], $search_query) === false && stripos($product['ctg_name'], $search_query) === false) {
            continue;
        }

        if ($status_filter !== 'all' && (string) $product['pdt_status'] !== $status_filter) {
            continue;
        }

        if ($category_filter !== 'all' && (string) $product['ctg_id'] !== $category_filter) {
            continue;
        }

        if ($stock_filter === 'low' && (int) $product['product_stock'] > 5) {
            continue;
        }

        if ($stock_filter === 'out' && (int) $product['product_stock'] > 0) {
            continue;
        }

        $products[] = $product;
    }
?>
<h2>Manage Product </h2> 
<br>
<form action="" method="get" class="admin-form-card" style="margin-bottom: 18px;">
    <div class="row">
        <div class="col-md-4">
            <label for="q">Search Product</label>
            <input type="text" name="q" id="q" class="form-control" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search by product or category">
        </div>
        <div class="col-md-3">
            <label for="status_filter">Status</label>
            <select name="status_filter" id="status_filter" class="form-control">
                <option value="all">All Statuses</option>
                <option value="1" <?php if ($status_filter === '1') { echo 'selected'; } ?>>Published</option>
                <option value="0" <?php if ($status_filter === '0') { echo 'selected'; } ?>>Unpublished</option>
            </select>
        </div>
        <div class="col-md-3">
            <label for="category_filter">Category</label>
            <select name="category_filter" id="category_filter" class="form-control">
                <option value="all">All Categories</option>
                <?php while ($category = mysqli_fetch_assoc($category_info)) { ?>
                    <option value="<?php echo $category['ctg_id']; ?>" <?php if ($category_filter === (string) $category['ctg_id']) { echo 'selected'; } ?>>
                        <?php echo $category['ctg_name']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <div class="col-md-2">
            <label for="stock_filter">Stock</label>
            <select name="stock_filter" id="stock_filter" class="form-control">
                <option value="all">All Stock</option>
                <option value="low" <?php if ($stock_filter === 'low') { echo 'selected'; } ?>>Low Stock</option>
                <option value="out" <?php if ($stock_filter === 'out') { echo 'selected'; } ?>>Out of Stock</option>
            </select>
        </div>
        <div class="col-md-12" style="margin-top: 12px;">
            <label>&nbsp;</label>
            <div>
                <button type="submit" class="btn btn-primary">Apply</button>
                <a href="manage_product.php" class="btn btn-light">Reset</a>
            </div>
        </div>
    </div>
</form>
<p><strong><?php echo count($products); ?></strong> product(s) found.</p>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Product Name</th>
            <th>Product Price (₹)</th>
            <th>Weight / Pack</th>
            <th>Stock</th>
            <th>Product Image</th>
            <th>Product Status</th>
            <th>Product Category</th>
            <th>Action</th>
        </tr>
    </thead>

    <tbody>
    <?php if (empty($products)) { ?>
        <tr>
            <td colspan="8" class="text-center">No products matched your filters.</td>
        </tr>
    <?php } ?>
    <?php foreach ($products as $pdt) {?>
        <tr>
            <td> <?php echo $pdt['pdt_name'] ?></td>
            <td>₹ <?php echo $pdt['pdt_price'] ?></td>
            <td><span class="badge badge-info" style="background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd; font-weight:700; font-size:12px; padding:3px 8px; border-radius:6px;"><?php echo htmlspecialchars($pdt['pdt_weight'] ?? '55g'); ?></span></td>
            <td>
                <?php echo $pdt['product_stock']; ?>
                <?php if ((int) $pdt['product_stock'] <= 5) { ?>
                    <span class="badge badge-warning">Low Stock</span>
                <?php } ?>
            </td>
            <td>
                <img style="height:60px" src="uploads/<?php echo $pdt['pdt_img'] ?>" alt="">
                <?php $gallery_info = $obj->display_product_images($pdt['pdt_id']); ?>
                <?php if ($gallery_info && mysqli_num_rows($gallery_info) > 0) { ?>
                    <div style="margin-top:8px;">
                        <?php while ($gallery = mysqli_fetch_assoc($gallery_info)) { ?>
                            <img style="height:35px; margin-right:4px; margin-bottom:4px;" src="uploads/<?php echo $gallery['img_name'] ?>" alt="">
                        <?php } ?>
                    </div>
                <?php } ?>
            </td>
            <td> 
                <?php 
                    if($pdt['pdt_status']==0){
                        echo "Unpublished";
                        
                        ?>
                        <a href="?<?php echo http_build_query(array_merge($redirect_params, array('prostatus' => 'published', 'id' => $pdt['pdt_id']))); ?>"  class="btn btn-sm btn-primary" >Publish</a>
                    <?php
                    }else{
                        echo "Published";
                       
                         ?>
                            <a href="?<?php echo http_build_query(array_merge($redirect_params, array('prostatus' => 'unpublished', 'id' => $pdt['pdt_id']))); ?>" class="btn btn-sm btn-warning">Unpublish</a>
                         <?php
                    }
                ?>
            </td>
            <td> <?php echo $pdt['ctg_name'] ?></td>
            <td>
                <a href="edit_product.php?prostatus=edit&&id=<?php echo $pdt['pdt_id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="?<?php echo http_build_query(array_merge($redirect_params, array('prostatus' => 'delete', 'id' => $pdt['pdt_id']))); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this product?');">Delete</a>
            </td>

        </tr>
        <?php }?>

        
    </tbody>
</table>


<script>




</script>
