<div class="row">
    <div class="col-12" style="margin-bottom: 20px;">
        <div style="background: #ffffff; padding: 20px 24px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 8px rgba(0,0,0,0.04); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
            <div>
                <h3 style="margin: 0; font-size: 22px; font-weight: 800; color: #0f172a; display: flex; align-items: center; gap: 10px;">
                    <i class="ti-package" style="color: #d32f2f;"></i> Order Management &amp; Parcel Dispatch
                </h3>
                <p style="margin: 4px 0 0 0; font-size: 13px; color: #64748b;">
                    Control customer order statuses, packing stages in Udaipur roastery, courier dispatch, and automated email alerts.
                </p>
            </div>
            <div style="display: flex; gap: 10px;">
                <a href="manage_order.php" class="btn btn-outline-primary" style="border-radius: 8px; font-size: 13px; font-weight: 600;">
                    <i class="ti-reload"></i> Refresh Orders
                </a>
            </div>
        </div>
    </div>
</div>

<?php
$search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
$status_filter = isset($_GET['status_filter']) ? (string) $_GET['status_filter'] : 'all';

if (isset($_POST['update_status_btn'])) {
   $status_msg = $obj->updat_order_status($_POST);
   $redirect_filter = isset($_POST['redirect_status_filter']) ? $_POST['redirect_status_filter'] : 'all';
   $redirect_search = isset($_POST['redirect_search']) ? trim($_POST['redirect_search']) : '';
   $redirect_params = array('status_filter' => $redirect_filter);
   if ($redirect_search !== '') {
        $redirect_params['q'] = $redirect_search;
   }
   admin_redirect_with_flash('manage_order.php?' . http_build_query($redirect_params), $status_msg);
}

$all_order_info = $obj->all_order_info();

$order_infos = array();
$count_all = 0;
$count_pending = 0;
$count_processing = 0;
$count_shipped = 0;
$count_delivered = 0;
$count_cancelled = 0;

if ($all_order_info) {
    while ($all_order = mysqli_fetch_assoc($all_order_info)) {
        $st = (int)$all_order['order_status'];
        $count_all++;
        if ($st === 0) $count_pending++;
        elseif ($st === 1) $count_processing++;
        elseif ($st === 2) $count_shipped++;
        elseif ($st === 3) $count_delivered++;
        elseif ($st === 4) $count_cancelled++;

        if ($status_filter !== 'all' && (string) $all_order['order_status'] !== $status_filter) {
            continue;
        }

        if ($search_query !== '') {
            $haystack = $all_order['order_id'] . ' ' . $all_order['product_name'] . ' ' . $all_order['customer_name'] . ' ' . $all_order['Shipping_mobile'] . ' ' . $all_order['trans_id'] . ' ' . $all_order['payment_method'] . ' ' . $all_order['payment_status'] . ' ' . $all_order['gateway_order_id'];
            if (stripos($haystack, $search_query) === false) {
                continue;
            }
        }

        $order_infos[] = $all_order; 
    }
}
?>

<!-- KPI Cards Row -->
<div class="row" style="margin-bottom: 20px;">
    <div class="col-md-6 col-xl-2 col-sm-6">
        <a href="manage_order.php?status_filter=all" style="text-decoration: none; color: inherit;">
            <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; padding: 16px; margin-bottom: 15px; border-left: 4px solid #3b82f6;">
                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #64748b;">Total Orders</span>
                <h3 style="margin: 4px 0 0 0; font-size: 22px; font-weight: 800; color: #0f172a;"><?php echo $count_all; ?></h3>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-xl-2 col-sm-6">
        <a href="manage_order.php?status_filter=0" style="text-decoration: none; color: inherit;">
            <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; padding: 16px; margin-bottom: 15px; border-left: 4px solid #ef4444;">
                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #ef4444;">Pending</span>
                <h3 style="margin: 4px 0 0 0; font-size: 22px; font-weight: 800; color: #ef4444;"><?php echo $count_pending; ?></h3>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-xl-2 col-sm-6">
        <a href="manage_order.php?status_filter=1" style="text-decoration: none; color: inherit;">
            <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; padding: 16px; margin-bottom: 15px; border-left: 4px solid #f59e0b;">
                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #d97706;">Processing</span>
                <h3 style="margin: 4px 0 0 0; font-size: 22px; font-weight: 800; color: #d97706;"><?php echo $count_processing; ?></h3>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-xl-2 col-sm-6">
        <a href="manage_order.php?status_filter=2" style="text-decoration: none; color: inherit;">
            <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; padding: 16px; margin-bottom: 15px; border-left: 4px solid #2563eb;">
                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #2563eb;">Shipped</span>
                <h3 style="margin: 4px 0 0 0; font-size: 22px; font-weight: 800; color: #2563eb;"><?php echo $count_shipped; ?></h3>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-xl-2 col-sm-6">
        <a href="manage_order.php?status_filter=3" style="text-decoration: none; color: inherit;">
            <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; padding: 16px; margin-bottom: 15px; border-left: 4px solid #10b981;">
                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #059669;">Delivered</span>
                <h3 style="margin: 4px 0 0 0; font-size: 22px; font-weight: 800; color: #059669;"><?php echo $count_delivered; ?></h3>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-xl-2 col-sm-6">
        <a href="manage_order.php?status_filter=4" style="text-decoration: none; color: inherit;">
            <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; padding: 16px; margin-bottom: 15px; border-left: 4px solid #64748b;">
                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #64748b;">Cancelled</span>
                <h3 style="margin: 4px 0 0 0; font-size: 22px; font-weight: 800; color: #64748b;"><?php echo $count_cancelled; ?></h3>
            </div>
        </a>
    </div>
</div>

<!-- Search & Filters -->
<form action="" method="get" class="admin-form-card" style="margin-bottom: 18px; padding: 16px 20px; background: #fff; border-radius: 10px; border: 1px solid #e2e8f0;">
    <div class="row">
        <div class="col-md-6">
            <label for="q" style="font-weight: 600; font-size: 13px;">Search Orders</label>
            <input type="text" name="q" id="q" class="form-control" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search by Order ID, Customer Name, Mobile, Product...">
        </div>
        <div class="col-md-3">
            <label for="status_filter" style="font-weight: 600; font-size: 13px;">Status Filter</label>
            <select name="status_filter" id="status_filter" class="form-control">
                <option value="all" <?php if ($status_filter === 'all') echo 'selected'; ?>>All Statuses (<?php echo $count_all; ?>)</option>
                <option value="0" <?php if ($status_filter === '0') echo 'selected'; ?>>🟡 Pending (<?php echo $count_pending; ?>)</option>
                <option value="1" <?php if ($status_filter === '1') echo 'selected'; ?>>⚙️ Processing / Packed (<?php echo $count_processing; ?>)</option>
                <option value="2" <?php if ($status_filter === '2') echo 'selected'; ?>>🚚 Shipped / In Transit (<?php echo $count_shipped; ?>)</option>
                <option value="3" <?php if ($status_filter === '3') echo 'selected'; ?>>✅ Delivered (<?php echo $count_delivered; ?>)</option>
                <option value="4" <?php if ($status_filter === '4') echo 'selected'; ?>>❌ Cancelled (<?php echo $count_cancelled; ?>)</option>
            </select>
        </div>
        <div class="col-md-3">
            <label>&nbsp;</label>
            <div style="display: flex; gap: 8px;">
                <button type="submit" class="btn btn-primary" style="flex: 1;"><i class="ti-search"></i> Filter</button>
                <a href="manage_order.php" class="btn btn-light"><i class="ti-close"></i> Reset</a>
            </div>
        </div>
    </div>
</form>

<!-- Filter Tabs -->
<div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px;">
    <?php $search_suffix = $search_query !== '' ? '&q=' . urlencode($search_query) : ''; ?>
    <a href="manage_order.php?status_filter=all<?php echo $search_suffix; ?>" class="btn btn-sm <?php echo $status_filter == 'all' ? 'btn-primary' : 'btn-outline-secondary'; ?>" style="border-radius: 20px; font-weight: 600;">
        All (<?php echo $count_all; ?>)
    </a>
    <a href="manage_order.php?status_filter=0<?php echo $search_suffix; ?>" class="btn btn-sm <?php echo $status_filter == '0' ? 'btn-danger' : 'btn-outline-danger'; ?>" style="border-radius: 20px; font-weight: 600;">
        Pending (<?php echo $count_pending; ?>)
    </a>
    <a href="manage_order.php?status_filter=1<?php echo $search_suffix; ?>" class="btn btn-sm <?php echo $status_filter == '1' ? 'btn-warning' : 'btn-outline-warning'; ?>" style="border-radius: 20px; font-weight: 600;">
        Processing (<?php echo $count_processing; ?>)
    </a>
    <a href="manage_order.php?status_filter=2<?php echo $search_suffix; ?>" class="btn btn-sm <?php echo $status_filter == '2' ? 'btn-info' : 'btn-outline-info'; ?>" style="border-radius: 20px; font-weight: 600;">
        Shipped (<?php echo $count_shipped; ?>)
    </a>
    <a href="manage_order.php?status_filter=3<?php echo $search_suffix; ?>" class="btn btn-sm <?php echo $status_filter == '3' ? 'btn-success' : 'btn-outline-success'; ?>" style="border-radius: 20px; font-weight: 600;">
        Delivered (<?php echo $count_delivered; ?>)
    </a>
    <a href="manage_order.php?status_filter=4<?php echo $search_suffix; ?>" class="btn btn-sm <?php echo $status_filter == '4' ? 'btn-secondary' : 'btn-outline-secondary'; ?>" style="border-radius: 20px; font-weight: 600;">
        Cancelled (<?php echo $count_cancelled; ?>)
    </a>
</div>

<!-- Orders Table -->
<div class="card" style="border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 8px rgba(0,0,0,0.04); overflow: hidden;">
    <div class="card-header" style="background: #ffffff; padding: 16px 20px; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center;">
        <h5 style="margin: 0; font-size: 15px; font-weight: 700; color: #1e293b;">
            Showing <?php echo count($order_infos); ?> Order(s)
        </h5>
        <span style="font-size: 12px; color: #64748b;">
            <i class="ti-info-alt"></i> Updating status automatically alerts customer via email (care@postic.in)
        </span>
    </div>
    <div class="table-responsive">
        <table class="table table-hover" style="margin-bottom: 0; font-size: 13px;">
            <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px;">
                <tr>
                    <th style="padding: 12px 16px;">Order ID</th>
                    <th style="padding: 12px 16px;">Customer &amp; Mobile</th>
                    <th style="padding: 12px 16px;">Makhana Item(s)</th>
                    <th style="padding: 12px 16px;">Total</th>
                    <th style="padding: 12px 16px;">Payment</th>
                    <th style="padding: 12px 16px; text-align: center;">Live Status</th>
                    <th style="padding: 12px 16px; min-width: 220px;">Change Status &amp; Notify</th>
                    <th style="padding: 12px 16px; text-align: right;">Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($order_infos)) { ?>
                <tr>
                    <td colspan="8" style="text-align: center; padding: 40px; color: #94a3b8;">
                        <i class="ti-package" style="font-size: 36px; display: block; margin-bottom: 8px; color: #cbd5e1;"></i>
                        No orders found matching your filters.
                    </td>
                </tr>
            <?php } ?>
            <?php foreach($order_infos as $order_info){ 
                $st_val = (int)$order_info['order_status'];
                $is_online = (strtolower($order_info['payment_method'] ?? '') === 'online' || strtolower($order_info['payment_status'] ?? '') === 'paid');
            ?>
            <tr>
                <td style="padding: 14px 16px; vertical-align: middle;">
                    <strong style="font-size: 14px; color: #0f172a; display: block;">
                        #<?php echo $order_info['order_id']; ?>
                    </strong>
                    <small style="color: #94a3b8; font-size: 11px;">
                        <?php echo date('d M, h:i A', strtotime($order_info['order_time'])); ?>
                    </small>
                </td>
                <td style="padding: 14px 16px; vertical-align: middle;">
                    <strong style="color: #1e293b; display: block;">
                        <i class="ti-user" style="color: #16a34a; margin-right: 4px;"></i>
                        <?php echo htmlspecialchars($order_info['customer_name']); ?>
                    </strong>
                    <small style="color: #64748b; font-size: 11px;">
                        <i class="ti-mobile"></i> <?php echo htmlspecialchars($order_info['Shipping_mobile']); ?>
                    </small>
                    <small style="display: block; color: #94a3b8; font-size: 11px; max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?php echo htmlspecialchars($order_info['shiping_address']); ?>">
                        <i class="ti-location-pin"></i> <?php echo htmlspecialchars($order_info['shiping_address']); ?>
                    </small>
                </td>
                <td style="padding: 14px 16px; vertical-align: middle;">
                    <div style="font-weight: 600; color: #0f172a;">
                        <?php echo htmlspecialchars($order_info['product_name']); ?>
                    </div>
                    <?php if (!empty($order_info['pdt_weight'])) { ?>
                        <span style="display: inline-block; background: #fef2f2; color: #d32f2f; font-size: 10px; font-weight: 700; padding: 1px 6px; border-radius: 4px; border: 1px solid #fecaca; margin-top: 2px;">
                            <?php echo htmlspecialchars($order_info['pdt_weight']); ?>
                        </span>
                    <?php } ?>
                    <small style="color: #64748b; display: block;">Qty: <?php echo $order_info['pdt_quantity']; ?></small>
                </td>
                <td style="padding: 14px 16px; vertical-align: middle;">
                    <strong style="color: #d32f2f; font-size: 15px;">₹ <?php echo $order_info['amount']; ?></strong>
                    <?php if (!empty($order_info['uses_coupon'])) { ?>
                        <small style="display: block; color: #059669; font-size: 10px; font-weight: 700;">
                            Coupon: <?php echo htmlspecialchars($order_info['uses_coupon']); ?>
                        </small>
                    <?php } ?>
                </td>
                <td style="padding: 14px 16px; vertical-align: middle;">
                    <?php if ($is_online) { ?>
                        <span style="background: #ecfdf5; color: #059669; border: 1px solid #a7f3d0; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 10px; display: inline-flex; align-items: center; gap: 4px;">
                            <i class="ti-check"></i> Online Paid
                        </span>
                    <?php } else { ?>
                        <span style="background: #eff6ff; color: #1e40af; border: 1px solid #bfdbfe; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 10px; display: inline-flex; align-items: center; gap: 4px;">
                            <i class="ti-wallet"></i> Cash on Delivery
                        </span>
                    <?php } ?>
                </td>
                <td style="padding: 14px 16px; text-align: center; vertical-align: middle;">
                    <?php 
                        if ($st_val === 0) {
                            echo '<span class="badge" style="background:#fee2e2; color:#dc2626; font-size:11px; font-weight:700; padding:4px 10px; border-radius:12px; border:1px solid #fecaca;"><i class="ti-time"></i> Pending</span>';
                        } elseif ($st_val === 1) {
                            echo '<span class="badge" style="background:#fef3c7; color:#d97706; font-size:11px; font-weight:700; padding:4px 10px; border-radius:12px; border:1px solid #fde68a;"><i class="ti-reload"></i> Processing</span>';
                        } elseif ($st_val === 2) {
                            echo '<span class="badge" style="background:#dbeafe; color:#1d4ed8; font-size:11px; font-weight:700; padding:4px 10px; border-radius:12px; border:1px solid #bfdbfe;"><i class="ti-truck"></i> Shipped</span>';
                        } elseif ($st_val === 3) {
                            echo '<span class="badge" style="background:#dcfce7; color:#15803d; font-size:11px; font-weight:700; padding:4px 10px; border-radius:12px; border:1px solid #bbf7d0;"><i class="ti-check"></i> Delivered</span>';
                        } elseif ($st_val === 4) {
                            echo '<span class="badge" style="background:#f1f5f9; color:#475569; font-size:11px; font-weight:700; padding:4px 10px; border-radius:12px; border:1px solid #cbd5e1;"><i class="ti-close"></i> Cancelled</span>';
                        }
                    ?>
                </td>
                <td style="padding: 14px 16px; vertical-align: middle;">
                    <form action="manage_order.php" method="POST" style="margin: 0;">
                        <input type="hidden" name="order_id" value="<?php echo $order_info['order_id']; ?>">
                        <input type="hidden" name="redirect_status_filter" value="<?php echo htmlspecialchars($status_filter, ENT_QUOTES, 'UTF-8'); ?>">
                        <input type="hidden" name="redirect_search" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>">
                        
                        <div style="display: flex; gap: 6px; align-items: center;">
                            <select name="update_status" class="form-control" style="font-size: 12px; height: 32px; padding: 2px 8px; border-radius: 6px;">
                                <option value="0" <?php if ($st_val === 0) echo 'selected'; ?>>🟡 0: Pending (New Order)</option>
                                <option value="1" <?php if ($st_val === 1) echo 'selected'; ?>>⚙️ 1: Processing (Packed at Roastery)</option>
                                <option value="2" <?php if ($st_val === 2) echo 'selected'; ?>>🚚 2: Shipped (Dispatched via Courier)</option>
                                <option value="3" <?php if ($st_val === 3) echo 'selected'; ?>>✅ 3: Delivered</option>
                                <option value="4" <?php if ($st_val === 4) echo 'selected'; ?>>❌ 4: Cancelled</option>
                            </select>
                            <button type="submit" name="update_status_btn" class="btn btn-sm btn-primary" style="padding: 4px 10px; border-radius: 6px; font-weight: 600; font-size: 12px;">
                                Update
                            </button>
                        </div>
                        <label style="font-size: 11px; color: #64748b; margin: 4px 0 0 2px; display: inline-flex; align-items: center; gap: 4px; cursor: pointer;">
                            <input type="checkbox" name="notify_customer" value="1" checked style="margin: 0;">
                            Email Customer Alert
                        </label>
                    </form>
                </td>
                <td style="padding: 14px 16px; vertical-align: middle; text-align: right;">
                    <a href="../print_invoice.php?order_id=<?php echo $order_info['order_id']; ?>" target="_blank" class="btn btn-sm btn-outline-primary" style="border-radius: 6px; font-size: 12px; font-weight: 600; padding: 5px 10px; white-space: nowrap;">
                        <i class="ti-printer"></i> Invoice
                    </a>
                </td>
            </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>

