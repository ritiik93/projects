<?php 
    if(isset($_GET['status'])){
        if($_GET['status']=='edit'){
            $id = $_GET['id'];
           $logo =$obj->display_logo_ID($id);
           $logo_version = file_exists("uploads/" . $logo['img']) ? filemtime("uploads/" . $logo['img']) : time();
        }
    }

    if(isset($_POST['update_logo'])){
        $up_msg = $obj->update_logo($_POST);
        if (stripos($up_msg, 'success') !== false) {
            admin_redirect_with_flash('edit_logo.php?status=edit&id=' . urlencode($_POST['id']), $up_msg);
        }
    }
?>


<h2>Update Logo</h2>

<h6 class="">
    <?php if(isset($up_msg)){ echo $up_msg;} ?>
</h6>

</h4>
<form action=""  enctype="multipart/form-data"  method="post" class="admin-form-card">


    <div class="form-group">
        <label>Current Logo</label>
        <div class="admin-preview-strip">
            <img src="uploads/<?php echo $logo['img'] ?>?v=<?php echo $logo_version; ?>" alt="Current logo" style="max-height: 90px; width:auto;">
        </div>
    </div>

    <div class="form-group">
        <label for="img">Image</label>
        <input type="file" name="img" class="form-control">
        <small class="form-text text-muted">Upload any JPG, JPEG, or PNG logo up to 2MB.</small>
       
    <input type="hidden" name="id" value="<?php echo $logo['id'] ?>" >


    <input type="submit" value="Update Logo" name="update_logo" class="btn btn-primary" >

</form>
