<?php 
    if(isset($_POST['add_user'])){
        $add_msg = $obj->add_admin_user($_POST);
        if (!empty($add_msg)) {
            admin_redirect_with_flash('manage_user.php', $add_msg);
        }
    }
?>
<div class="container">
<h2>Add Admin or Moderator</h2>
<br>
<?php if(isset($add_msg)){ echo '<h6 class="text-success">' . $add_msg . '</h6>'; } ?>
<form action="" method="POST" class="admin-form-card">
    <div class="form-group">
        <h4>User Email</h4>
        <input type="email" name="user_name" class="form-control" required>
    </div>
    <div class="form-group">
        <h4>Password</h4>
        <input type="password" name="user_password" class="form-control" required>
    </div>
    <div class="form-group">
        <h4>Role</h4>
       <select name="user_role" class="form-control">
           <option disabled selected>--Select--</option>
           <option value="1">Admin</option>
           <option value="2">Moderator</option>
       </select>
    </div>
    <div class="form-group">
        <input type="submit" name="add_user" class="btn btn-primary" value="Add User">
    </div>
</form>
</div>
