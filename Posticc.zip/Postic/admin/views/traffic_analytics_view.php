<?php
require_once dirname(__DIR__, 2) . '/includes/traffic_tracker.php';
require_once dirname(__DIR__, 2) . '/includes/traffic_simulator_service.php';
$tracker = new PosticTrafficTracker();
$simulator = PosticTrafficSimulator::get_instance();

// Handle optional test log reset
$reset_notice = '';
if (isset($_POST['reset_traffic_logs'])) {
    $db = get_db_connection();
    if ($db) {
        @mysqli_query($db, "TRUNCATE TABLE `visitor_logs`");
        $reset_notice = 'Test visitor logs have been reset successfully.';
    }
}

// Blend simulator preview in-memory (Real visitor_logs remains 100% clean and separate)
$raw_stats = $tracker->get_summary();
$traffic_stats = $simulator->apply_preview_to_summary($raw_stats);
$raw_recent_visitors = $tracker->get_recent_visits(25);
$recent_visitors = $simulator->get_blended_recent_visits($raw_recent_visitors, 25);
?>

<div class="row">
    <!-- Page Header -->
    <div class="col-12" style="margin-bottom: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; background: #ffffff; padding: 20px 24px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
            <div>
                <h3 style="margin: 0; font-size: 22px; font-weight: 800; color: #0f172a; display: flex; align-items: center; gap: 10px;">
                    <i class="ti-pulse" style="color: #d32f2f;"></i> Website Traffic &amp; Live Visitors
                </h3>
                <p style="margin: 4px 0 0 0; font-size: 13px; color: #64748b;">
                    Real-time visitor tracking, customer browsing analytics, and device statistics for Postic.
                </p>
            </div>
            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                <?php if (!empty($traffic_stats['_simulator_active'])) { ?>
                    <span style="display: inline-flex; align-items: center; gap: 6px; background: #fffbeb; color: #b45309; padding: 7px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; border: 1px solid #fde68a;" title="Simulated traffic is active in this preview">
                        <i class="ti-stats-up" style="color: #d97706;"></i>
                        Traffic Boost Active (+<?php echo number_format($traffic_stats['_simulated_active']); ?> online)
                    </span>
                <?php } ?>
                <span style="display: inline-flex; align-items: center; gap: 8px; background: #ecfdf5; color: #059669; padding: 7px 16px; border-radius: 20px; font-size: 13px; font-weight: 700; border: 1px solid #a7f3d0;">
                    <span style="width: 9px; height: 9px; background: #10b981; border-radius: 50%; display: inline-block; box-shadow: 0 0 8px #10b981;"></span>
                    Online Right Now: <?php echo max(1, $traffic_stats['active_now']); ?>
                </span>
                <a href="traffic_analytics.php" class="btn btn-outline-primary" style="border-radius: 8px; font-size: 12px; font-weight: 600; padding: 7px 14px;">
                    <i class="ti-reload"></i> Refresh
                </a>
            </div>
        </div>
    </div>

    <!-- Alert / Notice if logs were reset -->
    <?php if (!empty($reset_notice)) { ?>
        <div class="col-12">
            <div class="alert alert-success alert-dismissible" style="border-radius: 10px; font-size: 13px;">
                <i class="ti-check"></i> <?php echo htmlspecialchars($reset_notice); ?>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        </div>
    <?php } ?>

    <!-- KPI Metric Cards Row (3 Clean Balanced Cards) -->
    <div class="col-md-4 col-sm-12">
        <div class="card" style="border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 6px rgba(0,0,0,0.04); margin-bottom: 20px;">
            <div class="card-block" style="padding: 20px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px;">Today's Visitors</span>
                        <h3 style="font-size: 28px; font-weight: 800; color: #0f172a; margin: 4px 0 0 0;">
                            <?php echo number_format($traffic_stats['today_visitors']); ?>
                        </h3>
                    </div>
                    <div style="width: 48px; height: 48px; border-radius: 12px; background: #eff6ff; display: flex; align-items: center; justify-content: center; color: #2563eb; font-size: 22px;">
                        <i class="ti-user"></i>
                    </div>
                </div>
                <div style="margin-top: 12px; font-size: 12px; color: #64748b;">
                    <span style="font-weight: 700; color: #2563eb;"><?php echo number_format($traffic_stats['today_visitors']); ?></span> unique web visitors today
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4 col-sm-12">
        <div class="card" style="border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 6px rgba(0,0,0,0.04); margin-bottom: 20px;">
            <div class="card-block" style="padding: 20px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px;">Today's Page Views</span>
                        <h3 style="font-size: 28px; font-weight: 800; color: #0f172a; margin: 4px 0 0 0;">
                            <?php echo number_format($traffic_stats['today_pageviews']); ?>
                        </h3>
                    </div>
                    <div style="width: 48px; height: 48px; border-radius: 12px; background: #fdf2f8; display: flex; align-items: center; justify-content: center; color: #db2777; font-size: 22px;">
                        <i class="ti-eye"></i>
                    </div>
                </div>
                <div style="margin-top: 12px; font-size: 12px; color: #64748b;">
                    Total customer impressions &amp; catalog clicks
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4 col-sm-12">
        <div class="card" style="border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 6px rgba(0,0,0,0.04); margin-bottom: 20px;">
            <div class="card-block" style="padding: 20px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <span style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px;">30-Day Visitors</span>
                        <h3 style="font-size: 28px; font-weight: 800; color: #0f172a; margin: 4px 0 0 0;">
                            <?php echo number_format($traffic_stats['month_visitors']); ?>
                        </h3>
                    </div>
                    <div style="width: 48px; height: 48px; border-radius: 12px; background: #f0fdf4; display: flex; align-items: center; justify-content: center; color: #16a34a; font-size: 22px;">
                        <i class="ti-bar-chart"></i>
                    </div>
                </div>
                <div style="margin-top: 12px; font-size: 12px; color: #64748b;">
                    <span style="font-weight: 700; color: #16a34a;"><?php echo number_format($traffic_stats['month_pageviews']); ?></span> total views this month
                </div>
            </div>
        </div>
    </div>

    <!-- Live Visitors Feed (Full Width) -->
    <div class="col-12">
        <div class="card" style="border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 2px 8px rgba(0,0,0,0.04); margin-bottom: 25px;">
            <div class="card-header" style="background: #ffffff; border-bottom: 1px solid #f1f5f9; padding: 18px 22px; display: flex; justify-content: space-between; align-items: center;">
                <h5 style="margin: 0; font-size: 16px; font-weight: 800; color: #1e293b;">
                    <i class="ti-rss" style="color: #d32f2f; margin-right: 6px;"></i> Live Visitor Stream (Recent Arrivals)
                </h5>
                <span style="font-size: 12px; color: #94a3b8;"><i class="ti-time"></i> Updated Live</span>
            </div>
            <div class="card-block table-responsive" style="padding: 0;">
                <table class="table table-hover" style="margin-bottom: 0; font-size: 13px;">
                    <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px;">
                        <tr>
                            <th style="padding: 14px 18px;">Visitor / Customer</th>
                            <th style="padding: 14px 18px;">Page Visited</th>
                            <th style="padding: 14px 18px;">Device &amp; Browser</th>
                            <th style="padding: 14px 18px;">Traffic Source</th>
                            <th style="padding: 14px 18px; text-align: right;">Time</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (!empty($recent_visitors)) { 
                        foreach ($recent_visitors as $visit) { 
                            $is_cust = !empty($visit['customer_name']);
                            $device_icon = 'ti-desktop';
                            if (strtolower($visit['device_type'] ?? '') === 'mobile') {
                                $device_icon = 'ti-mobile';
                            } elseif (strtolower($visit['device_type'] ?? '') === 'tablet') {
                                $device_icon = 'ti-tablet';
                            }

                            $ref = $visit['referrer'] ?? 'Instagram';
                            $is_insta = (stripos($ref, 'Instagram') !== false);
                            $is_wa = (stripos($ref, 'WhatsApp') !== false);
                            $is_google = (stripos($ref, 'Google') !== false);
                    ?>
                        <tr>
                            <td style="padding: 14px 18px;">
                                <strong style="color: #0f172a; display: block; font-size: 13px;">
                                    <i class="ti-user" style="color: #0284c7; margin-right: 4px;"></i>
                                    <?php echo htmlspecialchars($visit['customer_name'] ?? 'User_' . rand(10000, 99999)); ?>
                                </strong>
                                <small style="color: #64748b; font-size: 11px;">
                                    <?php echo htmlspecialchars($visit['user_id'] ?? 'Active Web Session'); ?>
                                </small>
                            </td>
                            <td style="padding: 14px 18px;">
                                <strong style="color: #1e293b; font-size: 13px; display: block;">
                                    <?php echo htmlspecialchars($visit['page_title']); ?>
                                </strong>
                                <small style="display: block; color: #94a3b8; max-width: 260px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <?php echo htmlspecialchars($visit['page_url']); ?>
                                </small>
                            </td>
                            <td style="padding: 14px 18px;">
                                <span style="display: inline-flex; align-items: center; gap: 4px; background: #f1f5f9; padding: 2px 8px; border-radius: 4px; font-weight: 600; font-size: 11px; color: #334155;">
                                    <i class="<?php echo $device_icon; ?>"></i> <?php echo htmlspecialchars($visit['device_type'] ?? 'Mobile'); ?>
                                </span>
                                <small style="display: block; color: #64748b; font-size: 11px; margin-top: 2px;">
                                    <?php echo htmlspecialchars($visit['browser'] ?? 'Chrome'); ?> on <?php echo htmlspecialchars($visit['os'] ?? 'Android'); ?>
                                </small>
                            </td>
                            <td style="padding: 14px 18px;">
                                <?php if ($is_insta) { ?>
                                    <span style="background: #fdf2f8; color: #db2777; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; border: 1px solid #fbcfe8; display: inline-flex; align-items: center; gap: 4px;">
                                        <i class="ti-instagram"></i> Instagram
                                    </span>
                                <?php } elseif ($is_wa) { ?>
                                    <span style="background: #ecfdf5; color: #059669; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; border: 1px solid #a7f3d0; display: inline-flex; align-items: center; gap: 4px;">
                                        <i class="ti-share"></i> WhatsApp
                                    </span>
                                <?php } elseif ($is_google) { ?>
                                    <span style="background: #eff6ff; color: #2563eb; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; border: 1px solid #bfdbfe; display: inline-flex; align-items: center; gap: 4px;">
                                        <i class="ti-search"></i> Google
                                    </span>
                                <?php } else { ?>
                                    <span style="background: #f1f5f9; color: #475569; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; border: 1px solid #cbd5e1;">
                                        Direct
                                    </span>
                                <?php } ?>
                            </td>
                            <td style="padding: 14px 18px; text-align: right; white-space: nowrap; color: #64748b; font-size: 12px;">
                                <?php echo $visit['time_ago']; ?>
                            </td>
                        </tr>
                    <?php } 
                    } else { ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 40px 20px; color: #94a3b8;">
                                <i class="ti-stats-up" style="font-size: 32px; display: block; margin-bottom: 8px; color: #cbd5e1;"></i>
                                No visitor traffic recorded yet. Browse any page to see live arrivals here!
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
