
<?php 
    $cata_info = $obj-> p_display_catagory();

    if(isset($_POST['add_pdt'])){
        $rtn_msg = $obj->add_product($_POST);
        if (stripos($rtn_msg, 'success') !== false) {
            admin_redirect_with_flash('manage_product.php', $rtn_msg);
        }
    }
?>

<h2>Add Product</h2>
<h6 class="text-success">
   <?php 
     if(isset($rtn_msg)){
         echo $rtn_msg;
     }
   ?>

</h6>
<form action="" method="post" enctype="multipart/form-data" class="form admin-form-card">
    <div class="form-group">
        <label for="pdt_name">Product Name</label>
        <input type="text" name="pdt_name" class="form-control">
    </div>

    <div class="form-group">
        <label for="pdt_price">Product Price (₹ INR / MRP)</label>
        <input type="number" name="pdt_price" class="form-control" placeholder="e.g. 130" value="130" required>
    </div>

    <div class="form-group">
        <label for="pdt_weight">Net Weight / Pack Size</label>
        <input type="text" name="pdt_weight" class="form-control" placeholder="e.g. 55g or 250g (for Raw Makhana)" value="55g" required>
        <small class="text-muted" style="font-size: 12px; color: #64748b;">Set product net weight / pack size (e.g. <strong>55g</strong> for Flavours, <strong>250g / 500g</strong> for Raw Makhana).</small>
    </div>

    <div class="form-group">
        <label for="pdt_des">Product Description</label>
        <textarea name="pdt_des" cols="30" rows="10" class="form-control"></textarea>
    </div>

    <div class="form-group">
        <label for="pdt_img">Product Stock</label>
        <input type="number" name="pdt_stock" class="form-control" max='30' min='1'>
    </div>


    <div class="form-group">
        <label for="pdt_ctg">Product Categories</label>
        <select name="pdt_ctg" class="form-control">
        <option value="">Select a Category</option>

        <?php while($cata = mysqli_fetch_assoc($cata_info)){ ?>
        <option value="<?php echo $cata['ctg_id'] ?>"><?php echo $cata['ctg_name'] ?></option>

        <?php }?>
        </select>
    </div>

    <div class="form-group">
        <label for="pdt_img">Product Image</label>
        <input type="file" name="pdt_img" class="form-control">
    </div>

    <div class="form-group">
        <label for="multi_img">More Product Images</label>
        <input type="file" name="multi_img[]" class="form-control" multiple>
    </div>

    <div class="form-group">
        <label for="pdt_status">Status</label>
        <select name="pdt_status" class="form-control">
            <option value="1">Published</option>
            <option value="0">Unpublished</option>
        </select>
    </div>



    <input type="submit" value="Add Product" name="add_pdt" class="btn btn-block btn-primary">
</form>
