<?php
$rows = $obj->SlideShow();
$slides_list = array();
if ($rows && mysqli_num_rows($rows) > 0) {
    while ($r = mysqli_fetch_assoc($rows)) {
        $slides_list[] = $r;
    }
}
$total_slides = count($slides_list);
?>

<div class="row">
    <!-- Top Header Card -->
    <div class="col-12" style="margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; background: #ffffff; padding: 22px 26px; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04);">
            <div>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <div style="width: 42px; height: 42px; border-radius: 10px; background: #fef2f2; display: flex; align-items: center; justify-content: center;">
                        <i class="ti-layout-slider" style="color: #d32f2f; font-size: 20px;"></i>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 20px; font-weight: 800; color: #0f172a; letter-spacing: -0.3px;">
                            Homepage Banner Sliders
                        </h3>
                        <p style="margin: 3px 0 0 0; font-size: 13px; color: #64748b;">
                            Manage hero promotional carousel banners, headlines, and call-to-action buttons shown on the store frontpage.
                        </p>
                    </div>
                </div>
            </div>
            <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                <span style="display: inline-flex; align-items: center; gap: 7px; background: #eff6ff; color: #1d4ed8; padding: 7px 14px; border-radius: 20px; font-size: 13px; font-weight: 700; border: 1px solid #bfdbfe;">
                    <i class="ti-layers"></i> <?php echo $total_slides; ?> Active Slides
                </span>
                <span style="display: inline-flex; align-items: center; gap: 7px; background: #ecfdf5; color: #059669; padding: 7px 14px; border-radius: 20px; font-size: 13px; font-weight: 700; border: 1px solid #a7f3d0;">
                    <span style="width: 8px; height: 8px; background: #10b981; border-radius: 50%; display: inline-block; box-shadow: 0 0 6px #10b981;"></span>
                    Live on Homepage
                </span>
                <a href="../index.php" target="_blank" class="btn btn-outline-primary" style="border-radius: 8px; font-size: 13px; font-weight: 600; padding: 8px 16px; display: inline-flex; align-items: center; gap: 6px;">
                    <i class="ti-new-window"></i> View Storefront
                </a>
            </div>
        </div>
    </div>

    <!-- Quick Tip Banner -->
    <div class="col-12" style="margin-bottom: 20px;">
        <div style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); border: 1px solid #e2e8f0; border-left: 4px solid #0b6dc6; border-radius: 10px; padding: 14px 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
            <div style="display: flex; align-items: center; gap: 12px;">
                <i class="ti-info-alt" style="font-size: 20px; color: #0b6dc6;"></i>
                <div style="font-size: 13px; color: #334155; line-height: 1.5;">
                    <strong>Recommended Banner Artwork Dimensions:</strong> <code>1920 &times; 550 pixels</code> (Ultra-wide ~3.5:1 ratio). Supports JPG, PNG, WEBP, and GIF formats up to 10MB.
                </div>
            </div>
            <span style="font-size: 12px; font-weight: 600; color: #64748b; background: #fff; padding: 4px 10px; border-radius: 6px; border: 1px solid #cbd5e1;">
                Full-width responsive display
            </span>
        </div>
    </div>

    <!-- Sliders Showcase Table Card -->
    <div class="col-12">
        <div style="background: #ffffff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04); overflow: hidden;">
            <div style="padding: 18px 24px; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; background: #ffffff;">
                <h4 style="margin: 0; font-size: 16px; font-weight: 700; color: #1e293b; display: flex; align-items: center; gap: 8px;">
                    <i class="ti-view-list" style="color: #64748b;"></i> Hero Carousel Banners (<?php echo $total_slides; ?>)
                </h4>
                <span style="font-size: 12px; color: #64748b;">
                    Click <strong>Edit Slide</strong> to update image artwork or banner typography
                </span>
            </div>

            <div class="table-responsive" style="margin: 0;">
                <table class="table" style="margin-bottom: 0; vertical-align: middle;">
                    <thead>
                        <tr style="background: #f8fafc; border-bottom: 2px solid #e2e8f0; color: #475569; font-size: 12px; text-transform: uppercase; letter-spacing: 0.6px; font-weight: 700;">
                            <th style="padding: 14px 20px; width: 80px; text-align: center;">Order</th>
                            <th style="padding: 14px 20px; min-width: 260px;">Banner Artwork</th>
                            <th style="padding: 14px 20px; min-width: 240px;">Slide Text Content</th>
                            <th style="padding: 14px 20px; min-width: 180px;">Action Buttons</th>
                            <th style="padding: 14px 20px; width: 140px; text-align: center;">Status</th>
                            <th style="padding: 14px 20px; width: 140px; text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($slides_list)) { ?>
                            <tr>
                                <td colspan="6" style="padding: 40px 20px; text-align: center; color: #64748b;">
                                    <i class="ti-image" style="font-size: 38px; color: #cbd5e1; display: block; margin-bottom: 10px;"></i>
                                    <div style="font-size: 15px; font-weight: 600;">No slider banners found in the database.</div>
                                </td>
                            </tr>
                        <?php } else { ?>
                            <?php foreach ($slides_list as $index => $row) { 
                                $slide_num = $index + 1;
                                $img_filename = htmlspecialchars($row['slider_img'] ?? '', ENT_QUOTES, 'UTF-8');
                                $img_path = "uploads/" . $img_filename;
                                $file_exists = !empty($row['slider_img']) && file_exists(__DIR__ . "/../uploads/" . $row['slider_img']);
                            ?>
                                <tr style="border-bottom: 1px solid #f1f5f9; transition: background 0.15s ease;" onmouseover="this.style.background='#fafbfc';" onmouseout="this.style.background='#ffffff';">
                                    <!-- Slide ID / Number Badge -->
                                    <td style="padding: 18px 20px; text-align: center; vertical-align: middle;">
                                        <div style="display: inline-flex; flex-direction: column; align-items: center; justify-content: center; width: 44px; height: 44px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; font-weight: 800; color: #1e293b; font-size: 15px;">
                                            <span>#<?php echo htmlspecialchars($row['slider_id']); ?></span>
                                            <span style="font-size: 9px; font-weight: 600; color: #64748b; text-transform: uppercase;">Slide</span>
                                        </div>
                                    </td>

                                    <!-- Banner Image Preview -->
                                    <td style="padding: 18px 20px; vertical-align: middle;">
                                        <div style="position: relative; max-width: 320px; border-radius: 10px; overflow: hidden; border: 1px solid #e2e8f0; background: #f8fafc; box-shadow: 0 2px 8px rgba(0,0,0,0.06); group;">
                                            <?php if (!empty($row['slider_img'])) { ?>
                                                <img src="<?php echo $img_path; ?>" 
                                                     alt="Slide #<?php echo htmlspecialchars($row['slider_id']); ?>" 
                                                     style="width: 100%; height: 95px; object-fit: cover; display: block;"
                                                     loading="lazy"
                                                     onerror="this.src='https://placehold.co/1920x550?text=Banner+Image+Not+Found';">
                                                <div style="padding: 6px 10px; background: #ffffff; border-top: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #64748b;">
                                                    <span style="font-family: monospace; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 180px;" title="<?php echo $img_filename; ?>">
                                                        <i class="ti-image"></i> <?php echo $img_filename; ?>
                                                    </span>
                                                    <a href="<?php echo $img_path; ?>" target="_blank" style="color: #0b6dc6; font-weight: 700; text-decoration: none;" title="Open high-resolution artwork in new tab">
                                                        <i class="ti-fullscreen"></i> View
                                                    </a>
                                                </div>
                                            <?php } else { ?>
                                                <div style="height: 95px; display: flex; align-items: center; justify-content: center; color: #94a3b8; font-size: 13px;">
                                                    <i class="ti-gallery" style="margin-right: 6px;"></i> No banner uploaded
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </td>

                                    <!-- Slide Text Details -->
                                    <td style="padding: 18px 20px; vertical-align: middle;">
                                        <div style="display: flex; flex-direction: column; gap: 6px;">
                                            <!-- First Line -->
                                            <div>
                                                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.5px;">Headline 1:</span>
                                                <div style="font-size: 13px; font-weight: 600; color: #0f172a;">
                                                    <?php echo !empty($row['first_line']) ? htmlspecialchars($row['first_line']) : '<span style="color:#cbd5e1; font-style:italic;">None</span>'; ?>
                                                </div>
                                            </div>
                                            <!-- Second Line -->
                                            <div>
                                                <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.5px;">Headline 2:</span>
                                                <div style="font-size: 13px; font-weight: 500; color: #334155;">
                                                    <?php echo !empty($row['second_line']) ? htmlspecialchars($row['second_line']) : '<span style="color:#cbd5e1; font-style:italic;">None</span>'; ?>
                                                </div>
                                            </div>
                                            <!-- Third Line -->
                                            <?php if (!empty($row['third_line'])) { ?>
                                                <div>
                                                    <span style="font-size: 11px; font-weight: 700; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.5px;">Tagline / Offer:</span>
                                                    <div style="font-size: 12px; color: #64748b;">
                                                        <?php echo htmlspecialchars($row['third_line']); ?>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </td>

                                    <!-- Action Buttons (CTAs) -->
                                    <td style="padding: 18px 20px; vertical-align: middle;">
                                        <div style="display: flex; flex-direction: column; gap: 6px;">
                                            <div style="display: flex; align-items: center; gap: 6px;">
                                                <span style="font-size: 11px; color: #94a3b8; width: 40px; font-weight: 600;">Left:</span>
                                                <?php if (!empty($row['btn_left'])) { ?>
                                                    <span style="display: inline-block; background: #f1f5f9; color: #334155; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 600; border: 1px solid #e2e8f0;">
                                                        <i class="ti-arrow-right" style="font-size: 10px;"></i> <?php echo htmlspecialchars($row['btn_left']); ?>
                                                    </span>
                                                <?php } else { ?>
                                                    <span style="color: #cbd5e1; font-size: 12px; font-style: italic;">None</span>
                                                <?php } ?>
                                            </div>
                                            <div style="display: flex; align-items: center; gap: 6px;">
                                                <span style="font-size: 11px; color: #94a3b8; width: 40px; font-weight: 600;">Right:</span>
                                                <?php if (!empty($row['btn_right'])) { ?>
                                                    <span style="display: inline-block; background: #f1f5f9; color: #334155; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 600; border: 1px solid #e2e8f0;">
                                                        <i class="ti-arrow-right" style="font-size: 10px;"></i> <?php echo htmlspecialchars($row['btn_right']); ?>
                                                    </span>
                                                <?php } else { ?>
                                                    <span style="color: #cbd5e1; font-size: 12px; font-style: italic;">None</span>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </td>

                                    <!-- Status -->
                                    <td style="padding: 18px 20px; text-align: center; vertical-align: middle;">
                                        <span style="display: inline-flex; align-items: center; gap: 5px; background: #ecfdf5; color: #059669; padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 700; border: 1px solid #a7f3d0;">
                                            <span style="width: 6px; height: 6px; background: #10b981; border-radius: 50%; display: inline-block;"></span>
                                            Active
                                        </span>
                                    </td>

                                    <!-- Edit Action -->
                                    <td style="padding: 18px 20px; text-align: center; vertical-align: middle;">
                                        <a href="edit_slider.php?status=edit&id=<?php echo htmlspecialchars($row['slider_id']); ?>" 
                                           class="btn btn-primary btn-sm" 
                                           style="border-radius: 8px; font-weight: 700; font-size: 13px; padding: 8px 18px; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 2px 6px rgba(255,83,112,0.3); text-decoration: none;">
                                            <i class="ti-pencil-alt"></i> Edit Slide
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
