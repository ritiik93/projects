<?php
    $coupon = array(
        'cupon_id' => '',
        'cupon_code' => '',
        'description' => '',
        'discount' => '',
        'status' => 1,
    );
    $coupon_id = 0;

    if (isset($_GET['status'], $_GET['id']) && $_GET['status'] == 'edit') {
        $coupon_id = (int) $_GET['id'];
    } elseif (isset($_POST['cupon_id'])) {
        $coupon_id = (int) $_POST['cupon_id'];
    }

    if ($coupon_id > 0) {
        $coupon_info = $obj->show_coupon_by_id($coupon_id);
        if (!empty($coupon_info)) {
            $coupon = $coupon_info;
        }
    }

    if (isset($_POST['update_coupon'])) {
        $coupon_msg = $obj->update_coupon($_POST);
        if (!empty($coupon_msg)) {
            admin_redirect_with_flash('manage_coupon.php', $coupon_msg);
        }
    }
?>

<h2>Edit Coupon</h2>

<form action="edit_coupon.php?status=edit&id=<?php echo (int) $coupon['cupon_id']; ?>" method="POST" class="admin-form-card">
    <div class="form-group">
        <label for="cuopon_code">Coupon Code</label>
        <input type="text" name="cuopon_code" class="form-control" value="<?php echo htmlspecialchars($coupon['cupon_code'], ENT_QUOTES, 'UTF-8'); ?>" required>
    </div>

    <div class="form-group">
        <label for="cuopon_description">Coupon Description</label>
        <input type="text" name="cuopon_description" class="form-control" value="<?php echo htmlspecialchars($coupon['description'], ENT_QUOTES, 'UTF-8'); ?>" required>
    </div>

    <div class="form-group">
        <label for="cuopon_discount">Coupon Discount (%)</label>
        <input type="number" name="cuopon_discount" class="form-control" value="<?php echo htmlspecialchars($coupon['discount'], ENT_QUOTES, 'UTF-8'); ?>" placeholder="e.g. 10 for 10% discount" required>
    </div>

    <div class="form-group">
        <label for="cuopon_status">Coupon Status</label>
        <select name="cuopon_status" class="form-control">
            <option value="1" <?php if ((string) $coupon['status'] === '1') { echo 'selected'; } ?>>Active</option>
            <option value="2" <?php if ((string) $coupon['status'] === '2') { echo 'selected'; } ?>>Inactive</option>
        </select>
    </div>

    <input type="hidden" name="cupon_id" value="<?php echo htmlspecialchars($coupon['cupon_id'], ENT_QUOTES, 'UTF-8'); ?>">
    <input type="submit" value="Update Coupon" name="update_coupon" class="btn btn-primary">
</form>
