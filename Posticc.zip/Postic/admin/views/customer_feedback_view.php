

<?php 
    $search_query = isset($_GET['q']) ? trim($_GET['q']) : '';

    if (isset($_GET['status'], $_GET['id'])) {
        $comment_id = (int) $_GET['id'];
        if ($_GET['status'] == 'deletecomment') {
           $del_msg =  $obj->delete_comment($comment_id);
           $redirect_url = 'customer_feedback.php';
           if ($search_query !== '') {
                $redirect_url .= '?q=' . urlencode($search_query);
           }
           admin_redirect_with_flash($redirect_url, $del_msg, 'info');
        }
    }

    $cmt_info = $obj->view_comment_all();
    $comments = array();

    while ($comment = mysqli_fetch_assoc($cmt_info)) {
        if ($search_query !== '') {
            $haystack = $comment['user_name'] . ' ' . $comment['comment'] . ' ' . $comment['pdt_id'];
            if (stripos($haystack, $search_query) === false) {
                continue;
            }
        }

        $comments[] = $comment;
    }

?>
<h2>Manage Customer Feedback</h2>
<form action="" method="get" class="admin-form-card" style="margin-bottom: 18px;">
    <div class="row">
        <div class="col-md-8">
            <label for="q">Search Feedback</label>
            <input type="text" name="q" id="q" class="form-control" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search by user, product ID or comment">
        </div>
        <div class="col-md-4">
            <label>&nbsp;</label>
            <div>
                <button type="submit" class="btn btn-primary">Apply</button>
                <a href="customer_feedback.php" class="btn btn-light">Reset</a>
            </div>
        </div>
    </div>
</form>
<p><strong><?php echo count($comments); ?></strong> feedback item(s) found.</p>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Fd Id</th>
            <th>User Id</th>
            <th>User Name</th>
            <th>Product Id</th>
            <th>User Comment</th>
            <th>Comment Date</th>
            <th>Action</th>
        </tr>
    </thead>

    <tbody>
        <?php if (empty($comments)) { ?>
            <tr>
                <td colspan="7" class="text-center">No feedback matched your search.</td>
            </tr>
        <?php } ?>
        <?php foreach ($comments as $cmt_row) { ?>
        <tr>
            <td>
                <?php echo $cmt_row['id']?>
            </td>

            <td>
                <?php echo $cmt_row['user_id']?>
            </td>

            <td>
                <?php echo $cmt_row['user_name']?>
            </td>

            <td>
                <?php echo $cmt_row['pdt_id']?>
            </td>

            <td style="width:250px ;">
                <?php echo $cmt_row['comment']?>
            </td>

            <td>
                <?php echo $cmt_row['comment_date']?>
            </td>

            <td>
                <a href="edit_comment.php?status=editcomment&&id=<?php echo $cmt_row['id']?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="?<?php echo http_build_query(array_filter(array('status' => 'deletecomment', 'id' => $cmt_row['id'], 'q' => $search_query))); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this comment?');">Delete</a>
            </td>



        </tr>

        <?php }?>
    </tbody>
</table>
