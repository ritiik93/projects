
<?php 
    if(isset($_GET['status'])){
        if($_GET['status']=='edit'){
            $id = $_GET['id'];
           $cata = $obj->display_cataByID($id);
        }
    }

    if(isset($_POST['update_ctg'])){
        $up_msg = $obj->updata_catagory($_POST);
        if (stripos($up_msg, 'success') !== false) {
            admin_redirect_with_flash('manage_cata.php', $up_msg);
        }
    }
?>


<h2>Update Category</h2>

<h6 class="">
    <?php if(isset($up_msg)){ echo $up_msg;} ?>
</h6>

</h4>
<form action="" method="post" class="admin-form-card">


    <div class="form-group">
        <label for="u_ctg_name">Category Name</label>
        <input type="text" name="u_ctg_name" class="form-control" value="<?php echo $cata['ctg_name'] ?>">
    </div>

    <div class="form-group">
        <label for="u_ctg_des">Category Description</label>
        <input type="text" name="u_ctg_des" class="form-control"  value="<?php echo $cata['ctg_des'] ?>">
    </div>

    <div class="form-group">
        <label for="u_ctg_status">Category Status</label>
        <select name="u_ctg_status" class="form-control">
            <option value="1" <?php if ($cata['ctg_status'] == 1) { echo "selected"; } ?>>Published</option>
            <option value="0" <?php if ($cata['ctg_status'] == 0) { echo "selected"; } ?>>Unpublished</option>
        </select>
    </div>

    <input type="hidden" name="u_ctg_id" value="<?php echo $cata['ctg_id'] ?>" >

    <input type="submit" value="Update Category" name="update_ctg" class="btn btn-primary" >

</form>
