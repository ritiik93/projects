<?php

ini_set("display_errors", "Off");
$obj = new adminback();
$cata_info = $obj->p_display_catagory();
$gallery_info = false;
$pdt = array(
    'pdt_id' => '',
    'pdt_name' => '',
    'pdt_price' => '',
    'pdt_weight' => '55g',
    'pdt_des' => '',
    'product_stock' => '',
    'pdt_ctg' => '',
    'pdt_img' => '',
    'pdt_status' => 1,
);

if (isset($_GET['prostatus'], $_GET['id']) && $_GET['prostatus'] == 'edit') {
    $id = $_GET['id'];
    $pdt_info = $obj->edit_product($id);
    $pdt = mysqli_fetch_assoc($pdt_info);
    $gallery_info = $obj->display_product_images($id);
}

if (isset($_GET['gallery_action'], $_GET['image_id'], $_GET['id']) && $_GET['gallery_action'] == 'delete') {
    $gallery_msg = $obj->delete_product_image((int) $_GET['image_id']);
    admin_redirect_with_flash('edit_product.php?prostatus=edit&id=' . urlencode($_GET['id']), $gallery_msg, 'info');
}

if (isset($_POST['update_pdt'])) {
    $update_msg = $obj->update_product($_POST);
    if (stripos($update_msg, 'success') !== false) {
        admin_redirect_with_flash('manage_product.php', $update_msg);
    }

    $pdt_info = $obj->edit_product($_POST['pdt_id']);
    $pdt = mysqli_fetch_assoc($pdt_info);
    $gallery_info = $obj->display_product_images($_POST['pdt_id']);
}

?>
<h4>Update Product</h4>

<?php
if (isset($update_msg)) {
    echo $update_msg;
}
?>
<form action="" method="post" enctype="multipart/form-data" class="form admin-form-card">
    <div class="form-group">
        <label for="pdt_name">Product Name</label>
        <input type="text" name="u_pdt_name" class="form-control" value="<?php echo $pdt['pdt_name'] ?>">
    </div>

    <input type="hidden" name="pdt_id" value="<?php echo $pdt['pdt_id'] ?>">
    <div class="form-group">
        <label for="pdt_price">Product Price (₹ INR / MRP)</label>
        <input type="number" name="u_pdt_price" class="form-control" value="<?php echo $pdt['pdt_price'] ?>" required>
    </div>

    <div class="form-group">
        <label for="u_pdt_weight">Net Weight / Pack Size</label>
        <input type="text" name="u_pdt_weight" class="form-control" value="<?php echo htmlspecialchars($pdt['pdt_weight'] ?? '55g') ?>" placeholder="e.g. 55g or 250g" required>
        <small class="text-muted" style="font-size: 12px; color: #64748b;">Set product net weight / pack size (e.g. <strong>55g</strong> for Flavours, <strong>250g / 500g</strong> for Raw Makhana).</small>
    </div>

    <div class="form-group">
        <label for="pdt_des">Product Description</label>
        <textarea name="u_pdt_des" cols="30" rows="10" class="form-control"><?php echo $pdt['pdt_des'] ?> </textarea>
    </div>

    <div class="form-group">
        <label for="pdt_stock">Product Stock</label>
        <input type="number" name="pdt_stock" class="form-control" max='30' min='1'
            value="<?php echo $pdt['product_stock'] ?>">
    </div>


    <div class="form-group">
        <label for="pdt_ctg">Product Categories</label>
        <select name="u_pdt_ctg" class="form-control">
            <option value="">Select a Category</option>

            <?php while ($cata = mysqli_fetch_assoc($cata_info)) { ?>
                <option value="<?php echo $cata['ctg_id'] ?>" <?php if ($pdt['pdt_ctg'] == $cata['ctg_id']) {
                       echo "selected";
                   } ?>><?php echo $cata['ctg_name'] ?></option>

            <?php } ?>
        </select>
    </div>



    <div class="form-group">
        <label for="pdt_img">Product Image</label>
        <div class="mb-3">
            <img src="uploads/<?php echo $pdt['pdt_img'] ?>" style="width: 80px;">
        </div>
        <?php if ($gallery_info && mysqli_num_rows($gallery_info) > 0) { ?>
            <div class="mb-3 admin-preview-strip">
                <label>Current More Product Images</label><br>
                <?php while ($gallery = mysqli_fetch_assoc($gallery_info)) { ?>
                    <div style="display:inline-block; text-align:center; margin-right:10px; margin-bottom:10px;">
                        <img src="uploads/<?php echo $gallery['img_name'] ?>" style="width: 80px; margin-right: 0; margin-bottom: 6px;">
                        <br>
                        <a href="edit_product.php?gallery_action=delete&prostatus=edit&id=<?php echo $pdt['pdt_id']; ?>&image_id=<?php echo $gallery['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this gallery image?');">Delete</a>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
        <input type="file" name="u_pdt_img" class="form-control">
        <div class="form-group">
            <label>More Product Images</label>
            <input type="file" name="multi_img[]" class="form-control" multiple>
        </div>
    </div>

    <div class="form-group">
        <label for="pdt_status">Status</label>
        <select name="u_pdt_status" class="form-control">
            <option value="1" <?php if ($pdt['pdt_status'] == 1) {
                echo "selected";
            } ?>>Published</option>
            <option value="0" <?php if ($pdt['pdt_status'] == 0) {
                echo "selected";
            } ?>>Unpublished</option>
        </select>
    </div>

    <input type="submit" value="Update Product" name="update_pdt" class="btn btn-block btn-primary">
</form>
