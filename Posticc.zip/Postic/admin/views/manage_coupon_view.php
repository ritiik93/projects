<?php 
    $search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
    $status_filter = isset($_GET['status_filter']) ? (string) $_GET['status_filter'] : 'all';
    $redirect_params = array();

    if ($search_query !== '') {
        $redirect_params['q'] = $search_query;
    }
    if ($status_filter !== 'all') {
        $redirect_params['status_filter'] = $status_filter;
    }

    $redirect_url = 'manage_coupon.php';
    if (!empty($redirect_params)) {
        $redirect_url .= '?' . http_build_query($redirect_params);
    }

    if (isset($_GET['status'], $_GET['id'])) {
        $coupon_id = (int) $_GET['id'];

        if ($_GET['status'] == 'delete') {
            $msg = $obj->delete_coupon($coupon_id);
            admin_redirect_with_flash($redirect_url, $msg, 'info');
        } elseif ($_GET['status'] == 'activate') {
            $msg = $obj->update_coupon_status($coupon_id, 1);
            admin_redirect_with_flash($redirect_url, $msg);
        } elseif ($_GET['status'] == 'deactivate') {
            $msg = $obj->update_coupon_status($coupon_id, 2);
            admin_redirect_with_flash($redirect_url, $msg, 'info');
        }
    }

    $show_coupon = $obj->show_coupon();
    $coupons = array();

    while ($coupon = mysqli_fetch_assoc($show_coupon)) {
        if ($search_query !== '' && stripos($coupon['cupon_code'], $search_query) === false && stripos($coupon['description'], $search_query) === false) {
            continue;
        }

        if ($status_filter !== 'all' && (string) $coupon['status'] !== $status_filter) {
            continue;
        }

        $coupons[] = $coupon;
    }
?>

<h2>Manage Coupon</h2>
<form action="" method="get" class="admin-form-card" style="margin-bottom: 18px;">
    <div class="row">
        <div class="col-md-6">
            <label for="q">Search Coupon</label>
            <input type="text" name="q" id="q" class="form-control" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search by code or description">
        </div>
        <div class="col-md-3">
            <label for="status_filter">Status</label>
            <select name="status_filter" id="status_filter" class="form-control">
                <option value="all">All Statuses</option>
                <option value="1" <?php if ($status_filter === '1') { echo 'selected'; } ?>>Active</option>
                <option value="2" <?php if ($status_filter === '2') { echo 'selected'; } ?>>Inactive</option>
            </select>
        </div>
        <div class="col-md-3">
            <label>&nbsp;</label>
            <div>
                <button type="submit" class="btn btn-primary">Apply</button>
                <a href="manage_coupon.php" class="btn btn-light">Reset</a>
            </div>
        </div>
    </div>
</form>
<p><strong><?php echo count($coupons); ?></strong> coupon(s) found.</p>

<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>Coupon Id</th>
            <th>Coupon Code</th>
            <th>Coupon Description</th>
            <th>Coupon Discount (%)</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>

    <tbody>
            <?php if (empty($coupons)) { ?>
                <tr>
                    <td colspan="6" class="text-center">No coupons matched your filters.</td>
                </tr>
            <?php } ?>
            <?php foreach ($coupons as $result) { ?>
        <tr>
            <td> <?php echo $result['cupon_id'] ?></td>
            <td> <?php echo $result['cupon_code'] ?></td>
            <td> <?php echo $result['description'] ?></td>
            <td> <?php echo $result['discount'] ?>%</td>
            <td>
                <span class="badge badge-<?php echo $result['status'] == 1 ? 'info' : 'secondary'; ?>"><?php echo $result['status'] == 1 ? 'Active' : 'Inactive'; ?></span>
            </td>
            <td>
                <a href="edit_coupon.php?status=edit&id=<?php echo $result['cupon_id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                <?php if ((string) $result['status'] === '1') { ?>
                    <a href="?<?php echo http_build_query(array_merge($redirect_params, array('status' => 'deactivate', 'id' => $result['cupon_id']))); ?>" class="btn btn-sm btn-secondary">Deactivate</a>
                <?php } else { ?>
                    <a href="?<?php echo http_build_query(array_merge($redirect_params, array('status' => 'activate', 'id' => $result['cupon_id']))); ?>" class="btn btn-sm btn-success">Activate</a>
                <?php } ?>
                <a href="?<?php echo http_build_query(array_merge($redirect_params, array('status' => 'delete', 'id' => $result['cupon_id']))); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this coupon?');">Delete</a>
            </td>
           
        </tr>

        <?php }?>
    </tbody>
</table>
