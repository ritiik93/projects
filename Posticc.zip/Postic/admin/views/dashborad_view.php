<?php 
    date_default_timezone_set("Asia/Kolkata");
    $low_stock_count = $obj->count_low_stock_products();

?>
<style>
    .mydiv{
        width: 200px;
        position: absolute;
        right: 38px;
        overflow: hidden;
    }
</style>
<h2>Dashboard</h2>


<div class="mydiv">
<form action="" class="form">
    <select name="filterDate" id="filterDate" class="form-control">
        <option value="<?php echo date("Y-m-d")?>" >Today</option>
        <option value="<?php echo date('Y-m-d', strtotime('-7 days')) ?>" >This week</option>
        <option value="<?php echo date('Y-m-d', strtotime('-30 days')) ?>" >This Month</option>
        <option value="<?php echo date('Y-m-d', strtotime('-365 days')) ?>" >This Year</option>
        <option value="2020-01-01" >Life Time</option>
    </select>
</form>
</div>


<script>
    $(document).ready(function(){
        function loadStat(action, selector, filterId) {
            $.ajax({
                url: "json/dashboard_json.php",
                method: "POST",
                data: {
                    action: action,
                    did: filterId
                },
                success: function(data) {
                    $(selector).text(data ? data : 0);
                }
            });
        }

        function loadDashboardStats() {
            var filterId = $("#filterDate").val();

            loadStat('load_allorder', '#totalOrder', filterId);
            loadStat('load_allsell', '#totalSell', filterId);
            loadStat('load_allcustomer', '#totalCustomer', filterId);
            loadStat('load_delivered_order', '#DeliverOrder', filterId);
            loadStat('load_processing_order', '#processingOrder', filterId);
            loadStat('load_pending_order', '#pendingOrder', filterId);
        }

        $("#filterDate").change(function(){
            loadDashboardStats();
        });

        loadDashboardStats();
    });
</script>


<br> <br> <br>
<div class="row">



<!-- order-card start -->

<div class="col-md-6 col-xl-3">
    <a href="manage_order.php?status_filter=all" class="dashboard-card-link">
    <div class="card bg-c-blue order-card">
        <div class="card-block">
            <h6 class="m-b-20">Orders Received</h6>
            <h2 class="text-right"><i class="ti-shopping-cart f-left"></i><span id="totalOrder">0</span></h2>
            <p class="m-b-0">Tap to open orders</p>
        </div>
    </div>
    </a>
</div>


<div class="col-md-6 col-xl-3">
    <a href="make_report.php" class="dashboard-card-link">
    <div class="card bg-c-green order-card">
        <div class="card-block">
            <h6 class="m-b-20">Total Sales</h6>
            <h2 class="text-right"><i class="ti-tag f-left"></i><span>₹ </span><span id="totalSell">0</span></h2>
            <p class="m-b-0">Tap to open report</p>
        </div>
    </div>
    </a>
</div>
<div class="col-md-6 col-xl-3">
    <a href="manage_customers.php" class="dashboard-card-link">
    <div class="card bg-c-yellow order-card">
        <div class="card-block">
            <h6 class="m-b-20">Registered Customers</h6>
            <h2 class="text-right"><i class="ti-id-badge f-left"></i><span id="totalCustomer">0</span></h2>
            <p class="m-b-0">Tap to view customers</p>
        </div>
    </div>
    </a>
</div>
<div class="col-md-6 col-xl-3">
    <a href="manage_order.php?status_filter=2" class="dashboard-card-link">
    <div class="card bg-c-pink order-card">
        <div class="card-block">
            <h6 class="m-b-20">Delivered Order</h6>
            <h2 class="text-right"><i class="ti-wallet f-left"></i><span id="DeliverOrder">0</span></h2>
            <p class="m-b-0">Tap to view delivered</p>
        </div>
    </div>
    </a>
</div>

<div class="col-md-6 col-xl-3">
    <a href="manage_order.php?status_filter=1" class="dashboard-card-link">
    <div class="card bg-c-pink order-card">
        <div class="card-block">
            <h6 class="m-b-20">Processing Order</h6>
            <h2 class="text-right"><i class="ti-wallet f-left"></i><span id="processingOrder">0</span></h2>
            <p class="m-b-0">Tap to view processing</p>
        </div>
    </div>
    </a>
</div>

<div class="col-md-6 col-xl-3">
    <a href="manage_order.php?status_filter=0" class="dashboard-card-link">
    <div class="card bg-c-yellow order-card">
        <div class="card-block">
            <h6 class="m-b-20">Pending Order</h6>
            <h2 class="text-right"><i class="ti-reload f-left"></i><span id="pendingOrder">0</span></h2>
            <p class="m-b-0">Tap to view pending</p>
        </div>
    </div>
    </a>
</div>

<div class="col-md-6 col-xl-3">
    <a href="manage_product.php?stock_filter=low" class="dashboard-card-link">
    <div class="card bg-c-blue order-card">
        <div class="card-block">
            <h6 class="m-b-20">Low Stock Products</h6>
            <h2 class="text-right"><i class="ti-package f-left"></i><span><?php echo $low_stock_count; ?></span></h2>
            <p class="m-b-0">Tap to review stock</p>
        </div>
    </div>
    </a>
</div>


<!-- order-card end -->


<!-- users visite and profile start -->
<?php
require_once dirname(__DIR__, 2) . '/includes/traffic_tracker.php';
require_once dirname(__DIR__, 2) . '/includes/traffic_simulator_service.php';
$tracker = new PosticTrafficTracker();
$simulator = PosticTrafficSimulator::get_instance();
$raw_traffic_stats = $tracker->get_summary();
$traffic_stats = $simulator->apply_preview_to_summary($raw_traffic_stats);
$raw_recent_visitors = $tracker->get_recent_visits(10);
$recent_visitors = $simulator->get_blended_recent_visits($raw_recent_visitors, 10);
?>

<div class="col-12" style="margin-top: 30px; margin-bottom: 20px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px;">
        <div>
            <h3 style="margin: 0; font-size: 20px; font-weight: 700; color: #1e293b; display: flex; align-items: center; gap: 8px;">
                <i class="ti-pulse" style="color: #d32f2f;"></i> Website Traffic &amp; Live Visitors
            </h3>
            <p style="margin: 3px 0 0 0; font-size: 13px; color: #64748b;">Live visitor arrivals, customer browsing activity, and traffic sources.</p>
        </div>
        <div style="display: flex; align-items: center; gap: 10px;">
            <span style="display: inline-flex; align-items: center; gap: 6px; background: #ecfdf5; color: #059669; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; border: 1px solid #a7f3d0;">
                <span style="width: 8px; height: 8px; background: #10b981; border-radius: 50%; display: inline-block; box-shadow: 0 0 8px #10b981;"></span>
                Online Right Now: <?php echo max(1, $traffic_stats['active_now']); ?>
            </span>
            <a href="traffic_analytics.php" class="btn btn-sm btn-outline-danger" style="border-radius: 6px; font-size: 12px; font-weight: 700; padding: 6px 12px;">
                Open Full Analytics &rarr;
            </a>
        </div>
    </div>
</div>

<!-- Traffic KPI 3-Column Balanced Cards Row -->
<div class="col-md-4 col-sm-12">
    <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; box-shadow: 0 2px 6px rgba(0,0,0,0.04); margin-bottom: 20px;">
        <div class="card-block" style="padding: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <span style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: #64748b;">Today's Visitors</span>
                    <h3 style="font-size: 28px; font-weight: 800; color: #0f172a; margin: 4px 0 0 0;"><?php echo number_format($traffic_stats['today_visitors']); ?></h3>
                </div>
                <div style="width: 48px; height: 48px; border-radius: 12px; background: #eff6ff; display: flex; align-items: center; justify-content: center; color: #2563eb; font-size: 22px;">
                    <i class="ti-user"></i>
                </div>
            </div>
            <div style="margin-top: 12px; font-size: 12px; color: #64748b;">
                <span style="font-weight: 700; color: #2563eb;"><?php echo number_format($traffic_stats['today_visitors']); ?></span> unique web visitors today
            </div>
        </div>
    </div>
</div>

<div class="col-md-4 col-sm-12">
    <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; box-shadow: 0 2px 6px rgba(0,0,0,0.04); margin-bottom: 20px;">
        <div class="card-block" style="padding: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <span style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: #64748b;">Today's Page Views</span>
                    <h3 style="font-size: 28px; font-weight: 800; color: #0f172a; margin: 4px 0 0 0;"><?php echo number_format($traffic_stats['today_pageviews']); ?></h3>
                </div>
                <div style="width: 48px; height: 48px; border-radius: 12px; background: #fdf2f8; display: flex; align-items: center; justify-content: center; color: #db2777; font-size: 22px;">
                    <i class="ti-eye"></i>
                </div>
            </div>
            <div style="margin-top: 12px; font-size: 12px; color: #64748b;">
                Total customer impressions &amp; catalog clicks
            </div>
        </div>
    </div>
</div>

<div class="col-md-4 col-sm-12">
    <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; box-shadow: 0 2px 6px rgba(0,0,0,0.04); margin-bottom: 20px;">
        <div class="card-block" style="padding: 20px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <span style="font-size: 12px; font-weight: 700; text-transform: uppercase; color: #64748b;">30-Day Visitors</span>
                    <h3 style="font-size: 28px; font-weight: 800; color: #0f172a; margin: 4px 0 0 0;"><?php echo number_format($traffic_stats['month_visitors']); ?></h3>
                </div>
                <div style="width: 48px; height: 48px; border-radius: 12px; background: #f0fdf4; display: flex; align-items: center; justify-content: center; color: #16a34a; font-size: 22px;">
                    <i class="ti-bar-chart"></i>
                </div>
            </div>
            <div style="margin-top: 12px; font-size: 12px; color: #64748b;">
                <span style="font-weight: 700; color: #16a34a;"><?php echo number_format($traffic_stats['month_pageviews']); ?></span> total views this month
            </div>
        </div>
    </div>
</div>

<!-- Live Arrivals Feed (Full Width) -->
<div class="col-12">
    <div class="card" style="border-radius: 10px; border: 1px solid #e2e8f0; box-shadow: 0 2px 6px rgba(0,0,0,0.04); margin-bottom: 25px;">
        <div class="card-header" style="background: #ffffff; border-bottom: 1px solid #f1f5f9; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center;">
            <h5 style="margin: 0; font-size: 16px; font-weight: 700; color: #1e293b;">
                <i class="ti-rss" style="color: #d32f2f; margin-right: 6px;"></i> Live Visitor Stream (Recent Arrivals)
            </h5>
            <span style="font-size: 12px; color: #94a3b8;"><i class="ti-reload"></i> Real-time</span>
        </div>
        <div class="card-block table-responsive" style="padding: 0;">
            <table class="table table-hover" style="margin-bottom: 0; font-size: 13px;">
                <thead style="background: #f8fafc; font-size: 11px; text-transform: uppercase; color: #64748b;">
                    <tr>
                        <th style="padding: 12px 16px;">Visitor / Customer</th>
                        <th style="padding: 12px 16px;">Page Visited</th>
                        <th style="padding: 12px 16px;">Device &amp; Browser</th>
                        <th style="padding: 12px 16px;">Traffic Source</th>
                        <th style="padding: 12px 16px; text-align: right;">Time</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!empty($recent_visitors)) { 
                    foreach ($recent_visitors as $visit) { 
                        $is_cust = !empty($visit['customer_name']);
                        $device_icon = 'ti-desktop';
                        if (strtolower($visit['device_type'] ?? '') === 'mobile') {
                            $device_icon = 'ti-mobile';
                        } elseif (strtolower($visit['device_type'] ?? '') === 'tablet') {
                            $device_icon = 'ti-tablet';
                        }
                        
                        $ref = $visit['referrer'] ?? 'Instagram';
                        $is_insta = (stripos($ref, 'Instagram') !== false);
                        $is_wa = (stripos($ref, 'WhatsApp') !== false);
                        $is_google = (stripos($ref, 'Google') !== false);
                ?>
                    <tr>
                        <td style="padding: 12px 16px;">
                            <strong style="color: #0f172a; display: block; font-size: 13px;">
                                <i class="ti-user" style="color: #0284c7; margin-right: 4px;"></i>
                                <?php echo htmlspecialchars($visit['customer_name'] ?? 'User_' . rand(10000, 99999)); ?>
                            </strong>
                            <small style="color: #64748b; font-size: 11px;">
                                <?php echo htmlspecialchars($visit['user_id'] ?? 'Active Web Session'); ?>
                            </small>
                        </td>
                        <td style="padding: 12px 16px;">
                            <span style="font-weight: 600; color: #1e293b;"><?php echo htmlspecialchars($visit['page_title']); ?></span>
                            <small style="display: block; color: #94a3b8; max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <?php echo htmlspecialchars($visit['page_url']); ?>
                            </small>
                        </td>
                        <td style="padding: 12px 16px;">
                            <span style="display: inline-flex; align-items: center; gap: 4px; background: #f1f5f9; padding: 2px 8px; border-radius: 4px; font-weight: 600; font-size: 11px; color: #334155;">
                                <i class="<?php echo $device_icon; ?>"></i> <?php echo htmlspecialchars($visit['device_type'] ?? 'Mobile'); ?>
                            </span>
                            <small style="display: block; color: #64748b; font-size: 11px; margin-top: 2px;">
                                <?php echo htmlspecialchars($visit['browser'] ?? 'Chrome'); ?> on <?php echo htmlspecialchars($visit['os'] ?? 'Android'); ?>
                            </small>
                        </td>
                        <td style="padding: 12px 16px;">
                            <?php if ($is_insta) { ?>
                                <span style="background: #fdf2f8; color: #db2777; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; border: 1px solid #fbcfe8; display: inline-flex; align-items: center; gap: 4px;">
                                    <i class="ti-instagram"></i> Instagram
                                </span>
                            <?php } elseif ($is_wa) { ?>
                                <span style="background: #ecfdf5; color: #059669; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; border: 1px solid #a7f3d0; display: inline-flex; align-items: center; gap: 4px;">
                                    <i class="ti-share"></i> WhatsApp
                                </span>
                            <?php } elseif ($is_google) { ?>
                                <span style="background: #eff6ff; color: #2563eb; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; border: 1px solid #bfdbfe; display: inline-flex; align-items: center; gap: 4px;">
                                    <i class="ti-search"></i> Google
                                </span>
                            <?php } else { ?>
                                <span style="background: #f1f5f9; color: #475569; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 600; border: 1px solid #cbd5e1;">
                                    Direct
                                </span>
                            <?php } ?>
                        </td>
                        <td style="padding: 12px 16px; text-align: right; white-space: nowrap; color: #64748b; font-size: 12px;">
                            <?php echo $visit['time_ago']; ?>
                        </td>
                    </tr>
                <?php } 
                } else { ?>
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 35px 20px; color: #94a3b8;">
                            <i class="ti-stats-up" style="font-size: 32px; display: block; margin-bottom: 8px; color: #cbd5e1;"></i>
                            Visitor logs will appear here in real-time as users browse your website.
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- users visite and profile end -->

</div>
</div>
