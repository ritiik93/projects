<?php 
    $search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
    $role_filter = isset($_GET['role_filter']) ? (string) $_GET['role_filter'] : 'all';
    $redirect_params = array();

    if ($search_query !== '') {
        $redirect_params['q'] = $search_query;
    }
    if ($role_filter !== 'all') {
        $redirect_params['role_filter'] = $role_filter;
    }

    $redirect_url = 'manage_user.php';
    if (!empty($redirect_params)) {
        $redirect_url .= '?' . http_build_query($redirect_params);
    }

    if (isset($_GET['status'], $_GET['id'])) {
        $admin_id = (int) $_GET['id'];
        if ($_GET['status'] == 'delete') {
            $del_msg = $obj->delete_admin($admin_id);
            admin_redirect_with_flash($redirect_url, $del_msg, 'info');
        }
    }

    $arry = $obj->show_admin_user();
    $users = array();

    while ($user = mysqli_fetch_assoc($arry)) {
        if ($search_query !== '' && stripos($user['admin_email'], $search_query) === false) {
            continue;
        }

        if ($role_filter !== 'all' && (string) $user['role'] !== $role_filter) {
            continue;
        }

        $users[] = $user;
    }

?>

<div class="container-fluid" style="padding-left: 0; padding-right: 0;">
    <!-- Navigation Tabs -->
    <div style="display: flex; gap: 10px; margin-bottom: 22px; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; align-items: center; justify-content: space-between; flex-wrap: wrap;">
        <div style="display: flex; gap: 8px;">
            <a href="manage_customers.php" class="btn btn-outline-secondary" style="border-radius: 8px; font-weight: 600; padding: 8px 16px; background: #fff; border: 1px solid #cbd5e1; color: #475569;">
                <i class="ti-id-badge" style="margin-right: 5px;"></i> Store Customers (<?php echo $obj->count_all_registered_customers(); ?>)
            </a>
            <a href="manage_user.php" class="btn btn-primary" style="border-radius: 8px; font-weight: 700; padding: 8px 16px;">
                <i class="ti-user" style="margin-right: 5px;"></i> Admin &amp; Staff (<?php echo count($users); ?>)
            </a>
            <a href="add_admin_user.php" class="btn btn-success" style="border-radius: 8px; font-weight: 600; padding: 8px 16px;">
                <i class="ti-plus" style="margin-right: 5px;"></i> Add Admin Staff
            </a>
        </div>
        <div style="font-size: 13px; color: #64748b;">
            <i class="ti-info-alt" style="color: #2563eb; margin-right: 4px;"></i> Managing admin dashboard staff accounts. For store website users, click <strong>Store Customers</strong>.
        </div>
    </div>

    <h2>Manage Admin &amp; Staff Users</h2>
    <form action="" method="get" class="admin-form-card" style="margin-bottom: 18px;">
        <div class="row">
            <div class="col-md-6">
                <label for="q">Search User</label>
                <input type="text" name="q" id="q" class="form-control" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search by email">
            </div>
            <div class="col-md-3">
                <label for="role_filter">Role</label>
                <select name="role_filter" id="role_filter" class="form-control">
                    <option value="all">All Roles</option>
                    <option value="1" <?php if ($role_filter === '1') { echo 'selected'; } ?>>Admin</option>
                    <option value="2" <?php if ($role_filter === '2') { echo 'selected'; } ?>>Moderator</option>
                </select>
            </div>
            <div class="col-md-3">
                <label>&nbsp;</label>
                <div>
                    <button type="submit" class="btn btn-primary">Apply</button>
                    <a href="manage_user.php" class="btn btn-light">Reset</a>
                </div>
            </div>
        </div>
    </form>
    <p><strong><?php echo count($users); ?></strong> user(s) found.</p>
    <table class="table table-bordered">
        <thead>

       
            <tr>
                <th>User Id</th>
                <th>User Email</th>
                <th>User Role</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
        <?php if (empty($users)) { ?>
            <tr>
                <td colspan="4" class="text-center">No users matched your filters.</td>
            </tr>
        <?php } ?>
        <?php foreach ($users as $user) { ?>
            <tr>
                <td> <?php echo $user['admin_id'] ?> </td>
                <td> <?php echo $user['admin_email'] ?> </td>
               
                <td> <?php if($user['role']==1){
                    echo "Admin";
                }else{
                    echo "Moderator";
                } ?> </td>
            
                <td>  
                    <a href="edit_admin.php?status=userEdit&&id=<?php echo $user['admin_id'] ?>" class="btn btn-sm btn-warning">Edit </a>
                    <a href="?<?php echo http_build_query(array_merge($redirect_params, array('status' => 'delete', 'id' => $user['admin_id']))); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this admin user?');">Delete</a>

                </td>
            </tr>

           

            <?php }?>
        </tbody>
    </table>
</div>
