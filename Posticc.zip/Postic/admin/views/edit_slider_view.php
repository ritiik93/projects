<?php
$slide_id = isset($_GET['id']) ? (int) $_GET['id'] : 1;
if (isset($_GET['status']) && $_GET['status'] == "edit" && isset($_GET['id'])) {
    $slide_id = (int) $_GET['id'];
}

$slider_msg = null;
if (isset($_POST['update_slider_btn'])) {
    $slider_msg = $obj->slider_update($_POST);
    if ($slider_msg && stripos($slider_msg, 'success') !== false) {
        admin_redirect_with_flash('manage_slider.php', $slider_msg);
    }
}

$row = $obj->slide_By_id($slide_id);
$slide = ($row && mysqli_num_rows($row) > 0) ? mysqli_fetch_assoc($row) : null;
?>

<div class="row">
    <!-- Top Header & Breadcrumb Card -->
    <div class="col-12" style="margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; background: #ffffff; padding: 20px 26px; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04);">
            <div style="display: flex; align-items: center; gap: 14px;">
                <a href="manage_slider.php" class="btn btn-outline-secondary" style="border-radius: 10px; font-weight: 600; font-size: 13px; padding: 9px 16px; display: inline-flex; align-items: center; gap: 6px; border-color: #cbd5e1; color: #334155;">
                    <i class="ti-arrow-left"></i> Back to Sliders
                </a>
                <div>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <h3 style="margin: 0; font-size: 20px; font-weight: 800; color: #0f172a; letter-spacing: -0.3px;">
                            Edit Homepage Slide
                        </h3>
                        <span style="background: #eff6ff; color: #1d4ed8; padding: 4px 12px; border-radius: 20px; font-size: 13px; font-weight: 800; border: 1px solid #bfdbfe;">
                            Slide #<?php echo htmlspecialchars($slide_id); ?>
                        </span>
                    </div>
                    <p style="margin: 3px 0 0 0; font-size: 13px; color: #64748b;">
                        Update high-resolution banner image artwork, headline typography, and call-to-action buttons.
                    </p>
                </div>
            </div>

            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="display: inline-flex; align-items: center; gap: 6px; background: #ecfdf5; color: #059669; padding: 6px 14px; border-radius: 20px; font-size: 12px; font-weight: 700; border: 1px solid #a7f3d0;">
                    <span style="width: 7px; height: 7px; background: #10b981; border-radius: 50%; display: inline-block;"></span>
                    Live Hero Carousel
                </span>
                <a href="../index.php" target="_blank" class="btn btn-outline-primary" style="border-radius: 8px; font-size: 12px; font-weight: 600; padding: 7px 14px; display: inline-flex; align-items: center; gap: 6px;">
                    <i class="ti-new-window"></i> Preview Storefront
                </a>
            </div>
        </div>
    </div>

    <?php if (!$slide) { ?>
        <div class="col-12">
            <div style="background: #ffffff; border-radius: 14px; border: 1px solid #fee2e2; padding: 40px 24px; text-align: center; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04);">
                <i class="ti-alert" style="font-size: 40px; color: #ef4444; margin-bottom: 12px; display: inline-block;"></i>
                <h4 style="font-size: 18px; font-weight: 700; color: #991b1b; margin-bottom: 8px;">Slider Not Found</h4>
                <p style="color: #64748b; font-size: 14px; max-width: 480px; margin: 0 auto 20px auto;">
                    We couldn't find a slider with ID #<?php echo htmlspecialchars($slide_id); ?> in the database.
                </p>
                <a href="manage_slider.php" class="btn btn-primary" style="border-radius: 8px; font-weight: 700; padding: 9px 20px;">
                    Return to Sliders List
                </a>
            </div>
        </div>
    <?php } else { ?>

        <!-- Alert Notification If Any -->
        <?php if (!empty($slider_msg)) { 
            $is_success = (stripos($slider_msg, 'success') !== false);
            $bg_color = $is_success ? '#ecfdf5' : '#fef2f2';
            $text_color = $is_success ? '#065f46' : '#991b1b';
            $border_color = $is_success ? '#a7f3d0' : '#fecaca';
            $icon = $is_success ? 'ti-check' : 'ti-alert';
        ?>
            <div class="col-12" style="margin-bottom: 20px;">
                <div style="background: <?php echo $bg_color; ?>; color: <?php echo $text_color; ?>; border: 1px solid <?php echo $border_color; ?>; border-radius: 10px; padding: 14px 20px; display: flex; align-items: center; gap: 10px; font-size: 14px; font-weight: 600;">
                    <i class="<?php echo $icon; ?>" style="font-size: 18px;"></i>
                    <span><?php echo htmlspecialchars($slider_msg); ?></span>
                </div>
            </div>
        <?php } ?>

        <!-- Main Edit Form -->
        <div class="col-12">
            <form action="" method="post" enctype="multipart/form-data" id="editSliderForm">
                <input type="hidden" value="<?php echo htmlspecialchars($slide['slider_id']); ?>" name="slider_id">

                <div class="row">
                    <!-- Left Column: Typography & Content Fields -->
                    <div class="col-lg-7 col-md-12" style="margin-bottom: 24px;">
                        <div style="background: #ffffff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04); padding: 26px;">
                            
                            <!-- Section: Headline Typography -->
                            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid #f1f5f9;">
                                <div style="width: 32px; height: 32px; border-radius: 8px; background: #eff6ff; display: flex; align-items: center; justify-content: center;">
                                    <i class="ti-text" style="color: #0b6dc6; font-size: 15px;"></i>
                                </div>
                                <div>
                                    <h4 style="margin: 0; font-size: 15px; font-weight: 700; color: #0f172a;">Slide Headlines &amp; Typography</h4>
                                    <span style="font-size: 12px; color: #64748b;">Text overlays shown on the banner (optional if baked into artwork)</span>
                                </div>
                            </div>

                            <div class="form-group" style="margin-bottom: 18px;">
                                <label for="first_line" style="font-weight: 600; font-size: 13px; color: #334155; margin-bottom: 6px; display: flex; justify-content: space-between;">
                                    <span>First Line <span style="font-weight: 400; color: #64748b;">(Pre-headline / Category tag)</span></span>
                                    <span style="font-size: 11px; color: #94a3b8; font-weight: normal;">Optional</span>
                                </label>
                                <input type="text" 
                                       id="first_line"
                                       name="first_line" 
                                       class="form-control" 
                                       value="<?php echo htmlspecialchars($slide['first_line'] ?? ''); ?>" 
                                       placeholder="e.g. 100% Organic & Freshly Roasted"
                                       style="height: 44px; border-radius: 10px; border: 1px solid #cbd5e1; font-size: 14px; padding: 8px 14px; color: #1e293b;">
                            </div>

                            <div class="form-group" style="margin-bottom: 18px;">
                                <label for="second_line" style="font-weight: 600; font-size: 13px; color: #334155; margin-bottom: 6px; display: flex; justify-content: space-between;">
                                    <span>Second Line <span style="font-weight: 400; color: #64748b;">(Main Catchy Title)</span></span>
                                    <span style="font-size: 11px; color: #94a3b8; font-weight: normal;">Optional</span>
                                </label>
                                <input type="text" 
                                       id="second_line"
                                       name="second_line" 
                                       class="form-control" 
                                       value="<?php echo htmlspecialchars($slide['second_line'] ?? ''); ?>" 
                                       placeholder="e.g. Premium Crunchy Makhana Flavors"
                                       style="height: 44px; border-radius: 10px; border: 1px solid #cbd5e1; font-size: 14px; padding: 8px 14px; color: #1e293b;">
                            </div>

                            <div class="form-group" style="margin-bottom: 24px;">
                                <label for="third_line" style="font-weight: 600; font-size: 13px; color: #334155; margin-bottom: 6px; display: flex; justify-content: space-between;">
                                    <span>Third Line <span style="font-weight: 400; color: #64748b;">(Promotional Offer / Subtext)</span></span>
                                    <span style="font-size: 11px; color: #94a3b8; font-weight: normal;">Optional</span>
                                </label>
                                <input type="text" 
                                       id="third_line"
                                       name="third_line" 
                                       class="form-control" 
                                       value="<?php echo htmlspecialchars($slide['third_line'] ?? ''); ?>" 
                                       placeholder="e.g. Get Flat 15% OFF On First Order - Use Code: POSTIC15"
                                       style="height: 44px; border-radius: 10px; border: 1px solid #cbd5e1; font-size: 14px; padding: 8px 14px; color: #1e293b;">
                            </div>

                            <!-- Section: Call-To-Action Buttons -->
                            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid #f1f5f9;">
                                <div style="width: 32px; height: 32px; border-radius: 8px; background: #fef2f2; display: flex; align-items: center; justify-content: center;">
                                    <i class="ti-mouse-alt" style="color: #d32f2f; font-size: 15px;"></i>
                                </div>
                                <div>
                                    <h4 style="margin: 0; font-size: 15px; font-weight: 700; color: #0f172a;">Call-To-Action Buttons</h4>
                                    <span style="font-size: 12px; color: #64748b;">Interactive buttons rendered on the slide (links to store catalog)</span>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group" style="margin-bottom: 18px;">
                                        <label for="btn_left" style="font-weight: 600; font-size: 13px; color: #334155; margin-bottom: 6px;">
                                            Left Button Label
                                        </label>
                                        <input type="text" 
                                               id="btn_left"
                                               name="btn_left" 
                                               class="form-control" 
                                               value="<?php echo htmlspecialchars($slide['btn_left'] ?? ''); ?>" 
                                               placeholder="e.g. Shop Now"
                                               style="height: 44px; border-radius: 10px; border: 1px solid #cbd5e1; font-size: 14px; padding: 8px 14px; color: #1e293b;">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group" style="margin-bottom: 18px;">
                                        <label for="btn_right" style="font-weight: 600; font-size: 13px; color: #334155; margin-bottom: 6px;">
                                            Right Button Label
                                        </label>
                                        <input type="text" 
                                               id="btn_right"
                                               name="btn_right" 
                                               class="form-control" 
                                               value="<?php echo htmlspecialchars($slide['btn_right'] ?? ''); ?>" 
                                               placeholder="e.g. View All Products"
                                               style="height: 44px; border-radius: 10px; border: 1px solid #cbd5e1; font-size: 14px; padding: 8px 14px; color: #1e293b;">
                                    </div>
                                </div>
                            </div>

                            <div style="background: #f8fafc; border-radius: 10px; padding: 12px 16px; border: 1px solid #e2e8f0; font-size: 12px; color: #64748b; line-height: 1.5;">
                                <i class="ti-info" style="color: #0b6dc6; margin-right: 4px;"></i>
                                Tip: If your banner artwork graphic already includes its own headings and buttons inside the image, you can leave these text boxes empty or use them for SEO.
                            </div>
                        </div>
                    </div>

                    <!-- Right Column: Banner Visual Artwork & Live Upload Preview -->
                    <div class="col-lg-5 col-md-12" style="margin-bottom: 24px;">
                        <div style="background: #ffffff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04); padding: 26px;">
                            
                            <!-- Section: Banner Graphic -->
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; padding-bottom: 14px; border-bottom: 1px solid #f1f5f9;">
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <div style="width: 32px; height: 32px; border-radius: 8px; background: #ecfdf5; display: flex; align-items: center; justify-content: center;">
                                        <i class="ti-image" style="color: #059669; font-size: 15px;"></i>
                                    </div>
                                    <h4 style="margin: 0; font-size: 15px; font-weight: 700; color: #0f172a;">Banner Image Artwork</h4>
                                </div>
                                <span id="previewStatusBadge" style="font-size: 11px; font-weight: 700; background: #ecfdf5; color: #059669; padding: 3px 10px; border-radius: 12px; border: 1px solid #a7f3d0;">
                                    Current Artwork
                                </span>
                            </div>

                            <!-- Live Banner Preview Frame -->
                            <div style="margin-bottom: 18px;">
                                <div style="position: relative; width: 100%; border-radius: 12px; overflow: hidden; border: 2px solid #e2e8f0; background: #f8fafc; box-shadow: 0 4px 12px rgba(0,0,0,0.06);">
                                    <img id="bannerLivePreview" 
                                         src="uploads/<?php echo htmlspecialchars($slide['slider_img'] ?? ''); ?>" 
                                         alt="Banner Preview" 
                                         style="width: 100%; height: 160px; object-fit: cover; display: block; transition: all 0.2s ease;"
                                         onerror="this.src='https://placehold.co/1920x550?text=Banner+Not+Found';">
                                    <div style="padding: 8px 12px; background: #ffffff; border-top: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #64748b;">
                                        <span id="currentFilenameText" style="font-family: monospace; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 200px;">
                                            <?php echo htmlspecialchars($slide['slider_img'] ?? 'No file'); ?>
                                        </span>
                                        <a id="currentFileLink" href="uploads/<?php echo htmlspecialchars($slide['slider_img'] ?? ''); ?>" target="_blank" style="color: #0b6dc6; font-weight: 700; text-decoration: none;">
                                            <i class="ti-fullscreen"></i> Full View
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Interactive File Upload Picker -->
                            <div class="form-group" style="margin-bottom: 16px;">
                                <label style="font-weight: 600; font-size: 13px; color: #334155; margin-bottom: 8px; display: block;">
                                    Upload Replacement Banner <span style="font-size: 11px; color: #64748b; font-weight: normal;">(Optional)</span>
                                </label>
                                
                                <div id="dropZoneBox" style="border: 2px dashed #cbd5e1; border-radius: 12px; padding: 22px 16px; text-align: center; background: #f8fafc; cursor: pointer; transition: all 0.2s ease;" onclick="document.getElementById('sliderImgInput').click();">
                                    <div style="width: 48px; height: 48px; margin: 0 auto 10px auto; border-radius: 50%; background: #eff6ff; display: flex; align-items: center; justify-content: center;">
                                        <i class="ti-cloud-up" style="font-size: 24px; color: #0b6dc6;"></i>
                                    </div>
                                    <div style="font-weight: 700; font-size: 14px; color: #1e293b; margin-bottom: 4px;">
                                        Click here to choose new image
                                    </div>
                                    <div style="font-size: 12px; color: #64748b; margin-bottom: 10px;">
                                        or drag &amp; drop your image file here
                                    </div>
                                    <div style="display: flex; justify-content: center; gap: 6px; flex-wrap: wrap;">
                                        <span style="background: #e2e8f0; color: #475569; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 4px;">PNG</span>
                                        <span style="background: #e2e8f0; color: #475569; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 4px;">JPG / JPEG</span>
                                        <span style="background: #e2e8f0; color: #475569; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 4px;">WEBP</span>
                                        <span style="background: #e2e8f0; color: #475569; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 4px;">GIF</span>
                                    </div>
                                </div>

                                <!-- Hidden actual file input -->
                                <input type="file" 
                                       id="sliderImgInput" 
                                       name="slider_img" 
                                       accept="image/jpeg,image/png,image/webp,image/gif"
                                       style="display: none;">
                                
                                <small style="display: block; margin-top: 8px; font-size: 12px; color: #64748b; line-height: 1.4;">
                                    Leave empty if you only want to change the text content or buttons without changing the image.
                                </small>
                            </div>

                            <!-- Recommended Dimension Notes -->
                            <div style="background: #fffbeb; border: 1px solid #fef3c7; border-radius: 10px; padding: 12px 14px;">
                                <div style="display: flex; align-items: flex-start; gap: 8px;">
                                    <i class="ti-light-bulb" style="color: #d97706; font-size: 16px; margin-top: 2px;"></i>
                                    <div style="font-size: 12px; color: #92400e; line-height: 1.5;">
                                        <strong>Recommended Dimensions:</strong> <code>1920 &times; 550 px</code><br>
                                        Aspect Ratio ~3.5:1. Postic's responsive homepage ensures complete edge-to-edge artwork clarity without cropping.
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Bottom Action Buttons Card -->
                    <div class="col-12">
                        <div style="background: #ffffff; border-radius: 14px; border: 1px solid #e2e8f0; box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04); padding: 18px 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
                            <a href="manage_slider.php" class="btn btn-light" style="border-radius: 10px; font-weight: 600; font-size: 14px; padding: 10px 22px; color: #475569; border: 1px solid #cbd5e1;">
                                <i class="ti-close"></i> Cancel
                            </a>
                            
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <span style="font-size: 12px; color: #64748b;" id="saveHint">
                                    Changes will immediately reflect on the live storefront carousel.
                                </span>
                                <button type="submit" 
                                        name="update_slider_btn" 
                                        class="btn btn-primary btn-lg" 
                                        style="border-radius: 10px; font-weight: 700; font-size: 14px; padding: 12px 28px; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 4px 12px rgba(255,83,112,0.35);">
                                    <i class="ti-check"></i> Save &amp; Update Slide
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    <?php } ?>
</div>

<!-- JavaScript for Live Instant Banner Preview and Drag & Drop -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    var fileInput = document.getElementById('sliderImgInput');
    var livePreview = document.getElementById('bannerLivePreview');
    var filenameText = document.getElementById('currentFilenameText');
    var badge = document.getElementById('previewStatusBadge');
    var dropZone = document.getElementById('dropZoneBox');

    if (!fileInput || !livePreview) return;

    function handleFile(file) {
        if (!file) return;

        // Verify image type
        if (!file.type.match(/^image\//)) {
            alert('Please select a valid image file (PNG, JPG, WEBP, or GIF).');
            return;
        }

        // Verify file size (10MB limit)
        if (file.size > 10 * 1024 * 1024) {
            alert('File size exceeds 10MB limit. Please choose an optimized image.');
            return;
        }

        var reader = new FileReader();
        reader.onload = function (e) {
            livePreview.src = e.target.result;
            livePreview.style.transform = 'scale(0.98)';
            setTimeout(function() {
                livePreview.style.transform = 'scale(1)';
            }, 150);

            if (filenameText) {
                var sizeKB = (file.size / 1024).toFixed(1);
                filenameText.textContent = file.name + ' (' + sizeKB + ' KB)';
                filenameText.style.color = '#059669';
                filenameText.style.fontWeight = 'bold';
            }

            if (badge) {
                badge.textContent = 'New Image Selected';
                badge.style.background = '#eff6ff';
                badge.style.color = '#1d4ed8';
                badge.style.borderColor = '#bfdbfe';
            }

            if (dropZone) {
                dropZone.style.borderColor = '#10b981';
                dropZone.style.background = '#ecfdf5';
            }
        };
        reader.readAsDataURL(file);
    }

    fileInput.addEventListener('change', function () {
        if (this.files && this.files[0]) {
            handleFile(this.files[0]);
        }
    });

    if (dropZone) {
        // Drag over
        ['dragenter', 'dragover'].forEach(function(eventName) {
            dropZone.addEventListener(eventName, function(e) {
                e.preventDefault();
                e.stopPropagation();
                dropZone.style.borderColor = '#0b6dc6';
                dropZone.style.background = '#eff6ff';
            }, false);
        });

        // Drag leave
        ['dragleave', 'drop'].forEach(function(eventName) {
            dropZone.addEventListener(eventName, function(e) {
                e.preventDefault();
                e.stopPropagation();
                dropZone.style.borderColor = '#cbd5e1';
                dropZone.style.background = '#f8fafc';
            }, false);
        });

        // Drop
        dropZone.addEventListener('drop', function(e) {
            var dt = e.dataTransfer;
            var files = dt.files;
            if (files && files.length > 0) {
                fileInput.files = files;
                handleFile(files[0]);
            }
        }, false);
    }
});
</script>
