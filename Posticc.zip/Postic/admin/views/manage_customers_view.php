<?php 
    $search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
    $order_filter = isset($_GET['order_filter']) ? (string) $_GET['order_filter'] : 'all';
    $redirect_params = array();

    if ($search_query !== '') {
        $redirect_params['q'] = $search_query;
    }
    if ($order_filter !== 'all') {
        $redirect_params['order_filter'] = $order_filter;
    }

    $redirect_url = 'manage_customers.php';
    if (!empty($redirect_params)) {
        $redirect_url .= '?' . http_build_query($redirect_params);
    }

    // Handle Customer Deletion
    if (isset($_GET['status'], $_GET['id']) && $_GET['status'] == 'delete') {
        $del_id = (int) $_GET['id'];
        $del_msg = $obj->delete_registered_customer($del_id);
        admin_redirect_with_flash($redirect_url, $del_msg, 'info');
    }

    $customer_query = $obj->show_all_customers($search_query, $order_filter);
    $customers = array();
    $total_all_orders = 0;
    $total_all_revenue = 0;

    if ($customer_query) {
        while ($c = mysqli_fetch_assoc($customer_query)) {
            $customers[] = $c;
            $total_all_orders += (int)$c['total_orders'];
            $total_all_revenue += (float)$c['total_spent'];
        }
    }

    $total_registered_count = $obj->count_all_registered_customers();
?>

<div class="container-fluid" style="padding-left: 0; padding-right: 0;">
    <!-- Navigation Tabs -->
    <div style="display: flex; gap: 10px; margin-bottom: 22px; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; align-items: center; justify-content: space-between; flex-wrap: wrap;">
        <div style="display: flex; gap: 8px;">
            <a href="manage_customers.php" class="btn btn-primary" style="border-radius: 8px; font-weight: 700; padding: 8px 16px;">
                <i class="ti-id-badge" style="margin-right: 5px;"></i> Store Customers (<?php echo $total_registered_count; ?>)
            </a>
            <a href="manage_user.php" class="btn btn-outline-secondary" style="border-radius: 8px; font-weight: 600; padding: 8px 16px; background: #fff; border: 1px solid #cbd5e1; color: #475569;">
                <i class="ti-user" style="margin-right: 5px;"></i> Admin &amp; Staff
            </a>
        </div>
        <div style="font-size: 13px; color: #64748b;">
            <i class="ti-shield" style="color: #16a34a; margin-right: 4px;"></i> Customer Accounts verified via Postic Email OTP
        </div>
    </div>

    <!-- Summary Statistics Cards -->
    <div class="row" style="margin-bottom: 15px;">
        <div class="col-md-4 col-sm-6">
            <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px 20px; box-shadow: 0 4px 14px rgba(15,23,42,0.03); margin-bottom: 15px; border-left: 4px solid #d32f2f;">
                <div style="font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Registered Customers</div>
                <div style="font-size: 26px; font-weight: 800; color: #1e293b; margin-top: 4px;"><?php echo count($customers); ?> <span style="font-size: 13px; font-weight: 500; color: #94a3b8;">/ <?php echo $total_registered_count; ?> total</span></div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px 20px; box-shadow: 0 4px 14px rgba(15,23,42,0.03); margin-bottom: 15px; border-left: 4px solid #2563eb;">
                <div style="font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Customer Orders Placed</div>
                <div style="font-size: 26px; font-weight: 800; color: #1e293b; margin-top: 4px;"><?php echo $total_all_orders; ?> <span style="font-size: 13px; font-weight: 500; color: #94a3b8;">parcels</span></div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6">
            <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px 20px; box-shadow: 0 4px 14px rgba(15,23,42,0.03); margin-bottom: 15px; border-left: 4px solid #16a34a;">
                <div style="font-size: 12px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">Total Customer Spend</div>
                <div style="font-size: 26px; font-weight: 800; color: #1e293b; margin-top: 4px;">₹<?php echo number_format($total_all_revenue, 2); ?></div>
            </div>
        </div>
    </div>

    <!-- Search & Filter Card -->
    <div class="admin-form-card" style="margin-bottom: 22px;">
        <form action="" method="get">
            <div class="row" style="align-items: flex-end;">
                <div class="col-md-5 col-sm-12" style="margin-bottom: 10px;">
                    <label for="q" style="font-weight: 700; color: #334155; font-size: 13px;">Search Customers</label>
                    <input type="text" name="q" id="q" class="form-control" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search by name, email, phone, location...">
                </div>
                <div class="col-md-4 col-sm-6" style="margin-bottom: 10px;">
                    <label for="order_filter" style="font-weight: 700; color: #334155; font-size: 13px;">Order Status Filter</label>
                    <select name="order_filter" id="order_filter" class="form-control">
                        <option value="all" <?php echo ($order_filter === 'all') ? 'selected' : ''; ?>>All Customers</option>
                        <option value="with_orders" <?php echo ($order_filter === 'with_orders') ? 'selected' : ''; ?>>Has Placed Orders</option>
                        <option value="without_orders" <?php echo ($order_filter === 'without_orders') ? 'selected' : ''; ?>>New Signups (No Orders Yet)</option>
                    </select>
                </div>
                <div class="col-md-3 col-sm-6" style="margin-bottom: 10px;">
                    <div style="display: flex; gap: 8px;">
                        <button type="submit" class="btn btn-primary" style="flex: 1; border-radius: 8px; font-weight: 600;">
                            <i class="ti-search"></i> Apply
                        </button>
                        <a href="manage_customers.php" class="btn btn-light" style="border-radius: 8px; font-weight: 600; border: 1px solid #cbd5e1;">Reset</a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <!-- Customers List Table -->
    <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 4px 20px rgba(15,23,42,0.04);">
        <div style="padding: 18px 24px; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
            <div>
                <h4 style="margin: 0; font-size: 17px; font-weight: 800; color: #1e293b;">
                    <i class="ti-id-badge" style="color: #d32f2f; margin-right: 6px;"></i> Registered Store Customers
                </h4>
                <p style="margin: 4px 0 0 0; font-size: 13px; color: #64748b;">
                    Customers registered on Postic Foods website. Showing <strong><?php echo count($customers); ?></strong> result(s).
                </p>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover" style="margin-bottom: 0;">
                <thead style="background: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                    <tr>
                        <th style="padding: 14px 16px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase;">ID</th>
                        <th style="padding: 14px 16px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase;">Customer</th>
                        <th style="padding: 14px 16px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase;">Contact Info</th>
                        <th style="padding: 14px 16px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase;">Saved Address / Location</th>
                        <th style="padding: 14px 16px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase; text-align: center;">Orders &amp; Spend</th>
                        <th style="padding: 14px 16px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase; text-align: center;">Joined Date</th>
                        <th style="padding: 14px 16px; font-size: 12px; font-weight: 700; color: #475569; text-transform: uppercase; text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($customers)) { ?>
                        <tr>
                            <td colspan="7" class="text-center" style="padding: 40px 20px;">
                                <div style="font-size: 42px; color: #cbd5e1; margin-bottom: 12px;"><i class="ti-user"></i></div>
                                <h5 style="color: #475569; font-weight: 700;">No customers found</h5>
                                <p style="color: #94a3b8; font-size: 13px; margin: 0;">Try adjusting your search criteria or register a new account on the store.</p>
                            </td>
                        </tr>
                    <?php } else { ?>
                        <?php foreach ($customers as $c) { 
                            $fullName = trim($c['user_firstname'] . ' ' . $c['user_lastname']);
                            if (empty($fullName)) {
                                $fullName = $c['user_name'];
                            }
                            $ordersCount = (int)$c['total_orders'];
                            $spend = (float)$c['total_spent'];
                            $joinedDate = !empty($c['created_at']) ? date("d M Y, h:i A", strtotime($c['created_at'])) : 'N/A';
                            
                            // Determine primary display address
                            $displayAddr = !empty($c['user_address']) ? $c['user_address'] : (!empty($c['home_address']) ? $c['home_address'] : $c['office_address']);
                        ?>
                            <tr style="border-bottom: 1px solid #f1f5f9;">
                                <td style="padding: 14px 16px; font-weight: 700; color: #64748b;">
                                    #<?php echo $c['user_id']; ?>
                                </td>
                                <td style="padding: 14px 16px;">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 38px; height: 38px; border-radius: 50%; background: #fef2f2; color: #d32f2f; font-weight: 800; display: flex; align-items: center; justify-content: center; font-size: 15px; border: 1px solid #fecaca; flex-shrink: 0;">
                                            <?php echo strtoupper(substr($fullName, 0, 1)); ?>
                                        </div>
                                        <div>
                                            <strong style="color: #0f172a; font-size: 14px; display: block; line-height: 1.3;">
                                                <?php echo htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8'); ?>
                                            </strong>
                                            <span style="font-size: 12px; color: #64748b;">@<?php echo htmlspecialchars($c['user_name'], ENT_QUOTES, 'UTF-8'); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td style="padding: 14px 16px;">
                                    <div style="font-size: 13px; color: #0f172a; margin-bottom: 3px;">
                                        <i class="ti-email" style="color: #d32f2f; margin-right: 5px;"></i>
                                        <a href="mailto:<?php echo htmlspecialchars($c['user_email'], ENT_QUOTES, 'UTF-8'); ?>" style="color: #2563eb; text-decoration: none;">
                                            <?php echo htmlspecialchars($c['user_email'], ENT_QUOTES, 'UTF-8'); ?>
                                        </a>
                                    </div>
                                    <div style="font-size: 12px; color: #64748b;">
                                        <i class="ti-mobile" style="color: #16a34a; margin-right: 5px;"></i>
                                        <?php if (!empty($c['user_mobile'])) { ?>
                                            <strong><?php echo htmlspecialchars($c['user_mobile'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                        <?php } else { ?>
                                            <span style="color: #94a3b8; font-style: italic;">Not added yet</span>
                                        <?php } ?>
                                    </div>
                                </td>
                                <td style="padding: 14px 16px; max-width: 260px;">
                                    <?php if (!empty($displayAddr)) { ?>
                                        <div style="font-size: 12px; color: #334155; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" title="<?php echo htmlspecialchars($displayAddr, ENT_QUOTES, 'UTF-8'); ?>">
                                            <i class="ti-location-pin" style="color: #d32f2f; margin-right: 4px;"></i>
                                            <?php echo htmlspecialchars($displayAddr, ENT_QUOTES, 'UTF-8'); ?>
                                        </div>
                                        <?php if (!empty($c['home_address']) && !empty($c['office_address'])) { ?>
                                            <span class="badge badge-light" style="font-size: 10px; border: 1px solid #cbd5e1; margin-top: 4px;">Home + Office Saved</span>
                                        <?php } ?>
                                    <?php } else { ?>
                                        <span style="color: #94a3b8; font-size: 12px; font-style: italic;">No address saved yet</span>
                                    <?php } ?>
                                </td>
                                <td style="padding: 14px 16px; text-align: center;">
                                    <?php if ($ordersCount > 0) { ?>
                                        <a href="manage_order.php?q=<?php echo urlencode($c['user_email']); ?>" class="badge badge-success" style="font-size: 12px; padding: 5px 10px; border-radius: 12px; text-decoration: none;" title="View all orders by this customer">
                                            <?php echo $ordersCount; ?> order(s)
                                        </a>
                                        <div style="font-size: 12px; font-weight: 700; color: #16a34a; margin-top: 4px;">
                                            ₹<?php echo number_format($spend, 0); ?>
                                        </div>
                                    <?php } else { ?>
                                        <span class="badge badge-secondary" style="font-size: 11px; padding: 4px 8px; border-radius: 10px; background: #f1f5f9; color: #64748b; border: 1px solid #e2e8f0;">
                                            0 orders
                                        </span>
                                    <?php } ?>
                                </td>
                                <td style="padding: 14px 16px; text-align: center; font-size: 12px; color: #64748b;">
                                    <?php echo $joinedDate; ?>
                                </td>
                                <td style="padding: 14px 16px; text-align: center;">
                                    <div style="display: flex; gap: 6px; justify-content: center;">
                                        <?php if ($ordersCount > 0) { ?>
                                            <a href="manage_order.php?q=<?php echo urlencode($c['user_email']); ?>" class="btn btn-sm btn-info" title="View Orders" style="padding: 5px 9px; font-size: 11px;">
                                                <i class="ti-shopping-cart"></i> Orders
                                            </a>
                                        <?php } ?>
                                        <a href="?<?php echo http_build_query(array_merge($redirect_params, array('status' => 'delete', 'id' => $c['user_id']))); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete customer <?php echo htmlspecialchars(addslashes($fullName)); ?> (#<?php echo $c['user_id']; ?>)?');" title="Delete Customer" style="padding: 5px 9px; font-size: 11px;">
                                            <i class="ti-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

