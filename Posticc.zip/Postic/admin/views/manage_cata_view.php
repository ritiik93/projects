
  

<?php 

    $search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
    $status_filter = isset($_GET['status_filter']) ? (string) $_GET['status_filter'] : 'all';
    $redirect_params = array();

    if ($search_query !== '') {
        $redirect_params['q'] = $search_query;
    }
    if ($status_filter !== 'all') {
        $redirect_params['status_filter'] = $status_filter;
    }

    $redirect_url = 'manage_cata.php';
    if (!empty($redirect_params)) {
        $redirect_url .= '?' . http_build_query($redirect_params);
    }

    if (isset($_GET['status'], $_GET['id'])) {
        $get_id = (int) $_GET['id'];
        if ($_GET['status'] == "published") {
            $obj->catagory_published($get_id);
            admin_redirect_with_flash($redirect_url, 'Category published successfully');
        } elseif ($_GET['status'] == "unpublished") {
            $obj->catagory_unpublished($get_id);
            admin_redirect_with_flash($redirect_url, 'Category unpublished successfully', 'info');
        } elseif ($_GET['status'] == "delete") {
            $obj->delete_catagory($get_id);
            admin_redirect_with_flash($redirect_url, 'Category deleted successfully', 'info');
        }
    }

    $catagories = $obj->display_catagory();
    $category_rows = array();

    while ($category = mysqli_fetch_assoc($catagories)) {
        if ($search_query !== '' && stripos($category['ctg_name'], $search_query) === false && stripos($category['ctg_des'], $search_query) === false) {
            continue;
        }

        if ($status_filter !== 'all' && (string) $category['ctg_status'] !== $status_filter) {
            continue;
        }

        $category_rows[] = $category;
    }

?>
<div >
    <form action="" method="get" class="admin-form-card" style="margin-bottom: 18px;">
        <div class="row">
            <div class="col-md-5">
                <label for="q">Search Category</label>
                <input type="text" name="q" id="q" class="form-control" value="<?php echo htmlspecialchars($search_query, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search by name or description">
            </div>
            <div class="col-md-3">
                <label for="status_filter">Status</label>
                <select name="status_filter" id="status_filter" class="form-control">
                    <option value="all">All Statuses</option>
                    <option value="1" <?php if ($status_filter === '1') { echo 'selected'; } ?>>Published</option>
                    <option value="0" <?php if ($status_filter === '0') { echo 'selected'; } ?>>Unpublished</option>
                </select>
            </div>
            <div class="col-md-4">
                <label>&nbsp;</label>
                <div>
                    <button type="submit" class="btn btn-primary">Apply</button>
                    <a href="manage_cata.php" class="btn btn-light">Reset</a>
                </div>
            </div>
        </div>
    </form>
    <p><strong><?php echo count($category_rows); ?></strong> category(s) found.</p>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Category Name</th>
                <th>Category Description</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
           <?php if (empty($category_rows)) { ?>
            <tr>
                <td colspan="5" class="text-center">No categories matched your filters.</td>
            </tr>
           <?php } ?>
           <?php foreach ($category_rows as $ctg) { ?>
            <tr>
                <td><?php echo $ctg['ctg_id'] ?></td>
                <td><?php echo $ctg['ctg_name'] ?></td>
                <td><?php echo $ctg['ctg_des'] ?></td>
                <td>
                    <?php 
                    if($ctg['ctg_status']==0)
                    {echo "Unpublished";
                    
                         ?> 
                         <a href="?<?php echo http_build_query(array_merge($redirect_params, array('status' => 'published', 'id' => $ctg['ctg_id']))); ?>" class="btn btn-sm btn-success">Make Published</a>
                        <?php
                    } 
                    else{echo "Published";
                    
                    ?>
                     <a href="?<?php echo http_build_query(array_merge($redirect_params, array('status' => 'unpublished', 'id' => $ctg['ctg_id']))); ?>" class="btn btn-sm btn-warning">Make Unpublished</a>
                        <?php 
                    }  
                    
                    ?>
                
                </td>
                <td>
                    <a href="edit_cata.php?status=edit&&id=<?php echo $ctg['ctg_id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                         <a href="?<?php echo http_build_query(array_merge($redirect_params, array('status' => 'delete', 'id' => $ctg['ctg_id']))); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this category?');">Delete</a>
                </td>
               
            </tr>
            <?php 
                }
            ?>
           
        </tbody>
    </table>
</div>
