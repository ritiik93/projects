<?php 
    $views = "mail_settings";
    include ("template.php");
?>
