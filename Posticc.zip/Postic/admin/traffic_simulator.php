<?php
/**
 * =========================================================================================
 * POSTIC DEDICATED TRAFFIC SIMULATION DASHBOARD & OPERATOR CONSOLE
 * =========================================================================================
 * Route: /admin/traffic-simulator or admin/traffic_simulator.php
 * Completely isolated operator authentication & controls.
 * =========================================================================================
 */

require_once dirname(__DIR__) . '/includes/operator_auth.php';
require_once dirname(__DIR__) . '/includes/traffic_simulator_service.php';

$simulator = PosticTrafficSimulator::get_instance();
$login_error = '';
$logout_success = '';

// Handle Logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    operator_logout();
    header("Location: traffic_simulator.php?logged_out=1");
    exit();
}

if (isset($_GET['logged_out'])) {
    $logout_success = "You have been logged out of the Traffic Simulator Console safely.";
}

// Handle Operator Login Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['operator_login_btn'])) {
    $token = $_POST['csrf_token'] ?? '';
    if (!operator_verify_csrf_token($token)) {
        $login_error = "Session expired or invalid security token. Please try again.";
    } else {
        $email = trim($_POST['operator_email'] ?? '');
        $pass  = $_POST['operator_password'] ?? '';

        $auth_res = operator_authenticate($email, $pass);
        if ($auth_res['success']) {
            header("Location: traffic_simulator.php");
            exit();
        } else {
            $login_error = $auth_res['error'] ?? "Invalid operator credentials.";
        }
    }
}

$is_auth = operator_is_authenticated();
$csrf_token = operator_get_csrf_token();
$state = $simulator->get_state();
$bounds = $simulator->get_range_bounds($state);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Postic Traffic Simulator | Operator Console</title>
    <link rel="icon" type="image/x-icon" href="../favicon.ico">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- Themify Icons for admin consistency -->
    <link rel="stylesheet" type="text/css" href="assets/icon/themify-icons/themify-icons.css">
    
    <style>
        :root {
            --brand-crimson: #c8102e;
            --brand-crimson-dark: #9b0b21;
            --brand-gold: #f59e0b;
            --brand-gold-dark: #d97706;
            --bg-canvas: #0b0f19;
            --bg-card: #131b2e;
            --bg-card-subtle: #1a243b;
            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --border-line: #26334d;
            --success: #10b981;
            --success-glow: rgba(16, 185, 129, 0.25);
            --danger: #ef4444;
            --danger-glow: rgba(239, 68, 68, 0.25);
            --card-radius: 16px;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background-color: var(--bg-canvas);
            color: var(--text-primary);
            min-height: 100vh;
            line-height: 1.5;
            -webkit-font-smoothing: antialiased;
        }

        /* ------------------------------------------------------------------ */
        /* Operator Login View Styling */
        /* ------------------------------------------------------------------ */
        .login-wrap {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            background: radial-gradient(circle at 50% 20%, #1e293b 0%, #0b0f19 80%);
        }

        .login-card {
            width: 100%;
            max-width: 440px;
            background: var(--bg-card);
            border: 1px solid var(--border-line);
            border-radius: var(--card-radius);
            padding: 40px 32px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.05);
            position: relative;
            overflow: hidden;
        }

        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--brand-crimson), var(--brand-gold));
        }

        .login-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(200, 16, 46, 0.15);
            color: #ff6b81;
            border: 1px solid rgba(200, 16, 46, 0.35);
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            margin-bottom: 16px;
        }

        .login-title {
            font-size: 24px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 8px;
        }

        .login-sub {
            font-size: 13px;
            color: var(--text-secondary);
            margin-bottom: 28px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 12px;
            font-weight: 700;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }

        .form-input {
            width: 100%;
            background: var(--bg-card-subtle);
            border: 1px solid var(--border-line);
            border-radius: 10px;
            padding: 13px 16px;
            color: #ffffff;
            font-size: 14px;
            outline: none;
            transition: all 0.2s ease;
        }

        .form-input:focus {
            border-color: var(--brand-crimson);
            box-shadow: 0 0 0 3px rgba(200, 16, 46, 0.2);
            background: #202b44;
        }

        .login-btn {
            width: 100%;
            background: linear-gradient(135deg, var(--brand-crimson) 0%, var(--brand-crimson-dark) 100%);
            color: #ffffff;
            border: none;
            border-radius: 10px;
            padding: 14px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 4px 15px rgba(200, 16, 46, 0.4);
            margin-top: 10px;
        }

        .login-btn:hover {
            filter: brightness(1.1);
            transform: translateY(-1px);
        }

        .login-btn:active {
            transform: translateY(1px);
        }

        .alert-box {
            padding: 12px 16px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert-danger {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.35);
            color: #fca5a5;
        }

        .alert-success {
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.35);
            color: #6ee7b7;
        }

        .security-notice {
            margin-top: 24px;
            padding-top: 20px;
            border-top: 1px solid var(--border-line);
            font-size: 11px;
            color: var(--text-muted);
            text-align: center;
            line-height: 1.5;
        }

        /* ------------------------------------------------------------------ */
        /* Operator Dashboard Console Layout */
        /* ------------------------------------------------------------------ */
        .dash-header {
            background: var(--bg-card);
            border-bottom: 1px solid var(--border-line);
            padding: 16px 28px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .dash-header-inner {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 16px;
        }

        .brand-box {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-logo-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--brand-crimson), var(--brand-gold));
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 20px;
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(200, 16, 46, 0.3);
        }

        .brand-title {
            font-size: 18px;
            font-weight: 800;
            letter-spacing: -0.3px;
            color: #ffffff;
            line-height: 1.2;
        }

        .brand-sub {
            font-size: 12px;
            color: var(--text-secondary);
        }

        .dash-nav-actions {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .operator-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--bg-card-subtle);
            border: 1px solid var(--border-line);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            color: var(--text-secondary);
        }

        .operator-pill strong {
            color: #ffffff;
        }

        .btn-view-preview {
            background: #1e293b;
            color: #38bdf8;
            border: 1px solid #0284c7;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-view-preview:hover {
            background: #0284c7;
            color: #ffffff;
        }

        .btn-logout {
            background: rgba(239, 68, 68, 0.15);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.3);
            padding: 8px 14px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-logout:hover {
            background: var(--danger);
            color: #ffffff;
        }

        /* Container & Layout */
        .dash-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 28px 24px 60px;
        }

        .grid-main {
            display: grid;
            grid-template-columns: 1fr;
            gap: 24px;
        }

        @media (min-width: 1024px) {
            .grid-main {
                grid-template-columns: 1.15fr 0.85fr;
            }
        }

        /* Console Cards */
        .console-card {
            background: var(--bg-card);
            border: 1px solid var(--border-line);
            border-radius: var(--card-radius);
            padding: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            margin-bottom: 24px;
            position: relative;
        }

        .card-header-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 12px;
        }

        .card-title {
            font-size: 16px;
            font-weight: 800;
            color: #ffffff;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Big Toggle Section */
        .toggle-box {
            background: var(--bg-card-subtle);
            border: 1px solid var(--border-line);
            border-radius: 12px;
            padding: 20px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px;
            gap: 20px;
            flex-wrap: wrap;
        }

        .toggle-label-wrap h4 {
            font-size: 18px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 4px;
        }

        .toggle-label-wrap p {
            font-size: 13px;
            color: var(--text-secondary);
        }

        /* Switch */
        .switch {
            position: relative;
            display: inline-block;
            width: 72px;
            height: 38px;
            flex-shrink: 0;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #334155;
            transition: 0.3s;
            border-radius: 38px;
            border: 2px solid #475569;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: 0.3s;
            border-radius: 50%;
            box-shadow: 0 2px 5px rgba(0,0,0,0.4);
        }

        input:checked + .slider {
            background-color: var(--success);
            border-color: #059669;
            box-shadow: 0 0 16px var(--success-glow);
        }

        input:checked + .slider:before {
            transform: translateX(34px);
        }

        /* Status Badge */
        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 800;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }

        .status-active {
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
            border: 1px solid rgba(16, 185, 129, 0.35);
            box-shadow: 0 0 12px var(--success-glow);
        }

        .status-idle {
            background: rgba(100, 116, 139, 0.15);
            color: #94a3b8;
            border: 1px solid rgba(100, 116, 139, 0.35);
        }

        .pulse-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
        }

        .pulse-active {
            background: #10b981;
            box-shadow: 0 0 8px #10b981;
            animation: pulse-ring 1.8s infinite;
        }

        .pulse-idle {
            background: #64748b;
        }

        @keyframes pulse-ring {
            0% { transform: scale(0.95); opacity: 0.8; }
            50% { transform: scale(1.3); opacity: 1; }
            100% { transform: scale(0.95); opacity: 0.8; }
        }

        /* Range Selector Options Grid */
        .range-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
            gap: 12px;
            margin-bottom: 24px;
        }

        .range-btn {
            background: var(--bg-card-subtle);
            border: 2px solid var(--border-line);
            border-radius: 12px;
            padding: 16px 12px;
            cursor: pointer;
            text-align: center;
            transition: all 0.2s ease;
            position: relative;
        }

        .range-btn:hover {
            border-color: #475569;
            background: #202b44;
        }

        .range-btn.selected {
            border-color: var(--brand-gold);
            background: rgba(245, 158, 11, 0.08);
            box-shadow: 0 0 15px rgba(245, 158, 11, 0.15);
        }

        .range-title {
            font-size: 16px;
            font-weight: 800;
            color: #ffffff;
            margin-bottom: 4px;
            font-family: 'JetBrains Mono', monospace;
        }

        .range-desc {
            font-size: 11px;
            color: var(--text-secondary);
        }

        .range-check {
            position: absolute;
            top: 8px;
            right: 8px;
            font-size: 12px;
            color: var(--brand-gold);
            opacity: 0;
            transition: opacity 0.2s;
        }

        .range-btn.selected .range-check {
            opacity: 1;
        }

        /* Custom Range Inputs Row */
        .custom-range-box {
            background: #1e2638;
            border: 1px dashed var(--border-line);
            border-radius: 12px;
            padding: 18px 20px;
            display: none;
            margin-bottom: 24px;
        }

        .custom-range-box.show {
            display: block;
        }

        .custom-inputs-row {
            display: flex;
            align-items: flex-end;
            gap: 16px;
            flex-wrap: wrap;
        }

        .custom-field {
            flex: 1;
            min-width: 140px;
        }

        .btn-apply-custom {
            background: var(--brand-gold);
            color: #0f172a;
            border: none;
            border-radius: 8px;
            padding: 12px 20px;
            font-size: 13px;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.2s;
            height: 44px;
        }

        .btn-apply-custom:hover {
            background: #fbbf24;
            transform: translateY(-1px);
        }

        /* Big Animated Telemetry Dial */
        .telemetry-hero {
            background: linear-gradient(135deg, #131b2e 0%, #172138 100%);
            border: 1px solid var(--border-line);
            border-radius: var(--card-radius);
            padding: 28px;
            text-align: center;
            position: relative;
            overflow: hidden;
            margin-bottom: 24px;
        }

        .telemetry-hero::after {
            content: '';
            position: absolute;
            top: -50px;
            left: 50%;
            transform: translateX(-50%);
            width: 250px;
            height: 120px;
            background: radial-gradient(ellipse, rgba(16, 185, 129, 0.15) 0%, transparent 70%);
            pointer-events: none;
        }

        .hero-count-label {
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--text-secondary);
            margin-bottom: 8px;
        }

        .hero-count-val {
            font-size: 72px;
            font-weight: 900;
            font-family: 'JetBrains Mono', monospace;
            color: #ffffff;
            line-height: 1;
            margin-bottom: 8px;
            letter-spacing: -2px;
            transition: all 0.4s ease-out;
        }

        .hero-count-sub {
            font-size: 13px;
            color: var(--text-secondary);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .gauge-bar-track {
            width: 100%;
            max-width: 400px;
            height: 8px;
            background: #232f48;
            border-radius: 4px;
            margin: 18px auto 8px;
            overflow: hidden;
            position: relative;
        }

        .gauge-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #10b981, #f59e0b);
            border-radius: 4px;
            width: 0%;
            transition: width 0.6s ease;
        }

        /* KPI Cards 3-col */
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }

        .kpi-stat-card {
            background: var(--bg-card-subtle);
            border: 1px solid var(--border-line);
            border-radius: 12px;
            padding: 18px;
        }

        .kpi-stat-label {
            font-size: 11px;
            font-weight: 700;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }

        .kpi-stat-val {
            font-size: 24px;
            font-weight: 800;
            color: #ffffff;
            font-family: 'JetBrains Mono', monospace;
        }

        /* Live Activity Stream Table */
        .stream-wrap {
            max-height: 380px;
            overflow-y: auto;
        }

        .stream-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }

        .stream-table th {
            background: #172136;
            color: var(--text-muted);
            text-transform: uppercase;
            font-size: 10px;
            letter-spacing: 0.5px;
            padding: 10px 14px;
            text-align: left;
            position: sticky;
            top: 0;
        }

        .stream-table td {
            padding: 12px 14px;
            border-bottom: 1px solid #1e293b;
            color: var(--text-secondary);
        }

        .stream-table tr:hover td {
            background: rgba(255, 255, 255, 0.02);
            color: #ffffff;
        }

        .stream-city {
            font-weight: 700;
            color: #f1f5f9;
        }

        .badge-source {
            display: inline-block;
            background: rgba(245, 158, 11, 0.15);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.3);
            border-radius: 12px;
            padding: 2px 8px;
            font-size: 10px;
            font-weight: 600;
        }

        .toast-msg {
            position: fixed;
            bottom: 24px;
            right: 24px;
            background: #1e293b;
            border: 1px solid var(--border-line);
            border-left: 4px solid var(--brand-gold);
            color: #ffffff;
            padding: 14px 20px;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            font-size: 13px;
            font-weight: 600;
            z-index: 1000;
            display: none;
            animation: slideIn 0.3s ease;
        }

        @keyframes slideIn {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>

<?php if (!$is_auth): ?>
    <!-- ============================================================== -->
    <!-- DEDICATED OPERATOR SIGN-IN SCREEN -->
    <!-- ============================================================== -->
    <div class="login-wrap">
        <div class="login-card">
            <div class="login-badge">
                <i class="ti-lock"></i> Restricted Operator Console
            </div>
            <h1 class="login-title">Traffic Simulator</h1>
            <p class="login-sub">Dedicated authentication for traffic generation and simulation suite.</p>

            <?php if (!empty($login_error)): ?>
                <div class="alert-box alert-danger">
                    <i class="ti-alert"></i> <?php echo htmlspecialchars($login_error); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($logout_success)): ?>
                <div class="alert-box alert-success">
                    <i class="ti-check"></i> <?php echo htmlspecialchars($logout_success); ?>
                </div>
            <?php endif; ?>

            <form action="traffic_simulator.php" method="POST" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                
                <div class="form-group">
                    <label class="form-label" for="op_email">Operator Email</label>
                    <input type="email" id="op_email" name="operator_email" class="form-input" placeholder="Ritik@gmail.com" required autofocus value="<?php echo htmlspecialchars($_POST['operator_email'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="op_pass">Security Password</label>
                    <input type="password" id="op_pass" name="operator_password" class="form-input" placeholder="Enter operator password" required>
                </div>

                <button type="submit" name="operator_login_btn" class="login-btn">
                    <i class="ti-key"></i> Authenticate &amp; Launch Console
                </button>
            </form>

            <div class="security-notice">
                Protected Console. Credentials configured via <code>TRAFFIC_OPERATOR_EMAIL</code> &amp; <code>TRAFFIC_OPERATOR_PASSWORD</code>. Operator session does not grant standard admin privileges.
            </div>
        </div>
    </div>

<?php else: ?>
    <!-- ============================================================== -->
    <!-- OPERATOR SIMULATOR CONTROLLER CONSOLE -->
    <!-- ============================================================== -->
    <header class="dash-header">
        <div class="dash-header-inner">
            <div class="brand-box">
                <div class="brand-logo-icon">P</div>
                <div>
                    <div class="brand-title">Postic Traffic Simulation Suite</div>
                    <div class="brand-sub">Independent Stochastic Traffic Engine &amp; Operator Controls</div>
                </div>
            </div>

            <div class="dash-nav-actions">
                <div class="operator-pill">
                    <i class="ti-shield" style="color: var(--brand-gold);"></i>
                    Operator: <strong><?php echo htmlspecialchars($_SESSION['traffic_operator_email'] ?? 'Operator'); ?></strong>
                </div>

                <a href="traffic_analytics.php" target="_blank" class="btn-view-preview" title="View combined analytics preview on admin dashboard">
                    <i class="ti-pulse"></i> Preview in Analytics &nearr;
                </a>

                <a href="traffic_simulator.php?action=logout" class="btn-logout" onclick="return confirm('Do you want to log out of the operator console?');">
                    <i class="ti-power-off"></i> Log Out
                </a>
            </div>
        </div>
    </header>

    <main class="dash-container">
        <!-- Toast Notification -->
        <div id="toastMessage" class="toast-msg"></div>

        <div class="grid-main">
            <!-- Left Column: Controls & Dynamic Config -->
            <div>
                <!-- 1. Master Toggle Card -->
                <div class="console-card">
                    <div class="card-header-bar">
                        <div class="card-title">
                            <i class="ti-control-play" style="color: var(--brand-crimson);"></i> Master Simulation Engine
                        </div>
                        <div id="statusBadge" class="status-pill <?php echo $state['enabled'] ? 'status-active' : 'status-idle'; ?>">
                            <span class="pulse-dot <?php echo $state['enabled'] ? 'pulse-active' : 'pulse-idle'; ?>"></span>
                            <span id="statusText"><?php echo $state['enabled'] ? 'SIMULATOR ACTIVE' : 'SIMULATOR PAUSED'; ?></span>
                        </div>
                    </div>

                    <div class="toggle-box">
                        <div class="toggle-label-wrap">
                            <h4>Simulation Broadcast</h4>
                            <p>Toggle simulated visitor traffic generation ON or OFF instantly.</p>
                        </div>
                        <label class="switch">
                            <input type="checkbox" id="masterToggle" <?php echo $state['enabled'] ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- Range Selector -->
                    <div style="margin-bottom: 12px;">
                        <span style="font-size: 12px; font-weight: 700; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.5px;">
                            Select Visitor Traffic Range:
                        </span>
                    </div>

                    <div class="range-grid">
                        <div class="range-btn <?php echo ($state['range_type'] === '0-50') ? 'selected' : ''; ?>" data-range="0-50">
                            <i class="ti-check range-check"></i>
                            <div class="range-title">0 – 50</div>
                            <div class="range-desc">Subtle / Micro Flow</div>
                        </div>

                        <div class="range-btn <?php echo ($state['range_type'] === '50-100') ? 'selected' : ''; ?>" data-range="50-100">
                            <i class="ti-check range-check"></i>
                            <div class="range-title">50 – 100</div>
                            <div class="range-desc">Organic Growth</div>
                        </div>

                        <div class="range-btn <?php echo ($state['range_type'] === '0-200') ? 'selected' : ''; ?>" data-range="0-200">
                            <i class="ti-check range-check"></i>
                            <div class="range-title">0 – 200</div>
                            <div class="range-desc">Daily Store Traffic</div>
                        </div>

                        <div class="range-btn <?php echo ($state['range_type'] === '200-500') ? 'selected' : ''; ?>" data-range="200-500">
                            <i class="ti-check range-check"></i>
                            <div class="range-title">200 – 500</div>
                            <div class="range-desc">Steady Brand Flow</div>
                        </div>

                        <div class="range-btn <?php echo ($state['range_type'] === '500-1000') ? 'selected' : ''; ?>" data-range="500-1000">
                            <i class="ti-check range-check"></i>
                            <div class="range-title">500 – 1000</div>
                            <div class="range-desc">Festive / Peak Sale</div>
                        </div>

                        <div class="range-btn <?php echo ($state['range_type'] === 'custom') ? 'selected' : ''; ?>" data-range="custom">
                            <i class="ti-check range-check"></i>
                            <div class="range-title">Custom</div>
                            <div class="range-desc">User-Defined Min/Max</div>
                        </div>
                    </div>

                    <!-- Custom Range Form (Shown when custom is selected) -->
                    <div id="customRangeBox" class="custom-range-box <?php echo ($state['range_type'] === 'custom') ? 'show' : ''; ?>">
                        <div class="custom-inputs-row">
                            <div class="custom-field">
                                <label class="form-label" for="customMinInput">Minimum Visitors</label>
                                <input type="number" id="customMinInput" class="form-input" min="0" max="49999" value="<?php echo htmlspecialchars($state['custom_min'] ?? 50); ?>">
                            </div>
                            <div class="custom-field">
                                <label class="form-label" for="customMaxInput">Maximum Visitors</label>
                                <input type="number" id="customMaxInput" class="form-input" min="1" max="50000" value="<?php echo htmlspecialchars($state['custom_max'] ?? 250); ?>">
                            </div>
                            <button type="button" id="btnApplyCustom" class="btn-apply-custom">
                                <i class="ti-check"></i> Apply Bounds
                            </button>
                        </div>
                    </div>

                    <!-- Architecture & Safety Info Box -->
                    <div style="background: rgba(15, 23, 42, 0.6); border: 1px solid var(--border-line); border-radius: 10px; padding: 14px 16px; font-size: 12px; color: var(--text-secondary); line-height: 1.5;">
                        <strong style="color: #38bdf8; display: block; margin-bottom: 2px;">
                            <i class="ti-info-alt"></i> Non-Destructive In-Memory Engine:
                        </strong>
                        Simulation data is maintained in a separate runtime layer. It does <strong>not</strong> write fake rows to your real SQL <code>visitor_logs</code> or database orders. Turning the switch OFF instantly purges simulated figures from analytics previews.
                    </div>
                </div>

                <!-- 2. Live Activity Stream -->
                <div class="console-card">
                    <div class="card-header-bar">
                        <div class="card-title">
                            <i class="ti-rss" style="color: var(--brand-gold);"></i> Simulated Visitor Activity Stream
                        </div>
                        <span style="font-size: 11px; color: var(--text-muted);">Simulated Arrivals &bull; Real Time</span>
                    </div>

                    <div class="stream-wrap">
                        <table class="stream-table">
                            <thead>
                                <tr>
                                    <th>Location</th>
                                    <th>Page Viewed</th>
                                    <th>Device / Browser</th>
                                    <th>Source</th>
                                    <th style="text-align: right;">Time</th>
                                </tr>
                            </thead>
                            <tbody id="streamTableBody">
                                <?php if (!empty($state['live_stream'])): ?>
                                    <?php foreach ($state['live_stream'] as $event): ?>
                                        <tr>
                                            <td class="stream-city"><i class="ti-location-pin" style="color: var(--brand-crimson);"></i> <?php echo htmlspecialchars($event['city']); ?></td>
                                            <td><?php echo htmlspecialchars($event['page_title']); ?></td>
                                            <td><?php echo htmlspecialchars($event['device'] . ' (' . $event['browser'] . ')'); ?></td>
                                            <td><span class="badge-source"><?php echo htmlspecialchars($event['source']); ?></span></td>
                                            <td style="text-align: right;"><?php echo htmlspecialchars($event['time_ago'] ?? 'Just now'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" style="text-align: center; padding: 30px; color: var(--text-muted);">
                                            No simulated activity logged yet. Toggle simulator ON to stream visitors!
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Right Column: Live Telemetry & Stochastic Monitor -->
            <div>
                <!-- Hero Count Card -->
                <div class="telemetry-hero">
                    <div class="hero-count-label">Simulated Visitors Right Now</div>
                    <div id="liveActiveCount" class="hero-count-val">
                        <?php echo $state['enabled'] ? (int)$state['current_active'] : 0; ?>
                    </div>
                    <div class="hero-count-sub">
                        <span>Range: <strong id="activeRangeLabel" style="color: #ffffff;"><?php echo htmlspecialchars($bounds['label']); ?></strong></span>
                        <span>&bull;</span>
                        <span id="stochasticStatus" style="color: #10b981;">Simulating natural flow</span>
                    </div>

                    <div class="gauge-bar-track">
                        <?php 
                            $pct = 0;
                            if ($bounds['max'] > $bounds['min']) {
                                $pct = round((($state['current_active'] - $bounds['min']) / ($bounds['max'] - $bounds['min'])) * 100);
                                $pct = max(0, min(100, $pct));
                            }
                        ?>
                        <div id="gaugeBarFill" class="gauge-bar-fill" style="width: <?php echo $pct; ?>%;"></div>
                    </div>
                </div>

                <!-- Cumulative KPI Cards -->
                <div class="kpi-grid">
                    <div class="kpi-stat-card">
                        <div class="kpi-stat-label">Simulated Today's Visitors</div>
                        <div id="kpiTodayVisitors" class="kpi-stat-val">
                            <?php echo number_format($state['today_simulated_visitors'] ?? 0); ?>
                        </div>
                    </div>

                    <div class="kpi-stat-card">
                        <div class="kpi-stat-label">Simulated Page Views</div>
                        <div id="kpiTodayPageviews" class="kpi-stat-val">
                            <?php echo number_format($state['today_simulated_pageviews'] ?? 0); ?>
                        </div>
                    </div>

                    <div class="kpi-stat-card">
                        <div class="kpi-stat-label">Acquisition Channel</div>
                        <div id="kpiAvgDuration" class="kpi-stat-val" style="font-size: 15px; color: #f472b6;">
                            Instagram &amp; WA
                        </div>
                    </div>
                </div>

                <!-- Analytics Integration Preview Card -->
                <div class="console-card">
                    <div class="card-header-bar">
                        <div class="card-title">
                            <i class="ti-dashboard" style="color: #38bdf8;"></i> Client Admin Integration
                        </div>
                    </div>
                    <p style="font-size: 13px; color: var(--text-secondary); margin-bottom: 16px; line-height: 1.5;">
                        When this simulator is active, your client viewing the main admin panel (<code>dashboard.php</code> and <code>traffic_analytics.php</code>) will see:
                    </p>
                    <ul style="font-size: 13px; color: #cbd5e1; list-style: none; padding: 0; line-height: 1.8;">
                        <li><i class="ti-check" style="color: #10b981; margin-right: 6px;"></i> <strong>Live Online Count:</strong> Boosted by +<span id="previewLiveBoost"><?php echo $state['enabled'] ? $state['current_active'] : 0; ?></span> live shoppers.</li>
                        <li><i class="ti-check" style="color: #10b981; margin-right: 6px;"></i> <strong>Daily Visitors:</strong> Smooth organic increment reflecting consistent customer traffic.</li>
                        <li><i class="ti-check" style="color: #10b981; margin-right: 6px;"></i> <strong>Client Protection:</strong> Operator page is isolated &amp; hidden from regular sidebar navigation.</li>
                    </ul>

                    <div style="margin-top: 20px; display: flex; gap: 10px;">
                        <button type="button" id="btnResetToday" class="btn btn-sm" style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.3); color: #fca5a5; padding: 8px 14px; border-radius: 8px; font-size: 12px; font-weight: 700; cursor: pointer;">
                            <i class="ti-reload"></i> Reset Today's Simulation Stats
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Client-Side Simulator Controller Script -->
    <script>
        (function() {
            const CSRF_TOKEN = <?php echo json_encode($csrf_token); ?>;
            let isEnabled = <?php echo $state['enabled'] ? 'true' : 'false'; ?>;
            let currentRange = <?php echo json_encode($state['range_type']); ?>;
            let heartbeatTimer = null;

            // DOM elements
            const masterToggle = document.getElementById('masterToggle');
            const statusBadge = document.getElementById('statusBadge');
            const statusText = document.getElementById('statusText');
            const liveActiveCount = document.getElementById('liveActiveCount');
            const activeRangeLabel = document.getElementById('activeRangeLabel');
            const gaugeBarFill = document.getElementById('gaugeBarFill');
            const kpiTodayVisitors = document.getElementById('kpiTodayVisitors');
            const kpiTodayPageviews = document.getElementById('kpiTodayPageviews');
            const kpiAvgDuration = document.getElementById('kpiAvgDuration');
            const previewLiveBoost = document.getElementById('previewLiveBoost');
            const customRangeBox = document.getElementById('customRangeBox');
            const btnApplyCustom = document.getElementById('btnApplyCustom');
            const btnResetToday = document.getElementById('btnResetToday');
            const toastMessage = document.getElementById('toastMessage');
            const streamTableBody = document.getElementById('streamTableBody');
            const rangeButtons = document.querySelectorAll('.range-btn');

            function showToast(msg) {
                toastMessage.textContent = msg;
                toastMessage.style.display = 'block';
                setTimeout(() => {
                    toastMessage.style.display = 'none';
                }, 3500);
            }

            // Update UI with latest telemetry state
            function renderState(state, bounds) {
                isEnabled = !!state.enabled;
                currentRange = state.range_type;

                masterToggle.checked = isEnabled;
                if (isEnabled) {
                    statusBadge.className = 'status-pill status-active';
                    statusBadge.querySelector('.pulse-dot').className = 'pulse-dot pulse-active';
                    statusText.textContent = 'SIMULATOR ACTIVE';
                } else {
                    statusBadge.className = 'status-pill status-idle';
                    statusBadge.querySelector('.pulse-dot').className = 'pulse-dot pulse-idle';
                    statusText.textContent = 'SIMULATOR PAUSED';
                }

                const activeCount = isEnabled ? (parseInt(state.current_active) || 0) : 0;
                liveActiveCount.textContent = activeCount.toLocaleString();
                previewLiveBoost.textContent = activeCount.toLocaleString();

                if (bounds) {
                    activeRangeLabel.textContent = bounds.label;
                    if (bounds.max > bounds.min) {
                        const pct = Math.max(0, Math.min(100, Math.round(((activeCount - bounds.min) / (bounds.max - bounds.min)) * 100)));
                        gaugeBarFill.style.width = pct + '%';
                    }
                }

                kpiTodayVisitors.textContent = (state.today_simulated_visitors || 0).toLocaleString();
                kpiTodayPageviews.textContent = (state.today_simulated_pageviews || 0).toLocaleString();

                const phase = (state.wave_phase === 'ebb') ? 'Ebb (Holding)' : 'Flow (Growing)';
                kpiAvgDuration.textContent = 'Insta & WA (' + phase + ')';

                // Render live stream rows if available
                if (state.live_stream && state.live_stream.length > 0) {
                    let rowsHtml = '';
                    state.live_stream.forEach(ev => {
                        rowsHtml += `<tr>
                            <td class="stream-city"><i class="ti-location-pin" style="color: var(--brand-crimson);"></i> ${escapeHtml(ev.city)}</td>
                            <td>${escapeHtml(ev.page_title)}</td>
                            <td>${escapeHtml(ev.device)} (${escapeHtml(ev.browser)})</td>
                            <td><span class="badge-source">${escapeHtml(ev.source)}</span></td>
                            <td style="text-align: right;">${escapeHtml(ev.time_ago || 'Just now')}</td>
                        </tr>`;
                    });
                    streamTableBody.innerHTML = rowsHtml;
                }
            }

            function escapeHtml(str) {
                if (!str) return '';
                return String(str).replace(/[&<>"']/g, function(m) {
                    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
                });
            }

            // API: Toggle Master Switch
            masterToggle.addEventListener('change', function() {
                const checked = masterToggle.checked;
                fetch('traffic_simulator_api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=toggle&enabled=${checked ? 1 : 0}&csrf_token=${encodeURIComponent(CSRF_TOKEN)}`
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast(data.message);
                        renderState(data.state, data.bounds);
                        restartHeartbeat();
                    } else {
                        alert(data.error || 'Failed to toggle simulator.');
                        masterToggle.checked = !checked;
                    }
                })
                .catch(err => {
                    console.error(err);
                    masterToggle.checked = !checked;
                });
            });

            // API: Range Button Click Handler
            rangeButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    const range = this.getAttribute('data-range');
                    rangeButtons.forEach(b => b.classList.remove('selected'));
                    this.classList.add('selected');

                    if (range === 'custom') {
                        customRangeBox.classList.add('show');
                        return; // Wait for apply button
                    } else {
                        customRangeBox.classList.remove('show');
                    }

                    fetch('traffic_simulator_api.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `action=set_range&range_type=${encodeURIComponent(range)}&csrf_token=${encodeURIComponent(CSRF_TOKEN)}`
                    })
                    .then(r => r.json())
                    .then(data => {
                        if (data.success) {
                            showToast(data.message);
                            renderState(data.state, data.bounds);
                        } else {
                            alert(data.error || 'Failed to update range.');
                        }
                    })
                    .catch(console.error);
                });
            });

            // API: Apply Custom Bounds
            btnApplyCustom.addEventListener('click', function() {
                const minVal = parseInt(document.getElementById('customMinInput').value, 10);
                const maxVal = parseInt(document.getElementById('customMaxInput').value, 10);

                if (isNaN(minVal) || minVal < 0) {
                    alert('Please enter a valid minimum visitor count (0 or greater).');
                    return;
                }
                if (isNaN(maxVal) || maxVal <= minVal) {
                    alert('Maximum visitor count must be strictly greater than minimum.');
                    return;
                }

                fetch('traffic_simulator_api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=set_range&range_type=custom&custom_min=${minVal}&custom_max=${maxVal}&csrf_token=${encodeURIComponent(CSRF_TOKEN)}`
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast(data.message);
                        renderState(data.state, data.bounds);
                    } else {
                        alert(data.error || 'Failed to apply custom bounds.');
                    }
                })
                .catch(console.error);
            });

            // API: Reset Today Counters
            btnResetToday.addEventListener('click', function() {
                if (!confirm("Are you sure you want to reset today's simulated traffic counters to 0?")) {
                    return;
                }
                fetch('traffic_simulator_api.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=reset_today&csrf_token=${encodeURIComponent(CSRF_TOKEN)}`
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        showToast(data.message);
                        renderState(data.state);
                    }
                })
                .catch(console.error);
            });

            // Heartbeat: Dynamic Irregular Simulation Ticks
            function scheduleNextTick() {
                if (heartbeatTimer) clearTimeout(heartbeatTimer);
                if (!isEnabled) return;

                // Irregular intervals: natural relaxed jitter between 6500ms and 12500ms
                const jitter = Math.floor(Math.random() * (12500 - 6500 + 1)) + 6500;

                heartbeatTimer = setTimeout(() => {
                    if (!isEnabled) return;
                    fetch('traffic_simulator_api.php?action=tick')
                        .then(r => r.json())
                        .then(data => {
                            if (data.success) {
                                renderState(data.state, data.bounds);
                            }
                        })
                        .catch(console.error)
                        .finally(() => {
                            scheduleNextTick();
                        });
                }, jitter);
            }

            function restartHeartbeat() {
                if (heartbeatTimer) clearTimeout(heartbeatTimer);
                if (isEnabled) {
                    scheduleNextTick();
                }
            }

            // Cleanup on page unmount / unload
            window.addEventListener('beforeunload', () => {
                if (heartbeatTimer) clearTimeout(heartbeatTimer);
            });

            // Start heartbeat if initially active
            if (isEnabled) {
                restartHeartbeat();
            }
        })();
    </script>
<?php endif; ?>

</body>
</html>
