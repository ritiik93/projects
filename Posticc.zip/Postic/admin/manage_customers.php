<?php 
    $views = "manage_customers";
    include ("template.php");
?>

