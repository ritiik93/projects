<?php

require_once dirname(__DIR__, 2) . '/config/database.php';

class  adminback
{
    public $connection;
    function __construct()
    {
        $this->connection = get_db_connection();

        if (!$this->connection) {
            die("Database connection error!!!");
        }

        $this->ensure_product_images_table();
        $this->ensure_order_payment_columns();
        $this->ensure_customer_feedback_table();
        $this->ensure_user_address_book_columns();
        $this->ensure_users_table_defaults();
        $this->ensure_order_weight_column();
        $this->ensure_product_weight_column();
    }

    private function ensure_product_images_table()
    {
        static $images_table_ensured = false;
        if ($images_table_ensured) {
            return;
        }
        $images_table_ensured = true;

        $query = "CREATE TABLE IF NOT EXISTS `product_images` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `pdt_id` int(255) NOT NULL,
            `img_name` varchar(255) NOT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

        @mysqli_query($this->connection, $query);
    }

    private function ensure_order_payment_columns()
    {
        static $order_cols_ensured = false;
        if ($order_cols_ensured) {
            return;
        }
        $order_cols_ensured = true;

        $columns = array(
            'payment_method' => "ALTER TABLE `order_details` ADD `payment_method` varchar(30) NOT NULL DEFAULT 'manual'",
            'payment_status' => "ALTER TABLE `order_details` ADD `payment_status` varchar(30) NOT NULL DEFAULT 'pending'",
            'gateway_order_id' => "ALTER TABLE `order_details` ADD `gateway_order_id` varchar(100) NOT NULL DEFAULT ''"
        );

        foreach ($columns as $column => $query) {
            $check_query = "SHOW COLUMNS FROM `order_details` LIKE '$column'";
            $result = @mysqli_query($this->connection, $check_query);
            if ($result && mysqli_num_rows($result) == 0) {
                @mysqli_query($this->connection, $query);
            }
        }
    }

    private function ensure_customer_feedback_table()
    {
        static $feedback_ensured = false;
        if ($feedback_ensured) {
            return;
        }
        $feedback_ensured = true;

        $check_query = "SHOW COLUMNS FROM `customer_feedback` LIKE 'rating'";
        $result = @mysqli_query($this->connection, $check_query);
        if ($result && mysqli_num_rows($result) == 0) {
            @mysqli_query($this->connection, "ALTER TABLE `customer_feedback` ADD `rating` int(2) NOT NULL DEFAULT 5 AFTER `comment`");
        }
    }

    private function ensure_user_address_book_columns()
    {
        static $address_cols_ensured = false;
        if ($address_cols_ensured) {
            return;
        }
        $address_cols_ensured = true;

        $columns = array(
            'home_address' => "ALTER TABLE `users` ADD `home_address` TEXT NULL DEFAULT NULL AFTER `user_address`",
            'office_address' => "ALTER TABLE `users` ADD `office_address` TEXT NULL DEFAULT NULL AFTER `home_address`"
        );

        foreach ($columns as $column => $query) {
            $check_query = "SHOW COLUMNS FROM `users` LIKE '$column'";
            $result = @mysqli_query($this->connection, $check_query);
            if ($result && mysqli_num_rows($result) == 0) {
                @mysqli_query($this->connection, $query);
            }
        }
    }

    private function ensure_users_table_defaults()
    {
        static $users_defaults_ensured = false;
        if ($users_defaults_ensured) {
            return;
        }
        $users_defaults_ensured = true;

        @mysqli_query($this->connection, "ALTER TABLE `users` MODIFY `user_mobile` varchar(20) NULL DEFAULT ''");
        @mysqli_query($this->connection, "ALTER TABLE `users` MODIFY `user_address` varchar(255) NULL DEFAULT ''");
        @mysqli_query($this->connection, "ALTER TABLE `users` MODIFY `user_firstname` varchar(60) NULL DEFAULT ''");
        @mysqli_query($this->connection, "ALTER TABLE `users` MODIFY `user_lastname` varchar(60) NULL DEFAULT ''");
    }

    private function ensure_order_weight_column()
    {
        static $weight_col_ensured = false;
        if ($weight_col_ensured) {
            return;
        }
        $weight_col_ensured = true;

        $check_query = "SHOW COLUMNS FROM `order_details` LIKE 'pdt_weight'";
        $result = @mysqli_query($this->connection, $check_query);
        if ($result && mysqli_num_rows($result) == 0) {
            @mysqli_query($this->connection, "ALTER TABLE `order_details` ADD `pdt_weight` varchar(100) NOT NULL DEFAULT '55g' AFTER `product_name`");
        }
    }

    private function ensure_product_weight_column()
    {
        static $pdt_weight_col_ensured = false;
        if ($pdt_weight_col_ensured) {
            return;
        }
        $pdt_weight_col_ensured = true;

        $check_query = "SHOW COLUMNS FROM `products` LIKE 'pdt_weight'";
        $result = @mysqli_query($this->connection, $check_query);
        if ($result && mysqli_num_rows($result) == 0) {
            @mysqli_query($this->connection, "ALTER TABLE `products` ADD `pdt_weight` varchar(100) NOT NULL DEFAULT '55g' AFTER `pdt_price`");
        }

        $check_view = "SHOW COLUMNS FROM `product_info_ctg` LIKE 'pdt_weight'";
        $view_res = @mysqli_query($this->connection, $check_view);
        if ($view_res && mysqli_num_rows($view_res) == 0) {
            @mysqli_query($this->connection, "CREATE OR REPLACE VIEW `product_info_ctg` AS 
                SELECT 
                  `products`.`pdt_id` AS `pdt_id`,
                  `products`.`pdt_name` AS `pdt_name`,
                  `products`.`pdt_price` AS `pdt_price`,
                  `products`.`pdt_weight` AS `pdt_weight`,
                  `products`.`pdt_des` AS `pdt_des`,
                  `products`.`pdt_img` AS `pdt_img`,
                  `products`.`product_stock` AS `product_stock`,
                  `products`.`pdt_status` AS `pdt_status`,
                  `catagory`.`ctg_id` AS `ctg_id`,
                  `catagory`.`ctg_name` AS `ctg_name`
                FROM (`products` JOIN `catagory` ON `products`.`pdt_ctg` = `catagory`.`ctg_id`)");
        }

        // Clean legacy weight strings from product titles and normalize all flavour products to 130 MRP & 55g
        $legacy_check = @mysqli_query($this->connection, "SELECT pdt_id, pdt_name FROM `products` WHERE pdt_name LIKE '%(80g)%' OR pdt_name LIKE '%(Pouch 80g)%' OR pdt_name LIKE '%(Jar 200g)%'");
        if ($legacy_check && mysqli_num_rows($legacy_check) > 0) {
            while ($row = mysqli_fetch_assoc($legacy_check)) {
                $clean_name = trim(str_ireplace(array('(80g)', '(Pouch 80g)', '(Jar 200g)'), '', $row['pdt_name']));
                $pid = (int) $row['pdt_id'];
                @mysqli_query($this->connection, "UPDATE `products` SET `pdt_name`='" . mysqli_real_escape_string($this->connection, $clean_name) . "', `pdt_price`=130, `pdt_weight`='55g' WHERE `pdt_id`=$pid");
            }
        }
        @mysqli_query($this->connection, "UPDATE `products` SET `pdt_status`=0 WHERE `pdt_id`=1");
    }

    function admin_login($data)
    {
        $admin_email = $data["admin_email"];
        $admin_pass = md5($data['admin_pass']);

        $query = "SELECT * FROM `admin_info` WHERE admin_email = '$admin_email' AND admin_pass = '$admin_pass'";

        if (mysqli_query($this->connection, $query)) {
            $result = mysqli_query($this->connection, $query);
            $admin_info = mysqli_fetch_assoc($result);
            if ($admin_info) {
                header("location:dashborad.php");
                session_start();
                $_SESSION['admin_id'] = $admin_info['admin_id'];
                $_SESSION['admin_email'] = $admin_info['admin_email'];
                $_SESSION['role'] = $admin_info['role'];
            } else {
                $log_msg = "Email or password wrong";
                return $log_msg;
            }
        }
    }

    function admin_logout()
    {
        unset($_SESSION['admin_id']);
        unset($_SESSION['admin_email']);
        unset($_SESSION['role']);
        header("location:index.php");
        session_destroy();
    }

    function admin_password_recover($recover_email)
    {
        $query = "SELECT * FROM `admin_info` WHERE `admin_email`='$recover_email'";
        if (mysqli_query($this->connection, $query)) {
            $row =  mysqli_query($this->connection, $query);
            return $row;
        }
    }

    function update_admin_password($data)
    {
        $u_admin_id = $data['admin_update_id'];
        $u_admin_pass = md5($data['admin_update_password']);

        $query = "UPDATE `admin_info` SET `admin_pass`='$u_admin_pass' WHERE `admin_id`= $u_admin_id";

        if (mysqli_query($this->connection, $query)) {
            $update_mag = "You password updated successfull";
            return $update_mag;
        } else {
            return "Failed";
        }
    }

    function add_admin_user($data){
        $user_email = $data['user_name'];
        $user_pass = md5($data['user_password']);
        $user_role = $data['user_role'];

        $query = "INSERT INTO `admin_info`( `admin_email`, `admin_pass`, `role`) VALUES ('$user_email','$user_pass',$user_role)";

        if(mysqli_query($this->connection, $query)){
            $msg="{$user_email} add as a user successfully";
            return $msg;
        }
    }

    function show_admin_user(){
        $query = "SELECT * FROM `admin_info`";
        if(mysqli_query($this->connection, $query)){
            $result = mysqli_query($this->connection, $query);
            return $result;
        }
    }

    function show_admin_user_by_id($user_id){
        $query = "SELECT * FROM `admin_info` WHERE `admin_id`=$user_id";
        if(mysqli_query($this->connection, $query)){
            $result = mysqli_query($this->connection, $query);
            return $result;
        }
    }

    function update_admin($data){
        $u_id = $data['user_id'];
        $u_email = $data['u-user-email'];
        $u_role = $data['u_user_role'];
        $query = "UPDATE `admin_info` SET `admin_email`='$u_email',`role`= $u_role WHERE `admin_id`= $u_id ";
        if(mysqli_query($this->connection, $query)){
            $up_msg = "Updated successfully";
            return $up_msg;
        }
        
    }

    function delete_admin($admin_id){
        $query = "DELETE FROM `admin_info` WHERE `admin_id`=$admin_id";
        if(mysqli_query($this->connection, $query)){
            $del_msg = "User Deleted Successfully";
            return $del_msg;
        }
    }

    function add_catagory($data)
    {
        $ctg_name = $data['ctg_name'];
        $ctg_des = $data['ctg_des'];
        $ctg_status = $data['ctg_status'];

        $query = "INSERT INTO `catagory`( `ctg_name`, `ctg_des`, `ctg_status`) VALUES ('$ctg_name','$ctg_des', $ctg_status)";

        if (mysqli_query($this->connection, $query)) {
            return "{$ctg_name} added as a category successfully!!";
        } else {
            return "Failed to add category";
        }
    }

    function display_catagory()
    {
        $query = "SELECT * FROM `catagory`";

        if (mysqli_query($this->connection, $query)) {
            $ctg_info = mysqli_query($this->connection, $query);
            return $ctg_info;
        }
    }

    function p_display_catagory()
    {
        $query = "SELECT * FROM `catagory` WHERE ctg_status=1";

        if (mysqli_query($this->connection, $query)) {
            $ctg_info = mysqli_query($this->connection, $query);
            return $ctg_info;
        }
    }

    function catagory_published($id)
    {
        $query = "UPDATE `catagory` SET `ctg_status`= 1 WHERE ctg_id = $id";
        mysqli_query($this->connection, $query);
    }
    function catagory_unpublished($id)
    {
        $query = "UPDATE `catagory` SET `ctg_status`= 0 WHERE ctg_id = $id";
        mysqli_query($this->connection, $query);
    }

    function delete_catagory($id)
    {
        $query = "DELETE FROM `catagory` WHERE  ctg_id = $id";
        mysqli_query($this->connection, $query);
    }

    function display_cataByID($id)
    {
        $query = "SELECT * FROM `catagory` WHERE ctg_id = $id";

        if (mysqli_query($this->connection, $query)) {
            $cata_info = mysqli_query($this->connection, $query);
            return mysqli_fetch_assoc($cata_info);
        }
    }

    function updata_catagory($data)
    {
        $u_ctg_id = $data['u_ctg_id'];
        $u_ctg_name = $data['u_ctg_name'];
        $u_ctg_des = $data['u_ctg_des'];
        $u_ctg_status = $data['u_ctg_status'];

        $query = "UPDATE `catagory` SET `ctg_name`='$u_ctg_name',`ctg_des`='$u_ctg_des',`ctg_status`= $u_ctg_status WHERE ctg_id =  $u_ctg_id";
        if (mysqli_query($this->connection, $query)) {
            return "{$u_ctg_name} category updated successfully";
        }
    }

    private function save_product_gallery_images($pdt_id, $images)
    {
        if (empty($images['name'][0])) {
            return;
        }

        foreach ($images['name'] as $key => $img_name) {
            if (empty($img_name)) {
                continue;
            }

            $tmp = $images['tmp_name'][$key];
            $allowed_exts = array("jpg", "jpeg", "png", "webp", "gif");

            if (in_array($img_ext, $allowed_exts) && !empty($tmp)) {
                if (!is_dir("uploads")) {
                    @mkdir("uploads", 0755, true);
                }
                if (move_uploaded_file($tmp, "uploads/" . $img_name)) {
                    $query_img = "INSERT INTO `product_images`(`pdt_id`, `img_name`) VALUES ($pdt_id, '$img_name')";
                    mysqli_query($this->connection, $query_img);
                }
            }
        }
    }

    function display_product_images($pdt_id)
    {
        $query = "SELECT * FROM `product_images` WHERE `pdt_id`=$pdt_id ORDER BY `id` DESC";

        if (mysqli_query($this->connection, $query)) {
            $img_info = mysqli_query($this->connection, $query);
            return $img_info;
        }
    }

    function delete_product_image($image_id)
    {
        $select_query = "SELECT * FROM `product_images` WHERE `id`=$image_id";
        $result = mysqli_query($this->connection, $select_query);
        $image = mysqli_fetch_assoc($result);

        if (!$image) {
            return "Gallery image not found";
        }

        if (!empty($image['img_name']) && file_exists('uploads/' . $image['img_name'])) {
            unlink('uploads/' . $image['img_name']);
        }

        $delete_query = "DELETE FROM `product_images` WHERE `id`=$image_id";
        if (mysqli_query($this->connection, $delete_query)) {
            return "Gallery image deleted successfully";
        }

        return "Failed to delete gallery image";
    }

    private function delete_product_gallery_images($pdt_id)
    {
        $gallery_info = $this->display_product_images($pdt_id);

        if ($gallery_info) {
            while ($gallery_img = mysqli_fetch_assoc($gallery_info)) {
                if (file_exists('uploads/' . $gallery_img['img_name'])) {
                    unlink('uploads/' . $gallery_img['img_name']);
                }
            }
        }

        $delete_query = "DELETE FROM `product_images` WHERE `pdt_id`=$pdt_id";
        mysqli_query($this->connection, $delete_query);
    }

    function add_product($data)
    {
        $pdt_name = mysqli_real_escape_string($this->connection, trim($data['pdt_name']));
        $pdt_price = (int) $data['pdt_price'];
        $pdt_weight = !empty($data['pdt_weight']) ? mysqli_real_escape_string($this->connection, trim($data['pdt_weight'])) : '55g';
        $pdt_des = mysqli_real_escape_string($this->connection, $data['pdt_des']);
        $pdt_stock = (int) $data['pdt_stock'];
        $pdt_ctg = (int) $data['pdt_ctg'];
        $pdt_status = (int) $data['pdt_status'];
        $pdt_img_name = $_FILES['pdt_img']['name'];
        $pdt_img_size = $_FILES['pdt_img']['size'];
        $pdt_img_tmp = $_FILES['pdt_img']['tmp_name'];
        $img_ext = strtolower(pathinfo($pdt_img_name, PATHINFO_EXTENSION));
        $allowed_exts = array("jpg", "jpeg", "png", "webp", "gif");

        if (in_array($img_ext, $allowed_exts)) {
            if ($pdt_img_size <= 10 * 1024 * 1024) {
                if (!is_dir("uploads")) {
                    @mkdir("uploads", 0755, true);
                }

                $query = "INSERT INTO `products`( `pdt_name`, `pdt_price`, `pdt_weight`, `pdt_des`,`product_stock`, `pdt_ctg`, `pdt_img`, `pdt_status`) VALUES ('$pdt_name',$pdt_price,'$pdt_weight','$pdt_des',$pdt_stock,$pdt_ctg,'$pdt_img_name',$pdt_status)";

                if (mysqli_query($this->connection, $query)) {
                    move_uploaded_file($pdt_img_tmp, "uploads/" . $pdt_img_name);
                    $pdt_id = mysqli_insert_id($this->connection);
                    $this->save_product_gallery_images($pdt_id, $_FILES['multi_img']);
                    $msg = "Product uploaded successfully";
                    return $msg;
                } else {
                    return "Database error while adding product";
                }
            } else {
                $msg = "File size should not be larger than 10MB";
                return $msg;
            }
        } else {
            $msg = "File should be JPG, PNG, WEBP or GIF format";
            return $msg;
        }
    }

    function display_product()
    {
        $query = "SELECT * FROM `product_info_ctg`";

        if (mysqli_query($this->connection, $query)) {
            $pdt_info = mysqli_query($this->connection, $query);
            return $pdt_info;
        }
    }



    function delete_product($id)
    {
        $sel_query = "SELECT * FROM `products` WHERE pdt_id=$id";
        $query = mysqli_query($this->connection, $sel_query);
        $fetch = mysqli_fetch_assoc($query);
        $pdt_name = $fetch['pdt_name'];
        $img_name = $fetch['pdt_img'];

        $del_query = "DELETE FROM `products` WHERE pdt_id=$id";
        if (mysqli_query($this->connection, $del_query)) {
            if (file_exists('uploads/' . $img_name)) {
                unlink('uploads/' . $img_name);
            }
            $this->delete_product_gallery_images($id);
            return "{$pdt_name} deleted successfully";
        }
    }

    function published_product($id)
    {
        $query = "UPDATE `products` SET `pdt_status`='1' WHERE pdt_id=$id";
        if (mysqli_query($this->connection, $query)) {
            
            return "Published Successfully";
            
        }
    }

    function unpublished_product($id)
    {
        $query = "UPDATE `products` SET `pdt_status`='0' WHERE pdt_id=$id";
        if (mysqli_query($this->connection, $query)) {
            
            return "Unpublished Successfully";
            
        }
    }

    function edit_product($id)
    {
        $query = "SELECT * FROM `products` WHERE pdt_id=$id";
        if (mysqli_query($this->connection, $query)) {
            $pdt_info = mysqli_query($this->connection, $query);
            return $pdt_info;
        }
    }

  function update_product($data)
{
    $pdt_id = (int) $data['pdt_id'];
    $pdt_name = mysqli_real_escape_string($this->connection, trim($data['u_pdt_name']));
    $pdt_price = (int) $data['u_pdt_price'];
    $pdt_des = mysqli_real_escape_string($this->connection, $data['u_pdt_des']);
    $pdt_stock = (int) $data['pdt_stock'];
    $pdt_status = (int) $data['u_pdt_status'];

    $select_query = "SELECT * FROM products WHERE pdt_id=$pdt_id";
    $result = mysqli_query($this->connection, $select_query);
    $row = mysqli_fetch_assoc($result);

    if (!$row) {
        return "Product not found";
    }

    $pdt_weight = !empty($data['u_pdt_weight']) ? mysqli_real_escape_string($this->connection, trim($data['u_pdt_weight'])) : (!empty($row['pdt_weight']) ? $row['pdt_weight'] : '55g');
    $pdt_ctg = !empty($data['u_pdt_ctg']) ? (int) $data['u_pdt_ctg'] : (int) $row['pdt_ctg'];

    $pdt_img_name = $_FILES['u_pdt_img']['name'];
    $pdt_img_tmp = $_FILES['u_pdt_img']['tmp_name'];

    // =======================
    // 🔴 CASE 1: IMAGE UPLOADED
    // =======================
    if(!empty($pdt_img_name)){

        $img_ext = strtolower(pathinfo($pdt_img_name, PATHINFO_EXTENSION));
        $allowed_exts = array("jpg", "jpeg", "png", "webp", "gif");

        if (in_array($img_ext, $allowed_exts)) {

            // old image delete
            $pre_img = $row['pdt_img'];

            if (!empty($pre_img) && file_exists("uploads/" . $pre_img)) {
                @unlink("uploads/" . $pre_img);
            }

            if (!is_dir("uploads")) {
                @mkdir("uploads", 0755, true);
            }

            move_uploaded_file($pdt_img_tmp, "uploads/" . $pdt_img_name);

            $query = "UPDATE products SET 
                pdt_name='$pdt_name',
                pdt_price='$pdt_price',
                pdt_weight='$pdt_weight',
                pdt_des='$pdt_des',
                pdt_ctg='$pdt_ctg',
                pdt_img='$pdt_img_name',
                product_stock=$pdt_stock,
                pdt_status=$pdt_status
                WHERE pdt_id=$pdt_id";

        } else {
            return "Only JPG, PNG, WEBP, or GIF allowed";
        }

    }

    // =======================
    // 🟢 CASE 2: NO IMAGE UPLOAD
    // =======================
    else{
        $query = "UPDATE products SET 
            pdt_name='$pdt_name',
            pdt_price='$pdt_price',
            pdt_weight='$pdt_weight',
            pdt_des='$pdt_des',
            pdt_ctg='$pdt_ctg',
            product_stock=$pdt_stock,
            pdt_status=$pdt_status
            WHERE pdt_id=$pdt_id";
    }

    // =======================
    // 🔥 RUN UPDATE QUERY
    // =======================
    if(mysqli_query($this->connection, $query)){

        // =======================
        // 🔥 MULTIPLE IMAGES UPLOAD
        // =======================
        $this->save_product_gallery_images($pdt_id, $_FILES['multi_img']);

        return "Product Updated Successfully";
    } 
    else {
        return "Update Failed";
    }
}

    function display_product_byCata($cataId)
    {
        $query = "SELECT * FROM `product_info_ctg` WHERE ctg_id=$cataId AND pdt_status=1 AND `product_stock`>0";
        if (mysqli_query($this->connection, $query)) {
            $pdt_info = mysqli_query($this->connection, $query);
            return $pdt_info;
        }
    }

    function display_product_byId($pdtId)
    {
        $query = "SELECT * FROM `product_info_ctg` WHERE pdt_id=$pdtId";
        if (mysqli_query($this->connection, $query)) {
            $pdt_info = mysqli_query($this->connection, $query);
            return $pdt_info;
        }
    }

    function related_product($cataID)
    {
        $query = "SELECT * FROM `product_info_ctg` WHERE ctg_id=$cataID ORDER BY pdt_id DESC LIMIT 6";
        if (mysqli_query($this->connection, $query)) {
            $pdt_info = mysqli_query($this->connection, $query);
            return $pdt_info;
        }
    }

    function ctg_by_id($cataID)
    {
        $query = "SELECT * FROM `product_info_ctg` WHERE ctg_id=$cataID";
        if (mysqli_query($this->connection, $query)) {
            $pdt_info = mysqli_query($this->connection, $query);
            $pdt_fetch = mysqli_fetch_assoc($pdt_info);
            return $pdt_fetch;
        }
    }

    function is_user_email_registered($email)
    {
        $email = mysqli_real_escape_string($this->connection, strtolower(trim($email)));
        $check = mysqli_query($this->connection, "SELECT user_id FROM `users` WHERE `user_email`='$email'");
        return ($check && mysqli_num_rows($check) > 0);
    }

    function fast_user_register($fullName, $email, $password)
    {
        $fullName = trim($fullName);
        $email = mysqli_real_escape_string($this->connection, strtolower(trim($email)));
        $password_hash = md5($password);

        // Check if email already registered
        $check = mysqli_query($this->connection, "SELECT user_id FROM `users` WHERE `user_email`='$email'");
        if ($check && mysqli_num_rows($check) > 0) {
            return array('success' => false, 'message' => "An account with this email already exists. Please Sign In.");
        }

        // Split name into first and last
        $parts = explode(' ', $fullName, 2);
        $firstName = mysqli_real_escape_string($this->connection, trim($parts[0]));
        $lastName = isset($parts[1]) ? mysqli_real_escape_string($this->connection, trim($parts[1])) : '';

        // Generate username from email prefix
        $emailPrefix = explode('@', $email)[0];
        $baseUser = preg_replace('/[^a-zA-Z0-9_]/', '', $emailPrefix);
        if (empty($baseUser)) {
            $baseUser = preg_replace('/[^a-zA-Z0-9_]/', '', strtolower($firstName));
            if (empty($baseUser)) {
                $baseUser = 'user';
            }
        }

        $username = $baseUser;
        $idx = 1;
        while (true) {
            $u_check = mysqli_query($this->connection, "SELECT user_id FROM `users` WHERE `user_name`='$username'");
            if ($u_check && mysqli_num_rows($u_check) > 0) {
                $username = $baseUser . rand(10, 999);
                $idx++;
                if ($idx > 10) {
                    $username = $baseUser . time();
                    break;
                }
            } else {
                break;
            }
        }
        $username = mysqli_real_escape_string($this->connection, $username);

        $query = "INSERT INTO `users` (
            `user_name`, `user_firstname`, `user_lastname`, 
            `user_email`, `user_password`, `user_mobile`, 
            `user_address`, `home_address`, `office_address`, 
            `user_roles`
        ) VALUES (
            '$username', '$firstName', '$lastName', 
            '$email', '$password_hash', '', 
            '', NULL, NULL, 5
        )";

        if (mysqli_query($this->connection, $query)) {
            $new_user_id = mysqli_insert_id($this->connection);
            return array(
                'success' => true,
                'user_id' => $new_user_id,
                'user_name' => $username,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'email' => $email
            );
        } else {
            return array('success' => false, 'message' => "Database error: " . mysqli_error($this->connection));
        }
    }

    function user_register($data)
    {
        $username = mysqli_real_escape_string($this->connection, trim($data['username']));
        $user_firstname = mysqli_real_escape_string($this->connection, trim($data['user_firstname']));
        $user_lastname = mysqli_real_escape_string($this->connection, trim($data['user_lastname']));
        $user_email = mysqli_real_escape_string($this->connection, trim($data['user_email']));
        $user_password = md5($data['user_password']);
        $user_mobile = mysqli_real_escape_string($this->connection, trim($data['user_mobile']));
        $user_address = mysqli_real_escape_string($this->connection, trim($data['user_address']));
        $user_roles = (int) $data['user_roles'];


        $user_check = "SELECT * FROM `users` WHERE user_name='$username' or user_email='$user_email'";

        $mysqli_result = mysqli_query($this->connection, $user_check);

        $row = mysqli_num_rows($mysqli_result);

        if ($row == 1) {
            $msg = "Username or email already exist";
            return $msg;
        } else {
            $query = "INSERT INTO `users`( `user_name`, `user_firstname`, `user_lastname`, `user_email`, `user_password`, `user_mobile`,`user_address`, `user_roles`) VALUES ('$username','$user_firstname','$user_lastname','$user_email','$user_password','$user_mobile','$user_address',$user_roles)";

            if (mysqli_query($this->connection, $query)) {
                $msg = "Your registration done";
                return $msg;
            }
        }
    }


    function user_login($data)
    {
        $user_email = mysqli_real_escape_string($this->connection, trim($data['user_email']));
        $user_password = md5($data['user_password']);

        $query = "SELECT * FROM `users` WHERE (`user_email`='$user_email' OR `user_name`='$user_email') AND `user_password`='$user_password'";

        if (mysqli_query($this->connection, $query)) {
            $result = mysqli_query($this->connection, $query);
            $user_info = mysqli_fetch_array($result);
            if ($user_info) {
                if (session_status() == PHP_SESSION_NONE) {
                    session_start();
                }
                $_SESSION['user_id'] = $user_info['user_id'];
                $_SESSION['email'] = $user_info['user_email'];
                $_SESSION['mobile'] = $user_info['user_mobile'];
                $_SESSION['address'] = $user_info['user_address'];
                $_SESSION['home_address'] = isset($user_info['home_address']) ? $user_info['home_address'] : '';
                $_SESSION['office_address'] = isset($user_info['office_address']) ? $user_info['office_address'] : '';

                $_SESSION['username'] = $user_info['user_name'];
                $_SESSION['flash_success'] = "Welcome back, " . htmlspecialchars($user_info['user_firstname'] ? $user_info['user_firstname'] : $user_info['user_name']) . "!";
                if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
                    header("location:userprofile.php");
                } else {
                    header("location:exist_order.php");
                }
                exit();
            } else {
                $logmsg = "Your email/username or password is incorrect";
                return $logmsg;
            }
        }
    }

    function user_logout()
    {
        unset($_SESSION['user_id']);
        unset($_SESSION['email']);
        unset($_SESSION['password']);
        unset($_SESSION['home_address']);
        unset($_SESSION['office_address']);

        header("location:user_login.php");
        session_destroy();
    }

    function get_user_profile($user_id)
    {
        $user_id = (int) $user_id;
        $query = "SELECT * FROM `users` WHERE `user_id` = $user_id";
        $res = mysqli_query($this->connection, $query);
        if ($res && mysqli_num_rows($res) > 0) {
            return mysqli_fetch_assoc($res);
        }
        return null;
    }

    function update_user_saved_address($user_id, $type, $address)
    {
        $user_id = (int) $user_id;
        $address = mysqli_real_escape_string($this->connection, trim($address));
        $column = ($type === 'office') ? 'office_address' : 'home_address';

        $query = "UPDATE `users` SET `$column` = '$address' WHERE `user_id` = $user_id";
        if (mysqli_query($this->connection, $query)) {
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION[$column] = $address;
            return true;
        }
        return false;
    }

    function update_customer_profile($user_id, $data)
    {
        $user_id = (int) $user_id;
        $user_firstname = mysqli_real_escape_string($this->connection, trim($data['user_firstname'] ?? ''));
        $user_lastname = mysqli_real_escape_string($this->connection, trim($data['user_lastname'] ?? ''));
        $user_mobile = mysqli_real_escape_string($this->connection, trim($data['user_mobile'] ?? ''));
        $user_address = mysqli_real_escape_string($this->connection, trim($data['user_address'] ?? ''));
        $user_email = mysqli_real_escape_string($this->connection, strtolower(trim($data['user_email'] ?? '')));

        if (empty($user_firstname)) {
            return array('success' => false, 'message' => "First name cannot be empty.");
        }

        // Check if email changed and if already taken
        if (!empty($user_email)) {
            $chk = mysqli_query($this->connection, "SELECT user_id FROM `users` WHERE `user_email`='$user_email' AND `user_id` != $user_id");
            if ($chk && mysqli_num_rows($chk) > 0) {
                return array('success' => false, 'message' => "This email is already in use by another account.");
            }
        }

        $email_clause = !empty($user_email) ? ", `user_email`='$user_email'" : "";
        $query = "UPDATE `users` SET 
            `user_firstname`='$user_firstname',
            `user_lastname`='$user_lastname',
            `user_mobile`='$user_mobile',
            `user_address`='$user_address'
            $email_clause
            WHERE `user_id`=$user_id";

        if (mysqli_query($this->connection, $query)) {
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }
            if (!empty($user_email)) {
                $_SESSION['email'] = $user_email;
            }
            $_SESSION['mobile'] = $user_mobile;
            $_SESSION['address'] = $user_address;
            return array('success' => true, 'message' => "Profile updated successfully!");
        } else {
            return array('success' => false, 'message' => "Failed to update profile: " . mysqli_error($this->connection));
        }
    }

    function show_all_customers($search = '', $order_filter = 'all')
    {
        $where_clauses = array();

        if (!empty($search)) {
            $s = mysqli_real_escape_string($this->connection, trim($search));
            $where_clauses[] = "(u.user_name LIKE '%$s%' OR u.user_firstname LIKE '%$s%' OR u.user_lastname LIKE '%$s%' OR u.user_email LIKE '%$s%' OR u.user_mobile LIKE '%$s%' OR u.user_address LIKE '%$s%')";
        }

        $where_sql = !empty($where_clauses) ? "WHERE " . implode(' AND ', $where_clauses) : "";

        $having_sql = "";
        if ($order_filter === 'with_orders') {
            $having_sql = "HAVING total_orders > 0";
        } elseif ($order_filter === 'without_orders') {
            $having_sql = "HAVING total_orders = 0";
        }

        $query = "SELECT 
            u.*,
            COUNT(DISTINCT o.order_id) as total_orders,
            COALESCE(SUM(o.amount), 0) as total_spent,
            MAX(o.order_date) as last_order_date
        FROM `users` u
        LEFT JOIN `order_details` o ON u.user_id = o.user_id
        $where_sql
        GROUP BY u.user_id
        $having_sql
        ORDER BY u.user_id DESC";

        return mysqli_query($this->connection, $query);
    }

    function count_all_registered_customers()
    {
        $res = mysqli_query($this->connection, "SELECT COUNT(*) as cnt FROM `users`");
        if ($res && $row = mysqli_fetch_assoc($res)) {
            return (int) $row['cnt'];
        }
        return 0;
    }

    function delete_registered_customer($user_id)
    {
        $user_id = (int) $user_id;
        $query = "DELETE FROM `users` WHERE `user_id` = $user_id";
        if (mysqli_query($this->connection, $query)) {
            return "Customer #$user_id deleted successfully.";
        } else {
            return "Failed to delete customer: " . mysqli_error($this->connection);
        }
    }

    function get_customer_full_details($user_id)
    {
        $user_id = (int) $user_id;
        $user_res = mysqli_query($this->connection, "SELECT * FROM `users` WHERE `user_id` = $user_id");
        $user = ($user_res && mysqli_num_rows($user_res) > 0) ? mysqli_fetch_assoc($user_res) : null;
        if (!$user) {
            return null;
        }

        $orders = array();
        $orders_res = mysqli_query($this->connection, "SELECT * FROM `order_details` WHERE `user_id` = $user_id ORDER BY `order_id` DESC");
        if ($orders_res) {
            while ($ord = mysqli_fetch_assoc($orders_res)) {
                $orders[] = $ord;
            }
        }
        $user['orders'] = $orders;
        return $user;
    }

    function view_all_product()
    {
        $query = "SELECT * FROM `product_info_ctg` WHERE `product_stock`>1 ";

        if (mysqli_query($this->connection, $query)) {
            $pdt_info = mysqli_query($this->connection, $query);
            return $pdt_info;
        }
    }

    function display_five_catagory()
    {
        $query = "SELECT * FROM `catagory` LIMIT 5";
        if (mysqli_query($this->connection, $query)) {
            $catagories = mysqli_query($this->connection, $query);
            return $catagories;
        }
    }

    function display_five_products($ctg_id)
    {
        $query = "SELECT * FROM `product_info_ctg` WHERE `ctg_id`=$ctg_id LIMIT 8";

        if (mysqli_query($this->connection, $query)) {
            $eight_product = mysqli_query($this->connection, $query);
            return $eight_product;
        }
    }

    function display_top_rated_pdt()
    {
        $query = "SELECT * FROM `product_info_ctg` WHERE `pdt_status`=1 ORDER BY `pdt_id` DESC LIMIT 12";

        if (mysqli_query($this->connection, $query)) {
            $top_rated = mysqli_query($this->connection, $query);
            return $top_rated;
        }
    }

    function search_product($keyword)
    {
        $escaped = mysqli_real_escape_string($this->connection, trim($keyword));
        $query = "SELECT * FROM `product_info_ctg` WHERE `pdt_name` LIKE '%$escaped%' OR `ctg_name` LIKE '%$escaped%'";

        if ($search_query = mysqli_query($this->connection, $query)) {
            return $search_query;
        }
        return false;
    }

    function live_search_product($keyword, $limit = 6)
    {
        $escaped = mysqli_real_escape_string($this->connection, trim($keyword));
        $limit = (int) $limit;
        $query = "SELECT pdt_id, pdt_name, pdt_price, pdt_img, ctg_name FROM `product_info_ctg` WHERE `pdt_name` LIKE '%$escaped%' OR `ctg_name` LIKE '%$escaped%' LIMIT $limit";

        if ($res = mysqli_query($this->connection, $query)) {
            return $res;
        }
        return false;
    }

    function place_order($data)
    {
        $user_id = $data['user_id'];
        $product_name = $data['product_name'];
        $product_item = $data['product_item'];
        $quantity = $data['quan'];
        $amount = $data['amount'];
        $order_status = $data['order_status'];
        $trans_id = $data['txid'];
        $mobile = $data['shipping_Mobile'];

        $shiping = $data['shiping'];


        $query = "INSERT INTO `order_details`(`user_id`, `product_name`, `product_item`, `amount`, `order_status`, `trans_id`,`Shipping_mobile`, `shiping`, `order_time`, `order_date`) VALUES ( $user_id,'$product_name',$product_item, $amount, $order_status,'$trans_id',$mobile,'$shiping',NOW(), CURDATE())";

        if (mysqli_query($this->connection, $query)) {

            unset($_SESSION['cart']);
            header("location:exist_order.php");
        }
    }

    function confirm_order($post, $session){
        if (session_status() === PHP_SESSION_NONE) {
            @session_start();
        }
        if (empty($_SESSION['user_id'])) {
            $_SESSION['flash_error'] = "Please sign in or create an account to place an order.";
            header("location:user_login.php");
            exit();
        }
        $user_id = (int) $_SESSION['user_id'];
        $order_status = (int) $post['order_status'];
        $trans_id = mysqli_real_escape_string($this->connection, trim($post['txid']));
        $mobile = mysqli_real_escape_string($this->connection, trim($post['shipping_Mobile']));
        $shiping = mysqli_real_escape_string($this->connection, trim($post['shiping']));
        $payment_method = isset($post['payment_method']) ? mysqli_real_escape_string($this->connection, trim($post['payment_method'])) : 'manual';
        $payment_status = isset($post['payment_status']) ? mysqli_real_escape_string($this->connection, trim($post['payment_status'])) : 'pending';
        $gateway_order_id = isset($post['gateway_order_id']) ? mysqli_real_escape_string($this->connection, trim($post['gateway_order_id'])) : '';
        $coupon_code = isset($post['coupon']) ? trim($post['coupon']) : '';
        $quantity_inputs = isset($post['quantity']) && is_array($post['quantity']) ? $post['quantity'] : array();
        $coupon = $this->get_coupon_by_code($coupon_code);
        $coupon_discount = $coupon ? (int) $coupon['discount'] : 0;
        $coupon_code_to_save = $coupon ? $coupon['cupon_code'] : '';

        // Save address to address book if requested by customer
        if (isset($post['save_address_type']) && in_array($post['save_address_type'], array('home', 'office'))) {
            $this->update_user_saved_address($user_id, $post['save_address_type'], $shiping);
        }

        if (empty($session)) {
            return "Your cart is empty";
        }

        $order_items_for_email = array();
        $total_order_amount = 0;
        $first_inserted_order_id = 0;

        foreach($session as $index => $key){
            $pdt_name = mysqli_real_escape_string($this->connection, $key['pdt_name']);
            $pdt_weight = isset($key['pdt_weight']) && !empty($key['pdt_weight']) ? mysqli_real_escape_string($this->connection, $key['pdt_weight']) : '55g';
            $pdt_price = (int) $key['pdt_price'];
            $pdt_quantity = isset($quantity_inputs[$index]) ? (int) $quantity_inputs[$index] : (isset($key['quantity']) ? (int) $key['quantity'] : 1);
            if ($pdt_quantity < 1) {
                $pdt_quantity = 1;
            }

            $line_total = $pdt_price * $pdt_quantity;
            if ($coupon_discount > 0) {
                $line_total = (int) round($line_total - (($line_total * $coupon_discount) / 100));
            }
            $total_order_amount += $line_total;

            $query = "INSERT INTO `order_details`(`user_id`, `product_name`, `pdt_weight`, `pdt_quantity`, `amount`,`uses_coupon`, `order_status`, `trans_id`, `Shipping_mobile`, `shiping`, `payment_method`, `payment_status`, `gateway_order_id`, `order_time`) VALUES ($user_id,'$pdt_name','$pdt_weight',$pdt_quantity, $line_total,'$coupon_code_to_save', $order_status,'$trans_id','$mobile','$shiping','$payment_method','$payment_status','$gateway_order_id',NOW())";

            if (!mysqli_query($this->connection, $query)) {
                return "Order confirmation failed";
            }

            $inserted_id = mysqli_insert_id($this->connection);
            if ($first_inserted_order_id === 0) {
                $first_inserted_order_id = $inserted_id;
            }

            $order_items_for_email[] = array(
                'name' => $key['pdt_name'],
                'weight' => $pdt_weight,
                'qty' => $pdt_quantity,
                'price' => $pdt_price,
                'total' => $line_total
            );
        }

        // Send order confirmation email to customer & store care@postic.in
        $this->send_order_confirmation_email($user_id, $first_inserted_order_id, $order_items_for_email, $total_order_amount, $shiping, $mobile, $payment_method, $coupon_code_to_save, $coupon_discount);

        unset($_SESSION['cart']);
        unset($_SESSION['cart_pdt_number']);
        unset($_SESSION['subtotal']);
        $_SESSION['flash_success'] = "Order placed successfully! Order ID #" . $first_inserted_order_id;
        header("location:exist_order.php");
        exit();
    }

    function send_order_confirmation_email($user_id, $order_id, $items, $total_amount, $address, $mobile, $payment_method, $coupon = '', $coupon_discount = 0)
    {
        $user = $this->get_user_profile($user_id);
        if (!$user || empty($user['user_email'])) {
            return false;
        }

        $customer_email = $user['user_email'];
        $customer_name = trim($user['user_firstname'] . ' ' . $user['user_lastname']);
        if (empty($customer_name)) {
            $customer_name = $user['user_name'] ?? 'Customer';
        }

        $mailer_path = dirname(__DIR__, 2) . '/includes/postic_mailer.php';
        if (file_exists($mailer_path)) {
            require_once $mailer_path;
            $order_payload = array(
                'order_id'        => $order_id,
                'customer_email'  => $customer_email,
                'customer_name'   => $customer_name,
                'mobile'          => $mobile,
                'address'         => $address,
                'items'           => $items,
                'total_amount'    => $total_amount,
                'payment_method'  => $payment_method,
                'payment_status'  => 'processing',
                'coupon'          => $coupon,
                'coupon_discount' => $coupon_discount,
            );
            return PosticMailer::send_order_notifications($order_payload);
        }

        return false;
    }

    function order_details_by_id($user_id)
    {
        $user_id = (int)$user_id;
        $query = "SELECT * FROM `order_details` WHERE `user_id`=$user_id ORDER BY `order_time` DESC";
        if (mysqli_query($this->connection, $query)) {
            $order_query = mysqli_query($this->connection, $query);
            return $order_query;
        }
        return false;
    }

    function get_order_by_order_id($order_id)
    {
        $order_id = (int)$order_id;
        $query = "SELECT order_details.*, users.user_firstname, users.user_lastname, users.user_email, users.user_mobile, users.user_address FROM `order_details` JOIN `users` ON users.user_id = order_details.user_id WHERE order_details.order_id = $order_id";
        $result = mysqli_query($this->connection, $query);
        if ($result && mysqli_num_rows($result) > 0) {
            return mysqli_fetch_assoc($result);
        }
        return null;
    }

    function all_order_info()
    {
        $query = "SELECT order_details.order_id, order_details.product_name, order_details.pdt_weight, order_details.pdt_quantity, order_details.amount, order_details.uses_coupon, users.user_firstname AS customer_name, order_details.Shipping_mobile, order_details.trans_id, order_details.shiping AS shiping_address, order_details.payment_method, order_details.payment_status, order_details.gateway_order_id, order_details.order_status, order_details.order_time, order_details.order_date FROM `order_details` JOIN `users` ON users.user_id = order_details.user_id ORDER BY order_details.order_time DESC";

        if (mysqli_query($this->connection, $query)) {
            $all_order_info = mysqli_query($this->connection, $query);
            return $all_order_info;
        }
    }

    function updat_order_status($data)
    {
        $u_pdt_id = (int)$data['order_id'];
        $u_pdt_status = (int)$data['update_status'];
        $query = "UPDATE `order_details` SET `order_status`= $u_pdt_status WHERE `order_id`= $u_pdt_id";
        if (mysqli_query($this->connection, $query)) {
            $notify_customer = isset($data['notify_customer']) ? (bool)$data['notify_customer'] : true;
            if ($notify_customer) {
                $sel = mysqli_query($this->connection, "SELECT o.order_id, o.product_name, u.user_email, u.user_firstname, u.user_name FROM `order_details` o JOIN `users` u ON u.user_id = o.user_id WHERE o.order_id = $u_pdt_id LIMIT 1");
                if ($sel && $row = mysqli_fetch_assoc($sel)) {
                    $c_email = $row['user_email'];
                    $c_name = !empty($row['user_firstname']) ? $row['user_firstname'] : $row['user_name'];
                    require_once dirname(__DIR__, 2) . '/includes/postic_mailer.php';
                    PosticMailer::send_order_status_update($c_email, $c_name, $u_pdt_id, $u_pdt_status, $row['product_name']);
                }
            }
            $status_msg = "Order #{$u_pdt_id} status updated successfully.";
            return $status_msg;
        }
    }

    function customer_cancel_order($user_id, $order_id, $reason = '')
    {
        $user_id = (int)$user_id;
        $order_id = (int)$order_id;
        $reason = mysqli_real_escape_string($this->connection, trim($reason));

        if ($user_id <= 0 || $order_id <= 0) {
            return array('success' => false, 'message' => 'Invalid order details.');
        }

        // Verify ownership and fetch current order status
        $check_q = "SELECT o.*, u.user_email, u.user_firstname, u.user_name FROM `order_details` o JOIN `users` u ON u.user_id = o.user_id WHERE o.order_id = $order_id AND o.user_id = $user_id LIMIT 1";
        $res = mysqli_query($this->connection, $check_q);
        if (!$res || mysqli_num_rows($res) === 0) {
            return array('success' => false, 'message' => 'Order not found or permission denied.');
        }

        $order = mysqli_fetch_assoc($res);
        $st = (int)$order['order_status'];

        if ($st === 4) {
            return array('success' => false, 'message' => 'This order is already cancelled.');
        }
        if ($st === 2 || $st === 3) {
            return array('success' => false, 'message' => 'This order is already dispatched or delivered and cannot be cancelled directly. Please contact WhatsApp support.');
        }

        // Update status to 4 (Cancelled)
        $update_q = "UPDATE `order_details` SET `order_status` = 4 WHERE `order_id` = $order_id AND `user_id` = $user_id";
        if (mysqli_query($this->connection, $update_q)) {
            // Trigger cancellation email to customer and store
            require_once dirname(__DIR__, 2) . '/includes/postic_mailer.php';
            $c_email = $order['user_email'];
            $c_name = !empty($order['user_firstname']) ? $order['user_firstname'] : $order['user_name'];
            PosticMailer::send_order_status_update($c_email, $c_name, $order_id, 4, $order['product_name']);

            return array('success' => true, 'message' => "Order #{$order_id} has been cancelled successfully.");
        }

        return array('success' => false, 'message' => 'Failed to cancel order. Please try again.');
    }

    function user_password_recover($recover_email)
    {
        $query = "SELECT * FROM `users` WHERE `user_email`='$recover_email'";
        if (mysqli_query($this->connection, $query)) {
            $row =  mysqli_query($this->connection, $query);
            return $row;
        }
    }

    function update_user_password($data)
    {

        $update_id = $data['update_user_id'];
        $update_password = md5($data['update_user_password']);

        // echo $update_id.$update_password;

        $query = "UPDATE `users` SET `user_password`='$update_password' WHERE `user_id`=$update_id";


        if (mysqli_query($this->connection, $query)) {
            $update_mag = "You password updated successfull";
            return $update_mag;
        } else {
            return "Please enter a correct email";
        }
    }


    function display_links()
    {
        $query = "SELECT * FROM header_info";

        if (mysqli_query($this->connection, $query)) {
            $ctg_info = mysqli_query($this->connection, $query);
            return $ctg_info;
        }
    }

    function display_link_ID($id)
    {
        $query = "SELECT * FROM header_info WHERE id = $id";

        if (mysqli_query($this->connection, $query)) {
            $cata_info = mysqli_query($this->connection, $query);
            return mysqli_fetch_assoc($cata_info);
        }
    }

    //Mynul created 

    function updata_links($data)
    {
        $link_id = $data['id'];
        $link_email = $data['email'];
        $link_tweeter = $data['tweeter'];
        $link_fb = $data['fb'];
        $link_pin = $data['pin'];
        $link_phone = $data['phone'];


        $query = "UPDATE header_info SET email='$link_email',tweeter='$link_tweeter',fb_link= '$link_fb', pinterest='$link_pin', phone='$link_phone' WHERE id = $link_id";
        if (mysqli_query($this->connection, $query)) {
            return "Link Update successfully";
        }
    }

    function display_logo()
    {
        $query = "SELECT * FROM add_logo ORDER BY id DESC";

        if (mysqli_query($this->connection, $query)) {
            $pdt_info = mysqli_query($this->connection, $query);
            return $pdt_info;
        }
    }



    function display_logo_ID($id)
    {
        $query = "SELECT * FROM add_logo WHERE id = $id";

        if (mysqli_query($this->connection, $query)) {
            $cata_info = mysqli_query($this->connection, $query);
            return mysqli_fetch_assoc($cata_info);
        }
    }

    function update_logo($data){
        $lg_id = $data['id'];

        $lg_name = $_FILES['img']['name'];
        $lg_size = $_FILES['img']['size'];
        $lg_tmp = $_FILES['img']['tmp_name'];
        $lg_ext = strtolower(pathinfo($lg_name, PATHINFO_EXTENSION));

        if (empty($lg_name) || empty($lg_tmp)) {
            return "Please select a logo image";
        }


        $allowed_exts = array("jpg", "jpeg", "png", "webp", "gif", "svg");

        if (in_array($lg_ext, $allowed_exts)) {
            if ($lg_size <= 5 * 1024 * 1024) {
                if (!is_dir("uploads")) {
                    @mkdir("uploads", 0755, true);
                }

                $select_query = "SELECT * FROM `add_logo` WHERE id=$lg_id";
                $result = mysqli_query($this->connection, $select_query);
                $row = mysqli_fetch_assoc($result);
                $pre_img = $row['img'];
                $new_logo_name = "logo_" . time() . "_" . mt_rand(1000, 9999) . "." . $lg_ext;

                if (move_uploaded_file($lg_tmp, "uploads/" . $new_logo_name)) {
                    $query = "UPDATE add_logo SET img='$new_logo_name' WHERE id=$lg_id";

                    if (!mysqli_query($this->connection, $query)) {
                        if (file_exists("uploads/" . $new_logo_name)) {
                            @unlink("uploads/" . $new_logo_name);
                        }
                        return "Logo update failed";
                    }

                    if (!empty($pre_img) && file_exists("uploads/" . $pre_img)) {
                        @unlink("uploads/" . $pre_img);
                    }
                    $msg = "Logo updated successfully";
                    return $msg;
                }
                return "Logo upload failed";
            } else {
                $msg = "File size should not be larger than 5MB";
                return $msg;
            }
        } else {
            $msg = "File should be JPG, PNG, WEBP or SVG format";
            return $msg;
        }
    }

    function SlideShow(){
        $query = "SELECT * FROM `slider`";
        if(mysqli_query($this->connection, $query)){
            $row = mysqli_query($this->connection, $query);
            return $row;
        }
    }

    
    function slide_By_id($id){
        $query = "SELECT * FROM `slider` WHERE `slider_id`=$id";
        if(mysqli_query($this->connection, $query)){
            $row = mysqli_query($this->connection, $query);
            return $row;
        }
    }

    function slider_update($data){
        $slide_id = $data['slider_id'];
        $first_line = $data['first_line'];
        $second_line = $data['second_line'];
        $third_line = $data['third_line'];
        $btn_left = $data['btn_left'];
        $btn_right = $data['btn_right'];
        
        $lg_name = $_FILES['slider_img']['name'];
        $lg_size = $_FILES['slider_img']['size'];
        $lg_tmp = $_FILES['slider_img']['tmp_name'];
        $lg_ext = strtolower(pathinfo($lg_name, PATHINFO_EXTENSION));

        $select_query = "SELECT * FROM `slider` WHERE `slider_id`=$slide_id";
        $result = mysqli_query($this->connection, $select_query);
        $row = mysqli_fetch_assoc($result);

        if (!$row) {
            return "Slider not found";
        }

        if (!empty($lg_name)) {
            $allowed_exts = array("jpg", "jpeg", "png", "webp", "gif");

            if (in_array($lg_ext, $allowed_exts)) {
                if ($lg_size <= 10 * 1024 * 1024) {
                    if (!is_dir("uploads")) {
                        @mkdir("uploads", 0755, true);
                    }

                    $new_slider_name = "slider_" . time() . "_" . mt_rand(1000, 9999) . "." . $lg_ext;

                    if (!move_uploaded_file($lg_tmp, "uploads/" . $new_slider_name)) {
                        return "Slider upload failed. Please check folder permissions.";
                    }

                    $query = "UPDATE `slider` SET `first_line`='$first_line',`second_line`='$second_line',`third_line`='$third_line',`btn_left`='$btn_left',`btn_right`='$btn_right',`slider_img`='$new_slider_name' WHERE `slider_id`=$slide_id";

                    if (mysqli_query($this->connection, $query)) {
                        if (!empty($row['slider_img']) && file_exists("uploads/" . $row['slider_img'])) {
                            @unlink("uploads/" . $row['slider_img']);
                        }
                        return "Slider updated successfully";
                    }

                    if (file_exists("uploads/" . $new_slider_name)) {
                        @unlink("uploads/" . $new_slider_name);
                    }
                    return "Slider update failed";
                } else {
                    return "File size should not be larger than 10MB";
                }
            } else {
                return "File should be JPG, PNG, WEBP or GIF format";
            }
        }

        $query = "UPDATE `slider` SET `first_line`='$first_line',`second_line`='$second_line',`third_line`='$third_line',`btn_left`='$btn_left',`btn_right`='$btn_right' WHERE `slider_id`=$slide_id";

        if (mysqli_query($this->connection, $query)) {
            return "Slider updated successfully";
        }

        return "Slider update failed";
    }


    function post_comment($data){
        $user_id = (int) $data['user_id'];
        $user_name = mysqli_real_escape_string($this->connection, trim($data['user_name']));
        $pdt_id = (int) $data['pdt_id'];
        $user_comment = mysqli_real_escape_string($this->connection, trim($data['comment']));
        $rating = isset($data['rating']) ? max(1, min(5, (int) $data['rating'])) : 5;

        $query = "INSERT INTO `customer_feedback`(`user_id`, `user_name`, `pdt_id`, `comment`, `rating`, `comment_date`) VALUES ($user_id,'$user_name',$pdt_id,'$user_comment',$rating,CURDATE())";
        
        if(mysqli_query($this->connection, $query)){
            $msg = "Thanks for your valuable review & rating!";
            return $msg;
        }
        return "Review submission failed.";
    }

    function view_comment_id($id){
        $id = (int) $id;
        $query = "SELECT * FROM `customer_feedback` WHERE `pdt_id`=$id ORDER BY `id` DESC";
        if(mysqli_query($this->connection, $query)){
            $result = mysqli_query($this->connection, $query);

            if(mysqli_num_rows($result)>0){
                return $result;
            }
            
        }
        return false;
    }

    function get_product_rating_summary($pdt_id){
        $pdt_id = (int) $pdt_id;
        $query = "SELECT 
            COUNT(*) as total_reviews,
            COALESCE(AVG(rating), 5.0) as avg_rating,
            COALESCE(SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END), 0) as stars_5,
            COALESCE(SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END), 0) as stars_4,
            COALESCE(SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END), 0) as stars_3,
            COALESCE(SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END), 0) as stars_2,
            COALESCE(SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END), 0) as stars_1
        FROM `customer_feedback` WHERE `pdt_id` = $pdt_id";

        $res = mysqli_query($this->connection, $query);
        if ($res && $row = mysqli_fetch_assoc($res)) {
            $total = (int) $row['total_reviews'];
            $avg = $total > 0 ? round((float)$row['avg_rating'], 1) : 4.9;
            return array(
                'total' => $total,
                'avg' => $avg,
                'stars_5' => (int) $row['stars_5'],
                'stars_4' => (int) $row['stars_4'],
                'stars_3' => (int) $row['stars_3'],
                'stars_2' => (int) $row['stars_2'],
                'stars_1' => (int) $row['stars_1']
            );
        }
        return array('total' => 0, 'avg' => 4.9, 'stars_5' => 0, 'stars_4' => 0, 'stars_3' => 0, 'stars_2' => 0, 'stars_1' => 0);
    }

    function view_comment_all(){
        $query = "SELECT * FROM `customer_feedback`";
        if(mysqli_query($this->connection, $query)){
            $result = mysqli_query($this->connection, $query);

           return $result;
            
        }
    }

    function edit_comment($cmt_id){
        $query = "SELECT * FROM `customer_feedback` WHERE `id` = $cmt_id";

        if(mysqli_query($this->connection, $query)){
            $array = mysqli_query($this->connection, $query);
            return $array;
        }
    }
    function update_comment($data){
        $cmt_id = $data['cmt_id'];
        $comment = $data['u_comment'];
        $query = "UPDATE `customer_feedback` SET `comment`='$comment' WHERE `id`=$cmt_id";
        if(mysqli_query($this->connection, $query)){
            $updata_msg = "Comment updated successfully";
            return $updata_msg;
        }
    }

    function delete_comment($cmt_id){
        $query = "DELETE FROM `customer_feedback` WHERE `id`=$cmt_id";

        if(mysqli_query($this->connection, $query)){
            $del_msg = "Comment deleted successfully";
            return $del_msg;
        }
    }

    function add_coupon($data){
        $coupon_code = $data['cuopon_code'];
        $coupon_description = $data['cuopon_description'];
        $coupon_discount = $data['cuopon_discount'];
        $coupon_status = $data['cuopon_status'];


        $query = "INSERT INTO `cupon`( `cupon_code`, `description`, `discount`, `status`) VALUES ('$coupon_code','$coupon_description',$coupon_discount,$coupon_status)";

        if(mysqli_query($this->connection, $query)){

            
            $add_msg = "Coupon added successfully";
            return $add_msg;
        }
    }

    function show_coupon(){
        $query = "SELECT * FROM `cupon` ORDER BY `cupon_id` DESC";
        if(mysqli_query($this->connection, $query)){
            $result = mysqli_query($this->connection, $query);
            return $result;
        }
    }

    function get_coupon_by_code($coupon_code){
        $coupon_code = mysqli_real_escape_string($this->connection, trim($coupon_code));
        if ($coupon_code === '') {
            return false;
        }

        $query = "SELECT * FROM `cupon` WHERE `cupon_code`='$coupon_code' AND `status`=1 LIMIT 1";
        if (mysqli_query($this->connection, $query)) {
            $result = mysqli_query($this->connection, $query);
            return mysqli_fetch_assoc($result);
        }

        return false;
    }

    function show_coupon_by_id($coupon_id){
        $coupon_id = (int) $coupon_id;
        if ($coupon_id <= 0) {
            return false;
        }

        $query = "SELECT * FROM `cupon` WHERE `cupon_id`=$coupon_id";
        if(mysqli_query($this->connection, $query)){
            $result = mysqli_query($this->connection, $query);
            return mysqli_fetch_assoc($result);
        }

        return false;
    }

    function update_coupon($data){
        $coupon_id = (int) $data['cupon_id'];
        if ($coupon_id <= 0) {
            return "Coupon update failed";
        }

        $coupon_code = mysqli_real_escape_string($this->connection, trim($data['cuopon_code']));
        $coupon_description = mysqli_real_escape_string($this->connection, trim($data['cuopon_description']));
        $coupon_discount = (int) $data['cuopon_discount'];
        $coupon_status = (int) $data['cuopon_status'];

        $query = "UPDATE `cupon` SET `cupon_code`='$coupon_code', `description`='$coupon_description', `discount`=$coupon_discount, `status`=$coupon_status WHERE `cupon_id`=$coupon_id";

        if (mysqli_query($this->connection, $query)) {
            return "Coupon updated successfully";
        }

        return "Coupon update failed";
    }

    function delete_coupon($coupon_id){
        $query = "DELETE FROM `cupon` WHERE `cupon_id`=$coupon_id";
        if (mysqli_query($this->connection, $query)) {
            return "Coupon deleted successfully";
        }
    }

    function update_coupon_status($coupon_id, $status){
        $query = "UPDATE `cupon` SET `status`=$status WHERE `cupon_id`=$coupon_id";
        if (mysqli_query($this->connection, $query)) {
            return $status == 1 ? "Coupon activated successfully" : "Coupon deactivated successfully";
        }
    }

    function count_low_stock_products($limit = 5){
        $query = "SELECT COUNT(*) AS total FROM `products` WHERE `product_stock`<=$limit";
        if (mysqli_query($this->connection, $query)) {
            $result = mysqli_query($this->connection, $query);
            $row = mysqli_fetch_assoc($result);
            return $row['total'];
        }
        return 0;
    }
}
