<?php
/**
 * Direct route alias for /admin/traffic-simulator.php
 */
require_once __DIR__ . '/traffic_simulator.php';
