<?php 
    $views = "traffic_analytics";
    include ("template.php");
?>
