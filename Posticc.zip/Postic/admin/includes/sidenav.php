<nav class="pcoded-navbar">
                        <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
                        <div class="pcoded-inner-navbar main-menu">
                            
                            <div class="pcoded-navigatio-lavel" data-i18n="nav.category.navigation"></div>
                            <ul class="pcoded-item pcoded-left-item">
                                <li class="<?php echo (!isset($views) || $views == 'dashboard') ? 'active' : ''; ?>">
                                    <a href="dashboard.php">
                                        <span class="pcoded-micon"><i class="ti-home"></i><b>D</b></span>
                                        <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>

                                <li class="<?php echo (isset($views) && $views == 'traffic_analytics') ? 'active' : ''; ?>">
                                    <a href="traffic_analytics.php" style="position: relative; display: block;">
                                        <span class="pcoded-micon"><i class="ti-pulse" style="color: #ff5370;"></i><b>T</b></span>
                                        <span class="pcoded-mtext">Website Traffic</span>
                                        <span class="pcoded-badge label label-danger" style="position: absolute; right: 20px; top: 12px; font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 4px; line-height: 1.2;">Live</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>

                                <li class="pcoded-hasmenu <?php echo (isset($views) && $views == 'make_report') ? 'active pcoded-trigger' : ''; ?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-bar-chart"></i></span>
                                        <span class="pcoded-mtext" data-i18n="nav.basic-components.main">Report</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo (isset($views) && $views == 'make_report') ? 'active' : ''; ?>">
                                            <a href="make_report.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;">Generate Report</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>





                                <li class="pcoded-hasmenu">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Catagories</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class=" ">
                                            <a href="add_cata.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                            <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;">Add Category</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" ">
                                            <a href="manage_cata.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                            <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs" style="font-weight: 400;">Manage Category</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
   

                                    </ul>
                                </li>


                                <li class="pcoded-hasmenu">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Product</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class=" ">
                                            <a href="add_product.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;" >Add Product</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" ">
                                            <a href="manage_product.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs" style="font-weight: 400;" >Manage Product</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
   

                                    </ul>
                                </li>

                                <li class="pcoded-hasmenu">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Order</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>

                                    <ul class="pcoded-submenu">
                                        <li class="">
                                            <a href="add_order.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;">Add Order</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                      
   

                                    </ul>


                                    <ul class="pcoded-submenu">
                                        <li class="">
                                            <a href="manage_order.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;">Manage Order</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                      
   

                                    </ul>
                                </li>


                                <li class="pcoded-hasmenu">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Coupon</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class=" ">
                                            <a href="add_coupon.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;" >Add Coupon</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" ">
                                            <a href="manage_coupon.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs" style="font-weight: 400;" >Manage Coupon</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
   

                                    </ul>
                                </li>

                                <li class="<?php echo (isset($views) && $views == 'manage_customers') ? 'active' : ''; ?>">
                                    <a href="manage_customers.php">
                                        <span class="pcoded-micon"><i class="ti-id-badge" style="color: #06b6d4;"></i><b>C</b></span>
                                        <span class="pcoded-mtext">Customers</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                </li>

                                <?php 
                                    if($_SESSION['role']==1){
                                ?>

                                <li class="pcoded-hasmenu <?php echo (isset($views) && in_array($views, ['manage-user', 'add-admin-user', 'add-user', 'edit_admin'])) ? 'active pcoded-trigger' : ''; ?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-user"></i></span>
                                        <span class="pcoded-mtext" data-i18n="nav.basic-components.main">Admin &amp; Staff</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>

                                    <ul class="pcoded-submenu">
                                        <li class="<?php echo (isset($views) && $views == 'manage_customers') ? 'active' : ''; ?>">
                                            <a href="manage_customers.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" style="font-weight: 400;">Store Customers</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo (isset($views) && $views == 'manage-user') ? 'active' : ''; ?>">
                                            <a href="manage_user.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" style="font-weight: 400;">Manage Staff</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo (isset($views) && in_array($views, ['add-admin-user', 'add-user'])) ? 'active' : ''; ?>">
                                            <a href="add_admin_user.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" style="font-weight: 400;">Add Admin User</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>

                                <?php }?>

                                <li class="pcoded-hasmenu">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">FeedBack</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class=" ">
                                            <a href="customer_feedback.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;" >Customer Feedback</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                     

                                    </ul>
                                </li>



                                 
                                
                                
                                <li class="pcoded-hasmenu <?php echo (isset($views) && in_array($views, ['add_links', 'add_logo', 'mail_settings'])) ? 'active pcoded-trigger' : ''; ?>">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-settings"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Customization</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                        <li class=" ">
                                            <a href="add_links.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;">Social Media</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class=" ">
                                            <a href="add_logo.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.breadcrumbs" style="font-weight: 400;">Add Logo</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                        <li class="<?php echo (isset($views) && $views == 'mail_settings') ? 'active' : ''; ?>">
                                            <a href="mail_settings.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" style="font-weight: 400;">Email (care@postic.in)</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
   

                                    </ul>
                                </li>



                                <li class="pcoded-hasmenu">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Slider</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>

                                    
                                    <ul class="pcoded-submenu">
                                        <li class=" ">
                                            <a href="manage_slider.php">
                                                <span class="pcoded-micon"><i class="ti-angle-right"></i></span>
                                                <span class="pcoded-mtext" data-i18n="nav.basic-components.alert" style="font-weight: 400;">Manag Slider</span>
                                                <span class="pcoded-mcaret"></span>
                                            </a>
                                        </li>
                                   

                                    </ul>
                                </li>


                                <li class="pcoded-hasmenu">
                                <a href="../index.php" target="_blank">
                                   
                                        <span class="pcoded-micon"><i class="ti-layout-grid2-alt"></i></span>
                                        <span class="pcoded-mtext"  data-i18n="nav.basic-components.main">Visit Site</span>
                                        <span class="pcoded-mcaret"></span>
                                    </a>
                                   
                                </li>



                               
                            </ul>
                           
                           

                       
                         

                            
                           
                        </div>
                    </nav>
