<?php 
require_once dirname(__DIR__, 2) . '/config/database.php';
$connection = get_db_connection();

 
 if(isset($_POST['action'])){
    if($_POST['action']=='load_allorder'){
        $date = $_POST['did'];


        $dayquery = "SELECT * FROM `all_order_info` WHERE `order_date` BETWEEN '$date' and CURDATE();";

       
       $row = mysqli_query($connection, $dayquery);
       $result = mysqli_num_rows($row);
       echo $result;

    }
}

if(isset($_POST['action'])){
    if($_POST['action']=='load_allsell'){
        $date = $_POST['did'];


    $sumQuery = "SELECT SUM(`amount`) AS `sum` FROM `all_order_info` WHERE `order_date` BETWEEN '$date' and CURDATE();";

       
       $sum_row = mysqli_query($connection, $sumQuery);
       $asos = mysqli_fetch_assoc($sum_row);
       echo $asos['sum'] ? $asos['sum'] : 0;

    }
}

if(isset($_POST['action'])){
    if($_POST['action']=='load_allcustomer'){
        $date = mysqli_real_escape_string($connection, $_POST['did']);

        $cus_query = "SELECT COUNT(*) as cnt FROM `users` WHERE DATE(`created_at`) BETWEEN '$date' AND CURDATE();";
        $cus_row = mysqli_query($connection, $cus_query);
        if ($cus_row && $row = mysqli_fetch_assoc($cus_row)) {
            echo (int)$row['cnt'];
        } else {
            $fallback = mysqli_query($connection, "SELECT COUNT(*) as cnt FROM `users`");
            $r = $fallback ? mysqli_fetch_assoc($fallback) : null;
            echo $r ? (int)$r['cnt'] : 0;
        }
    }
}


if(isset($_POST['action'])){
    if($_POST['action']=='load_delivered_order'){
        $date = $_POST['did'];


        $deli_query = "SELECT * FROM `all_order_info` WHERE (`order_date` BETWEEN '$date' and CURDATE()) AND `order_status`=2";

       
       $deli_row = mysqli_query($connection, $deli_query);
       $deli_result = mysqli_num_rows($deli_row);
       echo $deli_result;

    }
}

if(isset($_POST['action'])){
    if($_POST['action']=='load_processing_order'){
        $date = $_POST['did'];


        $pros_query = "SELECT * FROM `all_order_info` WHERE (`order_date` BETWEEN '$date' and CURDATE()) AND `order_status`=1";

       
       $pros_row = mysqli_query($connection, $pros_query);
       $pros_result = mysqli_num_rows($pros_row);
       echo $pros_result;

    }
}

if(isset($_POST['action'])){
    if($_POST['action']=='load_pending_order'){
        $date = $_POST['did'];


        $pen_query = "SELECT * FROM `all_order_info` WHERE (`order_date` BETWEEN '$date' and CURDATE()) AND `order_status`=0";

       
       $pen_row = mysqli_query($connection, $pen_query);
       $pen_result = mysqli_num_rows($pen_row);
       echo $pen_result;

    }
}
?>
