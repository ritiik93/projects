<?php 
    include("class/adminback.php");
    $obj= new adminback();

    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (empty($_SESSION['admin_id'])) {
        header("location:index.php");
        exit();
    }

    $admin_id = $_SESSION['admin_id'];
    $admin_email = isset($_SESSION['admin_email']) ? $_SESSION['admin_email'] : '';

    if(isset($_GET['adminLogout'])){
        if($_GET['adminLogout']=="logout"){
            $obj->admin_logout();
        }
    }

    if (!function_exists('admin_set_flash')) {
        function admin_set_flash($message, $type = 'success')
        {
            $_SESSION['admin_flash'] = array(
                'message' => $message,
                'type' => $type,
            );
        }
    }

    if (!function_exists('admin_pull_flash')) {
        function admin_pull_flash()
        {
            if (!isset($_SESSION['admin_flash'])) {
                return null;
            }

            $flash = $_SESSION['admin_flash'];
            unset($_SESSION['admin_flash']);

            return $flash;
        }
    }

    if (!function_exists('admin_redirect_with_flash')) {
        function admin_redirect_with_flash($url, $message, $type = 'success')
        {
            admin_set_flash($message, $type);
            $safe_url = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
            echo "<script>window.location.href = " . json_encode($url) . ";</script>";
            echo '<noscript><meta http-equiv="refresh" content="0;url=' . $safe_url . '"></noscript>';
            exit();
        }
    }

    $admin_flash = admin_pull_flash();
?>

<?php 
    include ("includes/head.php")
?>

  <body>
  <body>
	  <div class="fixed-button">
		
	  </div>
       <!-- Pre-loader start -->
    <div class="theme-loader">
        <div class="loader-track">
            <div class="loader-bar"></div>
        </div>
    </div>
    <!-- Pre-loader end -->
    <div id="pcoded" class="pcoded">
        <div class="pcoded-overlay-box"></div>
        <div class="pcoded-container navbar-wrapper">

         <?php include_once ("includes/headernav.php") ?>


            <div class="pcoded-main-container">
                <div class="pcoded-wrapper">
                   
                <?php include_once ("includes/sidenav.php") ?>


                    <div class="pcoded-content">
                        <div class="pcoded-inner-content">
                            <div class="main-body">
                                <div class="page-wrapper">

                                    <div class="page-body">
                                        <style>
                                            .admin-toast {
                                                position: fixed;
                                                top: 20px;
                                                right: 20px;
                                                min-width: 280px;
                                                max-width: 420px;
                                                padding: 14px 16px;
                                                border-radius: 10px;
                                                color: #fff;
                                                box-shadow: 0 12px 32px rgba(0, 0, 0, 0.18);
                                                z-index: 9999;
                                                opacity: 0;
                                                transform: translateY(-10px);
                                                transition: all 0.25s ease;
                                            }

                                            .admin-toast.show {
                                                opacity: 1;
                                                transform: translateY(0);
                                            }

                                            .admin-toast-success {
                                                background: linear-gradient(135deg, #0f9d58, #1bbf72);
                                            }

                                            .admin-toast-error {
                                                background: linear-gradient(135deg, #d93025, #ef5350);
                                            }

                                            .admin-toast-info {
                                                background: linear-gradient(135deg, #1a73e8, #42a5f5);
                                            }

                                            .admin-toast-title {
                                                font-size: 14px;
                                                font-weight: 700;
                                                margin-bottom: 4px;
                                            }

                                            .admin-toast-message {
                                                margin: 0;
                                                font-size: 13px;
                                                line-height: 1.5;
                                            }

                                            .dashboard-card-link {
                                                display: block;
                                                text-decoration: none;
                                                color: inherit;
                                            }

                                            .dashboard-card-link:hover {
                                                text-decoration: none;
                                                color: inherit;
                                            }

                                            .page-body .table {
                                                background: #fff;
                                                border-radius: 14px;
                                                overflow: hidden;
                                                box-shadow: 0 10px 28px rgba(15, 23, 42, 0.06);
                                            }

                                            .page-body .table thead th {
                                                background: #f8fbff;
                                                border-top: 0;
                                                color: #31435f;
                                                font-weight: 700;
                                                vertical-align: middle;
                                            }

                                            .page-body .table td {
                                                vertical-align: middle;
                                            }

                                            .page-body .table td .btn,
                                            .page-body .table td a.btn,
                                            .page-body .btn {
                                                margin-right: 6px;
                                                margin-bottom: 6px;
                                                border-radius: 8px;
                                                font-weight: 600;
                                            }

                                            .page-body .table img {
                                                border-radius: 10px;
                                            }

                                            .admin-form-card {
                                                background: #fff;
                                                border: 1px solid #e6edf5;
                                                border-radius: 14px;
                                                padding: 22px;
                                                box-shadow: 0 10px 28px rgba(15, 23, 42, 0.06);
                                            }

                                            .admin-form-card .form-group:last-child {
                                                margin-bottom: 0;
                                            }

                                            .admin-form-card .form-control {
                                                min-height: 44px;
                                                border-radius: 10px;
                                                border-color: #d9e2ec;
                                            }

                                            .admin-form-card textarea.form-control {
                                                min-height: 140px;
                                            }

                                            .admin-form-card label,
                                            .admin-form-card h4,
                                            .admin-form-card h5 {
                                                font-weight: 600;
                                                color: #2f4058;
                                                margin-bottom: 8px;
                                            }

                                            .admin-preview-strip img {
                                                border: 1px solid #e6edf5;
                                                background: #fff;
                                                padding: 4px;
                                                border-radius: 10px;
                                                margin-right: 8px;
                                                margin-bottom: 8px;
                                            }
                                        </style>

                                        <?php if ($admin_flash) { ?>
                                            <div id="adminToast"
                                                class="admin-toast admin-toast-<?php echo htmlspecialchars($admin_flash['type'], ENT_QUOTES, 'UTF-8'); ?> show">
                                                <div class="admin-toast-title">Update Complete</div>
                                                <p class="admin-toast-message"><?php echo htmlspecialchars($admin_flash['message'], ENT_QUOTES, 'UTF-8'); ?></p>
                                            </div>
                                        <?php } ?>
                                     
        
                                <?php 
                                    if($views){
                                        if($views=="dashboard"){
                                            include ('views/dashborad_view.php');
                                        }elseif($views=="add-cata"){
                                            include ("views/add_cata_view.php");
                                        }elseif($views=="manage-cata"){
                                            include ("views/manage_cata_view.php");
                                        }elseif($views=="add-product"){
                                            include ("views/add_product_view.php");
                                        }elseif($views=="manage-product"){
                                            include ("views/manage_product_view.php");
                                        }elseif($views=="add-user"){
                                            include ("views/add_user_view.php");
                                        }elseif($views=="manage-user"){
                                            include ("views/manage_user_view.php");
                                        }elseif($views=="edit_cata"){
                                            include ("views/edit_cata_view.php");
                                        }elseif($views=="edit_product"){
                                            include ("views/edit_product_view.php");
                                        }elseif($views=="manage_order"){
                                            include ("views/manage_order_view.php");
                                        }elseif($views=="add_link"){
                                            include ("views/add_links_view.php");
                                        }elseif($views=="edit_logo"){
                                            include ("views/edit_logo_view.php");
                                        }elseif($views=="add_logo"){
                                            include ("views/add_logo_view.php");
                                        }elseif($views=="edit_links"){
                                            include ("views/edit_links_view.php");
                                        }elseif($views=="manage_slider"){
                                            include ("views/manage_slider_view.php");
                                        }elseif($views=="edit_slider"){
                                            include ("views/edit_slider_view.php");
                                        }elseif($views=="add_order"){
                                            include ("views/add_order_view.php");
                                        }elseif($views=="add_coupon"){
                                            include ("views/add_coupon_view.php");
                                        }elseif($views=="manage_coupon"){
                                            include ("views/manage_coupon_view.php");
                                        }elseif($views=="edit_coupon"){
                                            include ("views/edit_coupon_view.php");
                                        }elseif($views=="customer_feedback"){
                                            include ("views/customer_feedback_view.php");
                                        }elseif($views=="edit_comment"){
                                            include ("views/edit_comment_view.php");
                                        }elseif($views=="add-admin-user"){
                                            include ("views/add_admin_user_view.php");
                                        }elseif($views=="edit_admin"){
                                            include ("views/edit_admin_view.php");
                                        }elseif($views=="make_report"){
                                            include ("views/make_report_view.php");
                                        }elseif($views=="traffic_analytics"){
                                            include ("views/traffic_analytics_view.php");
                                        }elseif($views=="mail_settings"){
                                            include ("views/mail_settings_view.php");
                                        }elseif($views=="manage_customers"){
                                            include ("views/manage_customers_view.php");
                                        }

                                    }
                                ?>


                                    <div id="styleSelector">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Warning Section Starts -->
        <!-- Older IE warning message -->
    <!--[if lt IE 9]>
<div class="ie-warning">
    <h1>Warning!!</h1>
    <p>You are using an outdated version of Internet Explorer, please upgrade <br/>to any of the following web browsers to access this website.</p>
    <div class="iew-container">
        <ul class="iew-download">
            <li>
                <a href="http://www.google.com/chrome/">
                    <img src="assets/images/browser/chrome.png" alt="Chrome">
                    <div>Chrome</div>
                </a>
            </li>
            <li>
                <a href="https://www.mozilla.org/en-US/firefox/new/">
                    <img src="assets/images/browser/firefox.png" alt="Firefox">
                    <div>Firefox</div>
                </a>
            </li>
            <li>
                <a href="http://www.opera.com">
                    <img src="assets/images/browser/opera.png" alt="Opera">
                    <div>Opera</div>
                </a>
            </li>
            <li>
                <a href="https://www.apple.com/safari/">
                    <img src="assets/images/browser/safari.png" alt="Safari">
                    <div>Safari</div>
                </a>
            </li>
            <li>
                <a href="http://windows.microsoft.com/en-us/internet-explorer/download-ie">
                    <img src="assets/images/browser/ie.png" alt="">
                    <div>IE (9 & above)</div>
                </a>
            </li>
        </ul>
    </div>
    <p>Sorry for the inconvenience!</p>
</div>
<![endif]-->
<!-- Warning Section Ends -->
<!-- Required Jquery -->

<?php 
    include ("includes/script.php")
?>
