<?php
/**
 * Dedicated Traffic Simulator Operator Backend API Endpoint
 * Protected strictly for authenticated operators only.
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

require_once dirname(__DIR__) . '/includes/operator_auth.php';
require_once dirname(__DIR__) . '/includes/traffic_simulator_service.php';

// Verify operator authorization
if (!operator_is_authenticated()) {
    http_response_code(401);
    echo json_encode(array(
        'success' => false,
        'error' => 'Unauthorized: Operator authentication required.'
    ));
    exit();
}

$simulator = PosticTrafficSimulator::get_instance();
$action = $_GET['action'] ?? $_POST['action'] ?? 'get_state';

switch ($action) {
    case 'get_state':
        $state = $simulator->get_state();
        $bounds = $simulator->get_range_bounds($state);
        echo json_encode(array(
            'success' => true,
            'state' => $state,
            'bounds' => $bounds,
            'operator_email' => $_SESSION['traffic_operator_email'] ?? 'Operator'
        ));
        break;

    case 'toggle':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(array('success' => false, 'error' => 'Method not allowed. POST required.'));
            exit();
        }

        // Verify CSRF token
        $token = $_POST['csrf_token'] ?? '';
        if (!operator_verify_csrf_token($token)) {
            http_response_code(403);
            echo json_encode(array('success' => false, 'error' => 'Invalid CSRF token.'));
            exit();
        }

        $current_state = $simulator->get_state();
        $new_status = isset($_POST['enabled']) ? (bool) $_POST['enabled'] : !$current_state['enabled'];
        $updated_state = $simulator->set_enabled($new_status);
        $bounds = $simulator->get_range_bounds($updated_state);

        echo json_encode(array(
            'success' => true,
            'message' => $new_status ? 'Traffic Simulator ACTIVATED successfully.' : 'Traffic Simulator DEACTIVATED.',
            'state' => $updated_state,
            'bounds' => $bounds
        ));
        break;

    case 'set_range':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(array('success' => false, 'error' => 'Method not allowed. POST required.'));
            exit();
        }

        $token = $_POST['csrf_token'] ?? '';
        if (!operator_verify_csrf_token($token)) {
            http_response_code(403);
            echo json_encode(array('success' => false, 'error' => 'Invalid CSRF token.'));
            exit();
        }

        $range_type = trim($_POST['range_type'] ?? '0-200');
        $custom_min = isset($_POST['custom_min']) ? $_POST['custom_min'] : null;
        $custom_max = isset($_POST['custom_max']) ? $_POST['custom_max'] : null;

        $result = $simulator->set_range($range_type, $custom_min, $custom_max);
        if (!$result['success']) {
            http_response_code(400);
            echo json_encode($result);
            exit();
        }

        $bounds = $simulator->get_range_bounds($result['state']);
        echo json_encode(array(
            'success' => true,
            'message' => "Range updated to {$bounds['label']}.",
            'state' => $result['state'],
            'bounds' => $bounds
        ));
        break;

    case 'tick':
        // Simulation heartbeat tick
        $updated_state = $simulator->simulate_tick();
        $bounds = $simulator->get_range_bounds($updated_state);

        echo json_encode(array(
            'success' => true,
            'state' => $updated_state,
            'bounds' => $bounds
        ));
        break;

    case 'reset_today':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405);
            echo json_encode(array('success' => false, 'error' => 'Method not allowed. POST required.'));
            exit();
        }

        $token = $_POST['csrf_token'] ?? '';
        if (!operator_verify_csrf_token($token)) {
            http_response_code(403);
            echo json_encode(array('success' => false, 'error' => 'Invalid CSRF token.'));
            exit();
        }

        $updated_state = $simulator->reset_today_stats();
        echo json_encode(array(
            'success' => true,
            'message' => "Today's simulated traffic counters reset to zero.",
            'state' => $updated_state
        ));
        break;

    default:
        http_response_code(400);
        echo json_encode(array('success' => false, 'error' => 'Unknown action.'));
        break;
}
