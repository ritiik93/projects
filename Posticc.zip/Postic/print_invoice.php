<?php
session_start();
include_once("admin/class/adminback.php");
$obj = new adminback();

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
if ($order_id <= 0) {
    header("location:index.php");
    exit();
}

$is_admin = isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
$user_id = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : 0;

if (!$is_admin && $user_id <= 0) {
    header("location:user_login.php");
    exit();
}

$order = $obj->get_order_by_order_id($order_id);

if (!$order) {
    echo "<div style='text-align:center; padding:50px; font-family:sans-serif;'><h2>Order not found</h2><a href='index.php'>Return to Home</a></div>";
    exit();
}

// Ensure normal customer can only see their own order
if (!$is_admin && (int)$order['user_id'] !== $user_id) {
    echo "<div style='text-align:center; padding:50px; font-family:sans-serif;'><h2>Access Denied</h2><p>You cannot view this invoice.</p><a href='exist_order.php'>My Orders</a></div>";
    exit();
}

$customer_name = trim($order['user_firstname'] . ' ' . $order['user_lastname']);
if (empty($customer_name)) {
    $customer_name = 'Valued Customer';
}

$order_status_label = 'Pending';
$order_status_class = 'status-pending';
if ($order['order_status'] == 1) {
    $order_status_label = 'Processing (Roasted & Packed)';
    $order_status_class = 'status-processing';
} elseif ($order['order_status'] == 2) {
    $order_status_label = 'Shipped (In Transit)';
    $order_status_class = 'status-shipped';
} elseif ($order['order_status'] == 3) {
    $order_status_label = 'Delivered';
    $order_status_class = 'status-delivered';
} elseif ($order['order_status'] == 4) {
    $order_status_label = 'Cancelled';
    $order_status_class = 'status-cancelled';
}

$payment_status = isset($order['payment_status']) ? ucfirst($order['payment_status']) : 'Pending';
$payment_method = isset($order['payment_method']) ? strtoupper($order['payment_method']) : 'MANUAL';

$qty = (int)$order['pdt_quantity'] > 0 ? (int)$order['pdt_quantity'] : 1;
$total_amount = (float)$order['amount'];
$unit_price = round($total_amount / $qty, 2);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #INV-POSTIC-<?php echo str_pad($order_id, 5, '0', STR_PAD_LEFT); ?> | Postic Foods</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png"/>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: #f1f5f9;
            color: #1e293b;
            padding: 30px 15px;
            font-size: 14px;
            line-height: 1.5;
        }
        .invoice-wrapper {
            max-width: 820px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            border: 1px solid #e2e8f0;
        }
        .invoice-actions {
            max-width: 820px;
            margin: 0 auto 20px auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .btn-action {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 8px;
            text-decoration: none;
            cursor: pointer;
            border: none;
            transition: all 0.2s ease;
        }
        .btn-back {
            background-color: #ffffff;
            color: #475569;
            border: 1px solid #cbd5e1;
        }
        .btn-back:hover {
            background-color: #f8fafc;
            color: #0f172a;
        }
        .btn-print {
            background-color: #d32f2f;
            color: #ffffff;
            box-shadow: 0 2px 8px rgba(211, 47, 47, 0.3);
        }
        .btn-print:hover {
            background-color: #b71c1c;
        }
        .invoice-header {
            background: linear-gradient(135deg, #b71c1c 0%, #d32f2f 100%);
            color: #ffffff;
            padding: 36px 40px;
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }
        .brand-section h1 {
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -0.5px;
            color: #ffffff;
            margin-bottom: 4px;
        }
        .brand-section h1 span {
            color: #fecaca;
        }
        .brand-section p {
            color: #ffebee;
            font-size: 13px;
        }
        .invoice-meta {
            text-align: right;
        }
        .invoice-meta .inv-title {
            font-size: 24px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #ffffff;
            margin-bottom: 6px;
        }
        .invoice-meta p {
            font-size: 13px;
            color: #ffebee;
            margin-bottom: 2px;
        }
        .invoice-body {
            padding: 36px 40px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-bottom: 30px;
            padding-bottom: 24px;
            border-bottom: 1px dashed #e2e8f0;
        }
        .info-box h3 {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #64748b;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .info-box p {
            color: #1e293b;
            font-size: 14px;
            margin-bottom: 4px;
        }
        .info-box .name {
            font-weight: 700;
            font-size: 16px;
            color: #0f172a;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .status-pending { background-color: #fee2e2; color: #dc2626; }
        .status-processing { background-color: #fef3c7; color: #d97706; }
        .status-shipped { background-color: #e0f2fe; color: #0284c7; }
        .status-delivered { background-color: #d1fae5; color: #059669; }
        .status-cancelled { background-color: #f1f5f9; color: #64748b; }

        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
        }
        .items-table th {
            background-color: #f8fafc;
            color: #475569;
            font-weight: 700;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 12px 16px;
            border-top: 1px solid #e2e8f0;
            border-bottom: 1px solid #e2e8f0;
            text-align: left;
        }
        .items-table td {
            padding: 16px;
            border-bottom: 1px solid #f1f5f9;
            color: #334155;
        }
        .items-table .text-right { text-align: right; }
        .items-table .text-center { text-align: center; }
        .items-table .pdt-name {
            font-weight: 600;
            color: #0f172a;
            font-size: 15px;
        }

        .summary-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 30px;
        }
        .summary-table {
            width: 340px;
            border-collapse: collapse;
        }
        .summary-table td {
            padding: 8px 12px;
            font-size: 14px;
            color: #475569;
        }
        .summary-table td.amount {
            text-align: right;
            font-weight: 600;
            color: #1e293b;
        }
        .summary-table tr.total td {
            border-top: 2px solid #d32f2f;
            padding-top: 12px;
            font-size: 18px;
            font-weight: 800;
            color: #d32f2f;
        }

        .invoice-footer {
            background-color: #f8fafc;
            border-top: 1px solid #e2e8f0;
            padding: 24px 40px;
            color: #64748b;
            font-size: 12px;
            line-height: 1.6;
        }
        .invoice-footer .terms {
            margin-bottom: 8px;
        }

        @media print {
            body {
                background: #ffffff;
                padding: 0;
            }
            .invoice-actions {
                display: none !important;
            }
            .invoice-wrapper {
                box-shadow: none;
                border: none;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>

    <div class="invoice-actions">
        <a href="<?php echo $is_admin ? 'admin/manage_order.php' : 'exist_order.php'; ?>" class="btn-action btn-back">
            &larr; Back to Orders
        </a>
        <button onclick="window.print()" class="btn-action btn-print">
            <svg width="18" height="18" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4H7v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
            Print Invoice
        </button>
    </div>

    <div class="invoice-wrapper">
        <div class="invoice-header">
            <div class="brand-section">
                <h1>POSTIC<span>.</span></h1>
                <p>Postic Healthy Foods &amp; Roasted Makhana</p>
                <p style="margin-top: 4px; font-size: 12px; color: #a7f3d0;">Udaipur, Rajasthan - 313001, India</p>
                <p style="font-size: 12px; color: #a7f3d0;">Phone: +91 9216398316 | Email: care@postic.in</p>
            </div>
            <div class="invoice-meta">
                <div class="inv-title">TAX INVOICE</div>
                <p><strong>Invoice No:</strong> #INV-POSTIC-<?php echo str_pad($order_id, 5, '0', STR_PAD_LEFT); ?></p>
                <p><strong>Order ID:</strong> #<?php echo $order_id; ?></p>
                <p><strong>Order Date:</strong> <?php echo htmlspecialchars($order['order_date'] ?? date('Y-m-d')); ?></p>
                <p><strong>Order Time:</strong> <?php echo htmlspecialchars($order['order_time'] ?? date('H:i:s')); ?></p>
            </div>
        </div>

        <div class="invoice-body">
            <div class="info-grid">
                <div class="info-box">
                    <h3>Billed To (Customer)</h3>
                    <p class="name"><?php echo htmlspecialchars($customer_name); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($order['user_email'] ?? 'N/A'); ?></p>
                    <p><strong>Mobile:</strong> <?php echo htmlspecialchars($order['user_mobile'] ?? 'N/A'); ?></p>
                    <p><strong>Registered Address:</strong> <?php echo htmlspecialchars($order['user_address'] ?? 'N/A'); ?></p>
                </div>
                <div class="info-box">
                    <h3>Shipping &amp; Payment Details</h3>
                    <p><strong>Delivery Address:</strong><br><?php echo nl2br(htmlspecialchars($order['shiping'] ?? $order['shiping_address'] ?? 'N/A')); ?></p>
                    <p style="margin-top: 6px;"><strong>Delivery Phone:</strong> <?php echo htmlspecialchars($order['Shipping_mobile'] ?? 'N/A'); ?></p>
                    <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($payment_method); ?></p>
                    <p><strong>Transaction / Ref ID:</strong> <?php echo htmlspecialchars($order['trans_id'] ?? 'N/A'); ?></p>
                    <p style="margin-top: 8px;">
                        <strong>Order Status:</strong>
                        <span class="status-badge <?php echo $order_status_class; ?>">
                            <?php echo $order_status_label; ?>
                        </span>
                    </p>
                </div>
            </div>

            <table class="items-table">
                <thead>
                    <tr>
                        <th style="width: 50px;" class="text-center">#</th>
                        <th>Item Description</th>
                        <th class="text-center" style="width: 100px;">Quantity</th>
                        <th class="text-right" style="width: 120px;">Unit Price</th>
                        <th class="text-right" style="width: 130px;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="text-center">1</td>
                        <td>
                            <div class="pdt-name"><?php echo htmlspecialchars(trim($order['product_name'])); ?></div>
                            <?php if (!empty($order['pdt_weight'])) { ?>
                                <div style="margin-top: 3px;"><span style="background: #fef2f2; color: #d32f2f; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 4px; border: 1px solid #fecaca; display: inline-block;">Pack Size: <?php echo htmlspecialchars($order['pdt_weight']); ?></span></div>
                            <?php } ?>
                            <small style="color: #64748b;">Postic 100% Roasted Natural Fox Nuts / Makhana</small>
                        </td>
                        <td class="text-center"><strong><?php echo $qty; ?></strong></td>
                        <td class="text-right">₹ <?php echo number_format($unit_price, 2); ?></td>
                        <td class="text-right"><strong>₹ <?php echo number_format($total_amount, 2); ?></strong></td>
                    </tr>
                </tbody>
            </table>

            <div class="summary-container">
                <table class="summary-table">
                    <tr>
                        <td>Subtotal:</td>
                        <td class="amount">₹ <?php echo number_format($total_amount, 2); ?></td>
                    </tr>
                    <?php if (!empty($order['uses_coupon'])) { ?>
                    <tr>
                        <td>Coupon Applied:</td>
                        <td class="amount" style="color: #d32f2f;"><?php echo htmlspecialchars($order['uses_coupon']); ?></td>
                    </tr>
                    <?php } ?>
                    <tr>
                        <td>Shipping / Handling:</td>
                        <td class="amount" style="color: #d32f2f;">FREE</td>
                    </tr>
                    <tr>
                        <td>Applicable Taxes (GST):</td>
                        <td class="amount">Included</td>
                    </tr>
                    <tr class="total">
                        <td>Grand Total:</td>
                        <td class="amount">₹ <?php echo number_format($total_amount, 2); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="invoice-footer">
            <p class="terms"><strong>Terms &amp; Support:</strong> Thank you for your order with Postic Foods! We guarantee 100% natural, freshly roasted Makhana with no artificial preservatives. For support, returns, or wholesale inquiries, WhatsApp us at <strong>+91 9216398316</strong> or email <strong>care@postic.in</strong>.</p>
            <p style="margin-top: 4px; font-style: italic;">This is a computer-generated tax invoice and requires no physical signature.</p>
        </div>
    </div>

</body>
</html>
